"""Bounded read of the existing capability-status route; no purpose-claim parser.

Owner configuration supplies origin/token. A 200/body is evidence for a future
verified adapter, never admission. No cache, redirect, retry or authority issue.
"""
import asyncio,concurrent.futures,json,math,re
from urllib.parse import urlsplit
import httpx

MAX_BODY=65536

class StatusUnavailable(Exception):
    pass

def strict_object(pairs):
    value={}
    for key,item in pairs:
        if key in value:raise ValueError('duplicate field')
        value[key]=item
    return value

def invalid_constant(_):raise ValueError('nonfinite number')

def strict_float(value):
    result=float(value)
    if not math.isfinite(result):raise ValueError('nonfinite number')
    return result

class StatusHTTP:
    def __init__(self,origin,service_token,*,owner_loop=None):
        parsed=urlsplit(origin)
        if (parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password
                or parsed.query or parsed.fragment or parsed.path not in ('','/')
                or type(service_token) is not str or not service_token
                or any(ord(c)<33 or ord(c)>126 for c in service_token)):
            raise ValueError('exact owner origin and token required')
        self.origin=origin.rstrip('/');self._token=service_token
        self._owner_loop=owner_loop

    async def read(self,capability_id,*,timeout=3):
        if (type(capability_id) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',capability_id)
                or type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0<timeout<=3):
            raise ValueError('bounded exact capability read required')
        try:
            deadline=asyncio.get_running_loop().time()+timeout
            # Absolute deadline covers connection, headers, every body chunk
            # and close, preventing an endless trickle from resetting idle time.
            async with asyncio.timeout(timeout):
                async with httpx.AsyncClient(timeout=timeout,follow_redirects=False,trust_env=False) as client:
                    async with client.stream('GET',self.origin+'/api/services/capabilities/'+capability_id,
                            headers={'Authorization':'Bearer '+self._token,'Accept':'application/json','Accept-Encoding':'identity'}) as response:
                        if response.status_code!=200:
                            return {'http_status':response.status_code,'body':None}
                        if response.headers.get('content-encoding','identity').lower()!='identity':
                            raise ValueError('encoded status refused')
                        size=response.headers.get('content-length')
                        if size is not None and (not size.isdecimal() or int(size)>MAX_BODY):
                            raise ValueError('status size refused')
                        raw=bytearray()
                        async for part in response.aiter_raw():
                            if len(raw)+len(part)>MAX_BODY:raise ValueError('status too large')
                            raw.extend(part)
                        body=json.loads(raw.decode('utf-8'),object_pairs_hook=strict_object,
                            parse_constant=invalid_constant,parse_float=strict_float)
                        if type(body) is not dict:raise ValueError('status object required')
                        if asyncio.get_running_loop().time()>deadline:raise TimeoutError('late status')
                        return {'http_status':200,'body':body}
        except (TimeoutError,httpx.HTTPError,ValueError,UnicodeError,RecursionError):
            # Never expose request headers, owner token or an untrusted body in
            # an exception/log. Caller records outage; no earlier positive used.
            raise StatusUnavailable('capability status unavailable') from None

    def read_sync(self,capability_id,*,timeout=3):
        # Use the caller's existing owned loop; creating a loop per request can
        # wait for DNS-worker shutdown after timeout and violate the deadline.
        loop=self._owner_loop
        if not isinstance(loop,asyncio.AbstractEventLoop) or not loop.is_running():
            raise ValueError('existing running owner loop required; otherwise await read')
        try:current=asyncio.get_running_loop()
        except RuntimeError:current=None
        if current is loop:raise ValueError('await read from the owner loop')
        if type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0<timeout<=3:
            raise ValueError('bounded exact capability read required')
        future=asyncio.run_coroutine_threadsafe(self.read(capability_id,timeout=timeout),loop)
        try:return future.result(timeout=timeout)
        except (TimeoutError,concurrent.futures.CancelledError):
            future.cancel()
            raise StatusUnavailable('capability status unavailable') from None
