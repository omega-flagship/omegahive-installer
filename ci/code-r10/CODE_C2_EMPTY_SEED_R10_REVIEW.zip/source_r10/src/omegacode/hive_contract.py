"""Code read contract over an injected HiveConnect S3 adapter, draft r2.11.

No transport, credentials, MCP server or policy engine lives here. HiveConnect
owns negotiation/RPC and OmegaAtom owns snapshots; the host owns admission.
"""
import copy
import json
import math
import re

from .common import digest

SCHEMA = 's3-r1'
SERVER_VERSION = '0.2.0'
PROTOCOL = '2025-06-18'
# Expected native policy bindings, not decisions or authority to dispatch.
POLICIES = {
    'hive_goal_get': 'hive-goal-get', 'hive_goal_heartbeat': 'hive-goal-heartbeat',
    'hive_goal_cancel_ack': 'hive-goal-cancel-ack', 'hive_exhibit_read': 'hive-shared',
    'hive_artifact_read': 'hive-revision-read', 'hive_revision_read': 'hive-revision-read',
    'hive_request': 'hive-request', 'hive_capabilities': 'hive-capabilities',
    'hive_evidence_publish': 'hive-publish', 'hive_evidence_query': 'hive-query',
}


def expected_policy(tool, *, status=None):
    if tool == 'hive_goal_result':
        if status not in ('done', 'failed', 'waiting'):
            raise ValueError('result policy requires done, failed or waiting status')
        return {'done':'hive-goal-done','failed':'hive-goal-fail','waiting':'hive-goal-wait'}[status]
    return POLICIES[tool]


class CodeHiveReads:
    """An owner adapter is injected explicitly; there is no baseline fallback."""
    def __init__(self, adapter):
        if adapter.expected_server_version != SERVER_VERSION:
            raise ValueError('Code requires the r2.4 server version pin')
        self.adapter = adapter
        self.ready = False

    def initialize(self):
        self.ready = False
        negotiated = self.adapter.initialize()
        if negotiated.get('schema') != SCHEMA:
            raise ValueError('Code requires the s3-r1 schema marker')
        # Advertised labels do not authenticate a server; member admission is
        # separately required. The owner client checks the pinned member ID.
        self.adapter.call('hive_whoami', {})
        self.ready = True
        return negotiated

    def read_merge_export(self, artifact_id, revision, expected_digest, code_artifact):
        if not self.ready:
            raise ValueError('Code S3 reads not initialized')
        data = self.adapter.call('hive_artifact_read', {
            'artifact_id': artifact_id, 'revision': revision,
            'expected_digest': expected_digest})
        body = data.get('body')
        if not isinstance(body, str) or len(body.encode()) > 256 * 1024:
            raise ValueError('bounded artifact body required')
        if 'sha256:' + digest(body.encode()) != expected_digest:
            raise ValueError('export body digest mismatch')
        def pairs(items):
            result = {}
            for key, value in items:
                if key in result:
                    raise ValueError('duplicate export JSON key')
                result[key] = value
            return result
        def constant(_):
            raise ValueError('non-finite export JSON')
        value = json.loads(body, object_pairs_hook=pairs, parse_constant=constant)
        if (not isinstance(value, dict) or value.get('schema') != 'omegacode-merge-review-export-v1'
                or value.get('artifact') != code_artifact
                or value.get('execution_authority') != 'none'
                or value.get('quality_approval') != 'not_assessed'):
            raise ValueError('Code export binding or advisory scope mismatch')
        return copy.deepcopy(value)


class CodeEvidenceCursor:
    """Local traversal guard, not a wire schema or proof of host grant checks.

    Binding is caller-custodied context (resource/revision/digest/grant). Its
    structure stays opaque here. Call prepare before each owner-adapter read;
    supply page and snapshots separately until the built response schema exists.
    No cursor decoding, automatic retry, grant extension or persisted authority.
    """
    def __init__(self, adapter, binding, *, started_at, grant_expires_at):
        if (not isinstance(binding, dict) or set(binding) != {'resource', 'revision', 'digest', 'grant'}
                or not all(isinstance(binding[k], str) and binding[k] for k in ('resource', 'digest', 'grant'))
                or type(binding['revision']) is not int or binding['revision'] < 0
                or not re.fullmatch(r'sha256:[a-f0-9]{64}', binding['digest'])):
            raise ValueError('exact read binding required')
        for value in (started_at, grant_expires_at):
            if type(value) not in (float, int) or not math.isfinite(value):
                raise ValueError('finite local deadline required')
        if grant_expires_at <= started_at:
            raise ValueError('read grant already expired')
        self.adapter = adapter
        self._binding = copy.deepcopy(binding)
        self.deadline = min(started_at + 600, grant_expires_at)
        self.cursor = None
        self.finished = False
        self.seen = set()
        self.pages = 0

    def prepare(self, binding, *, now):
        if binding != self._binding:
            raise ValueError('cursor read binding changed')
        if type(now) not in (float, int) or not math.isfinite(now) or now >= self.deadline:
            raise ValueError('cursor or grant deadline passed')
        if self.finished or self.pages >= 128:
            raise ValueError('cursor traversal closed')
        return self.cursor

    def accept(self, page, snapshots, binding, *, now):
        self.prepare(binding, now=now)
        if not isinstance(page, dict) or 'next_cursor' not in page:
            raise ValueError('explicit page end marker required')
        # The owner client validates supplied closure shape, <=200 records and
        # end flags. It cannot detect controls omitted by the host: r2.6 requires
        # host projection with Atom.project_pages, including withdrawal controls.
        result = self.adapter.validate_query_page(page, snapshots)
        cursor = page['next_cursor']
        if cursor is not None and cursor in self.seen:
            raise ValueError('repeated cursor refused')
        if cursor is not None:
            self.seen.add(cursor)
        self.cursor = cursor
        self.finished = page['end']
        self.pages += 1
        return result
