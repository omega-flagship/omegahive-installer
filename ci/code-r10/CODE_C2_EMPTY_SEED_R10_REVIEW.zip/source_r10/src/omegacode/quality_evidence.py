"""Workspace-scoped MeTTa evidence drafts; publication and reasoning authority stay in Hive."""
import json


def quoted(value):
    return json.dumps(str(value), ensure_ascii=False)


def merge_facts(artifact, change_digest, verifications):
    """One stable evidence stamp per observed record, not per retry or query.

    Receipt passed/failed is a command-verification observation, never a merge quality
    verdict. Unknown receipts get no fabricated truth value. No private paths, source,
    command text or inferred confidence appears in these metadata-only drafts.
    """
    tree = quoted(artifact['tree_digest'])
    source_stamp = quoted('omegacode:change:' + artifact['changeset_id'] + ':' + change_digest)
    atoms = [f"(CodeMergedSource {source_stamp} {quoted(artifact['workspace_id'])} {artifact['generation']} {tree})",
             f'(CodeMergeQuality {source_stamp} {tree} "not-assessed")']
    for vr in verifications:
        stamp = quoted('omegacode:verification:' + vr['id'] + ':' + vr['record_digest'])
        receipt = quoted(vr['id'])
        atoms.append(f"(CodeVerificationState {stamp} {tree} {receipt} {quoted(vr['status'])})")
        if vr['status'] in ('passed', 'failed'):
            frequency = '1.0' if vr['status'] == 'passed' else '0.0'
            atoms.append(f'(CodeVerificationPassed {stamp} {tree} {receipt} (TruthValue {frequency} 0.5))')
    return {'format': 'omegacode-merge-evidence-metta-v1', 'atoms': atoms,
            'scope': 'workspace-only draft; no commons publication',
            'stamp_rule': 'immutable record ID and digest; repeat reads are not new evidence',
            'confidence_rule': 'single observation weight 0.5; host reasoning policy owns revision and inference',
            'advisory_only': True, 'publisher_authenticated': False,
            'publication': 'requires separately authorized host evidence capability'}
