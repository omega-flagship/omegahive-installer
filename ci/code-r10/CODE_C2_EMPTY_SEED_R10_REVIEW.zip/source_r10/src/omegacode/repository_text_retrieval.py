"""Bounded lexical UTF-8 project context; no parser, semantic facts or provider.

Reuses the existing source census, chunk identity and lexical ranker. Caller must
supply already-authorized/context-selected bytes. No persistent index or custody.
"""
from pathlib import PurePosixPath
from collections.abc import Mapping
import hashlib
from .repository_facts import RepositoryFacts
from .repository_retrieval import RetrievalIndex, Chunk, _digest

class TextIndex(RetrievalIndex):
    def search(self,query,*,limit=20,path_prefix=None):
        result=super().search(query,limit=limit,path_prefix=path_prefix)
        result.update(symbolic_filter='none: lexical text only',semantic_quality_qualified=False,
                      syntax_facts_emitted=False,diagnostics=[{'path':p,'reason':reason} for p,reason in self.graph.diagnostics])
        return result

def build_text_index(sources):
    if not isinstance(sources,Mapping) or len(sources)>512:raise ValueError('bounded source map required')
    frozen={};total=0
    for path,raw in sources.items():
        if type(path) is not str or type(raw) is not bytes:raise ValueError('exact named bytes required')
        p=PurePosixPath(path)
        if not path or p.is_absolute() or str(p)!=path or any(x in ('','.','..','.git') for x in path.split('/')) or '\\' in path or '\0' in path or len(path.encode())>4096:raise ValueError('relative source path required')
        total+=len(raw)
        if len(raw)>1024*1024 or total>8*1024*1024:raise ValueError('source byte limit')
        frozen[path]=raw
    census=[];chunks=[];diagnostics=[]
    for path,raw in sorted(frozen.items()):
        digest=hashlib.sha256(raw).hexdigest();census.append((path,digest))
        try:text=raw.decode('utf-8')
        except UnicodeError:
            diagnostics.append((path,'non-UTF-8 source omitted'));continue
        if '\0' in text:
            diagnostics.append((path,'NUL-containing source omitted'));continue
        lines=text.splitlines(keepends=True)
        for offset in range(0,len(lines),40):
            text=''.join(lines[offset:offset+40]);end=min(offset+40,len(lines))
            if len(text.encode())>64*1024:raise ValueError('source chunk exceeds64KiB')
            chunks.append(Chunk(_digest([path,digest,offset+1,end,text]),path,digest,offset+1,end,text))
            if len(chunks)>4096:raise ValueError('chunk census exceeds4096')
    graph=RepositoryFacts(tuple(census),(),(),tuple(diagnostics),'utf8-text-only/no-syntax-facts')
    return TextIndex(graph,tuple(chunks),'utf8-source-retrieval-v1')
