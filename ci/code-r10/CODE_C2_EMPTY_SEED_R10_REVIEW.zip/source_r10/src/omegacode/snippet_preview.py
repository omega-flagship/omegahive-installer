"""Retained inert snippet template. Client grammar/variables/transform admission stays explicit."""
import copy
from .common import CodeError
from .completion import preview

PROFILE='editor-snippet-template-v1'
def template_preview(item,text,position,language_id,path,source_digest,selection_mode=None):
    if (type(item) is not dict or type(item.get('insertTextFormat')) is not int or item['insertTextFormat']!=2
            or 'command' in item or 'insertTextMode' in item or item.get('unsupported_snippet_effects')):
        raise CodeError(422,'completion_unsupported','snippet template has unsupported provider effects or format')
    edit=item.get('textEdit')
    if (type(edit) is not dict or set(edit) not in ({'range','newText'},{'insert','replace','newText'})
            or type(edit.get('newText')) is not str):
        raise CodeError(422,'completion_unsupported','snippet template requires explicit original text edit ranges')
    additional=item.get('additionalTextEdits',[])
    if type(additional) is not list or len(additional)>128:
        raise CodeError(422,'completion_limit','snippet companion list is invalid')
    values=[edit['newText']]
    for row in additional:
        if type(row) is not dict or set(row)!={'range','newText'} or type(row.get('newText')) is not str:
            raise CodeError(422,'completion_unsupported','snippet companion fields are invalid')
        values.append(row['newText'])
    try: size=sum(len(v.encode('utf-8')) for v in values)
    except UnicodeError: raise CodeError(422,'completion_unsupported','snippet template is not valid UTF-8') from None
    if size>65536 or any('\0' in v for v in values):
        raise CodeError(422,'completion_limit','snippet template aggregate limit exceeded')
    detached=copy.deepcopy(item)
    # Existing original saved-source cursor/range/overlap validator. Its literal
    # whole-file result is discarded: template markup can never enter an edit.
    checked=preview({**detached,'insertTextFormat':1},text,position,language_id,path,source_digest,selection_mode)
    template={'item':detached,'position':copy.deepcopy(position),'path':path,'source_digest':source_digest,
              'selection_mode':checked['selection_mode'],'coordinate_domain':'LSP UTF-16 saved-source lines'}
    return {'template':template,'selection_mode':checked['selection_mode'],'additional_edit_count':checked['additional_edit_count'],
            'applied':False,'unsaved_buffers':False,'grammar_qualified':False,'editor_admitted':False,
            'effect':'inert snippet template only'}
