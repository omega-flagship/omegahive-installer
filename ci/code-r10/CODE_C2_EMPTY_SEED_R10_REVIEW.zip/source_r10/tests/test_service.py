"""Actual disposable git inputs and native processes; no model or live Hive claims."""
import json
import pathlib
import subprocess
import sys
import time

import httpx
import pytest
from fastapi.testclient import TestClient

from omegacode.api import create_app
from omegacode.auth import ACTIONS
from omegacode.common import CodeError, canonical, digest
from omegacode.runner import group_members
from omegacode.service import Service


OPERATOR = "synthetic-test-operator-token-123456789"


@pytest.fixture
def repo(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "calculator.py").write_text("def add(a, b):\n    return a - b\n")
    (repo / "test_calculator.py").write_text("from calculator import add\nassert add(2, 3) == 5\n")
    for argv in (["git", "init", "-q", str(repo)], ["git", "-C", str(repo), "add", "."],
                 ["git", "-C", str(repo), "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-qm", "synthetic"]):
        subprocess.run(argv, check=True, capture_output=True)
    return repo


@pytest.fixture
def service(tmp_path, repo):
    service = Service(tmp_path / "state", OPERATOR, {"synthetic": {"path": str(repo), "max_task_runs": 50,
                                                                 "task_runtime_budget_seconds": 1000}})
    yield service
    for run in service.store.list("run"):
        if run.get("pgid") and run["status"] in ("starting", "running", "cancel_requested"):
            (service.store.root / "runs" / run["id"] / "cancel.request").write_text("test cleanup")
    end = time.monotonic() + 8
    while time.monotonic() < end:
        service.reconcile()
        if not any(r["status"] in ("running", "cancel_requested") for r in service.store.list("run")):
            break
        time.sleep(.05)
    service.close()


def principal(service, **updates):
    config = dict(actor="user:test", kind="human", task_id="goal-test", swarm_id="swarm-test",
                  repository_id="synthetic", actions=sorted(ACTIONS), argv_prefixes=[[sys.executable]], max_runs=50)
    config.update(updates)
    grant = service.authority.issue(**config)
    return service.authority.authenticate(grant["token"], config.get("member_token")), grant


def workspace(service, p):
    return service.create_workspace(p, {"operation_id": "create", "task_id": "goal-test",
                                        "repository_id": "synthetic", "base_commit": "HEAD"})


def edit(service, p, ws, content, op="edit", path="calculator.py"):
    old = service.manifest(ws)["files"].get(path)
    return service.edit(p, ws["id"], {"operation_id": op, "expected_generation": ws["generation"],
                                     "expected_tree_digest": ws["tree_digest"], "edits": [
                                         {"path": path, "expected_digest": old["digest"] if old else None,
                                          "content": content}]})


def run(service, p, ws, argv=None, timeout=10, op="run"):
    return service.start_run(p, {"operation_id": op, "workspace_id": ws["id"],
                                 "expected_generation": ws["generation"], "expected_tree_digest": ws["tree_digest"],
                                 "argv": argv or [sys.executable, "test_calculator.py"], "timeout_seconds": timeout})


def finish(service, id, seconds=12):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        service.reconcile()
        r = service.store.get("run", id)
        if r["status"] not in ("prepared", "starting", "running", "cancel_requested"):
            return r
        time.sleep(.05)
    pytest.fail("native run did not reach an observed terminal state")


def test_failure_repair_stale_verification_and_restart(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    baseline = finish(service, run(service, p, ws)["id"])
    assert baseline["status"] == "failed"
    failed = service.verify(p, {"operation_id": "verify-fail", "run_id": baseline["id"]})
    assert failed["status"] == "failed"
    repaired = edit(service, p, ws, "def add(a, b):\n    return a + b\n")["workspace"]
    passed_run = finish(service, run(service, p, repaired, op="run-fixed")["id"])
    assert passed_run["descendants_terminated"] and passed_run["exit_code"] == 0
    vr = service.verify(p, {"operation_id": "verify-fixed", "run_id": passed_run["id"]})
    assert vr["status"] == "passed" and vr["currency"] == "current"
    assert vr["independent_rsi_evaluation"] is False
    edit(service, p, repaired, "def add(a, b):\n    return a + b + 1\n", "edit-later")
    assert service.verification(p, vr["id"])["currency"] == "stale"
    cp = service.checkpoint(p, ws["id"], {"operation_id": "checkpoint", "label": "review", "decision": "keep evaluator separate"})
    other = Service(service.store.root, OPERATOR, service.repositories)
    try:
        restored = other.authority.authenticate(grant["token"])
        assert other.verification(restored, vr["id"])["currency"] == "stale"
        assert other.store.get("checkpoint", cp["id"])["decision"] == "keep evaluator separate"
        assert len(other.store.events(ws["id"])) >= 10
    finally:
        other.close()


def test_atomic_stale_and_idempotence(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    payload = {"operation_id": "save", "expected_generation": ws["generation"], "expected_tree_digest": ws["tree_digest"],
               "edits": [{"path": "calculator.py", "expected_digest": service.read(p, ws["id"], "calculator.py")["digest"], "content": "new\n"}]}
    first = service.edit(p, ws["id"], payload)
    assert service.edit(p, ws["id"], payload) == first
    with pytest.raises(CodeError, match="already used"):
        service.edit(p, ws["id"], dict(payload, edits=[dict(payload["edits"][0], content="different")]))
    with pytest.raises(CodeError, match="workspace changed"):
        edit(service, p, ws, "worker stale", "other")
    current = service.workspace(ws["id"])
    with pytest.raises(CodeError, match="digest differs"):
        service.edit(p, ws["id"], {"operation_id": "atomic-fail", "expected_generation": current["generation"],
                                   "expected_tree_digest": current["tree_digest"], "edits": [
                                       {"path": "new.py", "expected_digest": None, "content": "must roll back"},
                                       {"path": "calculator.py", "expected_digest": None, "content": "bad"}]})
    assert "new.py" not in service.manifest(service.workspace(ws["id"]))["files"]


def test_expired_authority_cannot_commit_after_workspace_preparation(service, monkeypatch):
    p, _ = principal(service, ttl_seconds=1)
    original = service._repository_files
    def delayed(*args):
        result = original(*args)
        time.sleep(1.1)
        return result
    monkeypatch.setattr(service, "_repository_files", delayed)
    with pytest.raises(CodeError, match="expired"):
        workspace(service, p)
    assert not service.store.list("workspace")
    assert not service.store.db.execute("SELECT 1 FROM operations").fetchone()


@pytest.mark.parametrize("path", ["../outside", "/absolute", ".git/config", ".env", "a/.env.local", "a\\b", "a//b"])
def test_path_boundary(service, path):
    p, _ = principal(service)
    ws = workspace(service, p)
    with pytest.raises(CodeError):
        edit(service, p, ws, "bad", path=path)


def test_frozen_run_ignores_concurrent_edit(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    ws = edit(service, p, ws, "def add(a,b):\n    return a + b\n")["workspace"]
    r = run(service, p, ws, [sys.executable, "-c", "import time; time.sleep(.3); exec(open('test_calculator.py').read())"])
    edit(service, p, ws, "def add(a,b):\n    return 0\n", "concurrent")
    r = finish(service, r["id"])
    assert r["status"] == "completed" and not r["input_mutations"]
    vr = service.verify(p, {"operation_id": "frozen-verification", "run_id": r["id"]})
    assert vr["status"] == "passed" and vr["currency"] == "stale"


def test_human_run_reconciles_from_another_service_without_relaunch(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    r = run(service, p, ws, [sys.executable, "-c", "import time;time.sleep(.5);print('persisted-run')"])
    reopened = Service(service.store.root, OPERATOR, service.repositories)
    try:
        p2 = reopened.authority.authenticate(grant["token"])
        restored = finish(reopened, r["id"])
        assert restored["status"] == "completed" and restored["pid"] == r["pid"]
        assert b"persisted-run" in reopened.store.read_blob(restored["output_digest"], ws["id"])
        assert len(reopened.store.list("run")) == 1
        assert reopened.run(p2, r["id"])["descendants_terminated"]
    finally:
        reopened.close()


def test_stream_resume_and_artifact_task_scope(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    r = finish(service, run(service, p, ws, [sys.executable, "-c", "print('stream-data')"])["id"])
    client = TestClient(create_app(service))
    headers = {"Authorization": "Bearer " + grant["token"]}
    import base64
    with client.websocket_connect(f"/v1/runs/{r['id']}/stream", headers=headers) as socket:
        socket.send_json({"after": 7})
        chunk = socket.receive_json()
        assert base64.b64decode(chunk["data"]) == b"data\n"
        terminal = socket.receive_json()
        assert terminal["type"] == "exit" and terminal["process_group"]["terminated"]
    other, other_grant = principal(service, task_id="other")
    refused = client.get(f"/v1/artifacts/{r['output_digest']}", params={"workspace_id": ws["id"]},
                         headers={"Authorization": "Bearer " + other_grant["token"]})
    assert refused.status_code == 403
    assert client.get(f"/v1/artifacts/{r['output_digest']}", params={"workspace_id": ws["id"]}, headers=headers).content == b"stream-data\n"


def test_symlink_repository_input_is_refused(service, repo):
    (repo / "link.py").symlink_to("calculator.py")
    subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-qm", "symlink"], check=True, capture_output=True)
    p, _ = principal(service)
    with pytest.raises(CodeError, match="symlinks"):
        workspace(service, p)
    assert not service.store.list("workspace")


def test_cancel_observes_children_and_revocation(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    argv = [sys.executable, "-c", "import subprocess,time,sys; subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);print('ready',flush=True);time.sleep(60)"]
    r = run(service, p, ws, argv, timeout=20)
    end = time.monotonic() + 5
    while time.monotonic() < end:
        output = service.store.root / "runs" / r["id"] / "output.log"
        if output.exists() and b"ready" in output.read_bytes():
            break
        time.sleep(.05)
    assert b"ready" in output.read_bytes()
    requested = service.cancel(p, r["id"], {"operation_id": "cancel"})
    assert requested["status"] == "cancel_requested" and not requested["acknowledged"]
    stopped = finish(service, r["id"])
    assert stopped["status"] == "cancelled" and stopped["descendants_terminated"]
    assert not group_members(stopped["pgid"])
    r2 = run(service, p, ws, argv, timeout=20, op="revoke-run")
    service.authority.revoke(grant["grant"]["id"])
    assert finish(service, r2["id"])["status"] == "cancelled"
    with pytest.raises(CodeError):
        service.authority.authenticate(grant["token"])


def test_timeout_output_limit_mutation_and_clean_env(service, monkeypatch):
    p, _ = principal(service)
    ws = workspace(service, p)
    monkeypatch.setenv("OPENAI_API_KEY", "synthetic-secret-must-not-leak")
    r = finish(service, run(service, p, ws, [sys.executable, "-c", "import os;assert 'OPENAI_API_KEY' not in os.environ;open('calculator.py','w').write('tampered')"], op="env") ["id"])
    vr = service.verify(p, {"operation_id": "mutated", "run_id": r["id"]})
    assert r["exit_code"] == 0 and vr["status"] == "failed" and "calculator.py" in vr["input_mutations"]
    timed = finish(service, run(service, p, ws, [sys.executable, "-c", "import time;time.sleep(5)"], timeout=1, op="timeout")["id"])
    assert timed["status"] == "timed_out" and not group_members(timed["pgid"])
    large = finish(service, run(service, p, ws, [sys.executable, "-c", "print('x'*5000000)"], op="large")["id"])
    assert large["status"] == "output_limit" and large["output_bytes"] == 4194304


def test_capability_and_http_boundary(service):
    p, grant = principal(service)
    client = TestClient(create_app(service))
    assert client.get("/v1/capabilities").status_code == 401
    assert client.get("/v1/capabilities", headers={"Authorization": "Bearer garbage"}).status_code == 401
    operator = {"Authorization": "Bearer " + OPERATOR}
    assert client.post("/v1/workspaces", headers=operator, json={"operation_id": "op", "task_id": "goal-test", "repository_id": "synthetic", "base_commit": "HEAD"}).status_code == 403
    headers = {"Authorization": "Bearer " + grant["token"]}
    ws = workspace(service, p)
    other, _ = principal(service, task_id="other-task")
    with pytest.raises(CodeError):
        service.read(other, ws["id"], "calculator.py")
    read = client.get(f"/v1/workspaces/{ws['id']}/files", headers=headers, params={"path": "calculator.py"})
    assert read.status_code == 200
    assert client.post("/v1/runs", headers=headers, json={"operation_id": "invalid", "workspace_id": ws["id"], "expected_generation": 1, "expected_tree_digest": ws["tree_digest"], "argv": ["/bin/sh", "-c", "true"], "timeout_seconds": 1}).status_code == 403
    limited, _ = principal(service, paths=["test_calculator.py"])
    with pytest.raises(CodeError):
        service.read(limited, ws["id"], "calculator.py")
    with pytest.raises(CodeError):
        run(service, limited, ws)


def test_hive_policy_and_claim_are_server_checked(tmp_path, repo):
    state = {"decision": "deny", "status": "claimed", "binding": None, "redeemed": False}
    calls = []
    def transport(request):
        calls.append((request.url.path, request.content))
        if "/approvals/" in request.url.path:
            if request.method == "GET":
                return httpx.Response(200, json={"agent_id": "dot-test", "skill": "code-workspace", "status": "approved", "binding": state["binding"]})
            if state["redeemed"]:
                return httpx.Response(409, json={"error": "approval_redeemed"})
            state["redeemed"] = True
            return httpx.Response(200, json={"redeemed": True})
        if request.method == "GET":
            return httpx.Response(200, json={"swarm_id": "swarm-test", "claimed_by": "dot-test",
                                             "status": state["status"], "lease_until": "2099-01-01T00:00:00Z"})
        return httpx.Response(200, json={"decision": state["decision"]})
    service = Service(tmp_path / "hive-state", OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(transport), service_token="synthetic-service-token")
    try:
        p, grant = principal(service, actor="dot-test", kind="agent", member_token="synthetic-member-token")
        with pytest.raises(CodeError, match="denied"):
            workspace(service, p)
        assert not service.store.list("workspace")
        state["decision"] = "allow"
        # Even upstream default-allow cannot authorize a mutating request without its exact receipt.
        with pytest.raises(CodeError, match="approval"):
            workspace(service, p)
        payload = {"operation_id": "create", "task_id": "goal-test", "repository_id": "synthetic", "base_commit": "HEAD"}
        operation = {"action": "workspace", "workspace_id": None, **payload}
        state["binding"] = {"task_id": "goal-test", "swarm_id": "swarm-test", "workspace_id": None,
                            "operation_id": "create", "expected_generation": None,
                            "payload_digest": "sha256:" + digest(canonical(operation))}
        ws = service.create_workspace(p, dict(payload, approval_id="p_test"))
        assert state["redeemed"]
        assert service.create_workspace(p, dict(payload, approval_id="p_test")) == ws
        state["status"] = "cancelled"
        with pytest.raises(CodeError, match="not actively"):
            edit(service, p, ws, "forbidden", "stale-authority")
        assert service.read(p, ws["id"], "calculator.py")["content"]
        with pytest.raises(CodeError):
            service.authority.authenticate(grant["token"], "other-member-token")
        assert any(b"code-workspace" in body for _, body in calls)
    finally:
        service.close()


def test_enrolment_is_narrow_and_credentials_are_not_returned(tmp_path, repo):
    seen = []
    def transport(request):
        seen.append(request)
        return httpx.Response(201, json={"service_id": "svc-test", "service_token": "synthetic-registered-secret",
                                         "capability_secret": "synthetic-capability-secret", "address": "http://127.0.0.1:8724"})
    s = Service(tmp_path / "registration", OPERATOR, {"synthetic": {"path": str(repo)}},
                "http://hive.invalid", httpx.MockTransport(transport))
    try:
        client = TestClient(create_app(s))
        response = client.post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                               json={"enrol_token": "synthetic-one-time-enrol-token"})
        assert response.status_code == 201
        assert "secret" not in response.text and "token" not in response.text
        body = json.loads(seen[0].content)
        assert body["surfaces"] == ["diff", "log", "editor"] and "pty" not in body["surfaces"]
        path = s.store.root / "registration.json"
        assert path.stat().st_mode & 0o077 == 0
        assert s.authority.service_token == "synthetic-registered-secret"
        assert client.post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                           json={"enrol_token": "synthetic-one-time-enrol-token"}).status_code == 409
    finally:
        s.close()


def test_running_agent_stops_when_live_hive_authority_ends(tmp_path, repo):
    state = {"active": True, "binding": None}
    def transport(request):
        if "/approvals/" in request.url.path:
            return httpx.Response(200, json={"agent_id": "dot-test", "skill": "code-run", "status": "approved", "binding": state["binding"]})
        if request.method == "GET":
            return httpx.Response(200, json={"swarm_id": "swarm-test", "claimed_by": "dot-test",
                                             "status": "claimed" if state["active"] else "cancelled", "lease_until": "2099-01-01T00:00:00Z"})
        return httpx.Response(200, json={"decision": "allow"})
    s = Service(tmp_path / "agent-run", OPERATOR, {"synthetic": {"path": str(repo)}},
                "http://hive.invalid", httpx.MockTransport(transport), "synthetic-service-token")
    try:
        human, _ = principal(s)
        ws = workspace(s, human)
        agent, _ = principal(s, actor="dot-test", kind="agent", member_token="synthetic-member-token")
        payload = {"operation_id": "agent-run", "workspace_id": ws["id"], "expected_generation": ws["generation"],
                   "expected_tree_digest": ws["tree_digest"], "argv": [sys.executable, "-c", "import time;time.sleep(60)"], "timeout_seconds": 20}
        state["binding"] = {"task_id": "goal-test", "swarm_id": "swarm-test", "workspace_id": ws["id"],
                            "operation_id": payload["operation_id"], "expected_generation": ws["generation"],
                            "payload_digest": "sha256:" + digest(canonical({"action": "run", **payload}))}
        r = s.start_run(agent, dict(payload, approval_id="p_run"))
        state["active"] = False
        stopped = finish(s, r["id"])
        assert stopped["status"] == "cancelled" and stopped["descendants_terminated"]
        assert not group_members(stopped["pgid"])
    finally:
        s.close()


def test_workspace_creation_from_valid_empty_git_commit(service, repo):
    git = lambda *args: subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True).stdout
    git("rm", "-f", "calculator.py", "test_calculator.py")
    git("-c", "user.name=Test", "-c", "user.email=test@example.invalid",
        "commit", "-qm", "valid empty source tree")
    empty_head = git("rev-parse", "HEAD").strip()
    assert git("ls-tree", "-r", "--name-only", "HEAD").strip() == b""

    _, grant = principal(service)
    client = TestClient(create_app(service))
    headers = {"Authorization": "Bearer " + grant["token"]}
    payload = {"operation_id": "empty-tree-workspace", "task_id": "goal-test",
               "repository_id": "synthetic", "base_commit": "HEAD"}
    created = client.post("/v1/workspaces", headers=headers, json=payload)
    assert created.status_code == 201, created.text
    replay = client.post("/v1/workspaces", headers=headers, json=payload)
    assert replay.status_code == 201 and replay.json() == created.json()
    ws = created.json()
    assert ws["base_commit"] == empty_head.decode()
    assert ws["generation"] == 1 and service.manifest(ws)["files"] == {}
    tree = client.get(f"/v1/workspaces/{ws['id']}/tree", headers=headers)
    assert tree.status_code == 200 and tree.json()["files"] == []
