"""Sandbox-backed existence check; caller resolves exact bound source custody."""
import json


async def validate_source_target(ctx, source, target):
    if not isinstance(source, bytes) or not source or len(source) > 20*1024*1024:
        return {'ok': False, 'reason': 'Bounded host-resolved source required'}
    if not isinstance(target, dict):
        return {'ok': False, 'reason': 'Structured finding target required'}
    try:
        encoded = json.dumps(target, allow_nan=False).encode()
        if len(encoded) > 4096:
            return {'ok': False, 'reason': 'Finding target exceeds limit'}
        runner = getattr(ctx, 'sandbox_run', None)
        if not callable(runner):
            return {'ok': False, 'reason': 'Host sandbox unavailable'}
        result = await runner('review-target-cli.mjs', args=['source.json','target.json'],
                              inputs={'source.json':source,'target.json':encoded},
                              outputs=[], runtime='node', bundle='tools',
                              cpu_seconds=10, file_bytes=30*1024*1024, timeout=30)
        if result.get('exit') != 0 or result.get('stdout_truncated') or result.get('missing_outputs'):
            return {'ok': False, 'reason': 'Finding source validation refused or incomplete'}
        answer = json.loads(result['stdout'])
        if answer.get('ok') is not True or not isinstance(answer.get('location'), dict):
            return {'ok': False, 'reason': 'Finding source validation refused'}
        return {'ok': True}
    except (ValueError, TypeError, KeyError, AttributeError):
        return {'ok': False, 'reason': 'Finding validation context invalid'}


async def validate_bound_target(ctx, artifact_revision, target):
    """r2.10 exact host dispatch revision; requester binding selects this program."""
    import hashlib
    try:
        if not isinstance(artifact_revision, dict):
            raise ValueError('Retained revision required')
        artifact_id = artifact_revision['artifact_id']
        n = artifact_revision['revision']
        if not isinstance(artifact_id, str) or not artifact_id or type(n) is not int or n < 1:
            raise ValueError('Exact revision identity required')
        body = artifact_revision['body']
        if not isinstance(body, str):
            raise ValueError('Retained body required')
        raw = body.encode()
        expected = 'sha256:' + hashlib.sha256(raw).hexdigest()
        if artifact_revision['digest'] != expected:
            raise ValueError('Retained revision digest differs')
        if not raw or len(raw) > 20*1024*1024:
            raise ValueError('Retained source exceeds limit')
        source = json.loads(raw)
        if isinstance(source, dict) and source.get('schema')=='omega-model-artifact-1':
            from .model_delivery import read_delivery
            ref={'artifact_id':artifact_id,'revision':n,'digest':expected}
            raw=read_delivery(ctx,source,ref)['editable-model.json']
        if isinstance(source, dict) and source.get('schema') in {'omega-studio-source-pointer-1','omega-motion-artifact-1'}:
            if source['schema']=='omega-motion-artifact-1':
                assets=source.get('assets')
                if not isinstance(assets,list) or len(assets)!=3 or source.get('adopted') is not False:raise ValueError('Motion source assets required')
                asset=assets[0]
                if source.get('delivery',{}).get('files',{}).get('editable-motion.json')!={'digest':'sha256:'+asset['sha256'],'bytes':asset['bytes'],'mime':asset['mime']}:raise ValueError('Motion source binding differs')
            else:asset = source['asset']
            record = ctx.read_asset(asset['sha256'], artifact_id, n)
            raw = record['data']
            if not isinstance(raw, bytes) or len(raw) != asset['bytes'] or hashlib.sha256(raw).hexdigest() != asset['sha256'] or record.get('bytes') != asset['bytes'] or record.get('mime') != 'application/json' or record.get('mime') != asset['mime']:
                raise ValueError('Exact source asset differs')
        return await validate_source_target(ctx, raw, target)
    except (ValueError, TypeError, KeyError, AttributeError, PermissionError):
        return {'ok': False, 'reason': 'Exact bound source custody unavailable'}
