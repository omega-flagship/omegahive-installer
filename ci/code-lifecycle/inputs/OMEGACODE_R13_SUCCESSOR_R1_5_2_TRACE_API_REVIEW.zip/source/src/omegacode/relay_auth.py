"""Same-connection Hive relay proof primitives and one-use challenge state."""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import threading
import time

from .common import CodeError

DOMAIN = b"omegacode-relay-v1\n"
_HEX_64 = re.compile(r"^[0-9a-f]{64}$")
_METHOD = re.compile(r"^[A-Z]{1,16}$")
_BAD_PERCENT = re.compile(r"%(?![0-9a-fA-F]{2})")


def proof_fields(service_id: str, nonce: str, method: str, path: str,
                 body_sha256: str, challenge_id: str) -> dict:
    if not isinstance(service_id, str) or not service_id or len(service_id) > 160:
        raise ValueError("invalid service_id")
    if not isinstance(nonce, str) or not _HEX_64.fullmatch(nonce):
        raise ValueError("nonce must be 32 bytes encoded as lowercase hex")
    if not isinstance(method, str) or not _METHOD.fullmatch(method):
        raise ValueError("method must be a bounded uppercase token")
    if (not isinstance(path, str) or not path.startswith("/") or not path.isascii() or len(path) > 4096
            or any(c in path for c in "\\\r\n#\x00") or any(ord(c) <= 0x20 for c in path)
            or _BAD_PERCENT.search(path)):
        raise ValueError("path must be a canonical origin-form path and query")
    if not isinstance(body_sha256, str) or not _HEX_64.fullmatch(body_sha256):
        raise ValueError("body_sha256 must be lowercase SHA-256 hex")
    if not isinstance(challenge_id, str) or not challenge_id or len(challenge_id) > 160:
        raise ValueError("invalid challenge_id")
    return {"service_id": service_id, "nonce": nonce, "method": method,
            "path": path, "body_sha256": body_sha256, "challenge_id": challenge_id}


def canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def challenge_proof(secret: str, *, service_id: str, nonce: str, method: str,
                    path: str, body_sha256: str, challenge_id: str) -> str:
    """Lowercase hex HMAC-SHA256 used by the agreed R13 relay contract."""
    if not isinstance(secret, str) or len(secret) < 32:
        raise ValueError("capability secret is missing or too short")
    fields = proof_fields(service_id, nonce, method, path, body_sha256, challenge_id)
    return hmac.new(secret.encode("utf-8"), DOMAIN + canonical(fields), hashlib.sha256).hexdigest()


class RelayChallengeStore:
    """Bounded single-use challenges keyed to the ASGI-visible TCP 4-tuple."""

    def __init__(self, ttl_seconds: float = 5.0, max_pending: int = 1024):
        self.ttl_seconds = ttl_seconds
        self.max_pending = max_pending
        self._pending = {}
        self._connections = {}
        self._lock = threading.Lock()

    def _expire(self, now: float) -> None:
        expired = [challenge_id for challenge_id, item in self._pending.items()
                   if item["expires_at"] <= now]
        for challenge_id in expired:
            item = self._pending.pop(challenge_id)
            if self._connections.get(item["connection"]) == challenge_id:
                self._connections.pop(item["connection"], None)

    def issue(self, connection: tuple, *, secret: str, service_id: str, nonce: str,
              method: str, path: str, body_sha256: str) -> tuple[str, str]:
        # Validate every caller-supplied field before changing shared state.
        if not isinstance(secret, str) or len(secret) < 32:
            raise CodeError(503, "relay_proof_unavailable", "registered relay proof is unavailable")
        challenge_id = "rly_" + secrets.token_hex(16)
        fields = proof_fields(service_id, nonce, method, path, body_sha256, challenge_id)
        proof = hmac.new(secret.encode("utf-8"), DOMAIN + canonical(fields), hashlib.sha256).hexdigest()
        now = time.monotonic()
        with self._lock:
            self._expire(now)
            if connection in self._connections:
                raise CodeError(409, "relay_challenge_pending", "consume or let the current relay challenge expire")
            if len(self._pending) >= self.max_pending:
                raise CodeError(429, "relay_challenge_busy", "relay challenge capacity is full")
            self._pending[challenge_id] = {"connection": connection, "fields": fields,
                                           "expires_at": now + self.ttl_seconds}
            self._connections[connection] = challenge_id
        return challenge_id, proof

    def consume(self, connection: tuple, challenge_id: str, *, method: str, path: str,
                body: bytes) -> bool:
        if not isinstance(challenge_id, str) or not challenge_id or len(challenge_id) > 160:
            return False
        now = time.monotonic()
        with self._lock:
            self._expire(now)
            item = self._pending.get(challenge_id)
            if item is None or item["connection"] != connection:
                return False
            # Consume before checking the request binding or authenticating its bearer.
            self._pending.pop(challenge_id, None)
            self._connections.pop(connection, None)
        fields = item["fields"]
        return (item["expires_at"] > now and fields["method"] == method
                and fields["path"] == path
                and fields["body_sha256"] == hashlib.sha256(body).hexdigest())
