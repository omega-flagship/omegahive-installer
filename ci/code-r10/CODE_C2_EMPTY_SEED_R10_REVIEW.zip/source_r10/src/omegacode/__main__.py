"""Run with an owner-local configuration file; never expose operator credentials in argv."""
import argparse
import fcntl
import json
import os
import pathlib

import uvicorn

from .purpose_startup import create_purpose_app
from .service import Service
from .service_lock import ServiceLock, LockError


def main():
    parser = argparse.ArgumentParser(description="OmegaCode trusted disposable development service")
    parser.add_argument("--config", type=pathlib.Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    root = pathlib.Path(config["data_root"]).resolve()
    root.mkdir(parents=True, mode=0o700, exist_ok=True)
    try:
        owner = ServiceLock(root)
    except (BlockingIOError, OSError, LockError):
        parser.error("OmegaCode daemon ownership could not be established")
    service = None
    try:
        token_path = pathlib.Path(config["operator_token_file"])
        if token_path.stat().st_mode & 0o077:
            parser.error("operator token file must be owner-only (0600)")
        service_token = None
        if config.get("service_token_file"):
            service_path = pathlib.Path(config["service_token_file"])
            if service_path.stat().st_mode & 0o077:
                parser.error("service token file must be owner-only (0600)")
            service_token = service_path.read_text().strip()
        service = Service(root, token_path.read_text().strip(),
                          config["repositories"], config.get("hive_url"), service_token=service_token, toolchains=config.get("toolchains"),
                          language_servers=config.get("language_servers"), owner=owner)
        uvicorn.run(create_purpose_app(service, config.get("port", 8724), enabled=config.get("proposal_tests_enabled", False), capacity=config.get("proposal_status_capacity", 8)), host="127.0.0.1", port=config.get("port", 8724),
                    access_log=False, log_level="warning")
    finally:
        try:
            if service is not None: service.close()
        finally: owner.close()



if __name__ == "__main__":
    main()
