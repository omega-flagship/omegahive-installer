"""Uninstalled default-off purpose launch route over the existing owned runner."""
import time
from typing import Annotated
from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel, ConfigDict, Field, StrictStr
from omegacode.common import CodeError, canonical
from omegacode.proposal_launch_custody import Custody
from .purpose_auth import PurposeAuthority
from .launch_admission import admit, scope_binding
from .proposal_host_wire import launch_binding
from .dispatch_gate import claim
from .native_preparation import prepare
from .native_launch import launch

class LaunchBody(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    launch_key: Annotated[StrictStr, Field(pattern='^[A-Za-z0-9_.:-]{8,120}$')]
    argv: Annotated[list[Annotated[StrictStr, Field(min_length=1, max_length=8192)]], Field(min_length=1, max_length=64)]
    runtime_seconds: Annotated[int, Field(ge=1, le=600)]

def monitor_ready(service):
    service._check_owner(required=True)
    watcher = service._watcher
    if service._stop.is_set() or watcher is None or (not watcher.is_alive()) or (service._proposal_watchdog is None) or (service._proposal_status_pool is None):
        raise CodeError(503, 'purpose_monitor_required', 'existing owned monitor must be running')

def install(app, service, authority, host, *, enabled=False):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    if not enabled:
        return False
    if app.state.service is not service or not isinstance(authority, PurposeAuthority) or authority.store is not service.store or (authority.registration != service.authority.registration) or (not authority._proposal_enabled):
        raise ValueError('purpose authority must bind this registered service and Store')
    if getattr(app.state, '_code_purpose_launch_installed', False):
        raise ValueError('purpose launch route already installed')

    def principal(authorization: Annotated[str | None, Header()]=None, x_hive_token: Annotated[str | None, Header()]=None):
        if not authorization or not authorization.startswith('Bearer '):
            raise CodeError(401, 'authentication_required', 'a scoped bearer capability is required')
        return authority.authenticate(authorization[7:], x_hive_token)
    router = APIRouter()

    @router.post('/v1/proposal-tests/{test_id}/launches', status_code=201)
    def start(test_id: str, body: LaunchBody, p=Depends(principal)):
        path = '/v1/proposal-tests/' + test_id + '/launches'
        authority.require_route(p, 'POST', path)
        claims = canonical(p.grant)
        monitor_ready(service)
        admitted = admit(service, authority, p, host, body.launch_key, body.argv, body.runtime_seconds)
        row = admitted['launch']
        won = claim(service, authority, p, host, row['id'])
        if won is not None:
            prepare(service, authority, p, host, won['id'])
            launch(service, authority, p, host, won['id'])
        authority.require_route(p, 'GET', '/v1/proposal-tests/' + test_id)
        with service.store.lock:
            service._check_owner(required=True)
            current = Custody(service.store).get(row['id'])
            saved = service.store.get('proposal_preparation', test_id)
            if canonical(p.grant) != claims or p.grant['exp'] <= time.time() or current['test_id'] != test_id or (current['binding'] != launch_binding(p.grant)) or (saved['binding'] != scope_binding(p.grant)):
                raise CodeError(409, 'proposal_launch_custody', 'original launch binding changed')
        return dict(test_id=test_id, launch=current, recovered=admitted['recovered'], dispatch_claimed=won is not None, source_accepted=False, host_settled=False)
    app.include_router(router)
    app.state._code_purpose_launch_installed = True
    return True
