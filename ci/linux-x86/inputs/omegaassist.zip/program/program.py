"""Read-only public program boundary. No Hive imports, credentials or effectful actions."""


def describe():
    return {"contract": "0.1", "kinds": [{"id": "connection-gap", "label": "Connection", "role": "gap"}],
            "relations": [], "actions": [],
            "reads": [{"id": "connection", "label": "App connection capabilities"}]}


def view(ctx, focus=None, stage="unfold"):
    return {"revision": "public-frame-client-1", "focus": "connection", "title": "OmegaAssist",
            "suggested_stage": stage, "items": [{"id": "connection", "kind": "connection-gap",
            "label": "Open the Hive interface", "text": "The frame connects through Hive's public bridge. Standalone authorization is unavailable.",
            "status": "current"}], "links": [], "groups": [], "notes": ["Connection state is verified inside the frame."]}


def read(ctx, query, params):
    """Only this app's static capability description; no personal state or host internals."""
    if query != "connection":
        raise ValueError("Unknown app read")
    return {"program": "omegaassist", "contract": "0.1", "transport": "public-frame-bridge",
            "standalone": "unavailable", "memory": "unavailable", "semantic_decisions": "unavailable"}


def act(ctx, action, items, params):
    return {"status": "refused", "message": "This app does not declare an effectful action."}
