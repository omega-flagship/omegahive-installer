"""History-relative wrapper readback successor in the existing retained settlement Store; GET only."""
from omegacode.common import canonical, digest
from omegacode.proposal_launch_custody import Custody
from .settlement_submission import KIND, identity, same_original
from .proposal_host_wire import fail
from .settlement_wire import Reader, WireError, acknowledgement

def reconcile(service, host, submission_id):
    service._check_owner(required=True)
    with service.store.lock:
        record = service.store.get(KIND, submission_id)
        row = Custody(service.store).get(record['launch_id'])
        if record['id'] != submission_id or record['id'] != 'ps_' + digest(canonical([record['launch_id'], record['body_digest']])) or record['body_digest'] != digest(canonical(record['body'])) or (not same_original(record['identity'], identity(service, row))):
            fail('settlement_original')
        expected = dict(test_id=record['test_id'], hold_id=record['hold_id'], request_id=record['identity']['preparation']['binding']['request_id'], launch_key=row['launch_key'], argv_digest='sha256:' + digest(canonical(row['argv'])), runtime_seconds=row['runtime_seconds'])
    try:
        current = Reader(host).get(expected)
        if current is not None and current['hold']['run_id'] not in (None, row['run_id']):
            fail('settlement_host_binding')
        answer = acknowledgement(current, record['body'])
    except WireError:
        fail('settlement_host_binding')
    previous = record.get('host_readback')
    if previous is not None:
        if current is None or canonical(current['observations'][:len(previous['observations'])]) != canonical(previous['observations']) or current['hold']['created_at'] != previous['hold']['created_at']:
            fail('settlement_host_history')
    with service.store.transaction():
        service._check_owner(required=True)
        if canonical(service.store.get(KIND, submission_id)) != canonical(record) or not same_original(record['identity'], identity(service, Custody(service.store).get(row['id']))):
            fail('settlement_original')
        record['host_readback'] = current
        if answer['acknowledged']:
            record.update(state='acknowledged', host_state=current['hold']['state'], host_settled=answer['host_settled'], superseded=answer['superseded'])
        service.store.put(KIND, record)
    return dict(submission_id=submission_id, state=record['state'], acknowledged=answer['acknowledged'], superseded=answer['superseded'], host_settled=record['host_settled'], authority_renewed=False)
