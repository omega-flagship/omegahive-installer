"""Bounded stdio LSP queries against disposable, immutable source snapshots.

Only operator-configured servers and named language features are callable. This is
trusted-native analysis, not OS isolation. No server command or edit is executed
on the caller's behalf; rename yields a CAS patch preview.
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import selectors
import signal
import stat
import subprocess
import time
from urllib.parse import urlsplit, unquote

from .common import CodeError, MAX_FILE, canonical, digest, safe_path
from .runner import group_members

MAX_WIRE = 4 * 1024 * 1024
METHODS = {'definition': 'textDocument/definition', 'references': 'textDocument/references',
           'completion': 'textDocument/completion', 'hover': 'textDocument/hover',
           'rename': 'textDocument/rename', 'diagnostics': 'textDocument/publishDiagnostics',
           'document_symbols': 'textDocument/documentSymbol', 'signature_help': 'textDocument/signatureHelp'}
CAPABILITIES = {'definition': 'definitionProvider', 'references': 'referencesProvider',
                'completion': 'completionProvider', 'hover': 'hoverProvider', 'rename': 'renameProvider',
                'document_symbols': 'documentSymbolProvider', 'signature_help': 'signatureHelpProvider'}


def offered(capabilities, key):
    value = capabilities.get(key)
    return value is True or isinstance(value, dict)


class Stdio:
    def __init__(self, argv, root, timeout):
        self.deadline = time.monotonic() + timeout
        self.buffer, self.received, self.frames = bytearray(), 0, 0
        self.notifications = []
        self.next_id = 0
        self.root = root
        self.proc = subprocess.Popen(argv, cwd=root/'tree', stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.DEVNULL, start_new_session=True,
                                     env={'PATH': os.defpath, 'LANG': 'C.UTF-8', 'HOME': str(root/'home'),
                                          'TMPDIR': str(root/'tmp'), 'PYTHONNOUSERSITE': '1',
                                          'PYTHONDONTWRITEBYTECODE': '1'})
        os.set_blocking(self.proc.stdout.fileno(), False)
        os.set_blocking(self.proc.stdin.fileno(), False)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.proc.stdout, selectors.EVENT_READ)

    def send(self, message):
        body = canonical({'jsonrpc': '2.0', **message})
        if len(body) > MAX_WIRE:
            raise CodeError(413, 'language_limit', 'language request is too large')
        packet = f'Content-Length: {len(body)}\r\n\r\n'.encode() + body
        sent = 0
        with selectors.DefaultSelector() as writable:
            writable.register(self.proc.stdin, selectors.EVENT_WRITE)
            while sent < len(packet):
                if time.monotonic() >= self.deadline:
                    raise CodeError(504, 'language_timeout', 'language server exceeded query deadline')
                if writable.select(.05):
                    try: sent += os.write(self.proc.stdin.fileno(), packet[sent:])
                    except BlockingIOError: pass
                    except BrokenPipeError:
                        raise CodeError(502, 'language_exit', 'language server ended before responding') from None

    def notify(self, method, params=None):
        self.send({'method': method, **({'params': params} if params is not None else {})})

    def receive(self):
        while time.monotonic() < self.deadline:
            boundary = self.buffer.find(b'\r\n\r\n')
            if boundary > 8192 or boundary < 0 and len(self.buffer) > 8192:
                raise CodeError(502, 'language_protocol', 'language server header is oversized')
            if boundary >= 0:
                try:
                    pairs = [line.split(b':', 1) for line in self.buffer[:boundary].split(b'\r\n')]
                    lengths = [int(v.strip()) for k, v in pairs if k.lower() == b'content-length']
                    if len(lengths) != 1 or not 0 <= lengths[0] <= MAX_WIRE: raise ValueError()
                    length = lengths[0]
                except (ValueError, TypeError):
                    raise CodeError(502, 'language_protocol', 'invalid language server frame') from None
                end = boundary + 4 + length
                if len(self.buffer) >= end:
                    try: message = json.loads(self.buffer[boundary+4:end])
                    except (ValueError, UnicodeDecodeError):
                        raise CodeError(502, 'language_protocol', 'invalid language server JSON') from None
                    del self.buffer[:end]
                    self.frames += 1
                    if self.frames > 2048 or not isinstance(message, dict) or message.get('jsonrpc') != '2.0':
                        raise CodeError(502, 'language_protocol', 'unsupported language server message')
                    if 'method' in message and 'id' in message:
                        # Refuse workspace/applyEdit, executeCommand, configuration and all
                        # unsolicited server requests. No server request may widen authority.
                        self.send({'id': message['id'], 'error': {'code': -32601, 'message': 'Server requests are not supported'}})
                        continue
                    return message
            if self.selector.select(.05):
                chunk = os.read(self.proc.stdout.fileno(), 65536)
                if not chunk:
                    raise CodeError(502, 'language_exit', 'language server ended before responding')
                self.received += len(chunk)
                if self.received > MAX_WIRE:
                    raise CodeError(413, 'language_limit', 'language server output budget exceeded')
                self.buffer.extend(chunk)
        raise CodeError(504, 'language_timeout', 'language server exceeded query deadline')

    def request(self, method, params):
        self.next_id += 1
        id_ = self.next_id
        self.send({'id': id_, 'method': method, 'params': params})
        while True:
            message = self.receive()
            if message.get('id') == id_:
                if 'error' in message:
                    raise CodeError(422, 'language_refused', 'language server refused this query',
                                    {'server_error_code': message['error'].get('code')})
                if 'result' not in message:
                    raise CodeError(502, 'language_protocol', 'language response has no result')
                return message['result']
            if 'method' in message:
                self.notifications.append(message)

    def diagnostics(self, uri):
        while True:
            for message in self.notifications:
                if message.get('method') == 'textDocument/publishDiagnostics' and message.get('params', {}).get('uri') == uri:
                    return message['params'].get('diagnostics', [])
            self.notifications.append(self.receive())

    def close(self):
        self.selector.close()
        observed = False
        try:
            # Keep the owned child unreaped until group cleanup is observed.
            # Reaping between TERM/KILL releases its PID and can target a reused group.
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try: os.killpg(self.proc.pid, sig)
                except (ProcessLookupError, PermissionError): pass
                end = time.monotonic() + 1
                while True:
                    try: observed = not group_members(self.proc.pid)
                    except (RuntimeError, OSError, subprocess.SubprocessError): observed = False
                    if observed or time.monotonic() >= end: break
                    time.sleep(.02)
                if observed: break
        finally:
            try: self.proc.wait(timeout=1)
            except subprocess.TimeoutExpired: observed = False
            for stream in (self.proc.stdin, self.proc.stdout): stream.close()
        if not observed:
            raise CodeError(503, 'language_cleanup_unknown', 'language server group termination could not be confirmed')


def source_lines(text):
    # LSP line endings are LF, CRLF or CR; Unicode separators inside source
    # strings are characters, not editor line boundaries.
    return re.split(r'(?<=\n)|(?<=\r)(?!\n)', text)


def offset(text, position):
    """LSP zero-based UTF-16 coordinates to a Python offset, refusing split surrogates."""
    if not isinstance(position, dict) or any(type(position.get(k)) is not int or position[k] < 0 for k in ('line','character')):
        raise CodeError(422, 'language_range', 'invalid UTF-16 source position')
    lines = source_lines(text)
    line, character = position['line'], position['character']
    if line >= len(lines): raise CodeError(422, 'language_range', 'position is outside source')
    content = lines[line].rstrip('\r\n')
    units = 0
    for index, ch in enumerate(content):
        if units == character: return sum(map(len, lines[:line])) + index
        units += 2 if ord(ch) > 0xffff else 1
        if units > character: raise CodeError(422, 'language_range', 'position splits a UTF-16 surrogate pair')
    if units == character: return sum(map(len, lines[:line])) + len(content)
    raise CodeError(422, 'language_range', 'position is outside source line')


def from_server_range(value, text, encoding, clip=False):
    if encoding == 'utf-16' and not clip: return value
    if not isinstance(value, dict): raise CodeError(502, 'language_protocol', 'invalid server range')
    lines = source_lines(text)
    result = {}
    for key in ('start','end'):
        position = value.get(key, {})
        line, column = position.get('line'), position.get('character')
        if type(line) is not int or type(column) is not int or not 0 <= line < len(lines) or column < 0:
            raise CodeError(422, 'language_range', 'server position is outside source')
        content = lines[line].rstrip('\r\n')
        maximum = len(content.encode('utf-16-le'))//2 if encoding == 'utf-16' else len(content)
        if clip: column = min(column, maximum)
        elif column > maximum: raise CodeError(422, 'language_range', 'server position is outside source')
        result[key] = {'line':line, 'character':column if encoding == 'utf-16' else len(content[:column].encode('utf-16-le'))//2}
    return result


def relative_uri(uri, tree):
    try:
        parts = urlsplit(uri)
        if parts.scheme != 'file' or parts.netloc not in ('', 'localhost') or parts.query or parts.fragment: return None
        name = pathlib.Path(unquote(parts.path)).resolve().relative_to(tree.resolve()).as_posix()
        return safe_path(name)
    except (ValueError, TypeError, CodeError): return None


def checked_range(value, text):
    if not isinstance(value, dict) or 'start' not in value or 'end' not in value:
        raise CodeError(502, 'language_protocol', 'language result has no valid source range')
    start, end = offset(text, value['start']), offset(text, value['end'])
    if end < start: raise CodeError(422, 'language_range', 'range is reversed')
    return start, end


def rename_preview(raw, tree, files, texts, encoding="utf-16", whole_document=False):
    if not isinstance(raw, dict):
        raise CodeError(422, 'rename_unavailable', 'language server returned no rename edit')
    if raw.get('changeAnnotations'):
        raise CodeError(422, 'rename_unsupported', 'annotated edits need a separate review flow')
    changes = raw.get('changes', {})
    if not isinstance(changes, dict): raise CodeError(502, 'language_protocol', 'invalid workspace edit')
    changes = {uri: list(edits) for uri, edits in changes.items()}
    for item in raw.get('documentChanges', []):
        if not isinstance(item, dict) or 'kind' in item or 'textDocument' not in item:
            raise CodeError(422, 'rename_unsupported', 'rename cannot create, move or delete files')
        doc = item['textDocument']
        if doc.get('version') not in (None, 1):
            raise CodeError(409, 'rename_version', 'server edit does not match snapshot document version')
        changes.setdefault(doc['uri'], []).extend(item['edits'])
    result, seen, total = [], set(), 0
    for uri, edits in changes.items():
        name = relative_uri(uri, tree)
        if name is None or name not in files or name not in texts:
            raise CodeError(403, 'rename_scope', 'rename target is outside snapshot source')
        if name in seen: raise CodeError(422, 'rename_overlap', 'multiple URI aliases address one file')
        seen.add(name)
        spans = []
        for item in edits:
            if not isinstance(item, dict) or not isinstance(item.get('newText'), str) or 'annotationId' in item:
                raise CodeError(502, 'language_protocol', 'unsupported text edit')
            if whole_document:
                if len(edits) != 1 or item.get('range', {}).get('start') != {'line':0, 'character':0}:
                    raise CodeError(422, 'rename_unsupported', 'server whole-document rename profile mismatch')
                start, end = 0, len(texts[name])
            else:
                start, end = checked_range(from_server_range(item.get('range'), texts[name], encoding), texts[name])
            spans.append((start, end, item['newText']))
        spans.sort(key=lambda x: (x[0], x[1]))
        for previous, current in zip(spans, spans[1:]):
            if previous[1] > current[0] or previous[0] == current[0]:
                raise CodeError(422, 'rename_overlap', 'rename edits overlap')
        content = texts[name]
        for start, end, replacement in reversed(spans): content = content[:start] + replacement + content[end:]
        if not spans: continue
        total += len(content.encode())
        if len(content.encode()) > MAX_FILE or total > 2 * MAX_FILE or len(result) >= 200:
            raise CodeError(413, 'rename_limit', 'rename preview exceeds patch limits')
        result.append({'path': name, 'expected_digest': files[name]['digest'], 'content': content})
    return {'edits': sorted(result, key=lambda x:x['path']), 'applied': False}


COMPLETION_DEFAULTS = ('editRange', 'insertTextFormat', 'data')


def expand_completion_defaults(raw, limit):
    """Materialize negotiated 3.17 defaults before normalize or same-peer resolve.

    Copies are detached; explicit item fields win. Only displayed items expand,
    with a cumulative wire bound. Opaque data remains a same-server value.
    """
    if type(raw) is not dict or 'itemDefaults' not in raw:
        return raw
    if type(limit) is not int or not 1 <= limit <= 200:
        raise CodeError(400, 'language_limit', 'completion item limit is invalid')
    defaults = raw['itemDefaults']
    if type(defaults) is not dict or set(defaults) - set(COMPLETION_DEFAULTS) or 'applyKind' in raw:
        raise CodeError(422, 'completion_unsupported', 'completion defaults were not negotiated')
    values = raw.get('items')
    if type(values) is not list or any(type(v) is not dict for v in values[:limit]):
        raise CodeError(502, 'language_protocol', 'completion must return a list of items')
    if 'insertTextFormat' in defaults and (type(defaults['insertTextFormat']) is not int or defaults['insertTextFormat'] not in (1, 2)):
        raise CodeError(502, 'language_protocol', 'invalid default insert text format')
    def range_shape(value):
        if type(value) is not dict or set(value) != {'start', 'end'}:
            raise CodeError(502, 'language_protocol', 'invalid default completion range')
        for pos in value.values():
            if type(pos) is not dict or set(pos) != {'line', 'character'} or any(type(n) is not int or n < 0 for n in pos.values()):
                raise CodeError(502, 'language_protocol', 'invalid default completion position')
        a,b=value['start'],value['end']
        if a['line'] != b['line'] or a['character'] > b['character']:
            raise CodeError(502, 'language_protocol', 'default completion range must be ordered and single-line')
    edit_range = defaults.get('editRange')
    if 'editRange' in defaults:
        if type(edit_range) is dict and set(edit_range) == {'insert', 'replace'}:
            range_shape(edit_range['insert']); range_shape(edit_range['replace'])
            if edit_range['insert']['start'] != edit_range['replace']['start'] or edit_range['insert']['end']['character'] > edit_range['replace']['end']['character']:
                raise CodeError(502, 'language_protocol', 'default insert range is not a replace prefix')
        else:
            range_shape(edit_range)
    original = canonical(raw)
    if len(original) > MAX_WIRE:
        raise CodeError(413, 'language_limit', 'completion response exceeds wire limit')
    raw = json.loads(original)  # freeze caller/server objects before expansion
    defaults=raw.pop('itemDefaults'); values=raw['items']
    total=len(canonical(raw))
    for index,value in enumerate(values[:limit]):
        before=len(canonical(value));item=dict(value)
        for name in ('insertTextFormat', 'data'):
            if name not in item and name in defaults:item[name]=defaults[name]
        if 'textEdit' not in item and 'editRange' in defaults:
            text=item.get('textEditText', item.get('label'))
            if type(text) is not str:
                raise CodeError(502, 'language_protocol', 'default completion edit has no text')
            range_=defaults['editRange']
            item['textEdit']={'newText':text, **range_} if 'insert' in range_ else {'newText':text,'range':range_}
        total+=len(canonical(item))-before
        if total > MAX_WIRE:
            raise CodeError(413, 'language_limit', 'expanded completion response exceeds wire limit')
        values[index]=item
    return json.loads(canonical(raw))


def resolve_completions(client, raw, limit):
    """Resolve displayed items in the originating process, before retaining them.

    Opaque data and unknown fields go back to that process exactly. No commands
    run. Resolve may fill companion edits but cannot replace the primary edit.
    """
    raw = expand_completion_defaults(raw, limit)
    values = raw.get('items', []) if isinstance(raw, dict) else raw or []
    if type(values) is not list or any(type(item) is not dict for item in values[:limit]):
        raise CodeError(502, 'language_protocol', 'completion must return a list of items')
    if isinstance(raw, dict) and raw.get('itemDefaults'):
        raise CodeError(422, 'completion_unsupported', 'server completion item defaults were not negotiated')
    resolved = []
    mutable = {'detail', 'documentation', 'additionalTextEdits'}
    for item in values[:limit]:
        result = client.request('completionItem/resolve', item)
        if type(result) is not dict:
            raise CodeError(502, 'language_protocol', 'completion resolve must return an item')
        if (canonical({k: v for k, v in item.items() if k not in mutable})
                != canonical({k: v for k, v in result.items() if k not in mutable})):
            raise CodeError(502, 'completion_resolve_changed', 'resolve changed an immutable completion property')
        if item.get('additionalTextEdits') and canonical(item['additionalTextEdits']) != canonical(result.get('additionalTextEdits')):
            raise CodeError(502, 'completion_resolve_changed', 'resolve changed existing companion edits')
        resolved.append(result)
    values = resolved + values[limit:]
    result = {**raw, 'items': values} if isinstance(raw, dict) else values
    if len(canonical(result)) > MAX_WIRE:
        raise CodeError(413, 'language_limit', 'resolved completion response exceeds limit')
    return result, len(resolved)


def document_symbols(raw, tree, files, texts, path, limit, encoding):
    """Bounded preorder outline; flat locations never imply containment."""
    if raw is None: raw = []
    if type(raw) is not list:
        raise CodeError(502, 'language_protocol', 'document symbols must return a list')
    symbols, omitted, visited = [], 0, 0
    hierarchical = bool(raw) and type(raw[0]) is dict and 'location' not in raw[0]
    stack = [(v, None, 0) for v in reversed(raw)]
    while stack:
        value, parent, depth = stack.pop()
        visited += 1
        if visited > 4096 or depth > 64:
            raise CodeError(413, 'language_limit', 'document symbol outline exceeds its bound')
        if type(value) is not dict or ('location' not in value) != hierarchical:
            raise CodeError(502, 'language_protocol', 'mixed or malformed document symbols')
        name, kind = value.get('name'), value.get('kind')
        if (type(name) is not str or not name.strip() or len(name.encode()) > 1024 or '\x00' in name
                or type(kind) is not int or not 1 <= kind <= 26):
            raise CodeError(502, 'language_protocol', 'invalid document symbol name or kind')
        tags = value.get('tags', [])
        if type(tags) is not list or any(type(t) is not int or t != 1 for t in tags):
            raise CodeError(502, 'language_protocol', 'invalid document symbol tags')
        if 'deprecated' in value and type(value['deprecated']) is not bool:
            raise CodeError(502, 'language_protocol', 'invalid document symbol deprecation')
        children = value.get('children', [])
        if type(children) is not list or not hierarchical and children:
            raise CodeError(502, 'language_protocol', 'invalid document symbol children')
        target = path
        if not hierarchical:
            location = value.get('location')
            if type(location) is not dict:
                raise CodeError(502, 'language_protocol', 'invalid symbol location')
            target = relative_uri(location.get('uri'), tree)
            if target != path or target not in texts:
                omitted += 1
                continue
        range_ = from_server_range(value.get('range') if hierarchical else location.get('range'), texts[target], encoding)
        start, end = checked_range(range_, texts[target])
        selection = from_server_range(value.get('selectionRange'), texts[target], encoding) if hierarchical else range_
        a, b = checked_range(selection, texts[target])
        if not start <= a <= b <= end:
            raise CodeError(502, 'language_protocol', 'symbol selection is outside its range')
        item = {'name': name, 'kind': kind, 'path': target, 'range': range_, 'selection_range': selection,
                'source_digest': files[target]['digest'], 'parent_index': parent,
                'deprecated': value.get('deprecated', False) or 1 in tags}
        for key in ('detail', 'containerName'):
            if key in value and value[key] is not None:
                text = value[key]
                if type(text) is not str or len(text.encode()) > 4096 or '\x00' in text:
                    raise CodeError(502, 'language_protocol', 'invalid document symbol text')
                item['container_name' if key == 'containerName' else key] = text
        index = len(symbols)
        symbols.append(item)
        stack.extend((child, index, depth+1) for child in reversed(children))
    return {'symbols': symbols[:limit], 'hierarchical': hierarchical,
            'truncated': len(symbols) > limit, 'omitted_external': omitted, 'rendering': 'plain-text-only'}


def normalize(feature, raw, tree, files, texts, path, limit, encoding="utf-16", whole_document=False):
    if feature == 'signature_help':
        from .signature_help import normalize as signatures
        return signatures(raw, limit)
    if feature == 'document_symbols': return document_symbols(raw, tree, files, texts, path, limit, encoding)
    if feature == 'rename': return rename_preview(raw, tree, files, texts, encoding, whole_document)
    if feature in ('definition', 'references'):
        values = raw if isinstance(raw, list) else [raw] if raw else []
        matches, outside = [], 0
        for value in values:
            name = relative_uri(value.get('uri', value.get('targetUri')), tree)
            if name not in texts:
                outside += 1
                continue
            range_ = value.get('range', value.get('targetSelectionRange', value.get('targetRange')))
            range_ = from_server_range(range_, texts[name], encoding)
            checked_range(range_, texts[name])
            matches.append({'path':name,'range':range_, 'source_digest':files[name]['digest']})
        return {'locations':matches[:limit], 'truncated':len(matches)>limit, 'omitted_external':outside}
    if feature == 'diagnostics':
        result = []
        for value in raw or []:
            range_ = from_server_range(value.get('range'), texts[path], encoding, clip=True)
            checked_range(range_, texts[path])
            result.append({'range':range_, 'message':str(value.get('message',''))[:4000],
                           'severity':value.get('severity'), 'code':value.get('code'), 'source':value.get('source')})
        return {'diagnostics':result[:limit], 'truncated':len(result)>limit}
    if feature == 'completion':
        raw = expand_completion_defaults(raw, limit)
        values = raw.get('items', []) if isinstance(raw, dict) else raw or []
        if type(values) is not list or any(type(value) is not dict for value in values[:limit]):
            raise CodeError(502, 'language_protocol', 'completion must return a list of items')
        if isinstance(raw, dict) and raw.get('itemDefaults'):
            raise CodeError(422, 'completion_unsupported', 'server completion item defaults were not negotiated')
        items = []
        additional_total = 0
        for value in values[:limit]:
            item = {k:value[k] for k in ('label','kind','detail','insertText','insertTextFormat','sortText','filterText') if k in value}
            if 'textEdit' in value:
                edit = value['textEdit']
                if (type(edit) is not dict or type(edit.get('newText')) is not str
                        or set(edit) not in ({'newText', 'range'}, {'newText', 'insert', 'replace'})):
                    raise CodeError(502, 'language_protocol', 'completion has no plain text edit')
                keys = ('range',) if 'range' in edit else ('insert', 'replace')
                normalized = {'newText': edit['newText']}
                for key in keys:
                    normalized[key] = from_server_range(edit.get(key), texts[path], encoding)
                    checked_range(normalized[key], texts[path])
                item['textEdit'] = normalized
            additional = value.get('additionalTextEdits', [])
            if type(additional) is not list or len(additional) > 128:
                raise CodeError(422, 'completion_unsupported', 'completion additional edits exceed the supported bound')
            additional_total += len(additional)
            if additional_total > 512:
                raise CodeError(413, 'completion_limit', 'completion response exceeds the additional-edit budget')
            edits = []
            for edit in additional:
                if type(edit) is not dict or type(edit.get('newText')) is not str or set(edit) != {'range', 'newText'}:
                    raise CodeError(502, 'language_protocol', 'invalid additional completion text edit')
                range_ = from_server_range(edit.get('range'), texts[path], encoding)
                checked_range(range_, texts[path])
                edits.append({'range': range_, 'newText': edit['newText']})
            if 'command' in value or 'insertTextMode' in value:
                item['unsupported_snippet_effects'] = True
            item['additionalTextEdits'] = edits
            item['omitted_additional_edits'] = False
            if 'documentation' in value:
                documentation = value['documentation']
                if isinstance(documentation, str):
                    body, format_ = documentation, 'plaintext'
                elif (type(documentation) is dict and set(documentation) == {'kind', 'value'}
                      and documentation['kind'] in ('plaintext', 'markdown')
                      and type(documentation['value']) is str):
                    body, format_ = documentation['value'], documentation['kind']
                else:
                    raise CodeError(502, 'language_protocol', 'invalid completion documentation')
                if len(body.encode()) > 16384 or '\x00' in body:
                    raise CodeError(413, 'completion_limit', 'completion documentation exceeds limit')
                item['documentation'] = {'text': body, 'source_format': format_, 'rendering': 'plain-text-only'}
            # Never forward completion commands or executable markup.
            items.append(item)
        return {'items':items, 'truncated':len(values)>limit,
                'incomplete':bool(raw.get('isIncomplete',False)) if isinstance(raw,dict) else False}
    if feature == 'hover':
        return {'contents':raw.get('contents') if isinstance(raw,dict) else None,
                'rendering':'plain-text-or-sanitized-markdown-only'}
    raise CodeError(400, 'language_feature', 'unsupported language feature')


def runtime_files_identity(config):
    """Verify an optional exact operator-pinned dependency set; no caller paths."""
    if 'runtime_files' not in config:return None
    files=config['runtime_files']
    if type(files) is not dict or not 1<=len(files)<=512:
        raise CodeError(503,'language_configuration','runtime_files must be a nonempty bounded digest map')
    total=0
    for name,wanted in files.items():
        if (type(name) is not str or len(name.encode())>4096 or '\x00' in name or
                type(wanted) is not str or re.fullmatch('[a-f0-9]{64}',wanted) is None):
            raise CodeError(503,'language_configuration','invalid runtime file digest binding')
        path=pathlib.Path(name)
        if not path.is_absolute():raise CodeError(503,'language_configuration','runtime file paths must be absolute')
        try:
            info=path.lstat()
            if path.resolve()!=path or not stat.S_ISREG(info.st_mode):
                raise CodeError(409,'language_runtime_changed','runtime file is not a direct regular file')
            total+=info.st_size
            if info.st_size>32*1024*1024 or total>128*1024*1024:
                raise CodeError(503,'language_configuration','runtime file byte limits exceeded')
            with path.open('rb') as stream:data=stream.read(32*1024*1024+1)
            if len(data)!=info.st_size or digest(data)!=wanted:
                raise CodeError(409,'language_runtime_changed','operator-pinned runtime file changed')
        except OSError:
            raise CodeError(409,'language_runtime_changed','operator-pinned runtime file unavailable') from None
    return digest(canonical(files))


def runtime_identity(config):
    runtime_files_identity(config)
    argv = config.get('argv')
    if not isinstance(argv,list) or not argv or any(not isinstance(a,str) or not a or '\x00' in a for a in argv) or not pathlib.Path(argv[0]).is_absolute():
        raise CodeError(503, 'language_configuration', 'operator language server argv is invalid')
    executable = pathlib.Path(argv[0])  # Keep venv launcher path; resolving loses environment.
    if not executable.is_file(): raise CodeError(503, 'language_unavailable', 'configured language server is unavailable')
    executable_digest, config_digest = digest(executable.read_bytes()), digest(canonical(config))
    timeout = config.get('timeout_seconds', 20)
    if type(timeout) not in (int,float) or not 1 <= timeout <= 30:
        raise CodeError(503, 'language_configuration', 'language query timeout must be 1 to 30 seconds')
    resolve_enabled = config.get('completion_resolve_enabled', False)
    if type(resolve_enabled) is not bool:
        raise CodeError(503, 'language_configuration', 'completion_resolve_enabled must be a boolean')
    return argv, executable, executable_digest, config_digest, timeout, resolve_enabled


def query(root, config, payload, files, texts, session=None):
    argv, executable, executable_digest, config_digest, timeout, resolve_enabled = runtime_identity(config)
    client = session.get('client') if session is not None else None
    try:
        tree = root/'tree'
        if client is None:
            client = Stdio(argv, root, timeout)
            if session is not None: session['client'] = client
            initialized = client.request('initialize', {'processId':None, 'rootUri':tree.as_uri(),
                'workspaceFolders':[{'uri':tree.as_uri(),'name':'snapshot'}],
                'capabilities':{'general':{'positionEncodings':['utf-16']},
                                'textDocument':{'publishDiagnostics':{'relatedInformation':False},
                                    'signatureHelp':{'signatureInformation':{'documentationFormat':['plaintext'],
                                    'parameterInformation':{'labelOffsetSupport':True}, 'activeParameterSupport':True}},
                                    'documentSymbol':{'hierarchicalDocumentSymbolSupport':True,
                                    'symbolKind':{'valueSet':list(range(1,27))}, 'tagSupport':{'valueSet':[1]}},
                                    'completion':{'completionList':{'itemDefaults':list(COMPLETION_DEFAULTS)},'completionItem':{'snippetSupport':False,'insertReplaceSupport':True,
                                    **({'resolveSupport': {'properties': ['detail', 'documentation', 'additionalTextEdits']}}
                                       if resolve_enabled else {})}}}},
                'initializationOptions':config.get('initialization_options', {})})
            caps = initialized.get('capabilities', {})
            client.notify('initialized', {})
            if config.get('settings'): client.notify('workspace/didChangeConfiguration', {'settings':config['settings']})
            if session is not None:
                session.update(capabilities=caps, opened=set(), executable_digest=executable_digest, config_digest=config_digest)
        else:
            if session['executable_digest'] != executable_digest or session['config_digest'] != config_digest:
                raise CodeError(409, 'language_runtime_changed', 'language session runtime changed')
            caps = session['capabilities']
            client.deadline = min(time.monotonic()+timeout, session['expires'])
        if caps.get('positionEncoding', 'utf-16') != 'utf-16':
            raise CodeError(422, 'language_encoding', 'language server requires unsupported position encoding')
        encoding = config.get('position_encoding', 'utf-16')
        if encoding not in ('utf-16', 'python-codepoint'):
            raise CodeError(503, 'language_configuration', 'unsupported configured server position profile')
        feature, path = payload['feature'], payload['path']
        if feature in CAPABILITIES and not offered(caps, CAPABILITIES[feature]):
            raise CodeError(422, 'language_unsupported', 'server does not advertise requested feature')
        uri = (tree/path).as_uri()
        opened = session['opened'] if session is not None else set()
        if feature == 'diagnostics' and path in opened:
            client.notify('textDocument/didClose', {'textDocument':{'uri':uri}})
            opened.remove(path)
            client.notifications = [n for n in client.notifications if not
                (n.get('method') == 'textDocument/publishDiagnostics' and n.get('params', {}).get('uri') == uri)]
        if path not in opened:
            client.notify('textDocument/didOpen', {'textDocument':{'uri':uri,'languageId':config['language_id'],'version':1,'text':texts[path]}})
            opened.add(path)
        if feature == 'diagnostics': raw = client.diagnostics(uri)
        elif feature == 'document_symbols':
            raw = client.request(METHODS[feature], {'textDocument':{'uri':uri}})
        else:
            position = {'line':payload['line'], 'character':payload['character']}
            if encoding == 'python-codepoint':
                absolute = offset(texts[path], position)
                line_start = sum(map(len,source_lines(texts[path])[:position['line']]))
                position = {'line':position['line'],'character':absolute-line_start}
            params = {'textDocument':{'uri':uri},'position':position}
            if feature == 'references': params['context'] = {'includeDeclaration':True}
            if feature == 'rename': params['newName'] = payload['new_name']
            raw = client.request(METHODS[feature], params)
        resolution = None
        if feature == 'completion':
            provider = caps.get('completionProvider')
            supported = type(provider) is dict and provider.get('resolveProvider') is True
            count = 0
            if resolve_enabled and supported:
                raw, count = resolve_completions(client, raw, payload.get('limit', 50))
            resolution = {'enabled': resolve_enabled, 'server_supported': supported,
                          'resolved_items': count, 'mode': 'same-session-eager-displayed-items' if resolve_enabled and supported else 'not-resolved',
                          'lazy_selection': False, 'commands_executed': False}
        result = normalize(feature, raw, tree, files, texts, path, payload.get('limit',50), encoding, config.get('rename_edit_profile') == 'pylsp-jedi-whole-document')
        if resolution is not None: result['resolution'] = resolution
        if time.monotonic() > client.deadline:
            raise CodeError(504, 'language_timeout', 'language analysis exceeded query deadline')
        if digest(canonical(config)) != config_digest or digest(executable.read_bytes()) != executable_digest:
            raise CodeError(409, 'language_runtime_changed', 'language server configuration or executable changed during query')
        runtime_files_digest=runtime_files_identity(config)
        # Never accept server side modifications as canonical source or valid analysis.
        for name, entry in files.items():
            target = tree/name
            if target.is_symlink() or not target.is_file() or digest(target.read_bytes()) != entry['digest']:
                raise CodeError(409, 'language_snapshot_changed', 'language server modified snapshot input')
        return {'result':result, 'server_capabilities':[f for f,k in CAPABILITIES.items() if offered(caps, k)],
                'position_encoding':'utf-16', 'server_position_profile':encoding, 'rename_edit_profile':config.get('rename_edit_profile', 'lsp-text-edits'), 'server_executable_digest':executable_digest,
                'server_config_digest':config_digest,'server_runtime_files_digest':runtime_files_digest,
                'server_runtime_files_count':len(config.get('runtime_files',{})),
                'server_dependency_identity_profile':'operator-pinned-file-set' if runtime_files_digest is not None else 'not-pinned'}
    except (KeyError, TypeError, AttributeError, ValueError):
        raise CodeError(502, 'language_protocol', 'language server returned an unsupported result') from None
    except OSError:
        raise CodeError(503, 'language_unavailable', 'language server could not start or communicate') from None
    finally:
        if client is not None and session is None: client.close()
