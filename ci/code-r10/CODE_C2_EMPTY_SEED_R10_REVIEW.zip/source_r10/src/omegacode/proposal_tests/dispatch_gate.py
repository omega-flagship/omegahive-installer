"""Uninstalled purpose dispatch CAS. No process starts or authority conversion."""
import json
from omegacode.common import canonical, digest
from omegacode.proposal_launch_custody import Custody
from .proposal_host_wire import launch_binding, fail
from .launch_admission import candidate
KIND = 'proposal_dispatch_binding'

def claim(service, authority, principal, host, launch_id):
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    p = g['proposal_test']
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + p['test_id'] + '/launches')
    custody = Custody(service.store)
    original = custody.get(launch_id)
    if original['test_id'] != p['test_id'] or original['binding'] != launch_binding(g):
        fail('proposal_dispatch_binding')
    if original['state'] != 'admitted':
        return None
    if not any((original['argv'][:len(prefix)] == prefix for prefix in g['argv_prefixes'])) or original['runtime_seconds'] > min(g['max_runtime_seconds'], p['allowance']['per_launch_max_runtime_seconds']):
        fail('proposal_dispatch_limits')
    (saved, bound, fork) = candidate(service, authority, principal)
    parent = service.workspace(p['parent']['workspace_id'])
    records = [(kind, service.store.get(kind, id_)) for (kind, id_) in [('suggestion', p['proposal']['proposal_id']), ('suggestion_scope', p['origin_scope']['scope_id']), ('suggestion_provenance', p['proposal']['proposal_id'])]]
    scope = json.loads(service.store.read_blob(records[1][1]['digest'], parent['id']))
    files = service.manifest(fork)['files']
    execution = dict(workspace_id=fork['id'], generation=fork['generation'], tree_digest=fork['tree_digest'], grant_id=g['id'], actor=principal.actor)
    projection = dict(id=launch_id, run_id=original['run_id'], nonce=original['nonce'], host_binding=original['binding'], execution_binding=execution, claims_digest=digest(claims), argv_digest=digest(canonical(original['argv'])), runtime_seconds=original['runtime_seconds'], accepted_source=False, process_started=False)

    def live(row):
        service._check_owner(required=True)
        return host.dispatch_gate(g, row)

    def local(row):
        service._check_owner(required=True)
        if canonical(g) != claims or row != original or service.workspace(parent['id']) != parent or (service.workspace(fork['id']) != fork) or (service.store.get('proposal_preparation', saved['id']) != saved) or (service.store.get('proposal_preparation_bind', bound['id']) != bound):
            return False
        for (kind, record) in records:
            if service.store.get(kind, record['id']) != record:
                return False
            data = service.store.read_blob(record['digest'], parent['id'])
            if digest(data) != record['digest']:
                return False
        if service.manifest(fork)['files'] != files:
            return False
        for meta in files.values():
            data = service.store.read_blob(meta['digest'], fork['id'])
            if digest(data) != meta['digest'] or len(data) != meta['size']:
                return False
        service._context_current(parent, scope['context_selection'])
        if canonical(g) != claims:
            return False
        service.store.put(KIND, projection)
        return True
    return custody.claim_dispatch(launch_id, original['revision'], live, commit_check=local)
