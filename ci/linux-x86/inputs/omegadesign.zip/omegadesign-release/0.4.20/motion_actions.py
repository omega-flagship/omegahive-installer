"""Candidate motion execution; caller supplies host-authorized source custody."""
import hashlib,json


async def execute_motion(ctx, source):
    if not isinstance(source,bytes) or not source or len(source)>20*1024*1024:
        raise ValueError('Bounded host-resolved motion source required')
    runner=getattr(ctx,'sandbox_run',None)
    if not callable(runner):raise ValueError('Host sandbox capability unavailable')
    names=['editable-motion.json','animated-motion.svg','manifest.json']
    result=await runner('motion-sandbox-cli.mjs',inputs={'source.json':source},outputs=names,
                       runtime='node',bundle='tools',cpu_seconds=10,file_bytes=30*1024*1024,timeout=30)
    if result.get('exit')!=0 or result.get('stdout_truncated') or result.get('missing_outputs'):
        raise ValueError('Motion sandbox did not produce complete output')
    outputs=result.get('outputs',{})
    if set(outputs)!=set(names) or any(not isinstance(raw,bytes) or not raw for raw in outputs.values()) or sum(map(len,outputs.values()))>30*1024*1024:
        raise ValueError('Bounded motion outputs required')
    if outputs['editable-motion.json']!=source:raise ValueError('Motion source bytes changed')
    manifest=json.loads(outputs['manifest.json'])
    if manifest.get('schema')!='omega-motion-delivery-1' or manifest.get('adopted') is not False or manifest.get('editable') is not True or manifest.get('independent_review') is not False or set(manifest.get('files',{}))!=set(names[:2]):
        raise ValueError('Motion delivery manifest invalid')
    for name,mime in [('editable-motion.json','application/json'),('animated-motion.svg','image/svg+xml')]:
        raw=outputs[name];record=manifest['files'][name]
        if record!={'digest':'sha256:'+hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mime':mime}:
            raise ValueError('Motion output custody differs')
    return {'outputs':outputs,'manifest':manifest,'custody':'host-commit-required','adopted':False}


async def act_motion(ctx, params):
    import asyncio,contextlib
    from .studio_actions import held,read_source
    command=getattr(ctx,'command',None) or {}
    if not isinstance(params,dict) or not {'goal_id','source'}<=set(params) or set(params)-{'goal_id','source','base_revision'} or params.get('base_revision') is not None or not command.get('record_id') or not command.get('idempotency_key'):
        raise ValueError('Bound motion action identity required')
    goal=params['goal_id'];ref=params['source']
    def admit():
        held(ctx,goal)
        return read_source(ctx,ref)
    raw=admit()
    if (getattr(ctx,'actor',None) or {}).get('recovery'):
        recorded=command.get('recorded_result')
        if not isinstance(recorded,dict) or recorded.get('status')!='done':raise ValueError('Unknown prior effects require custody reconciliation; no replay')
        data=recorded['data'];out=data['output'];revision=ctx.read_revision(out['artifact_id'],out['revision']);body=revision['body'].encode()
        if revision['digest']!=out['digest'] or 'sha256:'+hashlib.sha256(body).hexdigest()!=out['digest']:raise ValueError('Recorded motion revision differs')
        manifest=json.loads(body)
        if manifest.get('action_record')!=command['record_id'] or manifest.get('source')!=ref or manifest.get('goal_id')!=goal or manifest.get('operation')!='motion' or manifest.get('adopted') is not False or data.get('assets')!=manifest.get('assets') or data.get('adopted') is not False:
            raise ValueError('Recorded motion binding differs')
        for asset in manifest['assets']:
            stored=ctx.read_asset(asset['sha256'],out['artifact_id'],out['revision'])
            if stored['mime']!=asset['mime'] or stored['bytes']!=asset['bytes'] or len(stored['data'])!=asset['bytes'] or hashlib.sha256(stored['data']).hexdigest()!=asset['sha256']:raise ValueError('Recorded motion asset custody differs')
        admit();return recorded
    task=asyncio.create_task(execute_motion(ctx,raw))
    try:
        while not task.done():
            admit();await asyncio.wait({task},timeout=.1)
        result=await task;admit()
        mimes={'editable-motion.json':'application/json','animated-motion.svg':'image/svg+xml','manifest.json':'application/json'}
        assets=[{'sha256':hashlib.sha256(result['outputs'][name]).hexdigest(),'bytes':len(result['outputs'][name]),'mime':mime} for name,mime in mimes.items()]
        manifest={'schema':'omega-motion-artifact-1','source':ref,'goal_id':goal,'operation':'motion','action_record':command['record_id'],'assets':assets,'originals':[assets[0],assets[2]],'previews':[assets[1]],'delivery':result['manifest'],'adopted':False}
        published=ctx.publish('motion-export','Editable motion',json.dumps(manifest,sort_keys=True,separators=(',',':')),assets=[{'data':result['outputs'][name],'name':name,'mime':mime} for name,mime in mimes.items()])
        return {'status':'done','data':{'output':{k:published[k] for k in ['artifact_id','revision','digest']},'assets':published['assets'],'adopted':False}}
    finally:
        if not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):await task
