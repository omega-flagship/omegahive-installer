"""Own closed profile prototype, only trusted-helper-owned inherited PTY."""
import json,os,re,stat
from pathlib import Path
from .confinement import profile as batch_profile


def profile(workspace,python,slave_fd):
    # No caller-provided device path. A trusted helper must create and own the fd.
    if type(slave_fd) is not int or slave_fd<0 or not os.isatty(slave_fd):
        raise ValueError('owned live slave PTY descriptor required')
    descriptor=os.fstat(slave_fd);tty=Path(os.ttyname(slave_fd))
    if not stat.S_ISCHR(descriptor.st_mode) or not re.fullmatch(r'/dev/ttys[0-9]+',str(tty)):
        raise ValueError('exact macOS slave PTY required')
    current=tty.stat()
    if current.st_rdev!=descriptor.st_rdev or not stat.S_ISCHR(current.st_mode):
        raise ValueError('PTY path/descriptor mismatch')
    policy=batch_profile(workspace,python)
    policy+='(allow file-read* (literal "/usr/share/locale/C.UTF-8/LC_CTYPE"))\n'
    policy+='(allow file-read-metadata (literal "/usr/share") (literal "/usr/share/locale") (literal "/usr/share/locale/C.UTF-8"))\n'
    return policy+'(allow process-exec (literal "/bin/bash"))\n'+'(allow file-read* (literal "/bin/bash"))\n'+'(allow file-read* file-write* file-ioctl (literal '+json.dumps(str(tty))+'))\n'
