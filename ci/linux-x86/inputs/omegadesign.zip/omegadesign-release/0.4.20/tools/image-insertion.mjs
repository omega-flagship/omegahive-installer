// Convert host-recovered bytes to an editable image. Receipt is provenance,
// never permission to recover, publish, or adopt the source.
import {validate} from './scene.mjs';
export async function imageInsertion(scene,{id,x,y,width,height,alt},bytes,receipt){
  validate(scene);
  if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length>10*1024*1024)throw Error('Bounded image bytes required');
  if(!receipt||receipt.custody!=='private-host-staging'||!['image/png','image/jpeg'].includes(receipt.mime)||receipt.bytes!==bytes.length||typeof receipt.reservation_id!=='string'||!receipt.reservation_id||receipt.reservation_id.length>128)throw Error('Recovered image receipt required');
  if(typeof alt!=='string'||!alt.trim()||alt.length>2000)throw Error('Image description required');
  const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(digest!==receipt.sha256)throw Error('Image bytes differ from receipt');
  let encoded='';
  for(let i=0;i<bytes.length;i+=32768)encoded+=String.fromCharCode(...bytes.subarray(i,i+32768));
  const value={id,kind:'image',x,y,width,height,alt,src:`data:${receipt.mime};base64,${btoa(encoded)}`,provenance:{schema:'omega-image-provenance-1',reservation_id:receipt.reservation_id,sha256:digest,requested_model:receipt.requested_model??null,resolved_model:receipt.resolved_model??null,prompt_sha256:receipt.prompt_sha256??null,quote_id:receipt.quote_id??null}};
  validate({...scene,elements:[...scene.elements,value]});
  return {op:'add',element:id,value};
}
