"""Frozen one-shot syntax/metadata query worker, never repository evaluation."""
import sys,json,base64,hashlib,resource
from pathlib import Path

def main():
    resource.setrlimit(resource.RLIMIT_CPU,(5,5))
    resource.setrlimit(resource.RLIMIT_FSIZE,(4*1024*1024,4*1024*1024))
    raw=sys.stdin.buffer.read(12*1024*1024+1)
    if len(raw)>12*1024*1024:raise ValueError('request bound')
    request=json.loads(raw)
    if set(request)!={'sources','kind','symbol','runtime'}:raise ValueError('closed parser request')
    sys.path.insert(0,str(Path(__file__).parent))
    from metta_source_facts import build,query
    import hyperon.base,hyperon.atoms,hyperonpy
    expected=request['runtime']
    if hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()!=expected['executable_digest']:
        raise ValueError('loaded executable identity mismatch')
    for module in (hyperon.base,hyperon.atoms,hyperonpy):
        loaded=Path(module.__file__).resolve()
        relative=str(loaded.relative_to(Path(expected['root']).resolve()))
        if hashlib.sha256(loaded.read_bytes()).hexdigest()!=expected['files'].get(relative):
            raise ValueError('loaded native/parser module identity mismatch')
    sources={p:base64.b64decode(v,validate=True) for p,v in request['sources'].items()}
    snapshot=build(sources)
    result=query(snapshot,request['kind'],request['symbol'],sources)
    result['sources']=snapshot['sources'];result['diagnostics']=snapshot['diagnostics']
    result['runtime_identity_digest']=hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    out=json.dumps(result,sort_keys=True,separators=(',',':')).encode()
    if len(out)>4*1024*1024:raise ValueError('response bound')
    sys.stdout.buffer.write(out)

if __name__=='__main__':main()
