// Editable React source handoff; running/building belongs to the recipient project.
import {validateUI,renderUI} from './ui-spec.mjs';
import {createHash} from 'node:crypto';
export function verifyComponentLibrary(library){
 if(library?.schema!=='omega-react-field-library-1'||typeof library.id!=='string'||!library.id.trim()||!Number.isSafeInteger(library.revision)||library.revision<1||library.contract!=='omega-onboarding-fields-1'||typeof library.source!=='string'||!library.source.trim()||Buffer.byteLength(library.source)>256*1024)throw Error('Invalid recipient component library');
 const measured='sha256:'+createHash('sha256').update(library.source).digest('hex');
 if(library.digest!==measured)throw Error('Recipient component source digest differs');
 return {id:library.id,revision:library.revision,digest:measured,contract:library.contract};
}
export function reactHandoff(input,library=null){
 const ui=validateUI(input);
 const dependency=library?verifyComponentLibrary(library):null;
 const components=`import React from 'react';
const h=React.createElement;
export function NameField({copy,value,onChange,error,inputRef}){return h('div',null,h('label',{htmlFor:'name'},copy.name_label),h('input',{id:'name',type:'text',maxLength:120,autoComplete:'off',required:true,value,onChange,ref:inputRef,'aria-invalid':!!error,'aria-describedby':'name-error'}),h('p',{id:'name-error',className:'error',hidden:!error},error));}
export function AvailabilityField({copy,selected,onToggle,error,inputRef}){return h('fieldset',{'aria-describedby':'availability-error'},h('legend',null,copy.availability_label),...copy.options.map((option,index)=>h('label',{key:index,htmlFor:'option-'+index},h('input',{id:'option-'+index,type:'checkbox',checked:selected.includes(index),onChange:()=>onToggle(index),ref:index===0?inputRef:undefined,'aria-invalid':!!error}),option)),h('p',{id:'availability-error',className:'error',hidden:!error},error));}
`;
 const app=`import React,{useState,useRef} from 'react';
import spec from './spec.mjs';
import {NameField,AvailabilityField} from './components.mjs';
const h=React.createElement;
export function validateChoices(name,selected){return {name:!name.trim()?spec.form.name_error:'',availability:!selected.length?spec.form.availability_error:''};}
export default function Onboarding(){
 const [name,setName]=useState(''),[selected,setSelected]=useState([]),[errors,setErrors]=useState({}),[result,setResult]=useState(null),nameRef=useRef(null),optionRef=useRef(null),copy=spec.form;
 function submit(event){event.preventDefault();const next=validateChoices(name,selected);setErrors(next);if(next.name||next.availability){setResult(null);(next.name?nameRef:optionRef).current?.focus();}else setResult({name:name.trim(),options:selected.map(i=>copy.options[i])});}
 return h('main',null,h('section',null,h('p',null,'Neighbourhood garden · proposal'),h('h1',null,spec.title),h('p',null,spec.introduction),h('p',{className:'hint'},'A local preview. Your details stay in this page.')),h('form',{onSubmit:submit,noValidate:true},h(NameField,{copy,value:name,onChange:e=>setName(e.target.value),error:errors.name,inputRef:nameRef}),h(AvailabilityField,{copy,selected,onToggle:i=>setSelected(previous=>previous.includes(i)?previous.filter(n=>n!==i):[...previous,i].sort((a,b)=>a-b)),error:errors.availability,inputRef:optionRef}),h('button',{type:'submit'},copy.button),h('div',{id:'result',role:'status','aria-live':'polite'},result?h(React.Fragment,null,copy.success,h('ul',null,h('li',null,result.name),...result.options.map((o,i)=>h('li',{key:i},o)))):errors.name||errors.availability?'Please check the highlighted fields.':'')));
}
`;
 return {'spec.mjs':'export default '+JSON.stringify(ui,null,2)+';\n','components.mjs':library?library.source:components,'Onboarding.mjs':app,'onboarding.css':renderUI(ui).split('<style>')[1].split('</style>')[0]+'\n','dependencies.json':JSON.stringify({schema:'omega-react-handoff-dependencies-1',component_library:dependency,component_exports:['NameField','AvailabilityField'],review:'unverified',adopted:false},null,2)+'\n','README.txt':'Import Onboarding from ./Onboarding.mjs and onboarding.css into your existing React application. React is a peer dependency supplied by that project. NameField and AvailabilityField are reusable editable components. The omega-onboarding-fields-1 contract requires the copy/value/onChange/error/inputRef props for NameField and copy/selected/onToggle/error/inputRef for AvailabilityField. Supplied library source is retained byte for byte and must be reviewed by the recipient before execution; a digest proves identity, not safety or compatibility. No network submission or persistence is implemented by the generated app. Original criteria remain in spec.mjs. Recipient runtime behavior requires qualification.\n'};
}
