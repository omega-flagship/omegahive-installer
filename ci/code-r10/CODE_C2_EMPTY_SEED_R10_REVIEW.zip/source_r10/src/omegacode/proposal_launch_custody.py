"""Local original-launch custody in the existing Store, not a host grant/ledger.

No route, capability parser, scheduler, settlement or process spawn is installed.
The future service adapter supplies owner-retained preparation and live admission
checks. A returned dispatch claim may be used once; reading a row never claims it.
"""
import copy,re
from omegacode.common import CodeError,canonical,digest,ident,stamp

KIND='proposal_launch'

def fail(code):raise CodeError(409,code,'original launch custody refused')

def execution_binding(store,row):
    """Resolve owner-retained executor identity; no authority or cleanup proof."""
    binding=row['binding']
    if 'workspace_id' in binding and 'fork' not in binding:
        return copy.deepcopy(binding) # unchanged ordinary reserved-run profile
    projection=store.get('proposal_dispatch_binding',row['id'])
    if (projection['id']!=row['id'] or projection['run_id']!=row['run_id']
            or projection['nonce']!=row['nonce'] or projection['host_binding']!=binding
            or projection['argv_digest']!=digest(canonical(row['argv']))
            or projection['runtime_seconds']!=row['runtime_seconds']
            or row['ever_spawning'] is not True):fail('execution_binding')
    native=projection['execution_binding']
    if (set(native)!={'workspace_id','generation','tree_digest','grant_id','actor'}
            or native['workspace_id']!=binding['fork']['workspace_id']
            or native['actor']!=binding['controller_id']
            or type(native['generation']) is not int or native['generation']!=2
            or type(native['tree_digest']) is not str or re.fullmatch(r'[0-9a-f]{64}',native['tree_digest']) is None
            or type(native['grant_id']) is not str or not native['grant_id']):fail('execution_binding')
    preparation=store.get('proposal_preparation',row['test_id'])
    if (preparation['id']!=row['test_id'] or native['workspace_id']!=preparation['fork_workspace_id']
            or native['tree_digest']!=preparation['test_tree_digest']
            or binding['fork']['preparation_digest']!='sha256:'+preparation['preparation_digest']):fail('execution_binding')
    return copy.deepcopy(native)

class Custody:
    def __init__(self,store):self.store=store

    def request(self,test_id,launch_key,binding,argv,runtime_seconds):
        if (type(test_id) is not str or not re.fullmatch(r'pt_[a-f0-9]{24}',test_id)
                or type(launch_key) is not str or not re.fullmatch(r'[A-Za-z0-9_.:-]{8,120}',launch_key)
                or type(binding) is not dict or not binding
                or type(argv) is not list or not argv or any(type(a) is not str or '\0' in a for a in argv)
                or type(runtime_seconds) is not int or not 1<=runtime_seconds<=600):
            raise CodeError(400,'launch_shape','exact bounded original launch required')
        payload={'test_id':test_id,'launch_key':launch_key,'binding':binding,
                 'argv':argv,'runtime_seconds':runtime_seconds}
        fingerprint=digest(canonical(payload));id_='pl_'+digest(canonical([test_id,launch_key]))
        with self.store.transaction():
            existing=[r for r in self.store.list(KIND) if r['id']==id_]
            if existing:
                if existing[0]['fingerprint']!=fingerprint:fail('operation_conflict')
                return existing[0]
            if any(r['test_id']==test_id and r['state'] in ('spawning','unknown')
                   for r in self.store.list(KIND)):
                fail('launch_unresolved')
            run_id=ident('run');nonce=ident('launch')
            row={**copy.deepcopy(payload),'id':id_,'fingerprint':fingerprint,'revision':1,
                 'state':'requested','hold_id':None,'run_id':run_id,'nonce':nonce,
                 'spawn_marker':str(self.store.root/'runs'/run_id),'ever_spawning':False,
                 'created_at':stamp(),'hold_recovery_required':True}
            self.store.put(KIND,row)
            return copy.deepcopy(row)

    def get(self,id_):return self.store.get(KIND,id_)

    def _put(self,row):
        row['revision']+=1;self.store.put(KIND,row)
        return copy.deepcopy(row)

    def attach_hold(self,id_,projection):
        """Trusted adapter's normalized existing-host-hold projection, not HTTP parsing.

        Recovery may attach an old hold after local never-spawning closure, but
        can never reopen it. This does not release a reservation or grant a run.
        """
        fields={'hold_id','test_id','launch_key','argv_digest','runtime_seconds','state'}
        if (type(projection) is not dict or set(projection)!=fields
                or type(projection['hold_id']) is not str or not re.fullmatch(r'ph_[a-f0-9]{24}',projection['hold_id'])
                or projection['state'] not in ('dispatched','released','settled','unknown')
                or type(projection['runtime_seconds']) is not int):fail('hold_shape')
        with self.store.transaction():
            row=self.get(id_)
            if (projection['test_id']!=row['test_id'] or projection['launch_key']!=row['launch_key']
                    or projection['argv_digest']!=digest(canonical(row['argv']))
                    or projection['runtime_seconds']!=row['runtime_seconds']):fail('hold_binding')
            hold_id=projection['hold_id']
            if row['hold_id'] is not None:
                if row['hold_id']!=hold_id:fail('hold_conflict')
                return row # acknowledgement only, including ended/unknown records
            if any(r['id']!=id_ and r['hold_id']==hold_id for r in self.store.list(KIND)):fail('hold_consumed')
            if row['state'] not in ('requested','not_started'):fail('launch_state')
            row['hold_id']=hold_id;row['hold_recovery_required']=False
            if row['state']=='requested':
                row['state']='admitted' if projection['state']=='dispatched' else 'not_started'
                if row['state']=='not_started':row['reason']='host_hold_not_dispatched'
            return self._put(row)

    def claim_dispatch(self,id_,expected_revision,check_admission,*,commit_check=None):
        """CAS before spawn. Callback is future trusted service live gate, not a flag.

        Must revalidate exact host claims, open test/lease AND current dispatched
        hold. No cached admission answer is authority. Exceptions fail closed and
        leave this unclaimed for explicit recovery. The callback is not installed
        or represented as a real host check by this standalone component.
        """
        if commit_check is not None and not callable(commit_check):fail('dispatch_commit_check')
        snapshot=self.get(id_)
        if snapshot['state']!='admitted' or snapshot['revision']!=expected_revision:return None
        active=check_admission(copy.deepcopy(snapshot))
        with self.store.transaction():
            row=self.get(id_)
            if row['state']!='admitted' or row['revision']!=expected_revision:return None
            if any(r['id']!=id_ and r['test_id']==row['test_id'] and r['state'] in ('spawning','unknown')
                   for r in self.store.list(KIND)):
                fail('launch_unresolved')
            if active is not True:
                row.update(state='not_started',reason='admission_inactive')
                self._put(row);return None
            if row['ever_spawning'] or not row['hold_id']:fail('dispatch_consumed')
            # Service-local predicate executes under the same CAS transaction;
            # it must perform no provider wait or effect outside this Store.
            if commit_check is not None and commit_check(copy.deepcopy(row)) is not True:
                fail('dispatch_binding_changed')
            row.update(state='spawning',ever_spawning=True,dispatch_committed_at=stamp())
            return self._put(row)

    def running(self,id_,run_id,pid,process_birth):
        if type(pid) is not int or pid<=1 or type(process_birth) is not str or not process_birth:fail('process_identity')
        with self.store.transaction():
            row=self.get(id_)
            if run_id!=row['run_id']:fail('run_mismatch')
            if row['state']=='running':
                if row['pid']!=pid or row['process_birth']!=process_birth:fail('process_mismatch')
                return row
            if row['state']!='spawning':fail('launch_state')
            row.update(state='running',pid=pid,process_birth=process_birth)
            return self._put(row)

    def recover_before_serving(self):
        """Exclusive service-start recovery; no absence-based spawn or release.

        Unknown spawning records retain original run/root/nonce for the service's
        independent process observer. Requested holds remain discoverable by the
        original request even if their answer was lost; no automatic settlement.
        """
        changed=[]
        with self.store.transaction():
            for row in self.store.list(KIND):
                if row['state'] in ('requested','admitted'):
                    row.update(state='not_started',reason='startup_never_spawning')
                    changed.append(self._put(row))
                elif row['state']=='spawning':
                    row.update(state='unknown',reason='startup_dispatch_unresolved')
                    changed.append(self._put(row))
        return changed
