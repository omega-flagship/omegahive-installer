"""C01 blank-seed first-app journey through R10 HTTP API; test-only probe."""
import hashlib
import subprocess

import pytest
from fastapi.testclient import TestClient

pytest_plugins = ["test_service"]

from omegacode.api import create_app
from test_service import principal


def git(repo, *args):
    return subprocess.run(
        ["git", "-C", str(repo), *args], check=True, capture_output=True
    ).stdout


def test_r10_blank_seed_to_person_approved_first_app_and_snapshot_export(service, repo):
    # Make the disposable registered seed an empty tree before creating a workspace.
    git(repo, "rm", "-f", "calculator.py", "test_calculator.py")
    git(repo, "-c", "user.name=Test", "-c", "user.email=test@example.invalid",
        "commit", "-qm", "empty synthetic first-app seed")
    seed_head = git(repo, "rev-parse", "HEAD").strip()
    seed_status = git(repo, "status", "--porcelain")
    assert git(repo, "ls-tree", "-r", "--name-only", "HEAD").strip() == b""

    client = TestClient(create_app(service))
    person, grant = principal(service)
    headers = {"Authorization": "Bearer " + grant["token"]}

    created = client.post("/v1/workspaces", headers=headers, json={
        "operation_id": "c01-open-empty-seed",
        "task_id": "goal-test",
        "repository_id": "synthetic",
        "base_commit": "HEAD",
    })
    assert created.status_code == 201, created.text
    ws = created.json()
    assert ws["generation"] == 1
    assert ws["base_commit"] == seed_head.decode()
    assert client.get(f"/v1/workspaces/{ws['id']}/tree", headers=headers).json()["files"] == []

    scope_response = client.post(f"/v1/workspaces/{ws['id']}/suggestion-scopes", headers=headers, json={
        "operation_id": "c01-scope-first-app",
        "schema": "omegacode-suggestion-scope-request-v2",
        "expected_generation": ws["generation"],
        "expected_tree_digest": ws["tree_digest"],
        "ranges": {},
        "create_files": {"main.py": {"max_bytes": 64}},
        "max_total_create_bytes": 64,
    })
    assert scope_response.status_code == 200, scope_response.text
    scope = scope_response.json()

    proposal_response = client.post(f"/v1/workspaces/{ws['id']}/suggestions", headers=headers, json={
        "operation_id": "c01-propose-first-app",
        "schema": "omegacode-suggestion-request-v2",
        "scope_id": scope["id"],
        "hunks": [{"kind": "create_text", "path": "main.py", "content": "print('Hello, Hive!')\n"}],
    })
    assert proposal_response.status_code == 200, proposal_response.text
    proposal = proposal_response.json()
    # Review the retained proposal before the human makes the decision.
    reviewed = client.get(f"/v1/workspaces/{ws['id']}/suggestions/{proposal['id']}", headers=headers)
    assert reviewed.status_code == 200
    body = reviewed.json()["content"]
    hunk = body["hunks"][0]
    assert hunk["kind"] == "create_text" and hunk["path"] == "main.py"

    decision = client.post(f"/v1/workspaces/{ws['id']}/suggestion-decisions", headers=headers, json={
        "operation_id": "c01-person-accept-first-app",
        "suggestion_id": proposal["id"],
        "suggestion_digest": proposal["digest"],
        "expected_generation": ws["generation"],
        "expected_tree_digest": ws["tree_digest"],
        "accepted_hunk_ids": [hunk["id"]],
        "rejected_hunk_ids": [],
    })
    assert decision.status_code == 200, decision.text
    result = decision.json()
    current = result["workspace"]
    assert current["generation"] == ws["generation"] + 1
    assert result["decision"]["accepted_hunk_ids"] == [hunk["id"]]
    file_read = client.get(f"/v1/workspaces/{ws['id']}/files", headers=headers,
                           params={"path": "main.py"})
    assert file_read.status_code == 200
    assert file_read.json()["content"] == "print('Hello, Hive!')\n"

    export_response = client.post(f"/v1/workspaces/{ws['id']}/git/exports", headers=headers, json={
        "operation_id": "c01-export-first-app",
        "expected_generation": current["generation"],
        "expected_tree_digest": current["tree_digest"],
        "branch": "review/first-hive-app",
        "message": "First person-approved Hive app",
        "history_mode": "snapshot",
    })
    assert export_response.status_code == 201, export_response.text
    export = export_response.json()
    assert export["author"] == person.actor
    assert export["source_repository_mutated"] is False
    patch_page = client.get(f"/v1/workspaces/{ws['id']}/git/exports/{export['id']}/patch",
                            headers=headers, params={"after": 0, "limit": 16384})
    assert patch_page.status_code == 200
    patch_bytes = __import__("base64").b64decode(patch_page.json()["data"], validate=True)
    assert hashlib.sha256(patch_bytes).hexdigest() == export["patch_digest"].removeprefix("sha256:")
    assert b"Hello, Hive!" in patch_bytes
    bundle = client.get(f"/v1/artifacts/{export['bundle_digest']}", headers=headers,
                        params={"workspace_id": ws["id"]})
    assert bundle.status_code == 200
    assert hashlib.sha256(bundle.content).hexdigest() == export["bundle_digest"].removeprefix("sha256:")

    assert git(repo, "rev-parse", "HEAD").strip() == seed_head
    assert git(repo, "status", "--porcelain") == seed_status

