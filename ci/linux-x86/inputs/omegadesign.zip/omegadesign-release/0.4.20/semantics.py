"""Pure creative-result check for a future host semantic hook.

Inputs must be read by the host, not accepted as worker evidence. This does not
implement the unpublished ctx adapter, authorization, expiry or a commit.
"""
import hashlib
import json
from .protocol import canonical, digest, revision_ref, text, validate_brief, validate_result


def validate_creative_completion(brief, request, goal, proposal, stored_revision, artifact):
    """Return host-hook-shaped errors without performing any effects.

    This checks the full creative-result contract, not the narrower native deck
    specification demonstration. A project-owned baseline may yield a separate
    proposal artifact; it does not require writing into the project's artifact.
    """
    errors = []
    try:
        brief = validate_brief(brief)
        revision_ref(proposal)
        ref = {k: proposal[k] for k in ('artifact_id', 'revision', 'digest')}
        for value in (request.get('id'), request.get('to_swarm'), request.get('from_swarm'),
                      goal.get('id'), goal.get('swarm_id'), goal.get('claimed_by')):
            text(value, 'host identity')
        binding = goal.get('binding') or {}
        if goal.get('status') != 'claimed' or not goal.get('claimed_by'):
            errors.append('goal is not held for completion')
        if request.get('cancelled_at') or request.get('receiving_goal') != goal.get('id'):
            errors.append('request is cancelled or bound to another goal')
        if binding.get('kind') != 'design' or binding.get('request_id') != request.get('id'):
            errors.append('goal request identity differs')
        if goal.get('swarm_id') != request.get('to_swarm') or binding.get('from_swarm') != request.get('from_swarm'):
            errors.append('request swarm binding differs')
        if request.get('kind') != 'design' or (request.get('constraints') or {}).get('brief_digest') != digest(brief):
            errors.append('request brief digest differs')
        if request.get('subject') != brief.get('subject'):
            errors.append('request baseline differs from brief')
        if binding.get('subject_digest') != (brief.get('subject') or {}).get('digest'):
            errors.append('goal baseline digest differs')
        if artifact.get('id') != ref['artifact_id'] or artifact.get('owner_swarm') != request.get('to_swarm'):
            errors.append('proposal artifact identity or ownership differs')
        stored_ref = {'artifact_id': stored_revision.get('artifact_id'),
                      'revision': stored_revision.get('n'), 'digest': stored_revision.get('digest')}
        if stored_ref != ref:
            errors.append('stored revision differs from returned reference')
        if stored_revision.get('author') != 'agent:' + str(goal.get('claimed_by')):
            errors.append('stored revision was not authored by the completing maker')
        body = stored_revision.get('body')
        if not isinstance(body, str) or len(body.encode()) > 256 * 1024:
            errors.append('stored body missing or oversized')
        else:
            measured = 'sha256:' + hashlib.sha256(body.encode()).hexdigest()
            if measured != ref['digest']:
                errors.append('stored bytes differ from returned digest')
            result = validate_result(json.loads(body), brief)
            if body != canonical(result):
                errors.append('stored creative result is not canonical')
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        errors.append(str(exc))
    return {'errors': errors} if errors else {'ok': True}
