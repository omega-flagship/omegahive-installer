"""Custody for Code iteration observations using its existing Store.

No scheduler, model execution, budget grant or assignment ownership is created.
Host admission/usage arguments remain reported observations, not trusted receipts.
"""
import json
from .iteration_evidence import decide,Limits
from .common import CodeError,canonical,digest,ident,stamp

def retain(service,principal,workspace_id,payload):
    required={'operation_id','verification_ids','commands','limits','observations','expected_generation','expected_tree_digest'}
    if not required <= set(payload) or set(payload)-required-{'approval_id'}:raise CodeError(400,'iteration_fields','closed iteration observation fields required')
    if principal.grant.get('paths'):
        raise CodeError(403,'iteration_scope','iteration observations require full workspace scope')
    if len(canonical(payload)) > 65536:
        raise CodeError(413,'iteration_size','observation request exceeds64KiB')
    try:
        limits=Limits(**payload['limits'])
    except (TypeError,ValueError):
        raise CodeError(400,'iteration_limits','invalid finite iteration limits') from None
    ws=service.workspace(workspace_id)
    def apply():
        current=service.workspace(workspace_id)
        service._fresh(current,payload['expected_generation'],payload['expected_tree_digest'])
        if sum(r['workspace_id']==workspace_id for r in service.store.list('iteration_observation'))>=128:
            raise CodeError(429,'iteration_budget','workspace observation budget exhausted')
        for vid in payload['verification_ids']:
            vr=service.verification(principal,vid)
            if vr['workspace_id']!=workspace_id or vr['task_id']!=ws['task_id']:
                raise CodeError(403,'iteration_scope','foreign verification')
        try:
            outcome=decide(service,principal,workspace_id,payload['verification_ids'],payload['commands'],limits,**payload['observations'])
        except (TypeError,ValueError):
            raise CodeError(400,'iteration_observation','invalid iteration observation') from None
        # Even early stop/usage outcomes have an authenticated exact source anchor.
        current=service.tree(principal,workspace_id)
        body={'schema':'omegacode-iteration-observation-v1','workspace_id':workspace_id,
              'task_id':ws['task_id'],'generation':current['generation'],'tree_digest':current['tree_digest'],
              'commands':payload['commands'],'verification_ids':payload['verification_ids'],
              'limits':payload['limits'],'reported_observations':payload['observations'],
              'host_usage_qualified':False,'outcome':outcome,'actor':principal.actor}
        blob=service.store.blob(canonical(body),workspace_id,'iteration-observation')
        record={'id':ident('iteration'),'workspace_id':workspace_id,'task_id':ws['task_id'],
                'digest':blob,'created_at':stamp(),'author':principal.actor}
        service.store.put('iteration_observation',record)
        service.store.emit(service.workspace(workspace_id),'iteration.observation',record)
        return {'record':record,'content':body}
    # Observation retention uses existing checkpoint authority. It creates no new
    # implicit read/edit/run permission and preserves ordinary exact approvals.
    return service._operation(principal,'checkpoint',ws,payload,apply)

def read(service,principal,workspace_id,record_id):
    if principal.grant.get('paths'):
        raise CodeError(403,'iteration_scope','iteration observations require full workspace scope')
    with service.store.lock:
        service._live(principal)
        current=service.tree(principal,workspace_id)
        record=service.store.get('iteration_observation',record_id)
        if record['workspace_id']!=workspace_id:raise CodeError(403,'iteration_scope','foreign workspace observation')
        body=json.loads(service.store.read_blob(record['digest'],workspace_id))
        service._live(principal)
        return {'record':record,'content':body,'currency':'current' if (body['generation'],body['tree_digest'])==(current['generation'],current['tree_digest']) else 'historical'}

class Iterations:
    def retain_iteration(self,principal,workspace_id,payload):
        return retain(self,principal,workspace_id,payload)
    def iteration(self,principal,workspace_id,record_id):
        return read(self,principal,workspace_id,record_id)
