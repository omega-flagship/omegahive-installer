import {exactReference, sameReference} from './app-reference.mjs';

export const STUDIO_DRAFT_LIMIT = 256 * 1024;
export const STUDIO_RECOVERY_LIMIT = 20 * 1024 * 1024;
const schema = 'omega-studio-private-draft-1';
const keyPattern = /^[a-z0-9][a-z0-9_-]{0,79}$/;
const idPattern = /^[\w.:-]{1,80}$/;
const revision = value => Number.isSafeInteger(value) && value >= 1;

// JSON.stringify silently drops undefined, invokes getters/toJSON and turns NaN
// into null. Refuse those values instead of changing someone's retained source.
function jsonData(value, depth = 0, seen = new Set()) {
 if (depth > 64) throw Error('Private draft exceeds the supported nesting depth.');
 if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
 if (typeof value === 'number' && Number.isFinite(value)) return;
 if (typeof value !== 'object' || seen.has(value)) throw Error('Private draft must contain JSON data only.');
 const prototype = Object.getPrototypeOf(value);
 if (!Array.isArray(value) && prototype !== Object.prototype && prototype !== null) throw Error('Private draft must contain plain JSON objects.');
 if (Object.getOwnPropertySymbols(value).length) throw Error('Private draft contains unsupported fields.');
 seen.add(value);
 const keys = Object.keys(value);
 if (Object.getOwnPropertyNames(value).some(key => !keys.includes(key) && !(Array.isArray(value) && key === 'length'))) throw Error('Private draft contains unsupported hidden fields.');
 if (Array.isArray(value) && (keys.length !== value.length || keys.some((key, index) => key !== String(index)))) throw Error('Private draft contains an unsupported array.');
 for (const key of keys) {
  const field = Object.getOwnPropertyDescriptor(value, key);
  if (!field || !('value' in field)) throw Error('Private draft contains an unsupported field.');
  jsonData(field.value, depth + 1, seen);
 }
 seen.delete(value);
}

function snapshotData(value) {
 jsonData(value);
 if (!value || Array.isArray(value) || !['omega-studio-draft-1', 'omega-deck-draft-1'].includes(value.schema) ||
     !value.source || typeof value.source !== 'object' || Array.isArray(value.source) ||
     !value.fields || typeof value.fields !== 'object' || Array.isArray(value.fields)) throw Error('A complete Studio snapshot and pending fields are required.');
 return JSON.parse(JSON.stringify(value));
}

function capture(readSnapshot, readSourceRef) {
 const snapshot = snapshotData(readSnapshot());
 const input = readSourceRef();
 const sourceRef = input == null ? null : exactReference(input);
 const body = {schema, snapshot, source_ref: sourceRef};
 const serialized = JSON.stringify(body);
 return {snapshot, sourceRef, body, token: serialized, expectedSnapshot: JSON.stringify(snapshot), bytes: new TextEncoder().encode(serialized).length};
}

// Local export keeps the whole editor snapshot, including unfinished fields and
// redo history, even when the Hive's smaller private-draft limit is exceeded.
export function serializeStudioRecovery(readSnapshot, readSourceRef = () => null) {
 const value = capture(readSnapshot, readSourceRef);
 const serialized = JSON.stringify({schema: 'omega-studio-recovery-1', snapshot: value.snapshot, source_ref: value.sourceRef});
 if (new TextEncoder().encode(serialized).length > STUDIO_RECOVERY_LIMIT) throw Error('Recovery snapshot exceeds the 20 MB download limit. Your local work is retained; reduce embedded image sizes before exporting.');
 return serialized;
}

export function parseStudioRecovery(serialized) {
 if (typeof serialized !== 'string' || new TextEncoder().encode(serialized).length > STUDIO_RECOVERY_LIMIT) throw Error('Recovery snapshot exceeds the 20 MB import limit.');
 const value = JSON.parse(serialized);
 jsonData(value);
 if (!value || value.schema !== 'omega-studio-recovery-1' || Object.keys(value).sort().join(',') !== 'schema,snapshot,source_ref') throw Error('Unsupported recovery snapshot.');
 const snapshot = snapshotData(value.snapshot);
 const sourceRef = value.source_ref === null ? null : exactReference(value.source_ref);
 return {snapshot, sourceRef};
}

// Reading a local file confers no source-ref authority and sends no requests.
// Replacement remains explicit, and both file reads and async source validation
// are fenced against newer local work, reference changes and frame disposal.
export function studioRecoveryImporter({readSnapshot, readSourceRef = () => null, restoreSnapshot,
 onRestored = () => {}, onChanged = () => {}, onReady = () => {}, notice = () => {}, onState = () => {}}) {
 let disposed = false, epoch = 0, pending = null, reading = false, restoring = false;
 const state = () => ({reading, restoring, ready: !!pending, disposed});
 const emit = () => onState(state());
 const current = () => capture(readSnapshot, readSourceRef);
 async function read(file) {
  if (disposed || restoring) return false;
  const requestEpoch = ++epoch; pending = null; reading = true; emit();
  try {
   const before = current();
   if (!file || !Number.isSafeInteger(file.size) || file.size < 0 || file.size > STUDIO_RECOVERY_LIMIT || typeof file.text !== 'function') throw Error('Choose a recovery JSON file no larger than 20 MB.');
   const serialized = await file.text();
   if (disposed || epoch !== requestEpoch) return false;
   if (current().token !== before.token) throw Error('Local work changed while reading the recovery file. Your work is retained; choose the file again when ready.');
   const recovery = parseStudioRecovery(serialized);
   pending = {recovery, before, epoch: requestEpoch};
   onReady(); return true;
  } catch (error) {if (!disposed && epoch === requestEpoch) notice(error.message + ' Your local work is retained.'); return false;}
  finally {if (!disposed && epoch === requestEpoch) {reading = false; emit();}}
 }
 async function restore() {
  if (disposed || reading || restoring || !pending) return false;
  const intent = pending; pending = null; restoring = true; emit();
  try {
   const isCurrent = () => !disposed && epoch === intent.epoch && current().token === intent.before.token;
   if (!isCurrent()) throw Error('Local work changed before recovery confirmation. Choose the file again to replace the current work.');
   await restoreSnapshot(intent.recovery.snapshot, intent.before.expectedSnapshot, {sourceRef: intent.recovery.sourceRef, isCurrent});
   if (disposed || epoch !== intent.epoch) return false;
   onRestored(intent.recovery.sourceRef); onChanged();
   notice('Local recovery snapshot restored with retained history and unfinished fields. Save to Hive is still required to publish it.');
   return true;
  } catch (error) {if (!disposed && epoch === intent.epoch) notice(error.message + ' Your current local work is retained.'); return false;}
  finally {restoring = false; if (!disposed) emit();}
 }
 function cancel() {epoch++; pending = null; reading = false; emit();}
 function dispose() {disposed = true; epoch++; pending = null; reading = false; restoring = false; emit();}
 return {read, restore, cancel, dispose, state};
}

export async function studioDraftKey(snapshot, sourceRef = null) {
 const projectId = snapshot?.source?.project?.brief?.id ?? snapshot?.source?.project?.id;
 const sceneId = snapshot?.source?.current?.scene?.id ?? snapshot?.source?.slides?.[0]?.id;
 const identity = sourceRef ? 'artifact:' + exactReference(sourceRef).artifact_id :
  snapshot?.document_id ? 'document:' + snapshot.document_id : 'local:' + JSON.stringify([projectId, sceneId]);
 if (!sourceRef && !snapshot?.document_id && (!projectId || !sceneId)) throw Error('An unsaved draft needs stable project and scene IDs or a retained editor document ID.');
 if (snapshot?.document_id && (typeof snapshot.document_id !== 'string' || snapshot.document_id.length > 200)) throw Error('The editor document ID is invalid.');
 const bytes = new TextEncoder().encode('omega-design-draft-1:' + identity);
 const hash = await crypto.subtle.digest('SHA-256', bytes);
 return 'studio-' + Array.from(new Uint8Array(hash), byte => byte.toString(16).padStart(2, '0')).join('');
}

const refusalText = {
 conflict: 'A different private draft revision exists. Restore it or explicitly keep your local work.',
 'too-large': 'Private recovery is limited to 256 KB. Your complete local source and history are retained; export them before closing.',
 'not-set-up': "Drafts aren't kept here: this app isn't set up in this swarm.",
 'not-found': 'This private draft no longer exists. Your local work is retained.',
 unavailable: 'Private draft recovery is unavailable. Your local work is retained.',
 'not-opened': 'Open this app in its swarm before using private drafts.',
 invalid: 'The private draft was refused. Your local work is retained.',
 'rate-limited': 'Private draft requests are temporarily limited. Your local work is retained.',
 busy: 'Another private draft write is in progress. Your local work is retained.'
};

// The caller validates event.source, origin and channel before receive(). The
// caller's restore hook must validate its entire source and check isCurrent()
// immediately before its synchronous commit, after any async verification.
export function studioDrafts({post, readSnapshot, restoreSnapshot, readSourceRef = () => null,
 onRestored = () => {}, onState = () => {}, id = () => crypto.randomUUID(),
 debounceMs = 900, requestTimeoutMs = 30000, deriveKey = studioDraftKey,
 setTimer = setTimeout, clearTimer = clearTimeout}) {
 if (![post, readSnapshot, restoreSnapshot, readSourceRef, onRestored, onState].every(value => typeof value === 'function')) throw Error('Studio draft callbacks are required.');
 let disposed = false, available = false, epoch = 0, generation = 0, observed = null;
 let key = null, admitted = false, knownRevision = null, exists = false, savedToken = null;
 let dirty = false, loading = false, restoring = false, write = null, debounce = null;
 let conflict = false, conflictRevision = null, blocked = null;
 let note = 'Private recovery drafts are available when the Hive grants this signed-in person access.';
 const requests = new Map();
 const state = () => ({available: available && !disposed, draftKey: key, admitted, revision: knownRevision,
  exists, dirty, loading, restoring, saving: !!write, uncertain: !!write?.timedOut,
  conflict, conflictRevision, blocked, note});
 const emit = () => onState(state());
 const stopDebounce = () => {if (debounce !== null) clearTimer(debounce); debounce = null;};
 const current = () => capture(readSnapshot, readSourceRef);
 const changedSince = token => current().token !== token;
 const removeRequest = request => {clearTimer(request.timer); requests.delete(request.id);};
 function fail(reason, text = refusalText[reason] || refusalText.invalid) {
  try {dirty = savedToken !== null && changedSince(savedToken);} catch {dirty = true;}
  blocked = reason; note = text; stopDebounce(); emit();
 }
 function request(op, message, extra = {}) {
  const requestId = id();
  if (typeof requestId !== 'string' || !idPattern.test(requestId) || requests.has(requestId)) throw Error('A unique bounded draft request ID is required.');
  const record = {id: requestId, op, key, epoch, ...extra};
  record.timer = setTimer(() => {
   if (!requests.has(requestId) || disposed) return;
   if (op === 'save') {
    record.timedOut = true;
    note = 'Private draft save is unconfirmed. Local work is retained; wait for its receipt before another write.';
    blocked = 'unconfirmed'; stopDebounce(); emit();
   } else {
    removeRequest(record); loading = false; restoring = false;
    fail('unavailable', 'Private draft request timed out. Local work is retained.');
   }
  }, requestTimeoutMs);
  requests.set(requestId, record);
  if (op === 'save') write = record;
  try {post({...message, id: requestId});}
  catch {
   if (op === 'save') {record.timedOut = true; fail('unconfirmed', 'Private draft save is unconfirmed. Local work is retained; wait for its receipt before another write.');}
   else {removeRequest(record); loading = false; restoring = false; fail('unavailable');}
  }
  return record;
 }
 function schedule() {
  stopDebounce();
  if (!disposed && available && admitted && dirty && !loading && !restoring && !write && !blocked && !conflict) {
   debounce = setTimer(() => {debounce = null; void save(false);}, debounceMs);
  }
 }
 function refreshList() {
  if (disposed || !available || !key || loading || restoring) return false;
  stopDebounce(); loading = true; admitted = false; blocked = null;
  note = 'Checking for this person’s private recovery draft…';
  request('list', {type: 'draft-list'}); emit(); return true;
 }
 async function change() {
  if (disposed) return false;
  let value;
  try {value = current();} catch (error) {fail('invalid', error.message); return false;}
  if (value.token !== observed) {observed = value.token; generation++;}
  const before = generation, authorityEpoch = epoch;
  let nextKey;
  try {nextKey = await deriveKey(value.snapshot, value.sourceRef);}
  catch (error) {if (!disposed && before === generation) fail('invalid', error.message); return false;}
  if (disposed || before !== generation || authorityEpoch !== epoch) return false;
  if (!keyPattern.test(nextKey)) {fail('invalid', 'Private draft key is invalid.'); return false;}
  if (nextKey !== key) {
   stopDebounce();
   // A reply for the previous document cannot establish this one's baseline.
   for (const record of requests.values()) if (record.op !== 'save') removeRequest(record);
   key = nextKey; admitted = false; knownRevision = null; exists = false;
   savedToken = value.token; dirty = false; loading = false; restoring = false;
   conflict = false; conflictRevision = null; blocked = null;
   if (available) refreshList();
  } else {
   dirty = value.token !== savedToken;
   if (available && !admitted && !loading && !restoring && !exists && !blocked && !conflict) refreshList();
   else schedule();
  }
  emit(); return true;
 }
 function context(message) {
  if (disposed) return false;
  const next = message?.capabilities?.draftSave === true && message?.person?.kind === 'person' && message.person.localOperator !== true;
  if (next !== available) {
   epoch++; available = next; stopDebounce(); admitted = false; loading = false; restoring = false;
   for (const record of requests.values()) if (record.op !== 'save') removeRequest(record);
   blocked = null; conflict = false;
   note = next ? 'Checking for this person’s private recovery draft…' : 'Private draft access is unavailable. Your local work is retained.';
   if (next) {void change().then(() => {if (!disposed && available && key && !loading) refreshList();});}
  }
  emit(); return true;
 }
 async function save(manual = true) {
  if (disposed || !available || !key || !admitted || loading || restoring || write || conflict) return false;
  if (blocked && !manual) return false;
  let value; const saveEpoch = epoch, saveKey = key;
  try {
   value = current();
   if (await deriveKey(value.snapshot, value.sourceRef) !== key) {void change(); return false;}
   if (disposed || !available || epoch !== saveEpoch || key !== saveKey || !admitted || loading || restoring || write || conflict) return false;
   // Re-read after SHA-256 so an intervening edit is never captured incompletely.
   if (current().token !== value.token) {void change(); return false;}
   if (value.bytes > STUDIO_DRAFT_LIMIT) {fail('too-large'); return false;}
  } catch (error) {fail('invalid', error.message); return false;}
  dirty = value.token !== savedToken;
  if (!manual && !dirty) return false;
  stopDebounce(); blocked = null; note = 'Saving a private recovery draft…';
  const message = {type: 'draft-save', draft_key: key, expected_revision: knownRevision, body: value.body};
  if (value.sourceRef) message.source_ref = value.sourceRef;
  request('save', message, {token: value.token, body: value.body, expectedRevision: knownRevision}); emit(); return true;
 }
 function restore() {
  if (disposed || !available || !key || loading || restoring || write || !exists) return false;
  let value;
  try {value = current();} catch (error) {fail('invalid', error.message); return false;}
  stopDebounce(); restoring = true; admitted = false; blocked = null;
  note = 'Loading the selected private draft. New local edits will cancel restoration.';
  request('load', {type: 'draft-load', draft_key: key}, {token: value.token, expectedSnapshot: value.expectedSnapshot, generation});
  emit(); return true;
 }
 async function keepMine() {
  if (disposed || !available || !key || loading || restoring || write || (!exists && !conflict)) return false;
  // This is a person-driven replacement using the exact revision observed in a
  // list/conflict receipt. It can still conflict; never retry it automatically.
  if (conflict) knownRevision = conflictRevision;
  conflict = false; blocked = null; admitted = true;
  note = 'Keeping local work as the next private draft revision.'; emit();
  return save(true);
 }
 async function receive(message) {
  if (disposed || !message || typeof message !== 'object') return false;
  const record = requests.get(message.id);
  if (!record) return false;
  const expectedType = {save: 'draft-saved', list: 'drafts', load: 'draft'}[record.op];
  if (message.type !== expectedType && message.type !== 'draft-refused') return false;
  if (message.type === 'draft-refused' && message.op !== record.op) return false;
  if (record.op !== 'list' && message.type !== 'draft-refused' && message.draft_key !== record.key) return false;
  removeRequest(record);
  if (record.op === 'save' && write === record) write = null;
  if (!available || record.epoch !== epoch || record.key !== key) {schedule(); emit(); return true;}
  if (record.op === 'list') loading = false;
  if (message.type === 'draft-refused') {
   if (record.op === 'load') restoring = false;
   if (message.reason === 'conflict' && record.op === 'save' && (message.current_revision === null || revision(message.current_revision))) {
    conflict = true; conflictRevision = message.current_revision; knownRevision = message.current_revision;
    exists = message.current_revision !== null; admitted = false;
   }
   fail(message.reason); return true;
  }
  try {
   if (record.op === 'list') {
    if (!Array.isArray(message.drafts)) throw Error('Invalid private draft list.');
    const rows = message.drafts.filter(row => row?.draft_key === key);
    if (rows.length > 1 || (rows.length && !revision(rows[0].revision))) throw Error('Invalid private draft revision list.');
    exists = !!rows.length; knownRevision = rows[0]?.revision ?? null;
    admitted = !exists; blocked = null; conflict = false;
    dirty = changedSince(savedToken);
    note = exists ? 'A private recovery draft exists. Restore it or explicitly keep your local work.' : 'Private recovery is ready. New edits will save here; this shares and publishes nothing.';
    schedule(); emit(); return true;
   }
   if (record.op === 'save') {
    if (!revision(message.revision) || (record.expectedRevision !== null && message.revision <= record.expectedRevision)) throw Error('Invalid private draft save receipt.');
    knownRevision = message.revision; exists = true; admitted = true; savedToken = record.token; blocked = null;
    dirty = changedSince(savedToken);
    note = dirty ? 'Private draft saved. Newer local edits are waiting to save.' : 'Private recovery draft saved. Hive publication still requires Save to Hive.';
    schedule(); emit(); return true;
   }
   if (!revision(message.revision) || !message.body || message.body.schema !== schema) throw Error('Invalid private draft snapshot.');
   jsonData(message.body);
   if (new TextEncoder().encode(JSON.stringify(message.body)).length > STUDIO_DRAFT_LIMIT) throw Error('Private draft exceeds the recovery size limit.');
   const snapshot = snapshotData(message.body.snapshot);
   const sourceRef = message.source_ref === null ? null : exactReference(message.source_ref);
   const bodyRef = message.body.source_ref === null ? null : exactReference(message.body.source_ref);
   if (sourceRef === null ? bodyRef !== null : bodyRef === null || !sameReference(sourceRef, bodyRef)) throw Error('Private draft source base differs from its host receipt.');
   if (await deriveKey(snapshot, sourceRef) !== key) throw Error('Private draft belongs to another creation.');
   const isCurrent = () => !disposed && available && epoch === record.epoch && key === record.key && generation === record.generation && !changedSince(record.token);
   if (!isCurrent()) throw Error('Local work or draft access changed while loading. Restoration was cancelled; your local work is retained.');
   await restoreSnapshot(snapshot, record.expectedSnapshot, {sourceRef, isCurrent});
   if (disposed || !available || epoch !== record.epoch || key !== record.key) {restoring = false; return true;}
   onRestored(sourceRef);
   const value = current(); observed = value.token; generation++;
   knownRevision = message.revision; exists = true; admitted = true; savedToken = value.token; dirty = false; restoring = false;
   blocked = null; conflict = false;
   note = 'Private draft restored, including pending fields. Save to Hive is still required to publish it.';
   emit(); return true;
  } catch (error) {if (record.op === 'load') restoring = false; if (!disposed && available && epoch === record.epoch) fail('invalid', error.message); return true;}
 }
 function dispose() {
  disposed = true; epoch++; stopDebounce();
  for (const record of requests.values()) clearTimer(record.timer);
  requests.clear(); write = null; available = false; admitted = false; loading = false; restoring = false;
  emit();
 }
 emit();
 return {context, receive, change, save, restore, keepMine, refresh: refreshList, state, dispose};
}

export function mountStudioDrafts(container, options) {
 const document = container.ownerDocument;
 const panel = document.createElement('section'); panel.className = 'hive-source-panel studio-private-drafts';
 const heading = document.createElement('h2'); heading.textContent = 'Private recovery';
 const hint = document.createElement('p'); hint.className = 'hint'; hint.textContent = 'Recover your artwork, retained history and unfinished fields. Saving a private draft shares nothing.';
 const notice = document.createElement('p'); notice.setAttribute('role', 'status'); notice.setAttribute('aria-live', 'polite');
 const controls = document.createElement('div'); controls.className = 'studio-draft-controls';
 const button = label => {const value = document.createElement('button'); value.type = 'button'; value.textContent = label; controls.append(value); return value;};
 const save = button('Save private draft'), restore = button('Restore private draft'), keep = button('Keep my local work'), refresh = button('Check private draft'), exportRecovery = button('Export recovery snapshot'), importRecovery = button('Import recovery snapshot');
 const file = document.createElement('input'); file.type = 'file'; file.accept = '.json,application/json'; file.hidden = true; panel.append(file);
 const recoveryUrls = new Set(); let mounted = true, importer = null, lastState = null, confirmationKind = 'private';
 const confirmation = document.createElement('div'); confirmation.hidden = true;
 const question = document.createElement('p'); question.textContent = 'Replace the current local artwork and unfinished fields with the saved private draft? Export your current source first if you want to keep both.';
 const confirm = document.createElement('button'); confirm.type = 'button'; confirm.textContent = 'Restore and replace local work';
 const cancel = document.createElement('button'); cancel.type = 'button'; cancel.textContent = 'Cancel';
 confirmation.append(question, confirm, cancel); panel.append(heading, hint, controls, confirmation, notice); container.append(panel);
 function renderState(value, updateNotice = true) {
  lastState = value;
  const importBusy = importer?.state().reading || importer?.state().restoring;
  if (updateNotice) notice.textContent = value.note;
  panel.dataset.state = value.available ? value.blocked || (value.saving ? 'saving' : 'ready') : 'unavailable';
  save.disabled = !value.available || !value.admitted || value.loading || value.restoring || value.saving || value.conflict || importBusy;
  restore.disabled = !value.available || !value.exists || value.loading || value.restoring || value.saving || importBusy;
  keep.hidden = !(value.conflict || value.exists && !value.admitted);
  keep.disabled = !value.available || value.loading || value.restoring || value.saving || importBusy;
  refresh.disabled = !value.available || value.loading || value.restoring || importBusy;
  importRecovery.disabled = !!importBusy; confirm.disabled = !!importBusy;
  if (!value.available && confirmationKind === 'private') confirmation.hidden = true;
  options.onState?.(value);
 }
 const client = studioDrafts({...options, onState: renderState});
 importer = studioRecoveryImporter({...options,
  onChanged: () => {void client.change();},
  notice: value => {notice.textContent = value;},
  onReady: () => {
   confirmationKind = 'local'; confirmation.hidden = false;
   question.textContent = 'Replace the current local artwork and unfinished fields with the selected recovery file? Export a recovery snapshot of your current work first if you want to keep both. This does not publish the file in Hive.';
   confirm.textContent = 'Import and replace local work'; confirm.focus();
  },
  onState: value => {if (lastState) renderState(lastState, false); if (value.ready && !value.reading && !value.restoring && confirmationKind === 'local') confirm.focus();}
 });
 save.onclick = () => {confirmation.hidden = true; void client.save();};
 restore.onclick = () => {importer.cancel(); confirmationKind = 'private'; question.textContent = 'Replace the current local artwork and unfinished fields with the saved private draft? Export a recovery snapshot of your current work first if you want to keep both.'; confirm.textContent = 'Restore and replace local work'; confirmation.hidden = false; confirm.focus();};
 confirm.onclick = () => {confirmation.hidden = true; if (confirmationKind === 'local') void importer.restore(); else client.restore();};
 cancel.onclick = () => {confirmation.hidden = true; importer.cancel(); (confirmationKind === 'local' ? importRecovery : restore).focus();};
 keep.onclick = () => {confirmation.hidden = true; void client.keepMine();};
 refresh.onclick = () => {confirmation.hidden = true; client.refresh();};
 importRecovery.onclick = () => {confirmation.hidden = true; importer.cancel(); file.value = ''; file.click();};
 file.onchange = () => {const selected = file.files?.[0]; if (selected) void importer.read(selected);};
 exportRecovery.onclick = () => {
  if (!mounted) return;
  try {
   const serialized = serializeStudioRecovery(options.readSnapshot, options.readSourceRef);
   const url = URL.createObjectURL(new Blob([serialized], {type: 'application/json;charset=utf-8'}));
   recoveryUrls.add(url);
   const link = document.createElement('a'); link.href = url; link.download = 'omegadesign-recovery.json';
   try {link.click();} finally {setTimeout(() => {URL.revokeObjectURL(url); recoveryUrls.delete(url);}, 5000);}
   notice.textContent = 'Recovery snapshot prepared for download with complete retained history and unfinished fields. This shares and publishes nothing.';
  } catch (error) {notice.textContent = error.message + ' Your local work remains in the editor.';}
 };
 return {...client, dispose() {mounted = false; importer.dispose(); for (const url of recoveryUrls) URL.revokeObjectURL(url); recoveryUrls.clear(); client.dispose(); panel.remove();}};
}
