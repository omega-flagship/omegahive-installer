"""Pure D2 transport projection; the host owns validation, identity custody and writes.

No IDs are allocated on a read. A caller must supply previously allocated identities
indexed by the full source/statement/scope key. This module never imports an evaluator.
"""
from .common import canonical, digest


def merge_observations(packet):
    """Metadata observations only; neither command success nor a merge proves quality."""
    artifact = packet['artifact']
    scope = packet['author_swarm']
    generation = artifact['generation']
    tree = artifact['tree_digest']
    observations = []

    def add(subject, record_digest, statement, frequency=None):
        record = {'source': {'owner': 'omegacode', 'subject': subject,
                            'revision': generation, 'digest': record_digest},
                  'statement': statement, 'scope': scope, 'status': 'observed',
                  'unknown': frequency is None}
        if frequency is not None:
            record['truth'] = ['stv', frequency, 0.5]
        # Include the claim: quality unknown and source existence share a receipt,
        # but are different statements, never independent corroboration.
        key = digest(canonical([record['source'], statement, scope]))
        observations.append((key, record))

    add(artifact['changeset_id'], packet['change_record_digest'],
        ['CodeMergedSource', artifact['workspace_id'], generation, tree], 1.0)
    add(artifact['changeset_id'], packet['change_record_digest'],
        ['CodeMergeQuality', tree, 'not-assessed'])
    for receipt in packet['verifications']:
        status = receipt['status']
        # Unknown status carries no truth, including no invented negative result.
        add(receipt['id'], receipt['record_digest'],
            ['CodeVerificationPassed', tree, receipt['id']],
            1.0 if status == 'passed' else 0.0 if status == 'failed' else None)
    return observations


def merge_envelope(packet, allocated_ids):
    """Project using owner-custodied IDs, refusing absent or reused identities.

    This is an L0 candidate. Consumers must use OmegaAtom's canonical validator;
    publication, authentication and persistence are separate host responsibilities.
    """
    records, seen = [], set()
    for key, observation in merge_observations(packet):
        identity = allocated_ids[key]  # missing custody never creates a new ID
        if (not isinstance(identity, list) or len(identity) != 3 or
                identity[:2] != ['ev', 'omegacode'] or
                type(identity[2]) is not int or not 0 < identity[2] <= 2**53 - 1):
            raise ValueError('expected a custodied, transport-safe OmegaCode evidence ID')
        if identity[2] in seen:
            raise ValueError('allocated evidence ID reused for distinct observations')
        seen.add(identity[2])
        records.append({**observation, 'id': list(identity), 'stamp': [list(identity)]})
    return {'version': '0.1', 'owner': 'omegacode', 'scope': packet['author_swarm'],
            'revision': packet['artifact']['generation'], 'records': records}
