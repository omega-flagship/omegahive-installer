import {validateSceneDeck} from './scene-deck.mjs';
import {initial,apply,svg,clone} from './scene.mjs';
import {pickedImageInsertion} from './studio-picked-image.mjs';
import {serializeStudioRecovery} from './studio-drafts.mjs';

const fieldKeys=['text','x','y','width','height','fontSize','color','fill','alt'];
const recoveryError='Edit would exceed the full recovery limit; your current work is retained. Use a smaller image or a creation with less embedded media.';
const jsonBytes=value=>new TextEncoder().encode(JSON.stringify(value)).length;
const reservedFields=Object.fromEntries(fieldKeys.map(key=>[key,'\0'.repeat(32000)]));
const futureReference={artifact_id:'r'.repeat(1024),revision:1e20,digest:'sha256:'+'f'.repeat(64)};
const recoveryBudget=(snapshot,sourceRef)=>{
 try{
  if(!snapshot.fields||Object.entries(snapshot.fields).some(([key,value])=>!fieldKeys.includes(key)||typeof value!=='string'||value.length>32000))throw Error('Deck fields exceed supported recovery limits; your current work is retained');
  serializeStudioRecovery(()=>snapshot,()=>sourceRef);
  const worst={...snapshot,document_id:jsonBytes(snapshot.document_id)>jsonBytes('d'.repeat(80))?snapshot.document_id:'d'.repeat(80),selectedSlide:'s'.repeat(80),selectedElement:'e'.repeat(80),fields:reservedFields};
  const futureRef=jsonBytes(sourceRef)>jsonBytes(futureReference)?sourceRef:futureReference;
  serializeStudioRecovery(()=>worst,()=>futureRef);
 }
 catch(error){if(error.message.includes('Recovery snapshot exceeds'))throw Error(recoveryError);throw error;}
};
// Direct sessions have no form/reference reader. Reserve every supported field
// at its restore limit and a large opaque reference; mounted editors budget the
// actual complete view and target reference instead.
const reservedReference={artifact_id:'\0'.repeat(32768),revision:Number.MAX_SAFE_INTEGER,digest:'sha256:'+'f'.repeat(64)};
const reservedSnapshot=state=>({schema:'omega-deck-draft-1',document_id:'d'.repeat(80),...state,selectedSlide:state.source.slides[0].id,selectedElement:state.source.slides[0].elements[0]?.id??'',fields:reservedFields});

export function deckSession(input,{recoverySnapshot=reservedSnapshot,readSourceRef=()=>reservedReference}={}){
 let history=[validateSceneDeck(input)],cursor=0,version=0,imageBusy=false;
 const snapshot=()=>({history:clone(history),cursor});
 const budget=(nextHistory,nextCursor,selection)=>recoveryBudget(recoverySnapshot({source:clone(nextHistory[nextCursor]),history:clone(nextHistory),cursor:nextCursor},selection),readSourceRef());
 const advance=(deck,selection)=>{
  if(cursor+2>500)throw Error('Deck history exceeds 500 retained revisions; export your recovery snapshot');
  const next=validateSceneDeck(deck);
  // Budget existing redo as well as the new revision before normal edit
  // branching, so no retained history is discarded merely to pass the limit.
  budget([...history,next],history.length,selection);
  history=history.slice(0,cursor+1);history.push(next);cursor++;version++;
 };
 budget(history,cursor);
 return {
  source:()=>clone(history[cursor]),
  async edit(slideId,elementId,patch,{isCurrent=()=>true}={}){
   if(cursor+2>500)throw Error('Deck history exceeds 500 retained revisions; export your recovery snapshot');
   const before=version,deck=clone(history[cursor]),slide=deck.slides.find(s=>s.id===slideId);
   if(!slide)throw Error('Slide is absent');
   const root=await initial(slide),next=await apply(root,root.digest,[{op:'set',element:elementId,patch}]);
   if(!isCurrent()||version!==before)throw Error('Deck changed during edit');
   deck.slides[deck.slides.findIndex(s=>s.id===slideId)]=next.scene;
   advance(deck);return this.source();
  },
  async insertImage(image,{slideId=history[cursor].slides[0].id,expectedSnapshot,readSnapshot=snapshot,isCurrent=()=>true,document=globalThis.document}={}){
   if(imageBusy)throw Error('Wait for the image insertion');
   const before=expectedSnapshot??JSON.stringify(readSnapshot()),original=version,deck=clone(history[cursor]),slide=deck.slides.find(s=>s.id===slideId);
   const current=()=>isCurrent()&&version===original&&JSON.stringify(readSnapshot())===before;
   if(!slide)throw Error('Slide is absent');
   if(!current())throw Error('Deck changed before image insertion; your work is retained');
   if(cursor+2>500)throw Error('Deck history exceeds 500 retained revisions; export your recovery snapshot');
   imageBusy=true;
   try{
    const id='element-'+crypto.randomUUID(),change=await pickedImageInsertion(slide,image,{id,document,isCurrent:current});
    if(!current())throw Error('Deck changed while preparing image; your work is retained');
    const root=await initial(slide),next=await apply(root,root.digest,[change]);
    if(!current())throw Error('Deck changed during image insertion; your work is retained');
    deck.slides[deck.slides.findIndex(s=>s.id===slideId)]=next.scene;
    advance(deck,{slideId,elementId:id});
    return {source:this.source(),elementId:id};
   }finally{imageBusy=false;}
  },
  move(slideId,offset){const deck=clone(history[cursor]),i=deck.slides.findIndex(s=>s.id===slideId),to=i+offset;if(i<0||![-1,1].includes(offset)||to<0||to>=deck.slides.length)return this.source();const [slide]=deck.slides.splice(i,1);deck.slides.splice(to,0,slide);advance(deck);return this.source();},
  undo(){if(cursor>0){budget(history,cursor-1);cursor--;version++;}return this.source();},redo(){if(cursor<history.length-1){budget(history,cursor+1);cursor++;version++;}return this.source();},
  snapshot,
  restore(value){if(!Array.isArray(value.history)||!value.history.length||value.history.length>500||!Number.isInteger(value.cursor)||!value.history[value.cursor])throw Error('Invalid deck history');const next=value.history.map(validateSceneDeck);budget(next,value.cursor);history=next;cursor=value.cursor;version++;return this.source();}
 };
}

export function mountDeckEditor(container,{onChange=()=>{},notice=()=>{},readSourceRef=()=>null}={}){
 const doc=container.ownerDocument;
 let documentId='deck-'+crypto.randomUUID(),session=null,selectedSlide='',selectedElement='',form=null,busy=false,disposed=false;
 const node=(tag,text)=>{const e=doc.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
 const button=(text,run)=>{const b=node('button',text);b.type='button';b.onclick=()=>{try{if(disposed)throw Error('Deck editor is closed');if(busy)throw Error('Wait for this edit');const result=run();Promise.resolve(result).catch(e=>notice(e.message));}catch(e){notice(e.message);}};return b;};
 const fieldValues=()=>form?Object.fromEntries([...form.elements].filter(x=>x.name).map(x=>[x.name,x.value])):{};
 const hasDraft=()=>{if(!session||!form)return false;const element=session.source().slides.find(s=>s.id===selectedSlide)?.elements.find(e=>e.id===selectedElement);return !!element&&Object.entries(fieldValues()).some(([k,v])=>String(element[k])!==v);};
 const sourceView=(source,slideId=selectedSlide,elementId=selectedElement)=>{
  const slide=source.slides.find(s=>s.id===slideId)??source.slides[0],element=slide.elements.find(e=>e.id===elementId)??slide.elements[0];
  return {documentId,selectedSlide:slide.id,selectedElement:element?.id??'',fields:element?Object.fromEntries(fieldKeys.filter(key=>Object.hasOwn(element,key)).map(key=>[key,String(element[key])])):{}};
 };
 const fullSnapshot=(state,view)=>({schema:'omega-deck-draft-1',document_id:view.documentId,...state,selectedSlide:view.selectedSlide,selectedElement:view.selectedElement,fields:clone(view.fields)});
 const pendingView=(source,selection)=>{
  const view=sourceView(source,selection?.slideId,selection?.elementId),pending=fieldValues();
  for(const [key,value] of Object.entries(pending))if(!Object.hasOwn(view.fields,key)||jsonBytes(value)>jsonBytes(view.fields[key]))view.fields[key]=value;
  return view;
 };
 const prepareSession=(source,view,sourceRef)=>{
  let installing=true;
  const next=deckSession(source,{recoverySnapshot:(state,selection)=>fullSnapshot(state,installing?view:pendingView(state.source,selection)),readSourceRef:()=>installing?sourceRef:readSourceRef()});
  return {session:next,finish:()=>{installing=false;}};
 };
 const chooseSelection=(slideId,elementId)=>{
  const source=session.source(),view=sourceView(source,slideId,elementId);
  recoveryBudget(fullSnapshot({source,...session.snapshot()},view),readSourceRef());
  selectedSlide=view.selectedSlide;selectedElement=view.selectedElement;render();
 };
 const render=()=>{
  if(!session)return;const deck=session.source();container.replaceChildren();
  container.append(node('h2',deck.title),node('p','Editable slides · source remains available for Hive save and export'));
  const nav=node('nav');nav.className='deck-thumbnails';nav.setAttribute('aria-label','Slide sorter');
  for(const slide of deck.slides){const b=button(`${deck.slides.indexOf(slide)+1}. ${slide.title}`,()=>{if(hasDraft())throw Error('Apply slide field edits first');chooseSelection(slide.id,slide.elements[0]?.id??'');});b.setAttribute('aria-pressed',String(slide.id===selectedSlide));const preview=node('div');preview.className='deck-thumbnail';preview.innerHTML=svg(slide);b.append(preview);nav.append(b);}container.append(nav);
  const controls=node('div');controls.className='grid';
  for(const [text,run] of [['Move slide earlier',()=>session.move(selectedSlide,-1)],['Move slide later',()=>session.move(selectedSlide,1)],['Undo deck edit',()=>session.undo()],['Redo deck edit',()=>session.redo()]])controls.append(button(text,()=>{if(hasDraft())throw Error('Apply slide field edits first');run();render();onChange();}));
  container.append(controls);const slide=deck.slides.find(s=>s.id===selectedSlide)??deck.slides[0];selectedSlide=slide.id;
  const stage=node('div');stage.className='deck-stage';stage.innerHTML=svg(slide);container.append(stage);
  if(slide.notes)container.append(node('p',slide.notes));
  const list=node('div');for(const element of slide.elements)list.append(button(element.id+' · '+element.kind,()=>{if(hasDraft())throw Error('Apply slide field edits first');chooseSelection(selectedSlide,element.id);}));container.append(list);
  const element=slide.elements.find(e=>e.id===selectedElement)??slide.elements[0];selectedElement=element?.id??'';form=node('form');
  if(element){for(const key of fieldKeys)if(Object.hasOwn(element,key)){const label=node('label',key),input=node(key==='text'?'textarea':'input');input.name=key;input.maxLength=32000;input.value=String(element[key]);label.append(input);form.append(label);}
   form.onsubmit=async event=>{event.preventDefault();if(busy||disposed)return;busy=true;try{const fieldsBefore=JSON.stringify(fieldValues()),slideBefore=selectedSlide,elementBefore=selectedElement;const patch=Object.fromEntries(Object.entries(fieldValues()).map(([k,v])=>[k,['x','y','width','height','fontSize'].includes(k)?Number(v):v]));await session.edit(selectedSlide,selectedElement,patch,{isCurrent:()=>!disposed&&selectedSlide===slideBefore&&selectedElement===elementBefore&&JSON.stringify(fieldValues())===fieldsBefore});render();onChange();}catch(e){notice(e.message);}finally{busy=false;}};
   const applyButton=node('button','Apply slide changes');applyButton.type='button';applyButton.onclick=()=>form.onsubmit({preventDefault(){}});form.append(applyButton);
  }container.append(form);
 };
 const editor={
  load(deck,options={}){
   if(disposed)throw Error('Deck editor is closed');if(busy)throw Error('Wait for the deck edit');
   const source=validateSceneDeck(deck),view=sourceView(source,source.slides[0].id,source.slides[0].elements[0]?.id??'');
   const prepared=prepareSession(source,view,Object.hasOwn(options,'sourceRef')?options.sourceRef:readSourceRef());
   session=prepared.session;selectedSlide=view.selectedSlide;selectedElement=view.selectedElement;render();prepared.finish();
  },
  source(){return session?.source()??null;},hasDraft,
  snapshot(){return {schema:'omega-deck-draft-1',document_id:documentId,source:session.source(),...session.snapshot(),selectedSlide,selectedElement,fields:fieldValues()};},
  async insertImage(image,{expectedSnapshot,isCurrent=()=>true}={}){
   if(disposed||!session)throw Error('An open deck is required');
   if(busy||hasDraft())throw Error('Apply or clear slide field edits before adding an image');
   const before=expectedSnapshot??JSON.stringify(editor.snapshot()),original=session,slideBefore=selectedSlide;
   const current=()=>!disposed&&isCurrent()&&session===original&&selectedSlide===slideBefore&&!hasDraft()&&JSON.stringify(editor.snapshot())===before;
   if(!current())throw Error('Deck changed before image insertion; your work is retained');
   busy=true;
   try{
    const result=await original.insertImage(image,{slideId:slideBefore,expectedSnapshot:before,readSnapshot:()=>editor.snapshot(),isCurrent:current,document:doc});
    selectedElement=result.elementId;render();onChange();return result.source;
   }finally{busy=false;}
  },
  restore(snapshot,options={}){
   if(disposed)throw Error('Deck editor is closed');if(busy)throw Error('Wait for the deck edit');
   if(snapshot?.schema!=='omega-deck-draft-1')throw Error('Unsupported deck draft');
   const source=validateSceneDeck(snapshot.source),slide=source.slides.find(s=>s.id===snapshot.selectedSlide),element=slide?.elements.find(e=>e.id===snapshot.selectedElement);
   if(!slide||(snapshot.selectedElement&&!element)||!snapshot.fields||typeof snapshot.fields!=='object'||Array.isArray(snapshot.fields)||Object.entries(snapshot.fields).some(([k,v])=>!fieldKeys.includes(k)||typeof v!=='string'||v.length>32000))throw Error('Invalid deck draft fields');
   const view=sourceView(source,snapshot.selectedSlide,snapshot.selectedElement);
   view.documentId=typeof snapshot.document_id==='string'?snapshot.document_id:documentId;view.fields={...view.fields,...clone(snapshot.fields)};
   const prepared=prepareSession(source,view,Object.hasOwn(options,'sourceRef')?options.sourceRef:readSourceRef());
   prepared.session.restore(snapshot);
   if(JSON.stringify(prepared.session.source())!==JSON.stringify(source))throw Error('Deck draft source differs');
   documentId=view.documentId;session=prepared.session;selectedSlide=view.selectedSlide;selectedElement=view.selectedElement;render();
   for(const input of form.elements)if(input.name&&Object.hasOwn(snapshot.fields,input.name))input.value=snapshot.fields[input.name];
   prepared.finish();onChange();
  },
  isBusy:()=>busy,
  dispose(){disposed=true;}
 };
 return editor;
}
