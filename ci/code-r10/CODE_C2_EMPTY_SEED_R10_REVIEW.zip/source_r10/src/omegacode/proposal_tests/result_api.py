"""Default-off own test collection/output/cancel, with no generic authority."""
import json, time
from typing import Annotated
from fastapi import APIRouter, Depends, Header, Query
from pydantic import BaseModel, ConfigDict, Field, StrictStr
from omegacode.common import canonical, digest, CodeError, MAX_LOG
from omegacode.proposal_launch_custody import Custody, execution_binding
from .purpose_auth import PurposeAuthority
from .proposal_host_wire import launch_binding, key, fail
from .launch_admission import scope_binding
from .result_view import view
from .own_cancel import cancel
from .pre_native_cancel import cancel as cancel_before_native
NATIVE_KEYS = ['id', 'nonce', 'workspace_id', 'generation', 'tree_digest', 'grant_id', 'author', 'argv', 'timeout_seconds', 'launch_custody_id', 'proposal_purpose_test']

def native_fence(service, row):
    """Original identity only: benign native status/receipt progress is allowed."""
    runs = [r for r in service.store.list('run') if r['id'] == row['run_id']]
    if not runs:
        return None
    run = runs[0]
    native = execution_binding(service.store, row)
    grant = service.store.db.execute('SELECT body FROM grants WHERE id=?', (native['grant_id'],)).fetchone()
    if grant is None:
        fail('purpose_result_original')
    return dict(run={n: run.get(n) for n in NATIVE_KEYS}, execution=native, grant_body=grant[0])

def collect(service, authority, p, host, launch_key=None, after=0, limit=16384):
    g = p.grant
    claims = canonical(g)
    purpose = g['proposal_test']
    tid = purpose['test_id']
    path = '/v1/proposal-tests/' + tid
    authority.require_route(p, 'GET', path)
    service._check_owner(required=True)
    if type(after) is not int or not 0 <= after <= MAX_LOG or type(limit) is not int or (not 1 <= limit <= 65536):
        fail('purpose_result_cursor')
    if launch_key is not None:
        key(launch_key)
    with service.store.lock:
        original_grant = None
        preparations = [r for r in service.store.list('proposal_preparation') if r['id'] == tid]
        bindings = [r for r in service.store.list('proposal_preparation_bind') if r['id'] == tid]
        rows = [r for r in service.store.list('proposal_launch') if r['test_id'] == tid]
        if len(rows) > 4:
            fail('purpose_result_collection')
        saved = preparations[0] if preparations else None
        bound = bindings[0] if bindings else None
        if saved is None:
            if rows or bound is not None or purpose['stage'] != 'prepare':
                fail('purpose_result_scope')
        else:
            if saved['binding'] != scope_binding(g):
                fail('purpose_result_scope')
            if bound is not None:
                if bound['fingerprint'] != digest(canonical(bound['body'])):
                    fail('purpose_result_scope')
                original = service.store.db.execute('SELECT body FROM grants WHERE id=?', (bound['body']['capability_id'],)).fetchone()
                if original is None:
                    fail('purpose_result_original')
                original_grant = (bound['body']['capability_id'], original[0])
                original = json.loads(original[0])
                if scope_binding(original) != scope_binding(g) or (purpose.get('origin_grant_id') if purpose['stage'] == 'result' else g.get('grant_id')) != original.get('grant_id'):
                    fail('purpose_result_original')
            elif rows or purpose['stage'] != 'prepare':
                fail('purpose_result_scope')
        expected = launch_binding(g)
        for row in rows:
            key(row['launch_key'])
            payload = {n: row[n] for n in ['test_id', 'launch_key', 'binding', 'argv', 'runtime_seconds']}
            if row['id'] != 'pl_' + digest(canonical([tid, row['launch_key']])) or row['fingerprint'] != digest(canonical(payload)):
                fail('purpose_result_scope')
            for (name, value) in expected.items():
                if name == 'fork' and (purpose['stage'] == 'prepare' or (purpose['stage'] == 'result' and value['workspace_id'] is None)):
                    continue
                if row['binding'].get(name) != value:
                    fail('purpose_result_scope')
            if row['binding']['fork'] != dict(workspace_id=saved['fork_workspace_id'], preparation_digest='sha256:' + saved['preparation_digest']):
                fail('purpose_result_scope')
    entries = []
    native_fences = {}
    for row in sorted(rows, key=lambda r: r['launch_key']):
        if launch_key is not None and row['launch_key'] != launch_key:
            continue
        if row['hold_id'] is None:
            existing = host.lookup(tid, row['launch_key'])
            service._check_owner(required=True)
            if existing is not None:
                row = Custody(service.store).attach_hold(row['id'], host.projection(existing, row))
        with service.store.lock:
            native_fences[row['id']] = native_fence(service, row)
        native = native_fences[row['id']] is not None
        result = view(service, authority, p, row['launch_key'], after, limit) if native else None
        entries.append(dict(launch_key=row['launch_key'], launch_id=row['id'], run_id=row['run_id'], nonce=row['nonce'], state=Custody(service.store).get(row['id'])['state'], hold_id=row['hold_id'], hold_recovery_required=row['hold_recovery_required'], result=result, recovery='original_native_result' if native else 'native_record_unconfirmed', descendants_stopped=result['observation'].get('descendants_stopped', False) if result else False))
    if launch_key is not None and (not entries):
        raise CodeError(404, 'proposal_launch_missing', 'own original launch not found')
    retained = [r for r in service.store.list('proposal_launch') if r['test_id'] == tid]
    fixed = ['id', 'test_id', 'launch_key', 'binding', 'argv', 'runtime_seconds', 'run_id', 'nonce', 'spawn_marker', 'fingerprint']
    if {r['id'] for r in retained} != {r['id'] for r in rows} or any(({n: r[n] for n in fixed} != {n: next((old for old in rows if old['id'] == r['id']))[n] for n in fixed} for r in retained)):
        fail('purpose_result_changed')
    authority.require_route(p, 'GET', path)
    with service.store.lock:
        service._check_owner(required=True)
        if canonical(g) != claims or g['exp'] <= time.time() or [r for r in service.store.list('proposal_preparation') if r['id'] == tid] != preparations or ([r for r in service.store.list('proposal_preparation_bind') if r['id'] == tid] != bindings) or ([r for r in service.store.list('proposal_launch') if r['test_id'] == tid] != retained):
            fail('purpose_result_changed')
        if original_grant is not None:
            current = service.store.db.execute('SELECT body FROM grants WHERE id=?', (original_grant[0],)).fetchone()
            if current is None or current[0] != original_grant[1]:
                fail('purpose_result_changed')
        for row in retained:
            if row['id'] in native_fences and native_fence(service, row) != native_fences[row['id']]:
                fail('purpose_result_changed')
    return dict(test_id=tid, preparation=None if saved is None else dict(fork_workspace_id=saved['fork_workspace_id'], preparation_digest='sha256:' + saved['preparation_digest'], test_tree_digest='sha256:' + saved['test_tree_digest'], bind_state=bound['state'] if bound else 'not_bound'), launches=entries, authority_renewed=False, host_settled=False, source_accepted=False)

class CancelBody(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    operation_id: Annotated[StrictStr, Field(pattern='^[A-Za-z0-9_.:-]{8,120}$')]

def install(app, service, authority, host, *, enabled=False):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    if not enabled:
        return False
    if app.state.service is not service or not isinstance(authority, PurposeAuthority) or authority.store is not service.store or (authority.registration != service.authority.registration) or (not authority._proposal_enabled):
        raise ValueError('same registered service/Store required')
    if getattr(app.state, '_code_purpose_result_installed', False):
        raise ValueError('purpose result routes already installed')

    def principal(authorization: Annotated[str | None, Header()]=None, x_hive_token: Annotated[str | None, Header()]=None):
        if not authorization or not authorization.startswith('Bearer '):
            raise CodeError(401, 'authentication_required', 'a scoped bearer capability is required')
        return authority.authenticate(authorization[7:], x_hive_token)
    router = APIRouter()

    @router.get('/v1/proposal-tests/{test_id}')
    def get(test_id: str, launch_key: Annotated[str | None, Query()]=None, after: Annotated[int, Query(ge=0, le=MAX_LOG)]=0, limit: Annotated[int, Query(ge=1, le=65536)]=16384, p=Depends(principal)):
        authority.require_route(p, 'GET', '/v1/proposal-tests/' + test_id)
        return collect(service, authority, p, host, launch_key, after, limit)

    @router.post('/v1/proposal-tests/{test_id}/launches/{launch_key}/cancel')
    def stop(test_id: str, launch_key: str, body: CancelBody, p=Depends(principal)):
        authority.require_route(p, 'POST', '/v1/proposal-tests/' + test_id + '/launches/' + launch_key + '/cancel')
        id_ = 'pl_' + digest(canonical([test_id, launch_key]))
        row = Custody(service.store).get(id_)
        if row['ever_spawning'] is False:
            return cancel_before_native(service, authority, p, host, launch_key, body.operation_id)
        return cancel(service, authority, p, launch_key, body.operation_id)
    app.include_router(router)
    app.state._code_purpose_result_installed = True
    return True
