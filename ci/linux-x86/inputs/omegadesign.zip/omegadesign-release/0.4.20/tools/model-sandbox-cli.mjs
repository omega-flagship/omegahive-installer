// Fixed native head; no provider, renderer substitution, caller paths or authority.
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {canonical,digest} from './scene.mjs';
import {MODEL_LIMITS,readModelSource,sourceText} from './model-source.mjs';
import {MODEL_ACTIONS,initializeModel,inspectModel,reviseModel} from './model-operations.mjs';
const hash=bytes=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
async function read(name,cap){const info=await fs.lstat(name);if(!info.isFile()||info.isSymbolicLink()||info.size>cap)throw Error('Bounded native input required');const raw=await fs.readFile(name);if(raw.length!==info.size||raw.length>cap)throw Error('Native input changed');return raw;}
const decode=raw=>new TextDecoder('utf-8',{fatal:true}).decode(raw);
const bytes=text=>Buffer.from(text,'utf8');
const write=async(name,raw)=>fs.writeFile(name,raw,{flag:'wx'});
try{
 const [operation,...extra]=process.argv.slice(2);if(extra.length||!MODEL_ACTIONS.includes(operation))throw Error('One fixed Model operation required');
 const source=await read('source.json',MODEL_LIMITS.sourceBytes),sourceText_=decode(source),arguments_=JSON.parse(decode(await read('params.json',64*1024)));
 if(operation==='model-inspect'){
  const inspection=await inspectModel(sourceText_,arguments_);await write('inspection.json',bytes(JSON.stringify(inspection)+'\n'));
  console.log(JSON.stringify({operation,adopted:false}));
 }else if(operation==='model-init'||operation==='model-revise'){
  const revision=operation==='model-init'?await initializeModel(JSON.parse(sourceText_),arguments_):await reviseModel(sourceText_,arguments_);
  const raw=bytes(sourceText(revision));await readModelSource(decode(raw));
  if(raw.length>MODEL_LIMITS.sourceBytes)throw Error('Bounded Model source output required');
  await write('editable-model.json',raw);
  console.log(JSON.stringify({operation,model_id:revision.document.id,model_digest:revision.digest,metadata_digest:await digest(revision.document.metadata),adopted:false}));
 }else{
  if(!arguments_||Object.getPrototypeOf(arguments_)!==Object.prototype||Object.keys(arguments_).length)throw Error('Model export has no caller options');
  const revision=await readModelSource(sourceText_);
  // Root must build this actual flat module from the pinned Three/client closure.
  // It intentionally does not exist in SOURCE_PREPARATION_PENDING_NATIVE_BUILD.
  const {exportNativeModelGLB,readNativeModelGLB,generator}=await import('./model-export-native.mjs');
  const buffer=await exportNativeModelGLB(revision),glb=Buffer.from(buffer);
  if(glb.length>20*1024*1024||canonical(await readNativeModelGLB(buffer))!==canonical(revision))throw Error('Native GLB retained source differs');
  const records={'editable-model.json':{digest:hash(source),bytes:source.length,mime:'application/json'},'model.glb':{digest:hash(glb),bytes:glb.length,mime:'model/gltf-binary'}};
  const delivery={schema:'omega-model-delivery-1',model_id:revision.document.id,model_digest:revision.digest,metadata_digest:await digest(revision.document.metadata),units:revision.document.units,object_ids:revision.document.objects.map(object=>object.id),source_digest:hash(source),files:records,precision:'Editable JSON numbers retained; delivered mesh attributes use glTF float32.',generator,editable:true,adopted:false,independent_review:false};
  const declaration=bytes(JSON.stringify(delivery)+'\n');
  if(declaration.length>32*1024||source.length+glb.length+declaration.length>30*1024*1024)throw Error('Model delivery output bound');
  // All validation/preparation precedes exclusive writes; any partial job is not published.
  await write('editable-model.json',source);await write('model.glb',glb);await write('manifest.json',declaration);
  console.log(JSON.stringify({operation,model_id:revision.document.id,model_digest:revision.digest,adopted:false}));
 }
}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}
