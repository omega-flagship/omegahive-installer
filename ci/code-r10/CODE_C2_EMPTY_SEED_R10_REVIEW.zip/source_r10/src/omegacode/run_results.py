"""Retain inspected stopped-run output via existing workspace artifact custody."""
import base64
import json
from .common import CodeError, canonical, digest, ident, safe_path, stamp
from .context_selection import select
from .run_tree_capture import capture, changes


class RunResults:
    def import_run_result(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        self._result_read_authority(principal, ws)
        selected = payload.get('selected_paths')
        if (type(selected) is not list or not 1 <= len(selected) <= 2000
                or any(type(p) is not str for p in selected) or len(set(selected)) != len(selected)):
            raise CodeError(400, 'result_selection', 'select unique bounded retained changed paths')
        selected = sorted(safe_path(p) for p in selected)
        retained = self.run_result(principal, ws_id, payload['result_id'])
        row, content = retained['record'], retained['content']
        if payload['result_digest'] != row['digest']:
            raise CodeError(409, 'result_selection', 'import requires exact retained record digest')
        delta = {c['path']:c for c in content['changes']}
        if not set(selected) <= delta.keys():
            raise CodeError(400, 'result_selection', 'selected paths must be retained changes')
        exact = {**payload, 'selected_paths':selected, 'paths':selected, 'mutation':'import-run-result',
                 'input_generation':content['input_generation'],'input_tree_digest':content['input_tree_digest'],
                 'result_tree_digest':content['result_tree_digest'],'run_receipt_digest':content['run_receipt_digest'],
                 'file_changes':{p:delta[p] for p in selected},
                 'context_policy_digest':content['context_selection']['policy_digest']}
        def apply():
            current = self.workspace(ws_id)
            self._fresh(current, payload['expected_generation'], payload['expected_tree_digest'])
            self._fresh(current, content['input_generation'], content['input_tree_digest'])
            self._context_current(current, content['context_selection'])
            self._result_read_authority(principal, current)
            before = self.manifest(current)['files']
            files = dict(before)
            for path in selected:
                change = delta[path]
                if before.get(path) != change['before']:
                    raise CodeError(409, 'result_stale', 'candidate file differs from captured run input')
                incoming = change['after']
                if incoming is None:
                    files.pop(path, None)
                else:
                    if incoming != content['manifest']['files'].get(path):
                        raise CodeError(409, 'result_corrupt', 'result path metadata differs from retained manifest')
                    data = self.store.read_blob(incoming['digest'], ws_id)
                    from .common import MAX_FILE
                    if len(data) != incoming['size'] or len(data) > MAX_FILE or type(incoming['executable']) is not bool:
                        raise CodeError(409, 'result_corrupt', 'result byte or mode binding differs from custody')
                    files[path] = dict(incoming)
            from .git_export import validate_paths
            validate_paths(files, code='result_path_collision')
            tree = self._manifest(files, ws_id)
            change = {'id':ident('cs'),'workspace_id':ws_id,'task_id':current['task_id'],'author':principal.actor,
                      'base_commit':current['base_commit'],'before_digest':current['tree_digest'],
                      'tree_digest':tree,'generation':current['generation']+1,'paths':selected,
                      'run_result_id':row['id'],'run_result_digest':row['digest'],'run_id':row['run_id'],
                      'file_changes':{p:{'before':before.get(p),'after':files.get(p)} for p in selected},
                      'created_at':stamp(),'verification_inherited':False}
            change['diff_digest'] = self.store.blob(self._diff(current,current['tree_digest'],tree).encode(),ws_id,'diff')
            current.update(generation=change['generation'],tree_digest=tree)
            current['history'].append({'generation':current['generation'],'tree_digest':tree,
                                       'author':principal.actor,'change_id':change['id'],'run_result_id':row['id']})
            self.store.put('workspace',current)
            self.store.put('change',change)
            self.store.emit(current,'workspace.run-result-imported',change)
            return {'workspace':current,'change':change,'result_id':row['id'],
                    'result_digest':row['digest'],'verification_inherited':False}
        return self._operation(principal,'edit',ws,exact,apply)

    def _result_read_authority(self, principal, ws):
        self._live(principal)
        self._authorize(principal, 'read', ws, {})
        if principal.grant['paths']:
            raise CodeError(403, 'result_scope', 'result capture and inspection require full workspace read scope')

    def _result_stopped(self, run):
        if (run['status'] not in ('completed','failed','cancelled','timed_out','interrupted','output_limit')
                or run.get('descendants_terminated') is not True or not run.get('receipt_digest')
                or self._group_live(run) is not False):
            raise CodeError(409, 'result_run_active', 'result capture requires observed stopped run and retained receipt')
        try:receipt = json.loads(self.store.read_blob(run['receipt_digest'], run['workspace_id']))
        except (ValueError, TypeError):
            raise CodeError(409, 'result_receipt', 'run receipt encoding is invalid') from None
        if (receipt.get('run_id') != run['id'] or receipt.get('nonce') != run['nonce']
                or receipt.get('descendants_terminated') is not True):
            raise CodeError(409, 'result_receipt', 'run receipt binding is invalid')
        for group in (run.get('debugger_cleanup') or {}).get('target_pgids', []):
            from .runner import group_members
            if group_members(group):
                raise CodeError(409, 'result_run_active', 'debugger target group is still present')

    def capture_run_result(self, principal, run_id, payload):
        self.reconcile()
        run = self.store.get('run', run_id)
        ws = self.workspace(run['workspace_id'])
        self._result_read_authority(principal, ws)
        payload = {**payload, 'run_id':run_id, 'mutation':'retain-run-result'}
        def apply():
            current = self.workspace(ws['id'])
            self._result_read_authority(principal, current)
            run = self.store.get('run', run_id)
            if (type(payload['expected_generation']) is not int or payload['expected_generation'] != run['generation']
                    or payload['expected_tree_digest'] != run['tree_digest']):
                raise CodeError(409, 'result_source', 'expected source must identify this run input')
            self._result_stopped(run)
            base = self.manifest(current, run['tree_digest'])
            config = self.repositories[current['repository_id']]
            base_visible, context = select(base['files'], config,
                lambda value:self.store.read_blob(value, current['id']), self.store.root)
            self._context_current(current, context)
            try:
                observed = capture(self.store.root/'runs'/run_id/'tree')
            except (ValueError, OSError, UnicodeError, RecursionError):
                raise CodeError(422, 'result_capture_refused', 'bounded result tree capture refused') from None
            by_digest = {digest(data):data for data in observed['bodies'].values()}
            visible, observed_context = select(observed['manifest']['files'], config,
                                               lambda value:by_digest[value], self.store.root)
            if observed_context['policy_digest'] != context['policy_digest']:
                raise CodeError(409, 'result_context', 'result changed context rules; refresh through explicit review')
            manifest = {'files':visible}
            delta = changes({'files':base_visible}, {'manifest':manifest})
            size = sum(v['size'] for v in visible.values())
            budget_row = self.store.db.execute("SELECT body FROM records WHERE kind='run_result_budget' AND id=?", (ws['id'],)).fetchone()
            budget = json.loads(budget_row[0]) if budget_row else {'id':ws['id'], 'count':0, 'bytes':0}
            if budget['count'] >= 32 or budget['bytes'] + size > 128*1024*1024:
                raise CodeError(429, 'result_budget', 'retained result count or byte budget exhausted')
            self._result_read_authority(principal, current)
            self._fresh(self.workspace(ws['id']), current['generation'], current['tree_digest'])
            self._context_current(self.workspace(ws['id']), context)
            self._result_stopped(self.store.get('run', run_id))
            # Only selected bytes are admitted to existing artifact custody.
            for name, entry in visible.items():
                if self.store.blob(observed['bodies'][name], ws['id'], 'run-result-source') != entry['digest']:
                    raise CodeError(409, 'result_capture_refused', 'result digest changed')
            result_digest = self.store.blob(canonical(manifest), ws['id'], 'run-result-tree')
            content = {'schema':'omegacode-run-result-v1','run_id':run_id,'workspace_id':ws['id'],
                       'input_generation':run['generation'],'input_tree_digest':run['tree_digest'],
                       'result_tree_digest':result_digest,'manifest':manifest,'changes':delta,
                       'context_selection':context,'run_receipt_digest':run['receipt_digest'],
                       'matching_observations':2,'atomic_snapshot':False,'source':'observed-stopped-run-tree',
                       'profile':'trusted-native','effect_authority':False,'verification_inherited':False}
            row = {'id':ident('rr'),'workspace_id':ws['id'],'run_id':run_id,
                   'digest':self.store.blob(canonical(content), ws['id'], 'run-result'),
                   'created_by':principal.actor,'created_at':stamp()}
            self.store.put('run_result', row)
            budget.update(count=budget['count']+1,bytes=budget['bytes']+size)
            self.store.put('run_result_budget', budget)
            self.store.emit(current, 'run.result-retained', row)
            return row
        return self._operation(principal, 'checkpoint', ws, payload, apply)

    def run_result(self, principal, ws_id, result_id):
        ws = self.workspace(ws_id)
        self._result_read_authority(principal, ws)
        self.authority.gate(principal, 'read', {'workspace_id':ws_id,'resource':'run-result','result_id':result_id})
        row = self.store.get('run_result', result_id)
        if row['workspace_id'] != ws_id:
            raise CodeError(403, 'result_scope', 'result belongs to another workspace')
        content = json.loads(self.store.read_blob(row['digest'], ws_id))
        if (content.get('schema') != 'omegacode-run-result-v1' or content.get('workspace_id') != ws_id
                or content.get('run_id') != row['run_id']
                or digest(canonical(content['manifest'])) != content['result_tree_digest']
                or self.store.read_blob(content['result_tree_digest'], ws_id) != canonical(content['manifest'])):
            raise CodeError(409, 'result_corrupt', 'retained result binding is invalid')
        run = self.store.get('run', row['run_id'])
        if (run['workspace_id'] != ws_id or run['generation'] != content['input_generation']
                or run['tree_digest'] != content['input_tree_digest'] or run.get('receipt_digest') != content['run_receipt_digest']):
            raise CodeError(409, 'result_corrupt', 'retained run source binding is invalid')
        self.store.read_blob(content['input_tree_digest'], ws_id)
        self.store.read_blob(content['run_receipt_digest'], ws_id)
        self._context_current(ws, content['context_selection'])
        self._result_read_authority(principal, ws)
        current = self.workspace(ws_id)
        self._context_current(current, content['context_selection'])
        return {'record':row,'content':content,'currency':'current-input' if
                (current['generation'],current['tree_digest']) == (content['input_generation'],content['input_tree_digest'])
                else 'historical-input'}

    def run_result_source(self, principal, ws_id, result_id, path, after=0, limit=16384):
        if type(after) is not int or after < 0 or type(limit) is not int or not 1 <= limit <= 16384:
            raise CodeError(400, 'result_page', 'bounded byte page required')
        result = self.run_result(principal, ws_id, result_id)
        path = safe_path(path)
        entry = result['content']['manifest']['files'].get(path)
        if entry is None:
            raise CodeError(404, 'result_path', 'path is absent or context-excluded from retained result')
        data = self.store.read_blob(entry['digest'], ws_id)
        if len(data) != entry['size']:
            raise CodeError(409, 'result_corrupt', 'result file size differs from custody')
        if after > len(data):
            raise CodeError(416, 'result_page', 'byte cursor exceeds result file')
        cursor = min(len(data), after+limit)
        final = self.run_result(principal, ws_id, result_id)
        return {'result_id':result_id,'result_digest':result['record']['digest'],'path':path,
                'run_id':result['content']['run_id'],'workspace_id':ws_id,
                'input_generation':result['content']['input_generation'],
                'input_tree_digest':result['content']['input_tree_digest'],
                'result_tree_digest':result['content']['result_tree_digest'],
                'file_digest':entry['digest'],'size':len(data),'after':after,'cursor':cursor,
                'eof':cursor==len(data),'data':base64.b64encode(data[after:cursor]).decode(),
                'currency':final['currency'],'source':'retained-run-result','effect_authority':False}
