"""Frozen, operator-enabled debugger JSONL worker. All controls require run authority."""
import json
import pathlib
import signal
import sys
import termios
import tty

# -I keeps target cwd out of imports; only the server's frozen executor is added.
if __package__ in (None, ''): sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from omegacode.common import atomic_write, canonical, digest, safe_path
from omegacode.debugger import Dap


def runtime_identity(config):
    root = pathlib.Path(config['root']).resolve()
    exe = pathlib.Path(config['executable']).absolute()
    if not exe.is_relative_to(root) or not exe.is_file(): raise ValueError('debugger interpreter must be inside operator runtime')
    hashes, total = {}, 0
    for site in (root/'lib').glob('python*/site-packages'):
        for package in site.glob('debugpy*'):
            for path in sorted(package.rglob('*')):
                if '__pycache__' in path.parts: continue
                if path.is_symlink(): raise ValueError('debugger package symlinks unsupported')
                if path.is_file():
                    total += path.stat().st_size
                    if total > 32*1024**2 or len(hashes) >= 2000: raise ValueError('debugger package identity budget exceeded')
                    hashes[str(path.relative_to(root))] = digest(path.read_bytes())
    if not hashes: raise ValueError('debugpy package unavailable')
    return {'root':str(root), 'executable':str(exe), 'runtime':'debugpy',
            'executable_digest':digest(exe.read_bytes()), 'package_digest':digest(canonical(hashes))}


def emit(value):
    raw = canonical(value)
    if len(raw) > 65536:
        raw = canonical({'event':'error', 'id':value.get('id'), 'reason':'debugger response exceeds 65536 bytes', 'state_may_have_changed':True})
    sys.stdout.buffer.write(raw+b'\n');sys.stdout.buffer.flush()


def unique(pairs):
    result = {}
    for key,value in pairs:
        if key in result: raise ValueError('duplicate JSON fields forbidden')
        result[key]=value
    return result


def positive(request, key, maximum=2147483647, default=None):
    value = request.get(key, default)
    if type(value) is not int or not 1 <= value <= maximum: raise ValueError('invalid '+key)
    return value


def control(adapter, request, expected, state):
    if type(request) is not dict or type(request.get('id')) is not str or not 1 <= len(request['id']) <= 160:
        raise ValueError('input needs bounded string id')
    op = request.get('op')
    allowed = {'launch':{'path','breakpoints'}, 'threads':set(), 'stack':{'thread_id','after','limit'},
        'scopes':{'frame_id'}, 'variables':{'reference','after','limit'},
        'next':{'thread_id'}, 'step-in':{'thread_id'}, 'step-out':{'thread_id'},
        'continue':{'thread_id'}, 'pause':{'thread_id'}, 'wait':{'event','timeout_ms'}, 'close':set()}
    if op not in allowed or set(request)-({'id','op'}|allowed[op]): raise ValueError('unknown debugger operation or fields')
    if op == 'close': return {'closed':True}, True
    if op == 'launch':
        if state['launched']: raise ValueError('one debug target per frozen session')
        name = safe_path(request.get('path'))
        state['launched'] = True  # An uncertain launch is never silently repeated.
        return adapter.launch_python(expected['executable'], name, request.get('breakpoints', [])), False
    if not state['launched']: raise ValueError('launch saved source first')
    if op == 'wait':
        if request.get('event') not in ('stopped','continued','output','exited','terminated','process','thread','breakpoint'):
            raise ValueError('unsupported debugger event')
        return adapter.event(request['event'], positive(request,'timeout_ms',5000,1000)/1000), False
    commands = {'threads':'threads', 'stack':'stackTrace','scopes':'scopes','variables':'variables',
        'next':'next','step-in':'stepIn','step-out':'stepOut','continue':'continue','pause':'pause'}
    args = {}
    if op in ('stack','next','step-in','step-out','continue','pause'): args['threadId']=positive(request,'thread_id')
    if op == 'scopes': args['frameId']=positive(request,'frame_id')
    if op == 'variables': args['variablesReference']=positive(request,'reference')
    if op in ('stack','variables'):
        after = request.get('after',0)
        if type(after) is not int or not 0 <= after <= 100000: raise ValueError('invalid after')
        limit = positive(request,'limit',100,20)
        args.update({'startFrame':after,'levels':limit} if op=='stack' else {'start':after,'count':limit})
    return adapter.request(commands[op],args), False


class Stopped(BaseException): pass


def main():
    config_path=pathlib.Path(sys.argv[1]);root=config_path.parent
    expected=json.loads(config_path.read_text());spec=json.loads((root/'spec.json').read_text())
    adapter=None;original=None;observed=False
    def stop(_sig,_frame): raise Stopped()
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if runtime_identity(expected)!=expected: raise ValueError('debugger runtime changed after approval')
        adapter=Dap([expected['executable'],'-I','-B','-m','debugpy.adapter'],root,lifetime=min(spec['timeout_seconds'],120))
        original=termios.tcgetattr(0);tty.setraw(0)
        context={'run_id':spec['run_id'],'generation':spec['generation'],'tree_digest':spec['tree_digest'],
                 'runtime_identity_digest':digest(canonical(expected)),'runtime':'debugpy'}
        emit({'event':'ready','protocol':'omegacode-debugger-jsonl-v1','context':context,'all_inputs_require_run_authority':True})
        state={'launched':False};sequence=0
        while True:
            line=sys.stdin.buffer.readline(8193)
            if not line: break
            if len(line)>8192 or not line.endswith(b'\n'): raise ValueError('debugger input exceeds 8192 bytes or lacks newline')
            request=None;sequence+=1
            try:
                request=json.loads(line,object_pairs_hook=unique)
                result,closed=control(adapter,request,expected,state)
                emit({'event':'result','id':request['id'],'op':request['op'],'result':result,'input_sequence':sequence})
                if closed: break
            except Exception as error:
                id_=request.get('id') if type(request) is dict else None
                emit({'event':'error','id':id_ if type(id_) is str and len(id_)<=160 else None,
                      'reason':str(error)[:2000],'input_sequence':sequence,'state_may_have_changed':True})
    except Stopped: pass
    finally:
        signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
        try:
            if adapter: adapter.close()
            observed=True
        finally:
            atomic_write(root/'debugger-stop.json',canonical({'nonce':spec['nonce'],'run_id':spec['run_id'],
                'observed':observed,'adapter_pid':adapter.proc.pid if adapter else None,
                'target_pgids':sorted(adapter.targets) if adapter else []}))
            if original is not None: termios.tcsetattr(0,termios.TCSANOW,original)


if __name__=='__main__': main()
