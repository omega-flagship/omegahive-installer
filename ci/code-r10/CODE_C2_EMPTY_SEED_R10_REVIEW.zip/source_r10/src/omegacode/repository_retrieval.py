"""Source-bound lexical/vector fusion over caller-authorized Python bytes.

No provider calls, persistent index, Atom publication or effect authority. Vector
model labels are caller declarations, not independently verified provenance.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import io
import json
import math
import re
import tokenize
from typing import Mapping

from .repository_facts import RepositoryFacts, build_repository_facts


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _tokens(text):
    # Identifier splitting supports lexical code vocabulary, not semantic claims.
    return re.findall(r'[a-z0-9]+', re.sub(r'([a-z])([A-Z])', r'\1 \2', text).lower())


@dataclass(frozen=True)
class Chunk:
    id: str
    path: str
    source_digest: str
    start_line: int
    end_line: int
    text: str


@dataclass(frozen=True)
class RetrievalIndex:
    graph: RepositoryFacts
    chunks: tuple[Chunk, ...]
    version: str = 'python-source-retrieval-v1'

    @property
    def digest(self):
        return _digest([self.version, self.graph.digest, [c.id for c in self.chunks]])

    def search(self, query, *, limit=20, mode='lexical', path_prefix=None,
               fact_kind=None, fact_target=None, vectors=None, query_vector=None,
               model_id=None, vector_index_digest=None):
        if not isinstance(query, str) or not query.strip() or len(query)>4000:
            raise ValueError('query requires 1..4000 nonblank characters')
        if type(limit) is not int or not 1<=limit<=100:
            raise ValueError('limit requires 1..100')
        if mode not in ('lexical','vector','hybrid'):
            raise ValueError('unsupported retrieval mode')
        if path_prefix is not None and (not isinstance(path_prefix,str) or path_prefix not in dict(self.graph.sources)
                and not any(p.startswith(path_prefix.rstrip('/')+'/') for p,_ in self.graph.sources)):
            raise ValueError('path filter outside source census')
        kinds={f.kind for f in self.graph.facts}
        if fact_kind is not None and fact_kind not in kinds:
            raise ValueError('unknown syntax fact kind')
        if fact_target is not None and (not isinstance(fact_target,str) or len(fact_target)>1000):
            raise ValueError('invalid syntax fact target')
        if fact_target is not None and fact_kind is None:
            raise ValueError('fact target requires a kind')
        eligible=[]
        for c in self.chunks:
            if path_prefix is not None and not (c.path==path_prefix or c.path.startswith(path_prefix.rstrip('/')+'/')):
                continue
            if fact_kind is not None and not any(f.path==c.path and c.start_line<=f.line<=c.end_line
                    and f.kind==fact_kind and (fact_target is None or f.target==fact_target) for f in self.graph.facts):
                continue
            eligible.append(c)
        counts={c.id:Counter(_tokens(c.path+' '+c.text)) for c in self.chunks}
        terms=sorted(set(_tokens(query)))
        frequencies=Counter(term for count in counts.values() for term in count if term in terms)
        lexical={c.id:sum((1+math.log(counts[c.id][term]))*math.log(1+len(self.chunks)/
                    (1+frequencies[term])) for term in terms if counts[c.id][term])
                 / math.sqrt(max(1,sum(counts[c.id].values()))) for c in eligible}
        similarity={}
        if mode!='lexical':
            if vector_index_digest!=self.digest or not isinstance(model_id,str) or not model_id.strip() or len(model_id)>256:
                raise ValueError('vectors require exact index binding and declared model id')
            if not isinstance(vectors,Mapping) or set(vectors)!={c.id for c in self.chunks}:
                raise ValueError('vector census differs from source index')
            query_vector=_vector(query_vector)
            if len(vectors)*len(query_vector)>2_000_000:
                raise ValueError('vector index exceeds scalar limit')
            normalized={key:_vector(value,len(query_vector)) for key,value in vectors.items()}
            similarity={c.id:sum(a*b for a,b in zip(query_vector,normalized[c.id])) for c in eligible}
        elif any(v is not None for v in (vectors,query_vector,model_id,vector_index_digest)):
            raise ValueError('lexical mode does not consume vectors')
        def ranks(scores):
            return {key:i+1 for i,(key,value) in enumerate(sorted(scores.items(),key=lambda pair:(-pair[1],pair[0]))) if value>0}
        lr,vr=ranks(lexical),ranks(similarity)
        scores=lexical if mode=='lexical' else similarity if mode=='vector' else {
            c.id:(1/(60+lr[c.id]) if c.id in lr else 0)+(1/(60+vr[c.id]) if c.id in vr else 0) for c in eligible}
        ordered=sorted((c for c in eligible if scores[c.id]>0),key=lambda c:(-scores[c.id],c.path,c.start_line))[:limit]
        return {'index_digest':self.digest,'facts_digest':self.graph.digest,'mode':mode,
                'vector_model_declared':model_id,'vector_provenance_verified':False,
                'symbolic_filter':'syntactic facts only','results':[{'chunk_id':c.id,'path':c.path,
                    'source_digest':c.source_digest,'start_line':c.start_line,'end_line':c.end_line,
                    'text':c.text,'score':scores[c.id],'lexical_score':lexical[c.id],
                    'vector_score':similarity.get(c.id)} for c in ordered]}


def _vector(value,dimension=None):
    if not isinstance(value,(list,tuple)) or not 1<=len(value)<=2048 or dimension is not None and len(value)!=dimension:
        raise ValueError('invalid vector dimension')
    if any(type(x) not in (int,float) or not math.isfinite(x) or abs(x)>1e100 for x in value):
        raise ValueError('nonfinite or invalid vector scalar')
    norm=math.hypot(*value)
    if norm==0:
        raise ValueError('zero vector')
    return tuple(x/norm for x in value)


def build_retrieval_index(sources:Mapping[str,bytes], *, previous=None):
    from .repository_facts import _inputs
    sources = _inputs(sources)  # validate/freeze once; graph and chunks consume this exact census
    graph=build_repository_facts(sources)
    if previous is not None and (not isinstance(previous, RetrievalIndex)
            or previous.version != RetrievalIndex.version or previous.graph.parser != graph.parser):
        raise ValueError('previous retrieval index version/parser is incompatible')
    old = {} if previous is None else dict(previous.graph.sources)
    old_chunks = {} if previous is None else {path:tuple(c for c in previous.chunks if c.path==path) for path in old}
    chunks=[]
    for path,digest in graph.sources:
        body=sources[path]
        try:
            encoding,_=tokenize.detect_encoding(io.BytesIO(body).readline)
            lines=body.decode(encoding).splitlines(keepends=True)
        except (UnicodeError,SyntaxError):
            continue
        if old.get(path)==digest:
            retained = old_chunks[path]
            if len(retained) != (len(lines)+39)//40:
                raise ValueError('previous chunk census does not match source')
            for c,offset in zip(retained, range(0,len(lines),40)):
                text=''.join(lines[offset:offset+40]);end=min(offset+40,len(lines))
                if len(text.encode())>64*1024:
                    raise ValueError('source chunk exceeds 64 KiB')
                if (c.source_digest!=digest or c.start_line!=offset+1 or c.end_line!=end or c.text!=text
                        or c.id!=_digest([path,digest,offset+1,end,text])):
                    raise ValueError('previous chunk does not match exact source')
            chunks.extend(retained)
            if len(chunks)>4096:
                raise ValueError('source index exceeds 4096 chunks')
            continue
        for offset in range(0,len(lines),40):
            text=''.join(lines[offset:offset+40])
            if len(text.encode())>64*1024:
                raise ValueError('source chunk exceeds 64 KiB')
            end=min(offset+40,len(lines))
            chunks.append(Chunk(_digest([path,digest,offset+1,end,text]),path,digest,offset+1,end,text))
            if len(chunks)>4096:
                raise ValueError('source index exceeds 4096 chunks')
    return RetrievalIndex(graph,tuple(chunks))
