"""Same-connection relay proof: synthetic local requests only."""

import base64
import asyncio
import hashlib
import hmac
import re
import socket
import subprocess
import threading
import time

from fastapi.testclient import TestClient
import httpx
import pytest
from starlette.routing import WebSocketRoute
import uvicorn

from omegacode.api import create_app
from omegacode.common import CodeError, canonical
from omegacode.relay_auth import RelayChallengeStore, challenge_proof
from omegacode.service import Service


SECRET = "synthetic-capability-secret-0123456789abcdef"
SERVICE_ID = "svc_synthetic_0123456789"
OPERATOR = "synthetic-relay-test-operator-token-123456789"


@pytest.fixture
def repo(tmp_path):
    path = tmp_path / "repo"
    path.mkdir()
    (path / "hello.py").write_text("print('synthetic')\n")
    for argv in (["git", "init", "-q", str(path)], ["git", "-C", str(path), "add", "."],
                 ["git", "-C", str(path), "-c", "user.name=Test", "-c",
                  "user.email=test@example.invalid", "commit", "-qm", "synthetic"]):
        subprocess.run(argv, check=True, capture_output=True)
    return path


@pytest.fixture
def service(tmp_path, repo):
    value = Service(tmp_path / "state", OPERATOR, {"synthetic": {"path": str(repo)}})
    yield value
    value.close()


def hc1_token(service):
    claims = {"id": "cap_synthetic_123", "iss": "hive", "aud": SERVICE_ID,
              "actor": "user:synthetic", "kind": "human", "task_id": "goal_synthetic",
              "swarm_id": "swarm_synthetic", "repository_id": "synthetic", "actions": ["read"],
              "paths": [], "argv_prefixes": [], "exp": time.time() + 300,
              "max_runs": 0, "max_runtime_seconds": 60, "grant_id": "grant_synthetic"}
    payload = base64.urlsafe_b64encode(canonical(claims)).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return "hc1." + payload + "." + sig


def registration(service):
    service.authority.registration = {"service_id": SERVICE_ID, "service_token": "synthetic-service-token",
                                      "capability_secret": SECRET, "address": "http://127.0.0.1:8724"}
    service.authority.host_live = lambda claims: None


def challenge_payload(method="GET", path="/v1/capabilities", body=b""):
    return {"version": 1, "service_id": SERVICE_ID, "nonce": "a" * 64,
            "method": method, "path": path, "body_sha256": hashlib.sha256(body).hexdigest()}


def relay_headers(service, challenge_id):
    return {"Authorization": "Bearer " + hc1_token(service),
            "X-OmegaCode-Relay-Challenge": challenge_id}


def test_challenge_proof_binds_exact_relay_request(service):
    registration(service)
    client = TestClient(create_app(service), base_url="http://127.0.0.1:8724",
                        client=("127.0.0.1", 50000))
    payload = challenge_payload()
    response = client.post("/v1/relay-challenge", json=payload)
    assert response.status_code == 200, response.text
    value = response.json()
    assert set(value) == {"version", "challenge_id", "proof"}
    assert value["version"] == 1
    assert re.fullmatch(r"[A-Za-z0-9_-]{16,128}", value["challenge_id"])
    assert value["proof"] == challenge_proof(
        SECRET, service_id=SERVICE_ID, nonce=payload["nonce"], method=payload["method"],
        path=payload["path"], body_sha256=payload["body_sha256"], challenge_id=value["challenge_id"])
    assert SECRET not in response.text and "service_token" not in response.text


def test_hc1_requires_matching_challenge_and_consumes_before_auth(service):
    registration(service)
    client = TestClient(create_app(service), base_url="http://127.0.0.1:8724",
                        client=("127.0.0.1", 50001))
    token = hc1_token(service)
    no_proof = client.get("/v1/capabilities", headers={"Authorization": "Bearer " + token})
    assert no_proof.status_code == 403 and no_proof.json()["error"] == "relay_proof_failed"

    response = client.post("/v1/relay-challenge", json=challenge_payload())
    challenge_id = response.json()["challenge_id"]
    accepted = client.get("/v1/capabilities", headers=relay_headers(service, challenge_id))
    assert accepted.status_code == 200, accepted.text
    replay = client.get("/v1/capabilities", headers=relay_headers(service, challenge_id))
    assert replay.status_code == 403 and replay.json()["error"] == "relay_proof_failed"


def test_challenge_is_connection_bound_and_request_mismatch_consumes_it(service):
    registration(service)
    app = create_app(service)
    first = TestClient(app, base_url="http://127.0.0.1:8724", client=("127.0.0.1", 50002))
    second = TestClient(app, base_url="http://127.0.0.1:8724", client=("127.0.0.1", 50003))
    challenge_id = first.post("/v1/relay-challenge", json=challenge_payload()).json()["challenge_id"]
    other_connection = second.get("/v1/capabilities", headers=relay_headers(service, challenge_id))
    assert other_connection.status_code == 403
    same_connection_wrong_method = first.post("/v1/capabilities", headers=relay_headers(service, challenge_id), json={})
    assert same_connection_wrong_method.status_code == 403
    retry = first.get("/v1/capabilities", headers=relay_headers(service, challenge_id))
    assert retry.status_code == 403


def test_challenge_rejects_wrong_service_and_bearer_on_challenge(service):
    registration(service)
    client = TestClient(create_app(service), base_url="http://127.0.0.1:8724",
                        client=("127.0.0.1", 50004))
    wrong = challenge_payload() | {"service_id": "svc_other"}
    assert client.post("/v1/relay-challenge", json=wrong).status_code == 404
    with_bearer = client.post("/v1/relay-challenge", json=challenge_payload(),
                              headers={"Authorization": "Bearer ignored"})
    assert with_bearer.status_code == 400


def test_hc1_websocket_consumes_same_connection_challenge_before_auth(service, monkeypatch):
    registration(service)
    app = create_app(service)
    client = TestClient(app, base_url="http://127.0.0.1:8724",
                        client=("127.0.0.1", 50006))
    path = "/v1/runs/run_synthetic/stream"
    headers = {"Authorization": "Bearer " + hc1_token(service)}
    route = next(route for route in app.routes
                 if isinstance(route, WebSocketRoute) and route.path == "/v1/runs/{id}/stream")

    class FakeSocket:
        def __init__(self, request_headers):
            self.headers = {key.lower(): value for key, value in request_headers.items()}
            self.scope = {"client": ("127.0.0.1", 50006), "server": ("127.0.0.1", 8724),
                          "path": path, "raw_path": path.encode("ascii"), "query_string": b""}
            self.close_code = None

        async def close(self, code):
            self.close_code = code

    run_calls = []
    def reject_missing_run(principal, run_id):
        run_calls.append(run_id)
        raise CodeError(404, "not_found", "synthetic run not found")
    monkeypatch.setattr(service, "run", reject_missing_run)

    unproved = FakeSocket(headers)
    asyncio.run(route.endpoint(unproved, "run_synthetic"))
    assert unproved.close_code == 4403
    assert run_calls == []

    payload = challenge_payload(method="GET", path=path)
    challenge = client.post("/v1/relay-challenge", json=payload).json()
    headers["X-OmegaCode-Relay-Challenge"] = challenge["challenge_id"]
    proved = FakeSocket(headers)
    asyncio.run(route.endpoint(proved, "run_synthetic"))
    # The non-existent run is checked only after the relay proof was consumed.
    assert proved.close_code == 1008
    assert run_calls == ["run_synthetic"]


def test_proof_rejects_noncanonical_origin_form_targets():
    base = {"service_id": SERVICE_ID, "nonce": "a" * 64, "method": "GET",
            "body_sha256": hashlib.sha256(b"").hexdigest(), "challenge_id": "rly_synthetic"}
    for path in ("https://host/path", "/café", "/bad%ZZ", "/with space", "/x#fragment", "/x\\y"):
        with pytest.raises(ValueError):
            challenge_proof(SECRET, path=path, **base)


def test_pending_challenge_store_is_bounded_per_connection_and_expires():
    store = RelayChallengeStore(ttl_seconds=0.01, max_pending=1)
    common = {"service_id": SERVICE_ID, "nonce": "b" * 64, "method": "GET",
              "path": "/v1/capabilities", "body_sha256": hashlib.sha256(b"").hexdigest()}
    connection = ("127.0.0.1", 50005, "127.0.0.1", 8724)
    challenge_id, _ = store.issue(connection, secret=SECRET, **common)
    try:
        store.issue(connection, secret=SECRET, **common)
        assert False, "a second in-flight challenge on one connection must be refused"
    except Exception as exc:
        assert getattr(exc, "code", None) == "relay_challenge_pending"
    time.sleep(0.02)
    replacement, _ = store.issue(connection, secret=SECRET, **common)
    assert replacement != challenge_id
    assert not store.consume(connection, challenge_id, method="GET", path="/v1/capabilities", body=b"")


def test_uvicorn_keepalive_reuses_the_challenged_tcp_connection(service):
    # Unlike TestClient, this exercises Uvicorn and a real persistent loopback socket.
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    registration(service)
    service.authority.registration["address"] = f"http://127.0.0.1:{port}"
    server = uvicorn.Server(uvicorn.Config(create_app(service, port), host="127.0.0.1", port=port,
                                          log_level="critical", access_log=False, lifespan="off"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 5
    while not server.started and time.monotonic() < deadline:
        time.sleep(0.01)
    assert server.started, "Uvicorn did not start within the bounded test interval"
    try:
        limits = httpx.Limits(max_keepalive_connections=1, max_connections=1)
        with httpx.Client(base_url=f"http://127.0.0.1:{port}", limits=limits,
                          timeout=2, trust_env=False, http2=False) as client:
            payload = challenge_payload()
            proof_response = client.post("/v1/relay-challenge", json=payload)
            assert proof_response.status_code == 200, proof_response.text
            challenge_id = proof_response.json()["challenge_id"]
            relayed = client.get("/v1/capabilities", headers=relay_headers(service, challenge_id))
            assert relayed.status_code == 200, relayed.text
    finally:
        server.should_exit = True
        thread.join(timeout=5)
        assert not thread.is_alive(), "Uvicorn test server did not stop cleanly"

