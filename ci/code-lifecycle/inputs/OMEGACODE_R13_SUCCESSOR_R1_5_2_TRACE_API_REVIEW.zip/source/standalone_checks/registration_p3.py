"""Standard-library checks for the P3 guards; no HTTP client or service is started."""
import json
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT / "src"))
httpx = types.ModuleType("httpx")
httpx.HTTPError = type("HTTPError", (Exception,), {})
sys.modules.setdefault("httpx", httpx)

from omegacode.common import CodeError
import omegacode.registration as registration


class RegistrationP3Test(unittest.TestCase):
    def assert_recovery_error(self, call):
        with self.assertRaises(CodeError) as raised:
            call()
        self.assertEqual(raised.exception.status, 503)
        self.assertEqual(raised.exception.code, "registration_recovery_required")

    def test_non_object_operation_and_registration_json_fail_closed(self):
        for raw in (b"[]", b'"state"', b"null"):
            with self.subTest(raw=raw), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                operation = root / "registration.operation.json"
                operation.write_bytes(raw)
                self.assert_recovery_error(lambda: registration._remove_operation(operation, "op-id"))
                self.assert_recovery_error(lambda: registration._clear_expired(root / "missing.json", operation, "op-id"))
                authority = types.SimpleNamespace(hive_url="http://hive.invalid", client=None)
                self.assert_recovery_error(lambda: registration._enrol_locked(authority, root, "demo-token", 8724))

                saved = root / "registration.json"
                saved.write_bytes(raw)
                self.assert_recovery_error(lambda: registration._clear_expired(saved, operation, "op-id"))
                self.assert_recovery_error(lambda: registration._enrol_locked(authority, root, "demo-token", 8724))

    def test_non_object_receipts_fail_closed(self):
        for receipt in (b"[]", b'"receipt"', b"null"):
            with self.subTest(receipt=receipt), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                saved = root / "registration.json"
                saved.write_bytes(b'{"receipt":' + receipt + b'}')
                authority = types.SimpleNamespace(hive_url="http://hive.invalid", client=None)
                self.assert_recovery_error(lambda: registration._enrol_locked(authority, root, "demo-token", 8724))
                self.assert_recovery_error(lambda: registration._clear_expired(saved, root / "operation.json", "op-id"))

    def test_expired_cleanup_validates_before_removing_either_record(self):
        for raw in (b"[]", b'"operation"', b"null"):
            with self.subTest(raw=raw), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                operation_id = "synthetic-operation-id"
                saved = root / "registration.json"
                saved_bytes = json.dumps({"receipt": {"operation_id": operation_id}}, sort_keys=True,
                                         separators=(",", ":")).encode()
                saved.write_bytes(saved_bytes)
                operation = root / "registration.operation.json"
                operation.write_bytes(raw)
                self.assert_recovery_error(lambda: registration._clear_expired(saved, operation, operation_id))
                self.assertEqual(saved.read_bytes(), saved_bytes)
                self.assertEqual(operation.read_bytes(), raw)

    def test_same_process_lock_wait_returns_bounded_503(self):
        with patch.object(registration, "_REGISTRATION_LOCK_TIMEOUT_SECONDS", 0.04):
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                result = []

                def contend():
                    try:
                        with registration._registration_lock(root):
                            result.append("acquired")
                    except CodeError as error:
                        result.append((error.status, error.code, error.details))

                with registration._registration_lock(root):
                    thread = threading.Thread(target=contend)
                    thread.start()
                    thread.join(timeout=1)
                    self.assertFalse(thread.is_alive())
                self.assertEqual(result, [(503, "registration_busy", {"retry_after_seconds": 35})])


if __name__ == "__main__":
    unittest.main()
