// Browser layout observations belong to one exact rendered scene, not a quality verdict.
export function boundsIssue(element,bounds,tolerance=1){
 if(!bounds||['x','y','width','height'].some(k=>!Number.isFinite(bounds[k])))return {element_id:element.id,status:'measurement-unavailable'};
 const axes=[];
 if(bounds.x<element.x-tolerance||bounds.x+bounds.width>element.x+element.width+tolerance)axes.push('horizontal');
 if(bounds.y<element.y-tolerance||bounds.y+bounds.height>element.y+element.height+tolerance)axes.push('vertical');
 return {element_id:element.id,status:axes.length?'overflow':'fits',axes,bounds:{...bounds}};
}
export function inspectTextLayout(root,revision){
 const results=revision.scene.elements.filter(e=>e.kind==='text').map(element=>{
  const node=[...root.querySelectorAll('text[data-element]')].find(n=>n.dataset.element===element.id);
  try{const b=node.getBBox();return boundsIssue(element,{x:b.x,y:b.y,width:b.width,height:b.height});}
  catch{return boundsIssue(element,null);}
 });
 return {schema:'omega-local-layout-observation-1',subject:{scene_id:revision.scene.id,revision:revision.revision,digest:revision.digest},renderer:'browser-svg-declared-family',method:'SVG getBBox',results,assessment:'geometry-only',independent_review:false};
}
