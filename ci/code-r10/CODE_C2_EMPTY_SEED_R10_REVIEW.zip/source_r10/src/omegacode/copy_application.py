"""Candidate mechanics only; no HTTP route or controller authority activation.

The server supplies verify_binding; browser input cannot supply it. Existing Code
edit authority is still mandatory. Host purpose-capability support is held.
"""
import json

from .common import CodeError, ident, stamp
from .auth import Principal
from .copy_effect_policy import check_effect
from .suggestion_validation import reconstruct,reconstruct_v2


FIELDS = {'operation_id', 'request_id', 'suggestion_id', 'suggestion_digest',
          'expected_generation', 'expected_tree_digest', 'scope_id', 'scope_digest'}


class CopyEngine:
    def __init__(self, service, verify_binding=None):
        self.service = service
        self.verify_binding = verify_binding

    def _verify(self, principal, ws_id, payload):
        if 'copy_apply' in principal.grant:
            self.service.authority._copy_binding(principal, self.service.workspace(ws_id), payload)
            provenance = self.service.store.get('suggestion_provenance', payload['suggestion_id'])
            body = json.loads(self.service.store.read_blob(provenance['digest'], ws_id))
            c = principal.grant['copy_apply']
            d = body['delegated']
            proposal = self.service.store.get('suggestion', payload['suggestion_id'])
            if (provenance['id'] != payload['suggestion_id']
                    or body['schema'] != 'omegacode-request-proposal-v1' or body['author'] != proposal['author']
                    or provenance['workspace_id'] != ws_id or body['workspace_id'] != ws_id
                    or body['proposal_id'] != payload['suggestion_id']
                    or body['proposal_digest'] != payload['suggestion_digest']
                    or body['origin_task_id'] != principal.grant['task_id']
                    or body['origin_swarm_id'] != principal.grant['swarm_id']
                    or body['repository_id'] != principal.grant['repository_id']
                    or any(d[k] != c[k] for k in ('request_id', 'controller_id', 'execution_goal', 'issuer'))
                    or d['origin_scope'] != {'scope_id': payload['scope_id'],
                        'scope_digest': payload['scope_digest'], 'generation': payload['expected_generation']}):
                raise CodeError(403, 'copy_apply_provenance_invalid', 'retained proposal belongs to another request')
            return
        if self.verify_binding is None:
            raise CodeError(503, 'application_binding_unavailable', 'host binding verifier is not installed')
        # Require a positive verdict, including on historical receipt replay.
        if self.verify_binding(principal, ws_id, dict(payload)) is not True:
            raise CodeError(403, 'application_binding_refused', 'request/application binding is inactive')

    def apply(self, principal, ws_id, payload):
        if set(payload) != FIELDS:
            raise CodeError(400, 'application_fields', 'application requires the exact closed request body')
        s = self.service
        ws = s.workspace(ws_id)
        if 'copy_apply' in principal.grant:
            s._authorize(principal, 'proposal-apply', ws, {**payload, 'paths': [], 'mutation': 'proposal-copy-application-r1'})
        record = s.store.get('suggestion', payload['suggestion_id'])
        if (record['workspace_id'] != ws_id or record['digest'] != payload['suggestion_digest']
                or record['scope_id'] != payload['scope_id']):
            raise CodeError(403, 'suggestion_scope', 'proposal identity mismatch')
        scope_record = s.store.get('suggestion_scope', record['scope_id'])
        if 'sha256:' + scope_record['digest'] != payload['scope_digest']:
            raise CodeError(403, 'suggestion_scope', 'scope digest mismatch')
        purpose = 'copy_apply' in principal.grant
        if purpose:
            s._authorize(principal, 'proposal-apply', ws,
                         {**payload, 'paths': list(principal.grant['paths']), 'mutation': 'proposal-copy-application-r1'})
            reader = Principal(scope_record['author'], scope_record['issuer_claims'])
            if reader.actor != principal.grant['copy_apply']['issuer']:
                raise CodeError(403, 'suggestion_scope', 'scope issuer differs from request person')
        else:
            reader = principal
        scope = s._bound_suggestion_scope(reader, ws, record['scope_id'], fresh=False)
        body = json.loads(s.store.read_blob(record['digest'], ws_id))
        v2=body.get('schema')=='omegacode-scoped-suggestion-v2'
        # Keep the v1 conservative ceiling; v2 units are fully reconstructed
        # and passed to the same owner classifier with their exact typed edits.
        if not v2 and any(len(h['replacement'].encode('utf-8')) < h['end_byte'] - h['start_byte']
               for h in body['hunks']):
            raise CodeError(403, 'application_effect_refused', 'shortening requires separate owner policy handling')
        binding = {'workspace_id': ws_id, 'task_id': ws['task_id'],
                   'generation': payload['expected_generation'], 'tree_digest': payload['expected_tree_digest']}
        files = {p: s.store.read_blob(h, ws_id) for p, h in scope['file_digests'].items()}
        try:
            if v2:
                edits = reconstruct_v2(body,record['digest'],binding,files,
                    [h['id'] for h in body['hunks']],existing_paths=s.manifest(ws)['files'].keys())
            else:
                edits = reconstruct({k: v for k, v in body.items() if k not in ('scope_id', 'author')},
                                    body['digest'], binding, files, [h['id'] for h in body['hunks']])
        except (ValueError, KeyError, TypeError) as exc:
            raise CodeError(409, 'suggestion_stale', str(exc))
        if not edits or any(e['content'] is None for e in edits):
            raise CodeError(403, 'application_effect_refused', 'empty or delete effects require separate handling')
        self._verify(principal, ws_id, payload)
        check_effect(s, ws_id, payload, edits)
        # Second immutable classification immediately before entering SQL, bounded
        # by caller. The callback inspects its result without running/waiting policy.
        admission = check_effect(s, ws_id, payload, edits)

        def retain(result):
            self._verify(principal, ws_id, payload)
            admission.assert_current()
            # Revalidate the original issuer inside the transaction as well.
            s._bound_suggestion_scope(reader, s.workspace(ws_id), record['scope_id'], fresh=False)
            if any(r['suggestion_id'] == record['id'] for r in s.store.list('copy_application')):
                raise CodeError(409, 'suggestion_applied', 'proposal already applied')
            if any(r['suggestion_id'] == record['id'] for r in s.store.list('suggestion_decision')):
                raise CodeError(409, 'suggestion_decided', 'proposal already has a decision')
            change = result['change']
            old = s.manifest(ws, change['before_digest'])['files']
            app = {'id': ident('application'), 'workspace_id': ws_id, 'actor': principal.actor,
                   'request': dict(payload), 'suggestion_id': record['id'],
                   'suggestion_digest': record['digest'], 'before_tree_digest': change['before_digest'],
                   'after_tree_digest': change['tree_digest'], 'after_generation': change['generation'],
                   'change_id': change['id'], 'paths': change['paths'],
                   'before_files': {p: old[p]['digest'] if p in old else None for p in change['paths']},
                   'created_at': stamp()}
            s.store.put('copy_application', app)
            s.store.emit(s.workspace(ws_id), 'proposal.copy_applied', app)
            return {**result, 'application': app}

        create_paths=[e['path'] for e in edits if e.get('expected_digest') is None] if v2 else []
        return s.edit(principal, ws_id, {**payload, 'edits': edits,
                      'mutation': 'proposal-copy-application-r1',
                      'context_policy_digest': scope['context_selection']['policy_digest']}, _after_edit=retain,
                      _action='proposal-apply' if purpose else 'edit', _create_paths=create_paths,
                      _authorization_paths=sorted(set(scope['file_digests']) | set(scope.get('create_files', {}))) if v2 else None)

    @staticmethod
    def application_receipt(result):
        """Wire projection of the retained result; never recompute replay heads."""
        app = result['application']
        return {'application_id': app['id'], 'request_id': app['request']['request_id'],
                'workspace_id': app['workspace_id'], 'suggestion_id': app['suggestion_id'],
                'suggestion_digest': app['suggestion_digest'], 'change_id': app['change_id'],
                'before': {'generation': app['request']['expected_generation'],
                           'tree_digest': app['before_tree_digest']},
                'after': {'generation': app['after_generation'], 'tree_digest': app['after_tree_digest']},
                'workspace': result['workspace'], 'undo': {'application_id': app['id'],
                'expected_generation': app['after_generation'], 'expected_tree_digest': app['after_tree_digest']},
                'effect': 'workspace-copy-write'}

    def read(self, principal, ws_id, application_id):
        s = self.service
        with s.store.transaction():
            ws = s.workspace(ws_id)
            purpose = 'copy_apply' in principal.grant
            if not purpose:
                s._authorize(principal, 'read', ws, {})
            s._live(principal)
            app = s.store.get('copy_application', application_id)
            if app['workspace_id'] != ws_id:
                raise CodeError(403, 'application_scope', 'application belongs to another workspace')
            if purpose:
                if app['actor'] != principal.actor:
                    raise CodeError(403, 'application_scope', 'recovery is restricted to the controller own application')
                self._verify(principal, ws_id, app['request'])
                s._authorize(principal, 'proposal-apply', ws,
                    {**app['request'], 'paths': app['paths'], 'mutation': 'proposal-copy-read-r3'})
            else:
                s._authorize(principal, 'read', ws, {'paths': app['paths']})
                s.authority.gate(principal, 'read', {'workspace_id': ws_id, 'paths': app['paths'],
                                             'resource': 'copy-application', 'application_id': application_id})
            undos = [r for r in s.store.list('copy_undo') if r['application_id'] == application_id]
            currency = 'undone' if undos else ('current' if (ws['generation'], ws['tree_digest']) ==
                    (app['after_generation'], app['after_tree_digest']) else 'stale')
            s._live(principal)
            return {'application': app, 'currency': currency, 'workspace': ws, 'undo': undos[0] if undos else None}

    def undo(self, principal, ws_id, application_id, payload):
        if principal.grant.get('kind') != 'human':
            raise CodeError(403, 'person_required', 'Undo is person-only')
        if set(payload) != {'operation_id', 'expected_generation', 'expected_tree_digest'}:
            raise CodeError(400, 'application_fields', 'Undo requires the exact closed body')
        s = self.service
        app = s.store.get('copy_application', application_id)
        if app['workspace_id'] != ws_id:
            raise CodeError(403, 'application_scope', 'application belongs to another workspace')
        if (payload['expected_generation'] != app['after_generation'] or
                payload['expected_tree_digest'] != app['after_tree_digest']):
            raise CodeError(409, 'undo_stale', 'Undo must bind the exact application result')
        # Immutable AFTER manifest keeps replay fingerprints stable after Undo.
        after = s.manifest(s.workspace(ws_id), app['after_tree_digest'])['files']
        edits = [{'path': p, 'expected_digest': after[p]['digest'] if p in after else None,
                  'content': s.store.read_blob(h, ws_id).decode('utf-8') if h else None}
                 for p, h in app['before_files'].items()]

        def retain(result):
            if any(r['application_id'] == application_id for r in s.store.list('copy_undo')):
                raise CodeError(409, 'already_undone', 'application already undone')
            undo = {'id': ident('undo'), 'application_id': application_id, 'workspace_id': ws_id,
                    'actor': principal.actor, 'change_id': result['change']['id'], 'created_at': stamp()}
            s.store.put('copy_undo', undo)
            s.store.emit(s.workspace(ws_id), 'proposal.copy_undone', undo)
            return {**result, 'undo': undo}

        return s.edit(principal, ws_id, {**payload, 'application_id': application_id,
                      'mutation': 'proposal-copy-undo-r1', 'edits': edits}, _after_edit=retain)

    @staticmethod
    def undo_receipt(result):
        change, undo = result['change'], result['undo']
        return {'undo_id': undo['id'], 'undo_of': undo['application_id'],
                'workspace_id': undo['workspace_id'], 'change_id': change['id'],
                'before': {'generation': change['generation'] - 1, 'tree_digest': change['before_digest']},
                'after': {'generation': change['generation'], 'tree_digest': change['tree_digest']},
                'workspace': result['workspace'], 'effect': 'workspace-copy-write'}
