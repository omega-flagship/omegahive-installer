"""One tick of proposal withdrawal, for the existing reconcile loop to own.

No thread/scheduler, HTTP parser, claim issuer, host ledger or live route. The
future frozen host adapter supplies a fresh status request honoring timeout=3.
"""
import copy,math,uuid
from omegacode.common import CodeError,atomic_write,canonical,stamp
from omegacode.proposal_launch_custody import Custody,execution_binding
from .proposal_settlement_evidence import capture_service

KIND='proposal_watchdog'

class Watchdog:
    def __init__(self,service,fetch_status,clock):
        self.service=service;self.fetch=fetch_status;self.clock=clock
        self.boot=uuid.uuid4().hex

    def tick(self,launch_id,verified_claims):
        service=self.service;service._check_owner(required=True)
        started=self.clock()
        if type(started) not in (int,float) or not math.isfinite(started):
            raise CodeError(409,'watchdog_clock','bounded monotonic observation required')
        with service.store.lock:
            row=Custody(service.store).get(launch_id)
            if row['ever_spawning'] is not True:
                raise CodeError(409,'watchdog_no_dispatch','original dispatched run required')
            previous={r['id']:r for r in service.store.list(KIND)}.get(launch_id)
            if previous and previous['claims']!=canonical(verified_claims).decode():
                raise CodeError(409,'watchdog_claim_binding','original verified claims required')
            if previous and previous['cancel_initiated']:
                return self._tick(launch_id,verified_claims,None,started,None)
            record=copy.deepcopy(previous) if previous else {
                'id':launch_id,'run_id':row['run_id'],'nonce':row['nonce'],
                'claims':canonical(verified_claims).decode(),'boot':self.boot,
                'outage_since':None,'cancel_initiated':False,'input_launch_closed':True}
            sequence=record.get('status_sequence',0)+1
            record.update(status_sequence=sequence,input_launch_closed=True)
            with service.store.transaction():service.store.put(KIND,record)
        # No Store/transaction lock crosses the provider wait. A lost reply leaves
        # the local gate closed. Sequence fences concurrent/reordered replies.
        try:
            status=self.fetch(copy.deepcopy(verified_claims),timeout=3)
            elapsed=self.clock()-started
            if not 0<=elapsed<=3 or type(status) is not dict or status.get('http_status')!=200:
                raise TimeoutError('status unavailable or late')
        except Exception:status=None
        with service.store.lock:
            return self._tick(launch_id,verified_claims,status,started,sequence)

    def _tick(self,launch_id,verified_claims,status,started,sequence):
        service=self.service;service._check_owner(required=True)
        now=started
        if type(now) not in (int,float) or not math.isfinite(now):
            raise CodeError(409,'watchdog_clock','bounded monotonic observation required')
        row=Custody(service.store).get(launch_id)
        if row['ever_spawning'] is not True:
            raise CodeError(409,'watchdog_no_dispatch','original dispatched run required')
        records={r['id']:r for r in service.store.list(KIND)}
        previous=records.get(launch_id)
        if previous and previous['claims']!=canonical(verified_claims).decode():
            raise CodeError(409,'watchdog_claim_binding','original verified claims required')
        record=copy.deepcopy(previous) if previous else {
            'id':launch_id,'run_id':row['run_id'],'nonce':row['nonce'],
            'claims':canonical(verified_claims).decode(),'boot':self.boot,
            'outage_since':None,'cancel_initiated':False,'input_launch_closed':True}
        if not record['cancel_initiated']:
            if previous.get('status_sequence')!=sequence:
                raise CodeError(409,'watchdog_status_superseded','older status cannot authorize an operation')
            active=bool(status and status.get('active') is True
                and canonical(status.get('claims'))==canonical(verified_claims)
                and type(status.get('lease')) is dict and status['lease'].get('state')=='active'
                and type(status.get('test')) is dict and status['test'].get('state')=='open')
            record['input_launch_closed']=not active
            record['status_observed_at']=stamp()
            if active:
                record.update(outage_since=None,boot=self.boot,last_status='active')
            elif status is not None:
                record.update(reason='status_inactive',last_status='inactive',cancel_initiated=True)
            else:
                record['last_status']='unavailable'
                # An outage cannot gain a fresh grace period across restart or
                # clock rollback. This is conservative withdrawal, not recovery
                # of prior positive authority.
                restarted=record['outage_since'] is not None and record['boot']!=self.boot
                rollback=record['outage_since'] is not None and now<record['outage_since']
                if record['outage_since'] is None:record['outage_since']=now
                if restarted or rollback or now-record['outage_since']>=10:
                    record.update(reason='status_outage',cancel_initiated=True)
            if record['cancel_initiated']:
                now=self.clock()
                if type(now) not in (int,float) or not math.isfinite(now):
                    raise CodeError(409,'watchdog_clock','bounded cancellation observation required')
                record['cancel_started_monotonic']=now
                record['cancellation_initiated_at']=stamp()
                record['cancel_boot']=self.boot
        # Journal withdrawal before requesting a native effect; exceptions leave
        # the retained closed gate available for explicit retry of cancellation.
        with service.store.transaction():
            current=Custody(service.store).get(launch_id)
            if current['run_id']!=record['run_id'] or current['nonce']!=record['nonce']:
                raise CodeError(409,'watchdog_original','original launch identity changed')
            service.store.put(KIND,record)
        if not record['cancel_initiated']:
            return record
        self._cancel_original(row)
        try:
            evidence=capture_service(service,launch_id)
        except CodeError as error:
            if error.code!='run_not_terminal':raise
            evidence=None
        stopped=bool(evidence and evidence['cleanup']['descendants_stopped'])
        deadline=(record['cancel_boot']!=self.boot or now<record['cancel_started_monotonic']
                  or now-record['cancel_started_monotonic']>=10)
        if stopped or deadline or (evidence and evidence['outcome']=='unknown'):
            record['termination']={
                'kind':'withdrawn' if stopped else 'unknown','reason':record['reason'],
                'status_observed':record['last_status'],
                'cancellation_initiated_at':record['cancellation_initiated_at'],
                'cleanup_observed_at':evidence['cleanup']['observed_at'] if stopped else None,
                'descendants_stopped':stopped}
            record['settlement_projection']=copy.deepcopy(evidence) if evidence else None
            if evidence and stopped:record['settlement_projection']['outcome']='withdrawn'
            with service.store.transaction():service.store.put(KIND,record)
        return record

    def _cancel_original(self,row):
        service=self.service;service._check_owner(required=True)
        with service.store.transaction():
            run=service.store.get('run',row['run_id']);binding=execution_binding(service.store,row)
            if (run.get('nonce')!=row['nonce'] or run.get('launch_custody_id')!=row['id']
                    or run['workspace_id']!=binding['workspace_id'] or run['generation']!=binding['generation']
                    or run['tree_digest']!=binding['tree_digest'] or run['grant_id']!=binding['grant_id']
                    or run['author']!=binding['actor'] or run['argv']!=row['argv']
                    or run['timeout_seconds']!=row['runtime_seconds']):
                raise CodeError(409,'watchdog_original','original run scope changed')
            root=service.store.root/'runs'/row['run_id']
            if row['spawn_marker']!=str(root):
                raise CodeError(409,'watchdog_original','original run root changed')
            if run['status'] in ('starting','running','cancel_requested'):
                # Same existing cancellation marker/runner path; never forge a
                # human grant to call a generic API after authority withdrawal.
                atomic_write(root/'cancel.request',b'proposal authority withdrawn')
                run.update(status='cancel_requested',cancel_requested_at=run.get('cancel_requested_at',stamp()))
                service.store.put('run',run)
