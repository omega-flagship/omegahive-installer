"""Uninstalled purpose-only saved test candidate, existing Store/Service primitives.

One owner record per test. No generic controller principal or source acceptance.
No host bind, run admission, native workload or serving route is installed.
"""
from omegacode.common import canonical, digest, stamp, CodeError
from .retained_preparation import inspect
KIND = 'proposal_preparation'

def fail(code):
    raise CodeError(409, code, 'purpose fork custody refused')

def materialize(service, authority, principal):
    service._check_owner(required=True)
    authority.require_route(principal, 'POST', '/v1/proposal-tests')
    g = principal.grant
    p = g['proposal_test']
    tid = p['test_id']
    binding = {k: p[k] for k in ['test_id', 'request_id', 'lease_id', 'controller_id', 'execution_goal', 'issuer', 'origin_scope', 'proposal', 'parent']}
    binding.update({k: g[k] for k in ['aud', 'task_id', 'swarm_id', 'repository_id']})
    fingerprint = digest(canonical(binding))
    claim_bytes = canonical(g)
    with service.store.transaction():
        service._check_owner(required=True)
        existing = next((r for r in service.store.list(KIND) if r['id'] == tid), None)
        if existing:
            if existing['fingerprint'] != fingerprint:
                fail('operation_conflict')
            fork = service.workspace(existing['fork_workspace_id'])
            if fork.get('proposal_test_id') != tid or fork['generation'] != 2 or fork['tree_digest'] != existing['test_tree_digest']:
                fail('test_fork_changed')
            authority.require_route(principal, 'POST', '/v1/proposal-tests')
            service._check_owner(required=True)
            if canonical(g) != claim_bytes:
                fail('proposal_claim_changed')
            if service.workspace(fork['id']) != fork or service.store.get(KIND, tid) != existing:
                fail('test_fork_changed')
            return existing
        if sum((w['task_id'] == g['task_id'] and w['swarm_id'] == g['swarm_id'] for w in service.store.list('workspace'))) >= 1000:
            raise CodeError(429, 'workspace_budget', 'task workspace limit reached')
        plan = inspect(service, authority, principal)
        parent = service.workspace(p['parent']['workspace_id'])
        fork = service._fork_snapshot(parent, principal.actor)
        if fork['id'] == parent['id']:
            fail('test_fork_identity')
        for edit in plan['edits']:
            if edit['content'] is None:
                fail('proposal_test_profile')
            data = edit['content'].encode('utf-8')
            expected = plan['test_files'][edit['path']]
            if digest(data) != expected['digest'] or len(data) != expected['size']:
                fail('preparation_changed')
            service.store.blob(data, fork['id'], 'source')
        tree = service._manifest(plan['test_files'], fork['id'])
        if tree != plan['test_tree_digest']:
            fail('test_tree_changed')
        fork.update(generation=2, tree_digest=tree, proposal_test_id=tid)
        fork['history'].append({'generation': 2, 'tree_digest': tree, 'author': principal.actor, 'purpose': 'proposal-test'})
        row = {'id': tid, 'fingerprint': fingerprint, 'binding': binding, 'fork_workspace_id': fork['id'], 'test_tree_digest': tree, 'preparation_digest': plan['preparation_digest'], 'plan_digest': service.store.blob(canonical(plan), fork['id'], 'proposal-test-preparation'), 'created_at': stamp(), 'accepted_source': False, 'launch_authority': False}
        fresh = inspect(service, authority, principal)
        if canonical(fresh) != canonical(plan) or canonical(g) != claim_bytes:
            fail('preparation_changed')
        service._check_owner(required=True)
        service.store.put('workspace', fork)
        service.store.put(KIND, row)
        service.store.emit(fork, 'workspace.forked', fork)
        service.store.emit(fork, 'proposal-test.prepared', row)
        return row
