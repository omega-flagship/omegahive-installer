"""Narrow Hive service enrolment. No Hive operator token is held by this service."""
import json
import pathlib

import httpx

from .common import CodeError, atomic_write, canonical


def enrol(authority, root: pathlib.Path, enrol_token: str, port: int):
    authority.store.effect_guard()
    if not authority.hive_url:
        raise CodeError(400, "hive_required", "service registration needs the configured Hive")
    path = root / "registration.json"
    if path.exists():
        raise CodeError(409, "already_registered", "registration exists; rotate through the owner before replacing it")
    address = f"http://127.0.0.1:{port}"
    body = {"name": "omegacode", "version": "0.1.0", "address": address, "contract": "omegacode/1",
            "surfaces": ["diff", "log", "editor"],
            "capabilities": ["workspaces", "runs", "changesets", "verifications", "events"]}
    try:
        response = authority.client.post(authority.hive_url + "/api/services/register", json=body,
                                         headers={"Authorization": "Bearer " + enrol_token})
    except httpx.HTTPError:
        raise CodeError(503, "registration_unknown", "registration response unavailable; owner must recover the enrolment receipt before retrying")
    if response.status_code != 200 and response.status_code != 201:
        raise CodeError(403, "registration_refused", "Hive refused service enrolment")
    try:
        registration = response.json()
        if not isinstance(registration["service_id"], str) or not isinstance(registration["service_token"], str) or not registration["service_token"]:
            raise ValueError()
        if registration.get("address", address) != address:
            raise ValueError()
    except (KeyError, TypeError, ValueError):
        raise CodeError(503, "registration_unknown", "invalid registration response; owner must recover the enrolment receipt")
    authority.store.effect_guard()
    atomic_write(path, canonical(registration))
    authority.service_token = registration["service_token"]
    authority.registration = registration
    # Never return keys or service authority to the caller or an event stream.
    return {k: v for k, v in registration.items() if k in ("service_id", "address", "registered_at")}
