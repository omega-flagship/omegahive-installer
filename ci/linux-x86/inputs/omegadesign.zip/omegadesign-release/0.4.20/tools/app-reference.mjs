export function exactReference(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).sort().join(',')!=='artifact_id,digest,revision'||typeof value.artifact_id!=='string'||!value.artifact_id||!Number.isInteger(value.revision)||value.revision<1||!/^sha256:[a-f0-9]{64}$/.test(value.digest))throw Error('An exact artifact ID, revision and SHA-256 digest are required');
 return {artifact_id:value.artifact_id,revision:value.revision,digest:value.digest};
}
export function sameReference(a,b){const left=exactReference(a),right=exactReference(b);return left.artifact_id===right.artifact_id&&left.revision===right.revision&&left.digest===right.digest;}
