import fs from 'node:fs/promises';import {targetImpact} from './target-impact.mjs';
try{
 const paths=process.argv.slice(2);if(paths.length!==3)throw Error('Exact before, after and target files required');
 const values=[];for(let i=0;i<paths.length;i++){if((await fs.stat(paths[i])).size>(i===2?4096:20*1024*1024))throw Error('Target comparison input exceeds limit');values.push(JSON.parse(await fs.readFile(paths[i],'utf8')));}
 console.log(JSON.stringify({ok:true,impact:await targetImpact(...values)}));
}catch(error){console.log(JSON.stringify({ok:false,reason:error.message}));process.exitCode=1;}
