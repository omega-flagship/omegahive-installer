"""Host-issued authority, not local grants: tampering, live revocation and collaborator scope."""
import base64
import hashlib
import hmac
import time

import httpx
import pytest

from omegacode.auth import ACTIONS
from omegacode.common import CodeError, canonical
from omegacode.service import Service
from test_service import OPERATOR, repo


@pytest.fixture
def host(tmp_path, repo):
    claims = dict(id="cap-host", iss="hive", aud="svc-host", actor="user:developer", kind="human",
                  task_id="goal-test", swarm_id="swarm-test", repository_id="synthetic", actions=sorted(ACTIONS),
                  paths=[], argv_prefixes=[], iat=int(time.time()), exp=time.time()+60, max_runs=5,
                  max_runtime_seconds=60, member_hash=None, grant_id="gr-host")
    state = dict(active=True, grant=dict(id="gr-host", goal_id="goal-test", principal="user:developer", scope="edit",
                                       workspace_id=None, active=True))
    def transport(request):
        assert request.headers["authorization"] == "Bearer synthetic-service-token"
        if request.url.path.endswith("/grants"):
            return httpx.Response(200, json=[state["grant"]])
        return httpx.Response(200, json=dict(id=claims["id"], active=state["active"], claims=claims))
    service = Service(tmp_path/"state", OPERATOR, {"synthetic": {"path": str(repo)}},
                      "http://hive.invalid", httpx.MockTransport(transport), "synthetic-service-token")
    service.authority.registration = dict(service_id="svc-host", capability_secret="synthetic-signing-key")
    def token(value=None):
        payload = base64.urlsafe_b64encode(canonical(value or claims)).decode().rstrip("=")
        signature = hmac.new(b"synthetic-signing-key", payload.encode(), hashlib.sha256).hexdigest()
        return f"hc1.{payload}.{signature}"
    yield service, claims, state, token
    service.close()


def test_live_host_workspace_and_revocation(host):
    service, claims, state, token = host
    p = service.authority.authenticate(token())
    ws = service.create_workspace(p, dict(operation_id="create", task_id="goal-test", repository_id="synthetic", base_commit="HEAD"))
    assert "return a - b" in service.read(p, ws["id"], "calculator.py")["content"]
    state["active"] = False
    with pytest.raises(CodeError):
        service.read(p, ws["id"], "calculator.py")
    with pytest.raises(CodeError):
        service.authority.authenticate(token())


@pytest.mark.parametrize("change", [dict(aud="other"), dict(iss="other"), dict(exp=0), dict(actions=["publish"]), dict(max_runs=-1)])
def test_signed_wrong_claims_refused(host, change):
    service, claims, state, token = host
    with pytest.raises(CodeError):
        service.authority.authenticate(token(claims | change))


def test_signature_and_bound_member_refused(host):
    service, claims, state, token = host
    with pytest.raises(CodeError):
        service.authority.authenticate(token()[:-1]+"X")
    claims.update(kind="agent", actor="mind-test", member_hash=hashlib.sha256(b"member-test").hexdigest(), grant_id=None)
    with pytest.raises(CodeError):
        service.authority.authenticate(token(), "wrong-member")
    assert service.authority.authenticate(token(), "member-test").actor == "mind-test"


@pytest.mark.parametrize("change", [dict(active=False), dict(principal="user:other"), dict(workspace_id="ws-other"), dict(scope="read")])
def test_collaborator_scope_cannot_create(host, change):
    service, claims, state, token = host
    p = service.authority.authenticate(token())
    state["grant"].update(change)
    with pytest.raises(CodeError):
        service.create_workspace(p, dict(operation_id="create", task_id="goal-test", repository_id="synthetic", base_commit="HEAD"))
    assert service.store.list("workspace") == []
