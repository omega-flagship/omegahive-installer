// Bounded solid-colour diagnostic; image pixels and partial overlays stay unknown.
import {validate} from './scene.mjs';
function rgb(value){if(!/^#[0-9a-f]{6}$/i.test(value))return null;return [1,3,5].map(i=>parseInt(value.slice(i,i+2),16)/255);}
function luminance(value){const v=rgb(value);if(!v)return null;const linear=v.map(c=>c<=.04045?c/12.92:((c+.055)/1.055)**2.4);return linear[0]*.2126+linear[1]*.7152+linear[2]*.0722;}
export function contrastRatio(a,b){const x=luminance(a),y=luminance(b);if(x===null||y===null)return null;return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
const intersects=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
const covers=(a,b)=>a.x<=b.x&&a.y<=b.y&&a.x+a.width>=b.x+b.width&&a.y+a.height>=b.y+b.height;
export function inspectReadability(input,{minimumRatio=4.5}={}){
 const scene=validate(input);if(!Number.isFinite(minimumRatio)||minimumRatio<1||minimumRatio>21)throw Error('Bounded contrast threshold required');
 return scene.elements.flatMap((text,index)=>{
  if(text.kind!=='text')return [];
  let background=scene.background,reason=null;
  for(const layer of scene.elements.slice(0,index)){
   if(!intersects(layer,text)||layer.kind==='text')continue;
   if(layer.kind==='rect'&&covers(layer,text)&&!layer.radius){background=layer.fill;reason=null;}
   else{background=null;reason=layer.kind==='image'?'image-pixels-uninspected':'partial-or-rounded-background';}
  }
  // Later artwork can obscure text regardless of the background below it.
  if(scene.elements.slice(index+1).some(layer=>layer.kind!=='text'&&intersects(layer,text))){background=null;reason='later-artwork-overlaps-text';}
  const ratio=background?contrastRatio(text.color,background):null;
  return [{element_id:text.id,scene_id:scene.id,ratio,minimum_ratio:minimumRatio,status:ratio===null?'unknown':ratio<minimumRatio?'low-contrast':'passes-solid-colour-check',reason:ratio===null?(reason??'unsupported-colour'):null,scope:'Solid colours and element bounding boxes; glyph pixels and creative quality unassessed'}];
 });
}
