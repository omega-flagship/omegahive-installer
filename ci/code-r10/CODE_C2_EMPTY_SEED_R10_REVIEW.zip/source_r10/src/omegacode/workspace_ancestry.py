"""Verify retained fork ancestry from existing workspace/checkpoint history, not Git claims."""
from omegacode.common import CodeError


def ancestor(workspace, checkpoint, get_workspace, authorize, *, max_depth=64):
    """A checkpoint must precede each recorded fork edge on the path to its workspace."""
    origin = workspace
    bound = workspace['generation']
    seen = set()
    chain = []
    for _ in range(max_depth):
        if workspace['id'] in seen:
            raise CodeError(409, 'fork_ancestry', 'fork ancestry contains a cycle')
        seen.add(workspace['id'])
        if any(workspace[k] != origin[k] for k in ('task_id','swarm_id','repository_id')):
            raise CodeError(403,'fork_ancestry','fork ancestry crosses task/swarm/repository authority')
        authorize(workspace)
        if type(bound) is not int or bound<1:
            raise CodeError(409,'fork_ancestry','invalid fork generation')
        if checkpoint['workspace_id'] == workspace['id']:
            if (type(checkpoint['generation']) is not int or not 1<=checkpoint['generation']<=bound or
                not any(h['generation']==checkpoint['generation'] and h['tree_digest']==checkpoint['tree_digest'] for h in workspace['history'])):
                raise CodeError(409,'fork_ancestry','base checkpoint is not retained before this fork edge')
            return chain
        edge = workspace.get('fork_origin')
        if not isinstance(edge,dict) or set(edge)!={'workspace_id','generation','tree_digest'}:
            raise CodeError(403,'checkpoint_forbidden','base checkpoint is not an ancestor of this workspace')
        if (edge['workspace_id']==workspace['id'] or type(edge['generation']) is not int or edge['generation']<1 or
            not any(h['generation']==1 and h['tree_digest']==edge['tree_digest'] for h in workspace['history'])):
            raise CodeError(409,'fork_ancestry','fork origin differs from the retained initial source')
        parent = get_workspace(edge['workspace_id'])
        if not any(h['generation']==edge['generation'] and h['tree_digest']==edge['tree_digest'] for h in parent['history']):
            raise CodeError(409,'fork_ancestry','fork origin is absent from parent source history')
        chain.append({'workspace_id':workspace['id'],'fork_origin':dict(edge)})
        workspace, bound = parent, edge['generation']
    raise CodeError(413,'fork_ancestry_limit','fork ancestry exceeds the bounded traversal depth')


def common_base(destination, incoming, checkpoint, get_workspace, authorize):
    return {'destination':ancestor(destination,checkpoint,get_workspace,authorize),
            'incoming':ancestor(incoming,checkpoint,get_workspace,authorize)}
