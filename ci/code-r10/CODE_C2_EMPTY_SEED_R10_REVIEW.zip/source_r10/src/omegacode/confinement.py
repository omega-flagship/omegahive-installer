"""Disposable Python execution profile candidate; no service/authority integration."""
import json
from pathlib import Path


def profile(workspace, python):
    workspace = Path(workspace).resolve(strict=True)
    python = Path(python).resolve(strict=True)
    if not workspace.is_dir() or not python.is_file() or workspace == Path('/'):
        raise ValueError('existing private workspace and interpreter required')
    # Pin one Python installation, not the whole user's Homebrew tree.
    installation = next((p for p in python.parents if p.parent.parent.name == 'Cellar'), None)
    if installation is None:
        raise ValueError('this prototype requires a pinned Homebrew Python installation')
    app = (python.parent.parent/'Resources/Python.app/Contents/MacOS/Python').resolve(strict=True)
    q = lambda p: json.dumps(str(p), ensure_ascii=True)
    reads = [workspace, installation, Path('/System'), Path('/usr/lib')]
    metadata = sorted(set(workspace.parents) | set(python.parents), key=str)
    return '\n'.join([
        '(version 1)', '(deny default)',
        '(allow process-fork)',
        '(allow process-exec (literal '+q(python)+') (literal '+q(app)+') (literal "/bin/sh"))',
        '(allow sysctl-read)',
        '(allow file-read* (literal "/"))',
        '(allow file-read* '+ ' '.join('(subpath '+q(p)+')' for p in reads)+')',
        '(allow file-read-metadata '+ ' '.join('(literal '+q(p)+')' for p in metadata)+')',
        '(allow file-read* (literal "/dev/null") (literal "/dev/urandom") (literal "/dev/random"))',
        '(allow file-write* (subpath '+q(workspace)+') (literal "/dev/null"))',
    ])+'\n'

"""Appended to the reviewed profile prototype to form a service candidate module."""

import hashlib
import platform


def identity(config):
    if platform.system() != 'Darwin' or not isinstance(config,dict) or set(config) != {
            'kind','python','python_sha256','application_sha256','sandbox_exec_sha256'} or config['kind'] != 'macos-seatbelt-python-v1':
        raise ValueError('exact operator-pinned macOS confinement configuration required')
    interpreter=Path(config['python']).resolve(strict=True)
    application=(interpreter.parent.parent/'Resources/Python.app/Contents/MacOS/Python').resolve(strict=True)
    binaries={str(interpreter):config['python_sha256'],str(application):config['application_sha256'],
              '/usr/bin/sandbox-exec':config['sandbox_exec_sha256']}
    if not all(isinstance(value,str) and len(value)==64 and all(c in '0123456789abcdef' for c in value) for value in binaries.values()):
        raise ValueError('runtime SHA256 pins required')
    for path,pin in binaries.items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=pin:
            raise ValueError('confinement runtime pin changed')
    return {'kind':config['kind'],'python':str(interpreter),'binaries':binaries,
            'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def prepare(root,config,logical_argv):
    pinned=identity(config)
    if not logical_argv or str(Path(logical_argv[0]).resolve(strict=True))!=pinned['python']:
        raise ValueError('this execution profile admits only its pinned Python command')
    root=Path(root).resolve(strict=True)
    policy=profile(root/'tree',pinned['python'])
    target=root/'confinement.sb'
    if target.exists() or target.is_symlink():
        raise ValueError('confinement profile already exists')
    with target.open('x') as handle:handle.write(policy)
    record={**pinned,'policy_sha256':hashlib.sha256(policy.encode()).hexdigest(),
            'logical_argv':list(logical_argv),'policy_file':'confinement.sb',
            'qualification':'macos-python-batch-candidate; not general shell or PTY'}
    return ['/usr/bin/sandbox-exec','-f',str(target),pinned['python'],*logical_argv[1:]],record


def validate(root,spec):
    root=Path(root).resolve(strict=True);record=spec['confinement']
    if record.get('kind')!='macos-seatbelt-python-v1' or record.get('policy_file')!='confinement.sb':
        raise ValueError('invalid confinement kind or profile path')
    target=root/'confinement.sb'
    if target.is_symlink() or hashlib.sha256(target.read_bytes()).hexdigest()!=record['policy_sha256']:
        raise ValueError('confinement policy changed before launch')
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=record['generator_sha256']:
        raise ValueError('confinement helper changed before launch')
    for path,pin in record['binaries'].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=pin:
            raise ValueError('confinement runtime changed before launch')
    expected=['/usr/bin/sandbox-exec','-f',str(target),record['python'],*record['logical_argv'][1:]]
    if spec['argv']!=expected or str(Path(record['logical_argv'][0]).resolve(strict=True))!=record['python']:
        raise ValueError('confinement wrapper does not match original command')
    return {'kind':record['kind'],'policy_sha256':record['policy_sha256'],'validated_before_launch':True,
            'qualification':record['qualification']}
