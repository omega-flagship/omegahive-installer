"""Exact saved Python function selection; no scope issuance or edit authority.

Names are display-only. A valid byte caret selects the smallest containing
function/method span. Decorators and indentation are included; trailing comment
lines beyond the last AST statement are not implicitly annexed.
"""
import ast
import hashlib

def select(data,caret,expected_digest):
    if type(data) is not bytes or len(data)>1024*1024:raise ValueError('bounded saved bytes required')
    if hashlib.sha256(data).hexdigest()!=expected_digest:raise ValueError('source digest mismatch')
    if type(caret) is not int or not 0<=caret<len(data):raise ValueError('valid byte caret required')
    try:
        text=data.decode('utf-8');data[:caret].decode('utf-8')
    except UnicodeDecodeError:raise ValueError('UTF-8 source and caret boundary required') from None
    if text.startswith('\ufeff'):raise ValueError('BOM source not supported by this selector')
    try:tree=ast.parse(text)
    except (SyntaxError,RecursionError):raise ValueError('valid bounded Python syntax required') from None
    lines=data.splitlines(keepends=True);starts=[];offset=0
    for line in lines:starts.append(offset);offset+=len(line)
    candidates=[];stack=[(tree,0)];visited=0
    while stack:
        node,depth=stack.pop();visited+=1
        if visited>4096 or depth>64:raise ValueError('syntax tree bound exceeded')
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            first=min([node.lineno]+[d.lineno for d in node.decorator_list])
            start=starts[first-1]
            # Include that final line's comment/newline; never subsequent lines.
            end=starts[node.end_lineno-1]+len(lines[node.end_lineno-1])
            if start<=caret<end:
                candidates.append(dict(start_byte=start,end_byte=end,name=node.name,async_function=isinstance(node,ast.AsyncFunctionDef)))
        stack.extend((child,depth+1) for child in ast.iter_child_nodes(node))
    if not candidates:raise ValueError('caret is outside a saved function')
    candidates.sort(key=lambda s:s['end_byte']-s['start_byte'])
    if len(candidates)>1 and candidates[0]['end_byte']-candidates[0]['start_byte']==candidates[1]['end_byte']-candidates[1]['start_byte']:
        raise ValueError('ambiguous containing function')
    chosen=candidates[0]
    return dict(schema='omegacode-python-function-range-v1',source_digest=expected_digest,
                parser='python-ast',position_unit='utf8-byte',**chosen,
                range_digest=hashlib.sha256(data[chosen['start_byte']:chosen['end_byte']]).hexdigest(),
                effect_authority=False,scope_issued=False)


def main():
    import sys,json,base64,resource
    resource.setrlimit(resource.RLIMIT_CPU,(2,2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(8192,8192))
    memory_limit_enforced=False
    if sys.platform!='darwin':
        _,hard=resource.getrlimit(resource.RLIMIT_DATA)
        memory_limit=256*1024*1024 if hard==resource.RLIM_INFINITY else min(hard,256*1024*1024)
        resource.setrlimit(resource.RLIMIT_DATA,(memory_limit,memory_limit))
        memory_limit_enforced=True
    try:
        raw=sys.stdin.buffer.read(2*1024*1024+1)
        if len(raw)>2*1024*1024:raise ValueError('request bound')
        request=json.loads(raw)
        if set(request)!={'data','caret','expected_digest'}:raise ValueError('request fields')
        data=base64.b64decode(request['data'],validate=True)
        result=select(data,request['caret'],request['expected_digest'])
        from pathlib import Path
        result['parser_python_version']=sys.version
        result['parser_executable_digest']=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()
        result['memory_limit_enforced']=memory_limit_enforced
        result['parser_profile']='trusted-child-process'
        if len(result['name'].encode())>256:
            result['name']=result['name'][:64];result['name_truncated']=True
        sys.stdout.buffer.write(json.dumps({'ok':True,'result':result},ensure_ascii=True).encode())
    except (ValueError,TypeError,SyntaxError,RecursionError,MemoryError):
        sys.stdout.buffer.write(b'{"ok":false,"reason":"function selection refused"}')
        raise SystemExit(2)

if __name__=='__main__':main()
