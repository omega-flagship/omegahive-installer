"""Uninstalled original launch/hold admission. No process dispatch or settlement."""
from omegacode.common import canonical, digest, CodeError
from omegacode.proposal_launch_custody import Custody
from .retained_preparation import inspect
from .proposal_host_wire import launch_binding, fail, snapshot

def scope_binding(g):
    p = g['proposal_test']
    return dict(test_id=p['test_id'], request_id=p['request_id'], lease_id=p['lease_id'], controller_id=p['controller_id'], execution_goal=p['execution_goal'], issuer=p['issuer'], origin_scope=p['origin_scope'], proposal=p['proposal'], parent=p['parent'], aud=g['aud'], task_id=g['task_id'], swarm_id=g['swarm_id'], repository_id=g['repository_id'])

def candidate(service, authority, principal):
    plan = inspect(service, authority, principal)
    g = principal.grant
    p = g['proposal_test']
    saved = service.store.get('proposal_preparation', p['test_id'])
    bound = service.store.get('proposal_preparation_bind', p['test_id'])
    fork = service.workspace(saved['fork_workspace_id'])
    if bound['state'] != 'acknowledged' or bound['ack'] is None or p['fork']['workspace_id'] != fork['id'] or (p['fork']['preparation_digest'] != 'sha256:' + plan['preparation_digest']) or (fork['generation'] != 2) or (fork.get('proposal_test_id') != p['test_id']) or any((fork[k] != g[k] for k in ('task_id', 'swarm_id', 'repository_id'))) or (fork['tree_digest'] != plan['test_tree_digest']) or (saved['test_tree_digest'] != plan['test_tree_digest']) or (saved['preparation_digest'] != plan['preparation_digest']) or (service.store.read_blob(saved['plan_digest'], fork['id']) != canonical(plan)):
        fail('proposal_launch_custody')
    expected = scope_binding(g)
    if saved['binding'] != expected:
        fail('proposal_launch_custody')
    body = bound['body']
    if body['fork_workspace_id'] != fork['id'] or body['proposal'] != p['proposal'] or body['parent'] != p['parent'] or (body['test_tree_digest'] != 'sha256:' + plan['test_tree_digest']) or (body['preparation_digest'] != 'sha256:' + plan['preparation_digest']):
        fail('proposal_launch_custody')
    if service.manifest(fork)['files'] != plan['test_files']:
        fail('proposal_launch_custody')
    for meta in plan['test_files'].values():
        data = service.store.read_blob(meta['digest'], fork['id'])
        if digest(data) != meta['digest'] or len(data) != meta['size']:
            fail('proposal_launch_custody')
    service._check_owner(required=True)
    return (saved, bound, fork)

def admit(service, authority, principal, host, launch_key, argv, runtime_seconds):
    service._check_owner(required=True)
    argv = snapshot(argv)
    g = principal.grant
    claim = canonical(g)
    p = g['proposal_test']
    tid = p['test_id']
    binding = launch_binding(g)
    custody = Custody(service.store)
    id_ = 'pl_' + digest(canonical([tid, launch_key]))
    existing = next((r for r in service.store.list('proposal_launch') if r['id'] == id_), None)
    if existing:
        authority.require_route(principal, 'GET', '/v1/proposal-tests/' + tid)
        if canonical(g) != claim or service.store.get('proposal_preparation', tid)['binding'] != scope_binding(g):
            fail('proposal_launch_custody')
        row = custody.request(tid, launch_key, binding, argv, runtime_seconds)
        current = host.lookup(tid, launch_key)
        service._check_owner(required=True)
        if current is not None:
            row = custody.attach_hold(row['id'], host.projection(current, row))
        return dict(launch=row, launch_authority=False, recovered=True)
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + tid + '/launches')
    if type(argv) is not list or not argv or any((type(a) is not str or not a or '\x00' in a for a in argv)) or (not any((argv[:len(prefix)] == prefix for prefix in g['argv_prefixes']))):
        fail('proposal_launch_argv')
    limits = p['allowance']
    if type(runtime_seconds) is not int or not 1 <= runtime_seconds <= min(g['max_runtime_seconds'], limits['per_launch_max_runtime_seconds'], limits['test']['runtime_seconds_remaining'], limits['request']['runtime_seconds_remaining']) or limits['test']['runs_remaining'] < 1 or (limits['request']['runs_remaining'] < 1):
        fail('proposal_launch_allowance')
    with service.store.lock:
        (saved, bound, fork) = candidate(service, authority, principal)
        row = custody.request(tid, launch_key, binding, argv, runtime_seconds)
        fresh = candidate(service, authority, principal)
        if fresh != (saved, bound, fork) or canonical(g) != claim:
            fail('proposal_launch_custody')
    host.admit(tid, g['id'], launch_key, argv, runtime_seconds)
    current = host.lookup(tid, launch_key)
    service._check_owner(required=True)
    if current is not None:
        row = custody.attach_hold(row['id'], host.projection(current, row))
    return dict(launch=row, launch_authority=False, recovered=False)
