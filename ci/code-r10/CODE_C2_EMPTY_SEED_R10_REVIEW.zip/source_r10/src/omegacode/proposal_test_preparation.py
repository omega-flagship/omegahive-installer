"""Pure retained-proposal/fork binding; no authority, I/O, acceptance or execution."""
import copy
from .common import canonical,digest,safe_path,MAX_FILES,MAX_TREE,MAX_FILE
from .suggestion_validation import reconstruct,reconstruct_v2


def prepare(projection,parent,manifest,files,*,proposal_id,proposal_digest):
    record,body=projection['record'],projection['content']
    binding={k:parent[k] for k in ('task_id','generation','tree_digest')}
    binding['workspace_id']=parent['id']
    v2=body.get('schema')=='omegacode-scoped-suggestion-v2'
    if (record['id']!=proposal_id or record['digest']!=proposal_digest or
            digest(canonical(body))!=proposal_digest or record['workspace_id']!=parent['id'] or
            record['scope_id']!=body.get('scope_id') or record['author']!=body.get('author') or
            body['binding']!=binding or projection['currency']!='current'):
        raise ValueError('stale, altered or foreign retained proposal')
    if set(manifest)!= {'files'} or digest(canonical(manifest))!=parent['tree_digest']:
        raise ValueError('source manifest binding mismatch')
    metas=manifest['files']
    if set(files)!=set(metas) or len(files)>MAX_FILES:
        raise ValueError('complete saved input required')
    total=0
    for path,data in files.items():
        safe_path(path)
        meta=metas[path]
        if (type(data) is not bytes or len(data)>MAX_FILE or meta['size']!=len(data) or
                meta['digest']!=digest(data) or type(meta['executable']) is not bool):
            raise ValueError('saved file custody mismatch')
        total+=len(data)
    if total>MAX_TREE:raise ValueError('saved input size limit')
    if v2:
        from .language_buffers import validate_new_path_namespace
        create_paths=sorted(path for path,row in body['scope'].items() if row.get('kind')=='create_text')
        if create_paths:
            validate_new_path_namespace(metas,create_paths,max_paths=100)
        edits=reconstruct_v2(body,proposal_digest,binding,files,
            [h['id'] for h in body['hunks']],existing_paths=metas.keys())
        normalized_digest=proposal_digest
    else:
        retained={k:v for k,v in body.items() if k not in ('author','scope_id')}
        edits=reconstruct(retained,retained['digest'],binding,files,[h['id'] for h in retained['hunks']])
        normalized_digest=retained['digest']
    output=copy.deepcopy(metas)
    for edit in edits:
        data=edit['content'].encode()
        if edit.get('expected_digest') is None:
            if edit['path'] in output:
                raise ValueError('created path already exists in source manifest')
            output[edit['path']]={'digest':digest(data),'size':len(data),'executable':False}
        else:
            if edit['path'] not in output or output[edit['path']]['digest']!=edit['expected_digest']:
                raise ValueError('edited path source manifest mismatch')
            output[edit['path']]={**output[edit['path']],'digest':digest(data),'size':len(data)}
    if sum(meta['size'] for meta in output.values())>MAX_TREE:
        raise ValueError('proposed tree size limit')
    artifact={'schema':'omegacode-proposal-test-preparation/1','proposal_id':proposal_id,
        'proposal_digest':proposal_digest,'normalized_hunks_digest':normalized_digest,
        'parent':{k:parent[k] for k in ('id','task_id','swarm_id','repository_id','generation','tree_digest')},
        'test_tree_digest':digest(canonical({'files':output})),'test_files':output,
        'edits':edits,'accepted_source':False,'execution_authority':'none'}
    return {**artifact,'preparation_digest':digest(canonical(artifact))}


def fork_edit_payload(plan,fork,*,operation_id):
    artifact={k:v for k,v in plan.items() if k!='preparation_digest'}
    if digest(canonical(artifact))!=plan['preparation_digest']:
        raise ValueError('altered preparation')
    parent=plan['parent']
    origin={'workspace_id':parent['id'],'generation':parent['generation'],'tree_digest':parent['tree_digest']}
    if (fork['id']==parent['id'] or fork.get('fork_origin')!=origin or fork['generation']!=1 or
            fork['tree_digest']!=parent['tree_digest'] or any(fork[k]!=parent[k] for k in ('task_id','swarm_id','repository_id'))):
        raise ValueError('exact pristine test fork required')
    if not isinstance(operation_id,str) or not operation_id:
        raise ValueError('caller-retained original operation required')
    return {'operation_id':operation_id,'expected_generation':1,
            'expected_tree_digest':fork['tree_digest'],'edits':copy.deepcopy(plan['edits'])}
