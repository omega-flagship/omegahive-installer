import {validate,clone} from './scene.mjs';
export function orderedSceneElements(scene, order){
 if(order===undefined)return scene.elements;
 const text=scene.elements.filter(e=>e.kind==='text');
 if(!Array.isArray(order)||order.length!==text.length||new Set(order).size!==text.length||order.some(id=>!text.some(e=>e.id===id)))throw Error('Reading order must cover exact text objects once');
 let cursor=0;const byId=new Map(text.map(e=>[e.id,e]));
 return scene.elements.map(e=>e.kind==='text'?byId.get(order[cursor++]):e);
}
export function validateSceneDeck(deck){
 if(deck?.schema!=='omega-scene-deck-1'||typeof deck.title!=='string'||!deck.title.trim()||!Array.isArray(deck.slides)||deck.slides.length<1||deck.slides.length>50)throw Error('Invalid scene deck');
 const scenes=deck.slides.map(validate);const first=scenes[0];
 if(scenes.some(s=>s.width!==first.width||s.height!==first.height))throw Error('Deck pages need equal dimensions');
 if(new Set(scenes.map(s=>s.id)).size!==scenes.length)throw Error('Duplicate scene ID');
 if(deck.reading_order!==undefined){
  if(!deck.reading_order||typeof deck.reading_order!=='object'||Array.isArray(deck.reading_order)||Object.keys(deck.reading_order).length!==scenes.length||scenes.some(s=>!Object.hasOwn(deck.reading_order,s.id)))throw Error('Reading order must cover exact scenes');
  for(const scene of scenes)orderedSceneElements(scene,deck.reading_order[scene.id]);
 }
 return clone(deck);
}
