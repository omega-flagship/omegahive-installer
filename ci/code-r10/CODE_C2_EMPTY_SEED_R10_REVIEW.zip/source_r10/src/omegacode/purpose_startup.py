"""Default-off composition candidate over existing app, authority and monitor.

The server owns the running ASGI loop. No loop, scheduler, claim issuer, grant
or controller is created here. The candidate entrypoint calls this; deployed enablement is separate.
"""
import asyncio, copy
from contextlib import asynccontextmanager
from omegacode.api import create_app
from omegacode.proposal_tests import HostClient, PurposeAuthority, install
from omegacode.common import CodeError
from .bounded_status_http import StatusHTTP


class BoundedHost(HostClient):
    def __init__(self, origin, token, loop):
        super().__init__(origin, token)
        self.status_http = StatusHTTP(origin, token, owner_loop=loop)

    def _call(self, method, path, body=None, expected=200, params=None):
        prefix = '/api/services/capabilities/'
        if method == 'GET' and path.startswith(prefix):
            if body is not None or params is not None or expected != 200:
                raise ValueError('exact status call required')
            try:
                reply = self.status_http.read_sync(path[len(prefix):])
            except Exception:
                raise CodeError(503, 'proposal_host_unavailable', 'capability status unavailable') from None
            if reply['http_status'] != 200:
                raise CodeError(409, 'proposal_host_refused', 'capability status refused')
            return reply['body']
        return super()._call(method, path, body, expected, params)

    def watch_status(self, claims, *, timeout=3):
        # Same fresh bounded owner route used by the existing watchdog; no cache.
        reply = self.status_http.read_sync(claims['id'], timeout=timeout)
        body = reply['body'] if reply['http_status'] == 200 else {}
        return dict(body, http_status=reply['http_status'])


def create_purpose_app(service, port=8724, *, enabled=False, capacity=8):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    app = create_app(service, port)
    if not enabled:
        return app
    if type(capacity) is not int or not 1 <= capacity <= 64:
        raise ValueError('bounded owner capacity required')
    service._check_owner(required=True)
    ordinary = service.authority
    if not ordinary.registration or not ordinary.hive_url or not ordinary.service_token:
        raise ValueError('same registered service and host credential required')
    if service._watcher is not None or service._proposal_watchdog is not None:
        raise ValueError('configure once before the existing monitor starts')

    registration = copy.deepcopy(ordinary.registration)
    origin, credential = ordinary.hive_url, ordinary.service_token

    @asynccontextmanager
    async def lifespan(app):
        host = authority = None
        try:
            if service.authority is not ordinary or ordinary.registration != registration or ordinary.hive_url != origin or ordinary.service_token != credential:
                raise ValueError('owner registration changed before startup')
            service._check_owner(required=True)
            if service._watcher is not None or service._proposal_watchdog is not None:
                raise ValueError("configure once before the existing monitor starts")
            loop = asyncio.get_running_loop()
            host = BoundedHost(ordinary.hive_url, ordinary.service_token, loop)
            authority = PurposeAuthority(service.store, ordinary.operator_token,
                ordinary.hive_url, service_token=ordinary.service_token,
                purpose_host=host, proposal_tests_enabled=True)
            authority.registration = copy.deepcopy(registration)
            # Recheck immediately before publishing routes; construction above
            # must not hide a lost owner or independently started monitor.
            service._check_owner(required=True)
            if service._watcher is not None or service._proposal_watchdog is not None:
                raise ValueError("configure once before the existing monitor starts")
            install(app, service, authority, host, enabled=True)
            service.install_proposal_watchdog(host.watch_status, capacity=capacity)
            app.state.purpose_host = host
            app.state.purpose_authority = authority
            # Ordinary routes still use their original authority. Purpose claims
            # remain exclusive to the four installed controller-test handlers.
            service.start_monitor()
            yield
        finally:
            # Keep the existing loop running while its monitor/status pool drains.
            # This is shutdown work, not another reconcile loop or authority owner.
            await asyncio.to_thread(service.close)
            if authority is not None:
                authority.client.close()
            if host is not None:
                host.close()

    app.router.lifespan_context = lifespan
    return app
