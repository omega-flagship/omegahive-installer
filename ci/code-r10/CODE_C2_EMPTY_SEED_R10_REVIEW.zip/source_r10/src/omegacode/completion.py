"""Convert a retained plain completion into an exact saved-source CAS preview."""
from .common import CodeError, MAX_FILE
from .language import checked_range, offset


def preview(item, text, position, language_id, path, source_digest, selection_mode=None):
    if (not isinstance(item, dict) or type(item.get('insertTextFormat', 1)) is not int
            or item.get('insertTextFormat', 1) != 1):
        raise CodeError(422, 'completion_unsupported', 'snippet completions need a snippet-aware editor')
    if item.get('omitted_additional_edits'):
        raise CodeError(422, 'completion_unsupported', 'completion has omitted additional edits; partial application is refused')
    cursor = offset(text, position)
    if 'textEdit' in item:
        edit = item['textEdit']
        if not isinstance(edit, dict) or not isinstance(edit.get('newText'), str):
            raise CodeError(502, 'language_protocol', 'completion text edit has no plain replacement')
        if 'range' in edit:
            if selection_mode is not None:
                raise CodeError(422, 'completion_selection', 'insert/replace selection only applies to a dual-range item')
            range_ = edit['range']
        else:
            if selection_mode not in ('insert', 'replace'):
                raise CodeError(422, 'completion_selection', 'explicitly choose insert or replace for this item')
            inserted = edit.get('insert'); replaced = edit.get('replace')
            a, b = checked_range(inserted, text); c, d = checked_range(replaced, text)
            if a != c or b > d or not a <= cursor <= b or inserted['start']['line'] != inserted['end']['line'] or replaced['start']['line'] != replaced['end']['line']:
                raise CodeError(422, 'completion_range', 'insert range must be a prefix of the single-line replace range')
            range_ = edit[selection_mode]
        start, end = checked_range(range_, text)
        if range_['start']['line'] != range_['end']['line'] or not start <= cursor <= end:
            raise CodeError(422, 'completion_range', 'primary completion range must be single-line and contain the query cursor')
        replacement = edit['newText']; mode = 'server-text-edit'
    else:
        if selection_mode is not None:
            raise CodeError(422, 'completion_selection', 'insert/replace selection needs a dual-range item')
        if language_id != 'python':
            raise CodeError(422, 'completion_unsupported', 'label/insertText completion needs qualified language word-boundary rules')
        replacement = item.get('insertText', item.get('label'))
        if not isinstance(replacement, str):
            raise CodeError(502, 'language_protocol', 'completion has no plain insertion text')
        start = end = cursor
        while start and ('x' + text[start - 1]).isidentifier(): start -= 1
        while end < len(text) and ('x' + text[end]).isidentifier(): end += 1
        mode = 'python-identifier-replacement'
    if '\x00' in replacement:
        raise CodeError(422, 'completion_unsupported', 'completion replacement contains NUL')
    additional = item.get('additionalTextEdits', [])
    if type(additional) is not list or len(additional) > 128:
        raise CodeError(422, 'completion_unsupported', 'additional completion edits exceed the supported bound')
    spans = [(start, end, replacement)]
    for edit in additional:
        if type(edit) is not dict or type(edit.get('newText')) is not str or '\x00' in edit['newText']:
            raise CodeError(502, 'language_protocol', 'invalid additional completion edit')
        left, right = checked_range(edit.get('range'), text)
        spans.append((left, right, edit['newText']))
    spans.sort(key=lambda span: (span[0], span[1]))
    for previous, current in zip(spans, spans[1:]):
        if previous[1] > current[0] or previous[0] == current[0]:
            raise CodeError(422, 'completion_overlap', 'completion primary/additional edits overlap')
    content = text
    for left, right, value in reversed(spans):
        content = content[:left] + value + content[right:]
    if len(content.encode()) > MAX_FILE:
        raise CodeError(413, 'completion_limit', 'completion preview exceeds file limit')
    if content == text:
        raise CodeError(422, 'completion_unchanged', 'completion makes no source change')
    return {'edits': [{'path': path, 'expected_digest': source_digest, 'content': content}],
            'mode': mode, 'selection_mode': selection_mode, 'additional_edit_count': len(additional), 'replacement': replacement, 'replaced_text': text[start:end],
            'offsets': {'start': start, 'end': end}, 'applied': False, 'unsaved_buffers': False}
