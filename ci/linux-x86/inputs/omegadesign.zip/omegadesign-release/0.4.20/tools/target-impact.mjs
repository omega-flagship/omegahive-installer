// Inspect target changes only. Finding disposition and applicability remain host/reviewer decisions.
import {resolveCreativeTarget} from './review-target.mjs';
import {digest,clone} from './scene.mjs';
export async function targetImpact(before,after,target){
 // Validate both complete sources before interpreting an absent target.
 await resolveCreativeTarget(before,{whole:true});await resolveCreativeTarget(after,{whole:true});
 if(before.schema!==after.schema)throw Error('Source schema changed; explicit target mapping required');
 const old=await resolveCreativeTarget(before,target),before_digest=await digest(before),after_digest=await digest(after);
 let next;
 try{next=await resolveCreativeTarget(after,target);}catch(error){
  if(!/Target (field not in reviewed UI source|UI not in reviewed source|scene not in reviewed source|element not in reviewed scene)/.test(error.message))throw error;
  return {target:clone(target),before_digest,after_digest,before:old,after:null,status:'target-missing',review_required:true,authority:'none'};
 }
 const status=before_digest===after_digest?'same-source':target.whole?'source-changed':old.element_digest!==next.element_digest||old.scene_digest!==next.scene_digest||old.target_motion_digest!==next.target_motion_digest?'target-changed':'same-target-context-changed';
 return {target:clone(target),before_digest,after_digest,before:old,after:next,status,review_required:status!=='same-source',authority:'none'};
}
