"""Uninstalled point-in-time launch check; no spawn, receipt or authority token."""
import importlib.machinery, json, pathlib, sys, stat
from omegacode.common import canonical, digest, CodeError
from omegacode.confinement import identity, profile
from omegacode.proposal_launch_custody import Custody, execution_binding
from .launch_admission import candidate
from .proposal_host_wire import fail

def inspect(service, authority, principal, host, launch_id):
    return _inspect(service, authority, principal, host, launch_id)

def _inspect(service, authority, principal, host, launch_id, *, _commit=None):
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    p = g['proposal_test']
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + p['test_id'] + '/launches')
    row = Custody(service.store).get(launch_id)
    native = execution_binding(service.store, row)
    run = service.store.get('run', row['run_id'])
    original = canonical(run)
    if row['state'] != 'spawning' or row['ever_spawning'] is not True or row['test_id'] != p['test_id'] or (run['status'] != 'prepared') or (run.get('proposal_purpose_test') != row['test_id']) or (run.get('launch_custody_id') != launch_id) or (run['nonce'] != row['nonce']) or (run['argv'] != row['argv']) or (run['timeout_seconds'] != row['runtime_seconds']) or any((run[k] != native[n] for (k, n) in [('workspace_id', 'workspace_id'), ('generation', 'generation'), ('tree_digest', 'tree_digest'), ('grant_id', 'grant_id'), ('author', 'actor')])) or (native['grant_id'] != g['id']) or (native['actor'] != principal.actor) or (not any((row['argv'][:len(prefix)] == prefix for prefix in g['argv_prefixes']))) or (row['runtime_seconds'] > min(g['max_runtime_seconds'], p['allowance']['per_launch_max_runtime_seconds'])):
        fail('purpose_launch_binding')
    (saved, bound, fork) = candidate(service, authority, principal)
    root = service.store.root / 'runs' / row['run_id']
    if row['spawn_marker'] != str(root) or root.is_symlink():
        fail('purpose_launch_root')

    def directories():
        result = {}
        for path in [service.store.root, root.parent, root, root / 'tree', root / 'executor', root / 'executor/omegacode']:
            info = path.lstat()
            if not stat.S_ISDIR(info.st_mode):
                fail('purpose_launch_root')
            result[str(path)] = (info.st_dev, info.st_ino)
        return result
    try:
        directory_ids = directories()
        pinned = identity(service.repositories[fork['repository_id']].get('execution_confinement'))
        retained = run['execution_confinement']
        if any((retained[k] != pinned[k] for k in ['kind', 'python', 'binaries', 'generator_sha256'])):
            fail('purpose_launch_runtime')
        if str(pathlib.Path(row['argv'][0]).resolve(strict=True)) != pinned['python']:
            fail('purpose_launch_runtime')
        if run['environment']['executor_python'] != sys.executable or run['environment']['executor_python_digest'] != digest(pathlib.Path(sys.executable).read_bytes()):
            fail('purpose_launch_runtime')

        def read(path):
            if directories() != directory_ids:
                fail('purpose_launch_root_changed')
            relative = path.relative_to(root)
            cursor = root
            for part in relative.parts:
                cursor = cursor / part
                if cursor.is_symlink():
                    fail('purpose_launch_root')
            return path.read_bytes()
        package = root / 'executor/omegacode'
        helpers = {name: read(package / name) for name in ['runner.py', 'common.py', 'confinement.py']}
        if read(package / '__init__.py') != b'' or digest(canonical({n: digest(v) for (n, v) in helpers.items()})) != run['evaluator_digest']:
            fail('purpose_launch_helper')
        importlib.machinery.PathFinder.invalidate_caches()
        origin = importlib.machinery.PathFinder.find_spec('omegacode', [str(root), str(root / 'executor')])
        if origin is None or origin.origin != str(package / '__init__.py'):
            fail('purpose_launch_import')
        if {str(f.relative_to(package)) for f in package.rglob('*') if f.is_file() or f.is_symlink()} != {'__init__.py', *helpers}:
            fail('purpose_launch_helper')
        policy = read(root / 'confinement.sb')
        if policy != profile(root / 'tree', pinned['python']).encode() or digest(policy) != retained['policy_sha256']:
            fail('purpose_launch_policy')
        files = service.manifest(fork)['files']
        if {str(f.relative_to(root / 'tree')) for f in (root / 'tree').rglob('*') if f.is_file() or f.is_symlink()} != set(files):
            fail('purpose_launch_tree')
        for (path, meta) in files.items():
            data = read(root / 'tree' / path)
            if digest(data) != meta['digest'] or len(data) != meta['size']:
                fail('purpose_launch_tree')
        raw = read(root / 'spec.json')
        spec = json.loads(raw)
        expected = dict(run_id=run['id'], nonce=run['nonce'], argv=['/usr/bin/sandbox-exec', '-f', str(root / 'confinement.sb'), pinned['python'], *row['argv'][1:]], generation=run['generation'], tree_digest=run['tree_digest'], timeout_seconds=run['timeout_seconds'], files=files, pinned_executable_digest=None, terminal=False, rows=24, cols=80, debugger_session=False, confinement=retained, pty_confinement=None)
        if raw != canonical(expected) or spec != expected:
            fail('purpose_launch_spec')
        observed_paths = [package / n for n in ['__init__.py', *helpers]] + [root / 'confinement.sb', root / 'spec.json'] + [root / 'tree' / n for n in files]
        observed = {str(f.relative_to(root)): digest(read(f)) for f in observed_paths}
        if (root / 'launch.json').exists() or (root / 'launch.json').is_symlink():
            fail('purpose_launch_original')
    except (OSError, ValueError, KeyError, TypeError):
        fail('purpose_launch_files')
    if not host.dispatch_gate(g, row):
        fail('purpose_launch_admission')
    record_ids = [('workspace', p['parent']['workspace_id']), ('workspace', fork['id']), ('suggestion', p['proposal']['proposal_id']), ('suggestion_scope', p['origin_scope']['scope_id']), ('suggestion_provenance', p['proposal']['proposal_id']), ('proposal_preparation', p['test_id']), ('proposal_preparation_bind', p['test_id']), ('proposal_dispatch_binding', launch_id), ('proposal_watch_binding', launch_id)] if _commit is not None else []
    records = [(kind, id_, service.store.get(kind, id_)) for (kind, id_) in record_ids]
    scope = next((value for (kind, id_, value) in records if kind == 'suggestion_scope'), None)
    grant_ids = {g['id']}
    if scope is not None:
        grant_ids.add(scope['issuer_claims']['id'])

    def grants():
        values = {}
        for id_ in grant_ids:
            value = service.store.db.execute('SELECT body,revoked FROM grants WHERE id=?', (id_,)).fetchone()
            if value is None:
                fail('purpose_launch_local_grant')
            values[id_] = (value[0], value[1])
        return values
    retained_grants = grants()
    fresh = candidate(service, authority, principal)
    if fresh != (saved, bound, fork) or canonical(g) != claims or canonical(service.store.get('run', run['id'])) != original or (Custody(service.store).get(launch_id) != row):
        fail('purpose_launch_binding')

    def local_check():
        if canonical(g) != claims or canonical(service.store.get('run', run['id'])) != original or Custody(service.store).get(launch_id) != row:
            fail('purpose_launch_binding')
        if grants() != retained_grants:
            fail('purpose_launch_local_grant')
        import time
        if any((revoked or json.loads(body)['exp'] <= time.time() for (body, revoked) in retained_grants.values())):
            fail('purpose_launch_local_grant')
        for (kind, id_, value) in records:
            if service.store.get(kind, id_) != value:
                fail('purpose_launch_local_record')
            if kind in ('suggestion', 'suggestion_scope', 'suggestion_provenance'):
                if digest(service.store.read_blob(value['digest'], p['parent']['workspace_id'])) != value['digest']:
                    fail('purpose_launch_local_record')
        if scope is not None:
            ceiling = json.loads(service.store.read_blob(scope['digest'], p['parent']['workspace_id']))
            service._context_current(service.workspace(p['parent']['workspace_id']), ceiling['context_selection'])
        try:
            if directories() != directory_ids:
                fail('purpose_launch_root_changed')
            if identity(service.repositories[fork['repository_id']].get('execution_confinement')) != pinned:
                fail('purpose_launch_runtime')
            if any((digest(read(root / n)) != h for (n, h) in observed.items())):
                fail('purpose_launch_files_changed')
            if {str(f.relative_to(package)) for f in package.rglob('*') if f.is_file() or f.is_symlink()} != {'__init__.py', *helpers}:
                fail('purpose_launch_helper')
            if {str(f.relative_to(root / 'tree')) for f in (root / 'tree').rglob('*') if f.is_file() or f.is_symlink()} != set(files):
                fail('purpose_launch_tree')
            importlib.machinery.PathFinder.invalidate_caches()
            origin = importlib.machinery.PathFinder.find_spec('omegacode', [str(root), str(root / 'executor')])
            if origin is None or origin.origin != str(package / '__init__.py'):
                fail('purpose_launch_import')
            if (root / 'launch.json').exists() or (root / 'launch.json').is_symlink():
                fail('purpose_launch_original')
        except (OSError, ValueError, KeyError, TypeError):
            fail('purpose_launch_files')
        service._check_owner(required=True)
    local_check()
    if _commit is not None:
        with service.store.lock:
            local_check()
            return _commit()
    return dict(launch_id=launch_id, run_id=row['run_id'], nonce=row['nonce'], scope='point-in-time prepared-file check', process_started=False, execution_authority='none', watchdog_qualified=False)
