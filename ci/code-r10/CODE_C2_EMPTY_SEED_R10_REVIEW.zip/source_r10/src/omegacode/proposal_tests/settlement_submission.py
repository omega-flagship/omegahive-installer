"""Owner-retained settlement intent. No POST, host ledger or authority issuance."""
from omegacode.common import canonical, digest, CodeError, stamp
from omegacode.proposal_launch_custody import Custody, execution_binding
from omegacode.proposal_settlement_evidence import capture
from .result_api import native_fence
from .proposal_host_wire import fail
from .launch_admission import scope_binding
import json
KIND = 'proposal_settlement_submission'
FIXED = ['id', 'test_id', 'launch_key', 'binding', 'argv', 'runtime_seconds', 'run_id', 'nonce', 'spawn_marker', 'fingerprint', 'hold_id']

def identity(service, row):
    payload = {n: row[n] for n in ['test_id', 'launch_key', 'binding', 'argv', 'runtime_seconds']}
    if row['fingerprint'] != digest(canonical(payload)):
        fail('settlement_original')
    saved = service.store.get('proposal_preparation', row['test_id'])
    bound = service.store.get('proposal_preparation_bind', row['test_id'])
    if saved['binding']['aud'] != service.authority.registration['service_id'] or row['id'] != 'pl_' + digest(canonical([row['test_id'], row['launch_key']])) or row['spawn_marker'] != str(service.store.root / 'runs' / row['run_id']) or (bound['state'] != 'acknowledged') or (bound['fingerprint'] != digest(canonical(bound['body']))) or (row['binding']['fork'] != dict(workspace_id=saved['fork_workspace_id'], preparation_digest='sha256:' + saved['preparation_digest'])):
        fail('settlement_original')
    projection = None
    execution_claims = None
    if row['ever_spawning'] is True:
        projection = execution_binding(service.store, row)
        raw = service.store.db.execute('SELECT body FROM grants WHERE id=?', (projection['grant_id'],)).fetchone()
        if raw is None:
            fail('settlement_original')
        claims = json.loads(raw[0])
        if claims['id'] != projection['grant_id'] or claims['actor'] != projection['actor'] or scope_binding(claims) != saved['binding'] or (claims['proposal_test']['fork'] != row['binding']['fork']):
            fail('settlement_original')
        execution_claims = raw[0]
    native = native_fence(service, row)
    if native is not None:
        expected = dict(id=row['run_id'], nonce=row['nonce'], workspace_id=projection['workspace_id'], generation=projection['generation'], tree_digest=projection['tree_digest'], grant_id=projection['grant_id'], author=projection['actor'], argv=row['argv'], timeout_seconds=row['runtime_seconds'], launch_custody_id=row['id'], proposal_purpose_test=row['test_id'])
        if canonical(native['run']) != canonical(expected):
            fail('settlement_original')
    return dict(launch={n: row[n] for n in FIXED}, preparation=saved, binding=bound, native=native, execution_projection=projection, execution_claims=execution_claims)

def same_original(retained, current):
    left = {k: v for (k, v) in retained.items() if k != 'native'}
    right = {k: v for (k, v) in current.items() if k != 'native'}
    return canonical(left) == canonical(right) and (retained['native'] is None or canonical(retained['native']) == canonical(current['native']))

def retain(service, host, launch_id):
    """Derive exact body from existing owner evidence; retain before transport."""
    service._check_owner(required=True)
    custody = Custody(service.store)
    with service.store.lock:
        row = custody.get(launch_id)
        pending = [r for r in service.store.list(KIND) if r['launch_id'] == launch_id and r['state'] == 'prepared']
        if len(pending) > 1:
            fail('settlement_unresolved')
        if pending:
            record = pending[0]
            if record['body_digest'] != digest(canonical(record['body'])) or not same_original(record['identity'], identity(service, row)):
                fail('settlement_original')
            return record
        before = identity(service, row)
    if row['hold_id'] is None:
        current = host.lookup(row['test_id'], row['launch_key'])
        with service.store.lock:
            service._check_owner(required=True)
            if identity(service, custody.get(launch_id)) != before:
                fail('settlement_original')
            if current is None:
                fail('hold_recovery_required')
            custody.attach_hold(launch_id, host.projection(current, row))
            row = custody.get(launch_id)
    with service.store.lock:
        if row['ever_spawning'] is False:
            if row['state'] != 'not_started' or native_fence(service, row) is not None or any((r['id'] == launch_id for r in service.store.list('proposal_dispatch_binding'))):
                fail('settlement_never_spawning')
            body = capture(service.store, launch_id, row['revision'])
        elif native_fence(service, row) is None:
            if row['state'] not in ('spawning', 'unknown'):
                fail('settlement_original')
            identity(service, row)
            with service.store.transaction():
                service._check_owner(required=True)
                if custody.get(launch_id) != row:
                    fail('settlement_original')
                if row['state'] == 'spawning':
                    row.update(state='unknown', reason='settlement_native_record_unconfirmed')
                    row = custody._put(row)
                body = dict(outcome='unknown', run_id=row['run_id'], runtime=dict(seconds=None, provenance='unknown'), cleanup=dict(descendants_stopped=False, observed_at=None), evidence=dict(launch_record_state='spawning', launch_record_rev=row['revision']), receipt_digest=None)
        else:
            body = service.proposal_settlement_evidence(launch_id)
        row = custody.get(launch_id)
        fixed = identity(service, row)
        fingerprint = digest(canonical(body))
        id_ = 'ps_' + digest(canonical([launch_id, fingerprint]))
        with service.store.transaction():
            service._check_owner(required=True)
            if identity(service, custody.get(launch_id)) != fixed:
                fail('settlement_original')
            existing = [r for r in service.store.list(KIND) if r['id'] == id_]
            if existing:
                return existing[0]
            record = dict(id=id_, launch_id=launch_id, test_id=row['test_id'], hold_id=row['hold_id'], body=body, body_digest=fingerprint, identity=fixed, state='prepared', created_at=stamp(), host_settled=False, authority_renewed=False)
            service.store.put(KIND, record)
    return record

def reconcile(service, host, submission_id):
    """Read original host observation; no POST or guessed ack/status parser."""
    service._check_owner(required=True)
    with service.store.lock:
        record = service.store.get(KIND, submission_id)
        row = Custody(service.store).get(record['launch_id'])
        if record['body_digest'] != digest(canonical(record['body'])) or not same_original(record['identity'], identity(service, row)):
            fail('settlement_original')
    current = host.hold(record['test_id'], record['hold_id'], row['launch_key'])
    projection = host.projection(current, row)
    acknowledged = type(current.get('observation')) is list and any((canonical(item) == canonical(record['body']) for item in current['observation'] if type(item) is dict))
    with service.store.transaction():
        service._check_owner(required=True)
        if service.store.get(KIND, submission_id) != record or not same_original(record['identity'], identity(service, Custody(service.store).get(row['id']))):
            fail('settlement_original')
        if projection['hold_id'] != record['hold_id']:
            fail('settlement_original')
        if acknowledged:
            if current.get('run_id') != record['body']['run_id']:
                fail('settlement_host_binding')
            if record['body']['outcome'] == 'not_started':
                expected = 'released'
            elif record['body']['outcome'] == 'unknown' or not record['body']['cleanup']['descendants_stopped']:
                expected = 'unknown'
            else:
                expected = 'settled'
            if current['state'] != expected:
                fail('settlement_host_binding')
            record.update(state='acknowledged', host_state=current['state'], host_settled=current['state'] in ('settled', 'released'))
            service.store.put(KIND, record)
    return dict(submission_id=submission_id, acknowledged=acknowledged, state=record['state'], host_settled=record['host_settled'], authority_renewed=False)
