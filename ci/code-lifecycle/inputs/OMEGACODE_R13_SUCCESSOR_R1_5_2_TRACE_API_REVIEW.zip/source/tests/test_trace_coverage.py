import importlib.util
import sys
import types
import unittest
from unittest.mock import patch
from pathlib import Path


MODULE = Path(__file__).parents[1] / 'src/omegacode/symbolic.py'
SPEC = importlib.util.spec_from_file_location('trace_candidate_symbolic', MODULE)
symbolic = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(symbolic)


class FakeSpace:
    def atom_count(self):
        return 0

    def get_atoms(self):
        return []


class FakeRunner:
    def __init__(self, metta, source):
        self.calls = 0

    def is_complete(self):
        return False

    def run_step(self):
        self.calls += 1

    def current_results(self):
        return [[str(self.calls)]]


class FakeMetta:
    def space(self):
        return FakeSpace()


def install_runner(modules):
    hyperon = types.ModuleType('hyperon')
    runner = types.ModuleType('hyperon.runner')
    runner.RunnerState = FakeRunner
    hyperon.runner = runner
    modules.update({'hyperon': hyperon, 'hyperon.runner': runner})


class TraceCoverageTest(unittest.TestCase):
    def test_step_status_distinguishes_full_history_from_dropped_prefix(self):
        with patch.dict(sys.modules) as modules:
            install_runner(modules)
            state = {'context': {'run_id': 'synthetic-run'}, 'sequence': 1}
            started = symbolic.step_command(FakeMetta(), {
                'id': 'start', 'op': 'step-start', 'source': '!(+ 1 1)', 'max_steps': 1000,
            }, state)
            self.assertEqual(started['observation_total'], 0)
            self.assertEqual(started['observation_dropped_prefix'], 0)
            self.assertEqual(started['observation_coverage'], 'complete-history')
            self.assertIsNone(started['first_retained_input_sequence'])
            self.assertIsNone(started['first_retained_step'])

            for sequence in range(2, 103):
                state['sequence'] = sequence
                current = symbolic.step_command(FakeMetta(), {
                    'id': f'next-{sequence}', 'op': 'step-next', 'trace_id': started['trace_id'], 'count': 1,
                }, state)

            self.assertEqual(current['observation_total'], 101)
            self.assertEqual(current['observation_window_limit'], 100)
            self.assertEqual(len(current['observations']), 100)
            self.assertEqual(current['observation_dropped_prefix'], 1)
            self.assertEqual(current['observation_coverage'], 'recent-tail')
            self.assertEqual(current['first_retained_input_sequence'], 3)
            self.assertEqual(current['first_retained_step'], 2)
            self.assertEqual(current['last_observed_step'], 101)

            state['sequence'] = 103
            status = symbolic.step_command(FakeMetta(), {
                'id': 'status', 'op': 'step-status', 'trace_id': started['trace_id'],
            }, state)
            self.assertEqual(status['observation_total'], 101)
            self.assertEqual(status['observation_dropped_prefix'], 1)
            self.assertEqual(status['observations'], current['observations'])

    def test_failed_observation_does_not_publish_unobserved_results(self):
        for failing_input in ('atom_strings', 'encoded', 'sha'):
            with self.subTest(failing_input=failing_input), patch.dict(sys.modules) as modules:
                install_runner(modules)
                state = {'context': {'run_id': 'synthetic-run'}, 'sequence': 1}
                started = symbolic.step_command(FakeMetta(), {
                    'id': 'start', 'op': 'step-start', 'source': '!(+ 1 1)', 'max_steps': 10,
                }, state)
                state['sequence'] = 2
                observed = symbolic.step_command(FakeMetta(), {
                    'id': 'one', 'op': 'step-next', 'trace_id': started['trace_id'], 'count': 1,
                }, state)
                self.assertEqual(observed['results'], [['1']])
                self.assertEqual(observed['observation_total'], 1)

                state['sequence'] = 3
                with patch.object(symbolic, failing_input,
                                  side_effect=ValueError(f'injected {failing_input} failure')):
                    with self.assertRaisesRegex(ValueError, f'injected {failing_input} failure'):
                        symbolic.step_command(FakeMetta(), {
                            'id': 'fault', 'op': 'step-next', 'trace_id': started['trace_id'], 'count': 1,
                        }, state)

                state['sequence'] = 4
                after_fault = symbolic.step_command(FakeMetta(), {
                    'id': 'status', 'op': 'step-status', 'trace_id': started['trace_id'],
                }, state)
                self.assertEqual(after_fault['status'], 'faulted')
                self.assertEqual(after_fault['step_count'], 2)
                self.assertEqual(after_fault['results'], [['1']])
                self.assertEqual(after_fault['results_currency'], 'last successful step batch')
                self.assertEqual(after_fault['observation_total'], 1)
                self.assertEqual(after_fault['last_observed_step'], 1)
                self.assertEqual(len(after_fault['observations']), 1)


if __name__ == '__main__':
    unittest.main()
