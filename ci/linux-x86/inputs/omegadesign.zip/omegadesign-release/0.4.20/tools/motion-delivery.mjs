// Local delivery only; host authority and project adoption remain separate.
import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';
import {readMotionSource} from './motion-source.mjs';import {exportMotionSVG} from './export-motion.mjs';
const sha=bytes=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
export async function deliverMotion(input,output){
 if((await fs.stat(input)).size>20*1024*1024)throw Error('Motion source exceeds 20 MiB limit');
 const bytes=await fs.readFile(input);
 const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes),source=await readMotionSource(text);
 const animation=Buffer.from(await exportMotionSVG(source.scene,source.timeline));
 const manifest={schema:'omega-motion-delivery-1',files:{'editable-motion.json':{digest:sha(bytes),bytes:bytes.length,mime:'application/json'},'animated-motion.svg':{digest:sha(animation),bytes:animation.length,mime:'image/svg+xml'}},scene_digest:source.timeline.scene_digest,duration_ms:source.timeline.duration_ms,editable:true,adopted:false,independent_review:false};
 // One writer in the host's private sandbox job directory. This is not a
 // no-replace rename primitive against arbitrary concurrent same-uid actors.
 const target=path.resolve(output),operationErrors=[];
 const absent=async()=>{
  try{await fs.lstat(target);}catch(error){if(error.code==='ENOENT')return;throw error;}
  throw Object.assign(new Error('Motion delivery directory already exists'),{code:'EEXIST'});
 };
 // No destination is created until all three closed files are complete.
 await absent();
 let staging;
 try{
  // Sibling staging keeps the final directory rename on the same filesystem.
  staging=await fs.mkdtemp(path.join(path.dirname(target),'.omega-motion-private-'));
  await fs.chmod(staging,0o700);
  for(const [name,data] of [['editable-motion.json',bytes],['animated-motion.svg',animation],['manifest.json',JSON.stringify(manifest,null,2)+'\n']]){
   const file=path.join(staging,name),handle=await fs.open(file,'wx');
   let primary,failed=false;
   try{await handle.writeFile(data);}catch(error){primary=error;failed=true;}
   try{await handle.close();}catch(closeError){
    if(failed)operationErrors.push(closeError);else{primary=closeError;failed=true;}
   }
   if(failed)throw primary;
  }
  await absent();
  await fs.rename(staging,target);
  staging=undefined;
 }catch(error){
  const cleanupErrors=[...operationErrors];
  // Never recursively remove the public target or its siblings. Only our
  // random, private staging tree is eligible for failure cleanup.
  if(staging)try{await fs.rm(staging,{recursive:true});}catch(cleanup){cleanupErrors.push(cleanup);}
  if(cleanupErrors.length)throw new AggregateError([error,...cleanupErrors],`${error.message}; Motion delivery cleanup failed: ${cleanupErrors.map(e=>e.message).join('; ')}`,{cause:error});
  throw error;
 }
 return manifest;
}
if(process.argv[1]===new URL(import.meta.url).pathname){try{const [input,output]=process.argv.slice(2);if(!input||!output)throw Error('Usage: motion-delivery.mjs input.json new-output-directory');console.log(JSON.stringify(await deliverMotion(input,output)));}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}}
