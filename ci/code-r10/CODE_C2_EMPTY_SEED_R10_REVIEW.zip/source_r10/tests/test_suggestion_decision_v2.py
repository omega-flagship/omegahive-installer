import copy, time
import httpx, pytest

pytest_plugins = ['test_service','test_hive_capabilities']

from omegacode.common import CodeError, canonical, digest
from omegacode.auth import ACTIONS
from omegacode.suggestion_validation import reconstruct_v2
from test_service import service, principal, workspace


def v2_scope(service,p,ws,files,total):
    return service.create_suggestion_scope(p,ws['id'],{
        'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'scope-v2',
        'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
        'ranges':{},'create_files':files,'max_total_create_bytes':total})


def v2_proposal(service,p,ws,scope,hunks,groups=None):
    payload={'schema_marker':'omegacode-suggestion-request-v2','operation_id':'proposal-v2',
             'scope_id':scope['id'],'hunks':hunks}
    if groups is not None:payload['groups']=groups
    return service.create_suggestion(p,ws['id'],payload)


def test_decision_creates_empty_file_with_absence_cas_and_one_change(service):
    p,_=principal(service);ws=workspace(service,p)
    scope=v2_scope(service,p,ws,{'src/empty.py':{'max_bytes':0}},0)
    proposal=v2_proposal(service,p,ws,scope,[{'kind':'create_text','path':'src/empty.py','content':''}])
    retained=service.suggestion(p,ws['id'],proposal['id'])['content']
    unit=retained['hunks'][0]
    decision={'operation_id':'accept-empty-v2','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id']],'rejected_hunk_ids':[]}
    result=service.decide_suggestion(p,ws['id'],decision)
    replay=service.decide_suggestion(p,ws['id'],decision)
    assert replay==result
    current=result['workspace']
    assert current['generation']==ws['generation']+1
    assert result['change']['paths']==['src/empty.py']
    assert service.manifest(current)['files']['src/empty.py']['size']==0
    assert len(service.store.list('suggestion_decision'))==1
    assert len(service.store.list('change'))==1


def test_mixed_edit_and_create_dependent_group_cannot_be_split(service):
    p,_=principal(service);ws=workspace(service,p)
    raw=service.read(p,ws['id'],'calculator.py')['content'].encode();pos=raw.index(b'-')
    scope=service.create_suggestion_scope(p,ws['id'],{
        'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'mixed-scope',
        'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
        'ranges':{'calculator.py':[[0,len(raw)]]},'create_files':{'src/main.py':{'max_bytes':100}},
        'max_total_create_bytes':100})
    proposal=v2_proposal(service,p,ws,scope,[
        {'kind':'edit_text','path':'calculator.py','start_byte':pos,'end_byte':pos+1,
         'replacement':'+','before_digest':digest(b'-')},
        {'kind':'create_text','path':'src/main.py','content':'app = True\n'}],groups=[[0,1]])
    retained=service.suggestion(p,ws['id'],proposal['id'])['content']
    created=next(h for h in retained['hunks'] if h['kind']=='create_text')
    decision={'operation_id':'split-group','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[created['id']],'rejected_hunk_ids':[]}
    with pytest.raises(CodeError) as refused:service.decide_suggestion(p,ws['id'],decision)
    assert refused.value.code=='suggestion_group_split'
    assert 'src/main.py' not in service.manifest(ws)['files']
    assert len(service.store.list('change'))==0


def test_mixed_edit_and_create_group_commits_as_one_generation(service):
    p,_=principal(service);ws=workspace(service,p)
    raw=service.read(p,ws['id'],'calculator.py')['content'].encode();pos=raw.index(b'-')
    scope=service.create_suggestion_scope(p,ws['id'],{
        'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'mixed-scope-accept',
        'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
        'ranges':{'calculator.py':[[0,len(raw)]]},'create_files':{'src/main.py':{'max_bytes':100}},
        'max_total_create_bytes':100})
    proposal=v2_proposal(service,p,ws,scope,[
        {'kind':'edit_text','path':'calculator.py','start_byte':pos,'end_byte':pos+1,
         'replacement':'+','before_digest':digest(b'-')},
        {'kind':'create_text','path':'src/main.py','content':'app = True\n'}],groups=[[0,1]])
    units=service.suggestion(p,ws['id'],proposal['id'])['content']['hunks']
    decision={'operation_id':'accept-group','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id'] for unit in units],'rejected_hunk_ids':[]}
    result=service.decide_suggestion(p,ws['id'],decision)
    assert result['workspace']['generation']==ws['generation']+1
    assert result['change']['paths']==['calculator.py','src/main.py']
    assert 'return a + b' in service.read(p,ws['id'],'calculator.py')['content']
    assert service.read(p,ws['id'],'src/main.py')['content']=='app = True\n'
    assert len(service.store.list('suggestion_decision'))==1


def test_destination_race_after_proposal_refuses_without_overwrite(service):
    p,_=principal(service);ws=workspace(service,p)
    scope=v2_scope(service,p,ws,{'src/main.py':{'max_bytes':100}},100)
    proposal=v2_proposal(service,p,ws,scope,[{'kind':'create_text','path':'src/main.py','content':'proposed'}])
    unit=service.suggestion(p,ws['id'],proposal['id'])['content']['hunks'][0]
    changed=service.edit(p,ws['id'],{
        'operation_id':'race-create','expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
        'edits':[{'path':'src/main.py','expected_digest':None,'content':'other'}]})['workspace']
    decision={'operation_id':'race-apply','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id']],'rejected_hunk_ids':[]}
    with pytest.raises(CodeError) as refused:service.decide_suggestion(p,ws['id'],decision)
    assert refused.value.code in ('stale_workspace','suggestion_stale')
    assert service.workspace(ws['id'])['generation']==changed['generation']
    assert service.read(p,ws['id'],'src/main.py')['content']=='other'
    assert len(service.store.list('suggestion_decision'))==0


def test_delegated_suggest_only_child_proposes_person_applies(host):
    svc,human,state,token=host
    person=svc.authority.authenticate(token())
    ws=svc.create_workspace(person,{'operation_id':'open-v2','task_id':human['task_id'],
                                    'repository_id':'synthetic','base_commit':'HEAD'})
    scope=v2_scope(svc,person,ws,{'src/main.py':{'max_bytes':100}},100)
    child={**copy.deepcopy(human),'id':'cap-child-v2','kind':'agent','actor':'agent:child-v2',
            'member_hash':digest(b'child-v2'),'grant_id':None,'actions':['read','search','suggest'],
            'iat':time.time(),'exp':time.time()+60,
            'delegated':{'request_id':'request-v2','controller_id':'controller-v2','execution_goal':'goal-v2',
                         'issuer':human['actor'],'origin_scope':{'scope_id':scope['id'],
                         'scope_digest':'sha256:'+scope['digest'],'generation':ws['generation']}}}
    def transport(request):
        if request.url.path=='/api/agent/authorize':return httpx.Response(200,json={'decision':'allow'})
        if request.url.path.endswith('/grants'):return httpx.Response(200,json=[state['grant']])
        claims=child if request.url.path.endswith('/cap-child-v2') else human
        return httpx.Response(200,json={'active':True,'claims':claims})
    svc.authority.client.close()
    svc.authority.client=httpx.Client(transport=httpx.MockTransport(transport))
    child_token=token(child)
    mind=svc.authority.authenticate(child_token,'child-v2')
    proposal=v2_proposal(svc,mind,ws,scope,[{'kind':'create_text','path':'src/main.py','content':'member app'}])
    retained=svc.suggestion(person,ws['id'],proposal['id'])['content']
    unit=retained['hunks'][0]
    decision={'operation_id':'person-confirm-v2','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id']],'rejected_hunk_ids':[]}
    with pytest.raises(CodeError) as refused:svc.decide_suggestion(mind,ws['id'],decision)
    assert refused.value.code=='person_required'
    result=svc.decide_suggestion(person,ws['id'],decision)
    assert result['change']['paths']==['src/main.py']
    assert svc.read(person,ws['id'],'src/main.py')['content']=='member app'
    assert svc.store.list('suggestion_provenance')


def test_edit_capable_agent_with_valid_approval_cannot_decide_or_replay_v2(host):
    svc,human,state,token=host
    person=svc.authority.authenticate(token())
    ws=svc.create_workspace(person,{'operation_id':'open-agent-decision','task_id':human['task_id'],
                                    'repository_id':'synthetic','base_commit':'HEAD'})
    scope=v2_scope(svc,person,ws,{'src/main.py':{'max_bytes':100}},100)
    proposal=v2_proposal(svc,person,ws,scope,[{'kind':'create_text','path':'src/main.py','content':'member app'}])
    projection=svc.suggestion(person,ws['id'],proposal['id'])
    body=projection['content'];unit=body['hunks'][0]
    decision={'operation_id':'agent-v2-decision','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id']],'rejected_hunk_ids':[]}
    agent_claims={**copy.deepcopy(human),'id':'cap-agent-edit','kind':'agent','actor':'mind:edit-capable',
                  'member_hash':digest(b'member-test'),'grant_id':None,'actions':sorted(ACTIONS),
                  'exp':time.time()+60}
    claims_by_id={human['id']:human,agent_claims['id']:agent_claims}
    calls=[];approval={'binding':None}
    def transport(request):
        calls.append((request.method,request.url.path))
        path=request.url.path
        if path.startswith('/api/services/capabilities/'):
            cid=path.rsplit('/',1)[-1]
            return httpx.Response(200,json={'active':True,'claims':claims_by_id[cid]})
        if path=='/api/agent/goals/goal-test':
            return httpx.Response(200,json={'swarm_id':'swarm-test','claimed_by':'mind:edit-capable',
                'status':'claimed','lease_until':'2099-01-01T00:00:00Z'})
        if path=='/api/agent/approvals/approved-v2-edit':
            return httpx.Response(200,json={'agent_id':'mind:edit-capable','skill':'code-edit',
                'status':'approved','binding':approval['binding']})
        if path=='/api/agent/approvals/approved-v2-edit/redeem':
            return httpx.Response(200,json={'redeemed':True})
        if path=='/api/goals/goal-test/grants':
            return httpx.Response(200,json=[state['grant']])
        return httpx.Response(200,json={'decision':'allow'})
    svc.authority.client.close()
    svc.authority.client=httpx.Client(transport=httpx.MockTransport(transport))
    agent=svc.authority.authenticate(token(agent_claims),'member-test')

    retained_scope=svc._bound_suggestion_scope(person,ws,scope['id'],fresh=False)
    paths=sorted(set(retained_scope['ranges'])|set(retained_scope['create_files']))
    manifest=svc.manifest(ws,ws['tree_digest'])['files']
    edit_binding={k:body['binding'][k] for k in ('workspace_id','task_id','generation','tree_digest')}
    edits=reconstruct_v2(body,proposal['digest'],edit_binding,{},[unit['id']],existing_paths=manifest.keys())
    op_payload={**decision,'paths':paths,'mutation':'suggestion-decision',
                'context_policy_digest':retained_scope['context_selection']['policy_digest'],'edits':edits}
    operation={'action':'edit','workspace_id':ws['id'],**op_payload}
    operation_digest='sha256:'+digest(canonical(operation))
    approval['binding']={'task_id':agent_claims['task_id'],'swarm_id':agent_claims['swarm_id'],
        'workspace_id':ws['id'],'operation_id':decision['operation_id'],
        'expected_generation':ws['generation'],'payload_digest':operation_digest}
    approved_payload={**op_payload,'approval_id':'approved-v2-edit'}
    svc._authorize(agent,'edit',ws,approved_payload)
    svc.authority.gate(agent,'edit',{**operation,'approval_id':'approved-v2-edit'})
    assert calls[-2:]==[('GET','/api/agent/approvals/approved-v2-edit'),
                        ('POST','/api/agent/approvals/approved-v2-edit/redeem')]

    before=len(calls)
    with pytest.raises(CodeError) as refused:svc.decide_suggestion(agent,ws['id'],approved_payload)
    assert refused.value.code=='person_required' and len(calls)==before
    accepted=svc.decide_suggestion(person,ws['id'],decision)
    assert accepted['change']['paths']==['src/main.py']
    before_replay=len(calls)
    with pytest.raises(CodeError) as replay:svc.decide_suggestion(agent,ws['id'],approved_payload)
    assert replay.value.code=='person_required' and len(calls)==before_replay
    assert len(svc.store.list('change'))==1 and len(svc.store.list('suggestion_decision'))==1


def test_create_apply_and_decision_roll_back_as_one_transaction(service,monkeypatch):
    p,_=principal(service);ws=workspace(service,p)
    scope=v2_scope(service,p,ws,{'src/main.py':{'max_bytes':100}},100)
    proposal=v2_proposal(service,p,ws,scope,[{'kind':'create_text','path':'src/main.py','content':'x'}])
    unit=service.suggestion(p,ws['id'],proposal['id'])['content']['hunks'][0]
    decision={'operation_id':'fault-create-commit','suggestion_id':proposal['id'],'suggestion_digest':proposal['digest'],
              'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
              'accepted_hunk_ids':[unit['id']],'rejected_hunk_ids':[]}
    original=service.store.put
    def fail_decision(kind,record):
        if kind=='suggestion_decision':raise CodeError(503,'synthetic_decision_failure','injected test failure')
        return original(kind,record)
    monkeypatch.setattr(service.store,'put',fail_decision)
    with pytest.raises(CodeError):service.decide_suggestion(p,ws['id'],decision)
    current=service.workspace(ws['id'])
    assert current['generation']==ws['generation'] and current['tree_digest']==ws['tree_digest']
    assert 'src/main.py' not in service.manifest(current)['files']
    assert not service.store.list('change') and not service.store.list('suggestion_decision')
