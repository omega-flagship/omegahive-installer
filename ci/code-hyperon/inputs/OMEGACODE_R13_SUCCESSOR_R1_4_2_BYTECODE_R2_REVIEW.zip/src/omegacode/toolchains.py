"""Read-only discovery of owner-configured runtimes. No installs or client-selected paths."""
import hashlib
import os
import pathlib
import subprocess
import json

HYPERON_PROBE = '''import hashlib,json,pathlib,importlib.metadata
import hyperon,hyperonpy
from hyperon import MeTTa
m=MeTTa()
assert str(m.run("!(+ 2 3)"))=="[[5]]"
root=pathlib.Path(hyperon.__file__).parent
files=sorted(p for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
h=hashlib.sha256()
for p in files:
 h.update(str(p.relative_to(root)).encode()+b"\\x00"+hashlib.sha256(p.read_bytes()).digest())
h.update(hashlib.sha256(pathlib.Path(hyperonpy.__file__).read_bytes()).digest())
print(json.dumps(dict(version=importlib.metadata.version("hyperon"),source_digest=h.hexdigest(),source_files=len(files),arithmetic="5")))
'''


def inventory(configs):
    result = []
    for name, config in sorted(configs.items()):
        entry = {"id": name, "kind": config["kind"], "available": False, "qualified": False,
                 "capabilities": ["batch-execution"] if config["kind"] == "petta" else [],
                 "limitations": "Discovery only; no symbolic debugger, persistent REPL or runtime-equivalence qualification."}
        root = pathlib.Path(config["root"]).resolve()
        # Preserve a virtualenv launcher path; resolving its symlink loses that environment.
        executable = pathlib.Path(config["executable"]).absolute()
        if config['kind'] == 'leatta':
            try:
                from .leatta import runtime_identity
                identity = runtime_identity(config)
                probe = subprocess.run([str(executable), '--min', '!(+ 2 3)'],
                    capture_output=True, text=True, timeout=5, stdin=subprocess.DEVNULL,
                    env={'PATH':os.defpath, 'LANG':'C.UTF-8'})
                if probe.returncode != 0 or probe.stderr.strip() or probe.stdout.strip() != '[5]' or runtime_identity(config) != identity:
                    raise ValueError('LeaTTa arithmetic/binary probe failed')
                entry.update(available=True, executable_digest=identity['executable_digest'],
                    runtime_identity_digest=hashlib.sha256(json.dumps(identity,sort_keys=True,
                        separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),
                    limitations='Pinned trusted-native LeaTTa binary; saved-file batch execution only. No OS sandbox, proof applicability, resident debugger or full Hyperon equivalence qualification.')
                if config.get('execution_enabled') is True:
                    entry.update(capabilities=['leatta-saved-file'],execution_argv_prefix=[str(executable),'--file'],
                                 execution_protocol='omegacode-leatta-file-v1')
            except (OSError,ValueError,subprocess.TimeoutExpired):
                entry['reason']='LeaTTa binary/arithmetic probe failed'
            result.append(entry)
            continue
        if config['kind'] == 'lean':
            try:
                from .proof_checker import runtime_identity
                identity = runtime_identity(config)
                probe = subprocess.run([str(executable), '--version'], capture_output=True, text=True,
                    timeout=5, stdin=subprocess.DEVNULL, env={'PATH':os.defpath, 'LANG':'C.UTF-8'})
                if probe.returncode != 0 or probe.stderr.strip() or len(probe.stdout) > 1024:
                    raise ValueError('Lean version probe failed')
                entry.update(available=True, version=probe.stdout.strip(),
                    runtime_identity_digest=hashlib.sha256(json.dumps(identity,sort_keys=True,
                        separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),
                    limitations='Operator-enabled saved-module trusted-native proof checks; Lean source may execute native code. No OS sandbox, implementation correspondence, proof UI or comparator qualification.')
                if config.get('check_enabled') is True:
                    entry.update(capabilities=['lean-single-module-check'],
                                 check_protocol='omegacode-lean-check-v1', check_argv_prefix=[str(executable)])
                    if config.get('project_check_enabled') is True:
                        entry['capabilities'].append('lean-project-check')
                        entry['project_check_protocol'] = 'omegacode-lean-project-check-v1'
                        entry['limitations'] += ' Projects require explicit ordered modules; no Lake, Mathlib installation or dependency discovery.'
            except (OSError, ValueError, subprocess.TimeoutExpired):
                entry['reason'] = 'Lean runtime probe failed'
            result.append(entry)
            continue
        if config["kind"] == "debugpy":
            try:
                from .debug_session import runtime_identity
                identity = runtime_identity(config)
                probe = subprocess.run([str(executable), '-I', '-B', '-c',
                    'import debugpy,json;print(json.dumps({"version":debugpy.__version__}))'],
                    capture_output=True,text=True,timeout=5,stdin=subprocess.DEVNULL,
                    env={"PATH":os.defpath,"LANG":"C.UTF-8","PYTHONDONTWRITEBYTECODE":"1"})
                if probe.returncode != 0 or probe.stderr.strip() or len(probe.stdout)>1024: raise ValueError()
                entry.update(json.loads(probe.stdout), available=True, runtime_identity_digest=hashlib.sha256(
                    json.dumps(identity,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),
                    limitations='Trusted-native Python DAP discovery; all inspection requires execution authority. No UI, remote attach, expression evaluation or comparative qualification.')
                if config.get('session_enabled') is True:
                    entry.update(capabilities=['python-dap-session'],session_argv=[str(executable)],
                                 session_protocol='omegacode-debugger-jsonl-v1')
            except (OSError,ValueError,subprocess.TimeoutExpired): entry['reason']='debugpy package probe failed'
            result.append(entry)
            continue
        if config["kind"] == "hyperon":
            try:
                source_identity = None
                if config.get('source_search_enabled') is True:
                    from .symbolic import runtime_identity
                    source_identity = runtime_identity(config)
                probe = subprocess.run([str(executable), "-I", "-B", "-c", HYPERON_PROBE], capture_output=True, text=True, timeout=10,
                                       env={"PATH":os.defpath,"LANG":"C.UTF-8"},stdin=subprocess.DEVNULL)
                if probe.returncode != 0 or probe.stderr.strip():
                    raise ValueError()
                if source_identity is not None and runtime_identity(config) != source_identity:
                    raise ValueError('Hyperon source-search runtime changed during discovery')
                entry.update(json.loads(probe.stdout), available=True, capabilities=["batch-execution"],
                             executable_digest=hashlib.sha256(executable.read_bytes()).hexdigest(),
                             limitations="Arithmetic/package probe only; no persistent REPL, symbolic debugger, UI or PeTTa equivalence qualification.")
                if source_identity is not None:
                    entry['capabilities'].append('metta-source-search')
                    entry['source_search_protocol'] = 'omegacode-metta-source-retrieval-v1'
                    # Same default-ASCII canonical JSON domain as the source parser.
                    entry['source_search_runtime_identity_digest'] = hashlib.sha256(
                        json.dumps(source_identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                if config.get('session_enabled') is True:
                    entry['capabilities'].append('resident-jsonl-session')
                    entry['session_argv'] = [str(executable)]
                    entry['session_protocol'] = 'omegacode-symbolic-jsonl-v1'
                    entry['limitations'] = 'Operator-enabled trusted-native resident session; inputs require run authority. No automatic replay, symbolic debugger, UI or PeTTa equivalence qualification.'
            except (OSError, ValueError, subprocess.TimeoutExpired):
                entry["reason"] = "Hyperon package probe failed"
            result.append(entry)
            continue
        if config["kind"] != "petta" or not (root/"src/main.pl").is_file() or not executable.is_file():
            entry["reason"] = "configured runtime is unavailable or unsupported"
            result.append(entry)
            continue
        try:
            env = {"PATH": os.defpath, "LANG": "C.UTF-8"}
            if config.get("framework_path"):
                env["DYLD_FRAMEWORK_PATH"] = config["framework_path"]
            version = subprocess.run([str(executable), "--version"], capture_output=True, text=True, timeout=5,
                                     env=env, stdin=subprocess.DEVNULL)
            bridge = subprocess.run([str(executable), "-q", "-g", "use_module(library(janus)),py_call(sys:version,V),writeln(V),halt"],
                                    capture_output=True, text=True, timeout=5, env=env, stdin=subprocess.DEVNULL)
            files = sorted(list((root/"src").rglob("*.pl")) + list((root/"lib").rglob("*.metta")))
            fingerprint = hashlib.sha256()
            for path in files:
                if path.is_symlink():
                    raise ValueError("runtime source symlink is unqualified")
                fingerprint.update(str(path.relative_to(root)).encode()+b"\x00"+hashlib.sha256(path.read_bytes()).digest())
            entry.update(available=version.returncode == 0, version=version.stdout.strip()[:1024],
                         python_interop_available=bridge.returncode == 0 and not bridge.stderr.strip(),
                         python_interop_version=bridge.stdout.strip()[:1024] if bridge.returncode == 0 and not bridge.stderr.strip() else None,
                         source_digest=fingerprint.hexdigest(), executable_digest=hashlib.sha256(executable.read_bytes()).hexdigest(),
                         source_files=len(files), execution_argv_prefix=[str(executable), "--stack_limit=1g", "-q", "-s", str(root/"src/main.pl"), "--"])
        except (OSError, ValueError, subprocess.TimeoutExpired):
            entry["reason"] = "runtime probe failed"
        result.append(entry)
    return {"toolchains": result, "selection_policy": "operator configuration only", "hyperon_equivalence": "unqualified"}
