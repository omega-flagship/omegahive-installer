import pytest

from omegacode.__main__ import SERVICE_PORT, configured_service_port


def test_production_service_port_defaults_to_reviewed_loopback_port():
    assert configured_service_port({}) == 8724
    assert SERVICE_PORT == 8724


def test_production_service_port_accepts_only_exact_integer_port():
    assert configured_service_port({"port": 8724}) == 8724
    for value in (0, 8080, 8725, "8724", True, None):
        with pytest.raises(ValueError, match="127.0.0.1:8724"):
            configured_service_port({"port": value})
