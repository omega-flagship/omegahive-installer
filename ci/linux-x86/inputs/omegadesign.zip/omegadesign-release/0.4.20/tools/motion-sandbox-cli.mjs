import fs from 'node:fs/promises';import {deliverMotion} from './motion-delivery.mjs';
const created=[];
try{
 const manifest=await deliverMotion('source.json','delivery');
 for(const name of ['editable-motion.json','animated-motion.svg','manifest.json']){
  const bytes=await fs.readFile('delivery/'+name);
  const output=await fs.open(name,'wx');
  created.push(name);
  try{await output.writeFile(bytes);}finally{await output.close();}
 }
 console.log(JSON.stringify({schema:manifest.schema,editable:true,adopted:false}));
}catch(error){
 const cleanupErrors=[];
 for(const name of created.reverse()){
  try{await fs.unlink(name);}catch(cleanup){if(cleanup.code!=='ENOENT')cleanupErrors.push({file:name,error:cleanup.message});}
 }
 console.error(JSON.stringify({error:error.message,...(cleanupErrors.length?{cleanupErrors}:{})}));process.exitCode=1;
}
