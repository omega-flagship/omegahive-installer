import {sampleMotion} from './motion.mjs';
import {svg,clone} from './scene.mjs';
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
export async function exportMotionSVG(scene,timeline){
 await sampleMotion(scene,timeline,0);
 // Text resize requires font-engine reflow; refuse unsupported flattened semantics.
 if(timeline.tracks.some(t=>scene.elements.find(e=>e.id===t.element_id).kind==='text'&&['width','height'].includes(t.field)))throw Error('Animated text needs reflow-capable export; use rectangle or image tracks');
 let result=svg(scene);
 for(const element of scene.elements){
  const tracks=timeline.tracks.filter(t=>t.element_id===element.id);if(!tracks.length)continue;
  const identifier=element.id.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  if(element.kind==='text'){
   const times=[...new Set(tracks.flatMap(t=>t.keyframes.map(f=>f.time_ms)))].sort((a,b)=>a-b);
   const values=[];
   for(const time of times){const frame=(await sampleMotion(scene,timeline,time)).scene.elements.find(e=>e.id===element.id);values.push((frame.x-element.x)+' '+(frame.y-element.y));}
   const pattern=new RegExp('<text data-element="'+identifier+'"[^>]*>[\\s\\S]*?</text>');
   result=result.replace(pattern,text=>`<g>${text}<animateTransform attributeName="transform" type="translate" values="${values.join(';')}" keyTimes="${times.map(t=>t/timeline.duration_ms).join(';')}" dur="${timeline.duration_ms/1000}s" calcMode="linear" fill="freeze"/></g>`);
   continue;
  }
  const opening=new RegExp('<'+(element.kind==='rect'?'rect':'image')+' data-element="'+identifier+'"[^>]*>');
  result=result.replace(opening,tag=>{
   const animation=tracks.map(track=>`<animate attributeName="${track.field}" values="${track.keyframes.map(f=>f.value).join(';')}" keyTimes="${track.keyframes.map(f=>f.time_ms/timeline.duration_ms).join(';')}" dur="${timeline.duration_ms/1000}s" calcMode="linear" fill="freeze"/>`).join('');
   return tag.endsWith('/>')?tag.slice(0,-2)+'>'+animation+'</rect>':tag+animation;
  });
 }
 const source=escape(JSON.stringify({schema:'omega-editable-motion-export-1',scene:clone(scene),timeline:clone(timeline),adopted:false}));
 return result.replace('<title>',`<metadata id="omega-editable-motion">${source}</metadata><title>`);
}
