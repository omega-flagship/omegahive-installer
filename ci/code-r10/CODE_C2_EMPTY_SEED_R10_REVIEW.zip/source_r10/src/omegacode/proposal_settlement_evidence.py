"""Local original-run evidence. No host ledger, HTTP schema or authority issuance.

Consumes trusted service-retained run observations in the existing Store. Native
observation/cleanup remain the executor's responsibility, never inferred here.
"""
import datetime, json, math, re
from omegacode.common import CodeError, canonical, digest
from omegacode.proposal_launch_custody import Custody, KIND

TERMINAL = {'completed', 'failed', 'cancelled', 'timed_out', 'output_limit', 'interrupted', 'unknown'}

def fail(code):
    raise CodeError(409, code, 'original settlement evidence refused')

def timestamp(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        fail('observation_time')
    try:
        return datetime.datetime.fromtimestamp(value, datetime.timezone.utc).isoformat().replace('+00:00', 'Z')
    except (ValueError, OverflowError, OSError):
        fail('observation_time')

def executor_receipt(store, run):
    """Only exact original executor receipt bytes can attest a duration."""
    sha = run.get('receipt_digest')
    if sha is None:
        return None
    if type(sha) is not str or not re.fullmatch(r'[a-f0-9]{64}', sha):
        fail('receipt_digest')
    raw = store.read_blob(sha, run['workspace_id'])
    if digest(raw) != sha:
        fail('receipt_digest')
    try:
        receipt = json.loads(raw)
    except (ValueError, UnicodeError):
        fail('executor_receipt')
    if (type(receipt) is not dict or receipt.get('run_id') != run['id']
            or receipt.get('nonce') != run['nonce']
            or receipt.get('status') != run['status']
            or type(receipt.get('descendants_terminated')) is not bool
            or receipt['descendants_terminated'] != run['descendants_terminated']):
        fail('executor_receipt_identity')
    return receipt

def measured(receipt):
    if receipt is None or receipt.get('duration_seconds') is None:
        return {'seconds': None, 'provenance': 'unknown'}
    duration = receipt.get('duration_seconds')
    if type(duration) not in (int, float) or not math.isfinite(duration) or not 0 <= duration <= 86400:
        fail('executor_duration')
    # Receipt rounding can produce 0 for a very short spawned process. Never
    # treat a spawned original as zero, even when the receipt rounded to zero.
    return {'seconds': max(1, math.ceil(duration)), 'provenance': 'executor_measured'}

def capture(store, launch_id, expected_revision):
    """Persist terminal evidence before any future settlement POST; CAS + replay.

    Caller must first reconcile through the actual executor. No caller-provided
    cleanup/duration/outcome flags enter this function. It does not settle a host
    hold, permit another launch or turn unknown into permission to replace it.
    """
    if type(expected_revision) is not int or expected_revision < 1:
        fail('observation_revision')
    with store.transaction():
        custody = Custody(store)
        row = custody.get(launch_id)
        previous = row.get('settlement_evidence')
        if previous is not None and previous['outcome'] != 'unknown':
            return row['settlement_evidence']  # original bytes; no fresh authority
        if row['revision'] != expected_revision:
            fail('observation_revision')
        if not row.get('hold_id'):
            fail('hold_recovery_required')
        if row['state'] == 'not_started' and row['ever_spawning'] is False:
            evidence = {
                'outcome': 'not_started', 'run_id': None,
                'runtime': {'seconds': 0, 'provenance': 'executor_measured'},
                'cleanup': {'descendants_stopped': True, 'observed_at': timestamp(row['created_at'])},
                'evidence': {'launch_record_state': 'never_spawning', 'launch_record_rev': row['revision']},
                'receipt_digest': None,
            }
        else:
            if row['state'] not in ('spawning', 'running', 'unknown', 'ended') or row['ever_spawning'] is not True:
                fail('launch_state')
            run = store.get('run', row['run_id'])
            if (run['id'] != row['run_id'] or run.get('nonce') != row['nonce']
                    or run.get('launch_custody_id') != row['id']):
                fail('original_run_binding')
            if run.get('status') not in TERMINAL:
                fail('run_not_terminal')
            stopped = run.get('descendants_terminated')
            if type(stopped) is not bool:
                fail('cleanup_shape')
            receipt = executor_receipt(store, run)
            known = stopped and receipt is not None and run['status'] != 'unknown'
            if row['state'] == 'ended' and not known:
                fail('terminal_observation_conflict')
            # A helper claim is not a service observation. Unknown executor
            # status cannot become cleanup proof even if a stray flag is true.
            observed_at = timestamp(run.get('observed_at')) if known else None
            outcome = run['status'] if run['status'] in ('completed', 'failed', 'cancelled') else 'failed'
            if not known:
                outcome = 'unknown'
            runtime = measured(receipt)
            if previous is not None and not known:
                return previous  # unresolved observation cannot reduce liability
            row['state'] = 'ended' if known else 'unknown'
            row['revision'] += 1
            evidence = {
                'outcome': outcome, 'run_id': row['run_id'], 'runtime': runtime,
                'cleanup': {'descendants_stopped': known, 'observed_at': observed_at},
                'evidence': {'launch_record_state': 'ended' if known else 'spawning' if 'pid' not in row else 'running',
                             'launch_record_rev': row['revision']},
                'receipt_digest': 'sha256:' + run['receipt_digest'] if run.get('receipt_digest') else None,
            }
        row['settlement_evidence'] = evidence
        row['settlement_evidence_digest'] = digest(canonical(evidence))
        # For never-spawning closure also retain a revision for this new local
        # evidence; its evidence revision attests the prior never-spawning row.
        if row['state'] == 'not_started':
            row['revision'] += 1
        store.put(KIND, row)
        return evidence

def capture_service(service, launch_id):
    """Use the existing observer and actual service owner before evidence CAS."""
    from omegacode.proposal_launch_result import observe
    service._check_owner(required=True)
    observation = observe(service, launch_id)
    if observation.get('terminal') is not True:
        fail('run_not_terminal')
    row = Custody(service.store).get(launch_id)
    return capture(service.store, launch_id, row['revision'])
