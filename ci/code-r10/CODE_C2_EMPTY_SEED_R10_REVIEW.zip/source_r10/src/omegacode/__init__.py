"""OmegaCode's coding framework. Importing it never launches execution."""

__version__ = "0.1.0"

