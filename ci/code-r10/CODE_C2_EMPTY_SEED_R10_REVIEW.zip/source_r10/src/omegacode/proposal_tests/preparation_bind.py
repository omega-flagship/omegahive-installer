"""Uninstalled service-owned prepare binding. Host is the only binding authority.

No caller body, widened principal, hold, dispatch, source acceptance or retry.
"""
from omegacode.common import canonical, digest, CodeError, stamp
from .retained_preparation import inspect
from .purpose_fork import materialize, KIND
from .proposal_host_wire import test_id, key, pattern, sha, object_, snapshot, equal, fail
BIND = 'proposal_preparation_bind'

def retained(service, authority, principal):
    row = materialize(service, authority, principal)
    plan = inspect(service, authority, principal)
    fork = service.workspace(row['fork_workspace_id'])
    if fork.get('proposal_test_id') != row['id'] or fork['generation'] != 2 or fork['task_id'] != principal.grant['task_id'] or (fork['swarm_id'] != principal.grant['swarm_id']) or (fork['repository_id'] != principal.grant['repository_id']) or (fork['tree_digest'] != plan['test_tree_digest']) or (row['test_tree_digest'] != plan['test_tree_digest']) or (row['preparation_digest'] != plan['preparation_digest']) or (service.store.read_blob(row['plan_digest'], fork['id']) != canonical(plan)):
        fail('proposal_bind_custody')
    if service.manifest(fork)['files'] != plan['test_files']:
        fail('proposal_bind_custody')
    for meta in plan['test_files'].values():
        data = service.store.read_blob(meta['digest'], fork['id'])
        if digest(data) != meta['digest'] or len(data) != meta['size']:
            fail('proposal_bind_custody')
    service._check_owner(required=True)
    return (row, fork)

def bind_wire(host, tid, body):
    """Strict r3.2 b.5, service-token transport. Body built internally below."""
    tid = test_id(tid)
    body = snapshot(body)
    if set(body) != {'capability_id', 'operation_id', 'fork_workspace_id', 'proposal', 'parent', 'test_tree_digest', 'preparation_digest'}:
        fail()
    pattern(body['capability_id'], 'cap_[A-Za-z0-9_-]+')
    key(body['operation_id'])
    pattern(body['fork_workspace_id'], 'ws_[0-9a-f]{32}')
    proposal = object_(body['proposal'])
    parent = object_(body['parent'])
    if set(proposal) != {'proposal_id', 'proposal_digest', 'normalized_hunks_digest'} or set(parent) != {'workspace_id', 'generation', 'tree_digest'}:
        fail()
    pattern(proposal['proposal_id'], 'suggestion_[0-9a-f]{32}')
    pattern(parent['workspace_id'], 'ws_[0-9a-f]{32}')
    if type(parent['generation']) is not int or parent['generation'] < 1:
        fail()
    for value in [proposal['proposal_digest'], proposal['normalized_hunks_digest'], parent['tree_digest'], body['test_tree_digest'], body['preparation_digest']]:
        sha(value)
    answer = host._call('POST', f'/api/services/proposal-tests/{tid}/preparation', body, expected=201)
    if set(answer) != {'test_id', 'fork_workspace_id', 'test_tree_digest', 'preparation_digest', 'bound_at'}:
        fail()
    if answer['test_id'] != tid or any((answer[n] != body[n] for n in ['fork_workspace_id', 'test_tree_digest', 'preparation_digest'])):
        fail('proposal_host_binding')
    pattern(answer['bound_at'], '\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?Z')
    return snapshot(answer)

def bind(service, authority, principal, host):
    service._check_owner(required=True)
    g = principal.grant
    p = g['proposal_test']
    tid = p['test_id']
    with service.store.lock:
        existing = next((r for r in service.store.list(BIND) if r['id'] == tid), None)
    if existing:
        if g['id'] != existing['body']['capability_id'] or p['stage'] != 'prepare' or p['proposal'] != existing['body']['proposal'] or (p['parent'] != existing['body']['parent']):
            fail('proposal_bind_conflict')
        return recover(service, host, tid)
    with service.store.lock:
        (row, fork) = retained(service, authority, principal)
        with service.store.transaction():
            g = principal.grant
            p = g['proposal_test']
            body = dict(capability_id=g['id'], operation_id='prepare-' + row['id'], fork_workspace_id=fork['id'], proposal=p['proposal'], parent=p['parent'], test_tree_digest='sha256:' + row['test_tree_digest'], preparation_digest='sha256:' + row['preparation_digest'])
            body = snapshot(body)
            fingerprint = digest(canonical(body))
            found = next((r for r in service.store.list(BIND) if r['id'] == row['id']), None)
            if found and found['fingerprint'] != fingerprint:
                fail('proposal_bind_conflict')
            if not found:
                found = dict(id=row['id'], body=body, fingerprint=fingerprint, state='pending', ack=None, created_at=stamp())
                service.store.put(BIND, found)
            claim = canonical(g)
    answer = bind_wire(host, row['id'], body)
    with service.store.transaction():
        service._check_owner(required=True)
        if canonical(g) != claim or service.store.get(KIND, row['id']) != row or service.workspace(fork['id']) != fork or (service.store.get(BIND, row['id']) != found):
            fail('proposal_bind_custody')
        if found['ack'] is not None and (not equal(found['ack'], answer)):
            fail('proposal_host_binding')
        found.update(state='acknowledged', ack=answer)
        service.store.put(BIND, found)
    return dict(test_id=row['id'], ack=answer, launch_authority=False, accepted_source=False)

def recover(service, host, tid):
    """Service-owner-only original recovery; never expose as caller authority.

 No claim issuance/liveness is used to recover an already retained effect.
 Host enforces current service auth and original capability-to-test ownership.
 Future outward result routes must separately authorize their recipient.
 """
    tid = test_id(tid)
    service._check_owner(required=True)
    with service.store.lock:
        original = service.store.get(BIND, tid)
        body = snapshot(original['body'])
        if original['id'] != tid or original['fingerprint'] != digest(canonical(body)):
            fail('proposal_bind_custody')
    answer = bind_wire(host, tid, body)
    with service.store.transaction():
        service._check_owner(required=True)
        if service.store.get(BIND, tid) != original:
            fail('proposal_bind_custody')
        if original['ack'] is not None and (not equal(original['ack'], answer)):
            fail('proposal_host_binding')
        original.update(state='acknowledged', ack=answer)
        service.store.put(BIND, original)
    return dict(test_id=tid, ack=answer, launch_authority=False, accepted_source=False)
