import {sourceRelations} from './source-relations.mjs';
import {briefPlan} from './brief-plan.mjs';
import {steerSource} from './source-steering.mjs';
// Headless counterpart to the local canvas. Caller must supply host authority.
import fs from 'node:fs/promises';
import {renderUI} from './ui-spec.mjs';
import {initial,apply,digest,svg,canonical} from './scene.mjs';
import {createProject,proposeDirection,reuseIdentity,selectDirection,verifyProject,relations} from './project.mjs';
import {verifySource,mergeSources,retainedFeedback,feedbackScope} from './source.mjs';
const read=async path=>JSON.parse(await fs.readFile(path,'utf8'));
async function source(path){return verifySource(await read(path));}
async function write(path,body){await fs.writeFile(path,body,{flag:'wx'});}
try{
 const [command,input,arg,output]=process.argv.slice(2);let s,target;
 if(command==='react'){
  if((await fs.stat(input)).size>512*1024)throw Error('React handoff input exceeds 512 KB');
  const request=await read(input);
  if(request?.schema!=='omega-react-handoff-request-1')throw Error('Invalid React handoff request');
  const {reactHandoff}=await import('./react-handoff.mjs');
  const files=reactHandoff(request.ui,request.component_library??null);
  const source_digest=await digest(request);
  await write(arg,JSON.stringify({schema:'omega-react-handoff-1',source_digest,files,editable:true,adopted:false},null,2)+'\n');
  console.log(JSON.stringify({output:arg,source_digest,editable:true,adopted:false}));process.exit(0);
 }
 if(command==='ui'){await write(arg,renderUI(await read(input)));console.log(JSON.stringify({output:arg,editable:true,adopted:false}));process.exit(0);}
 if(command==='init'){
  const {scene,brief}=await read(input);s={schema:'omega-studio-source-1',current:await initial(scene),project:await createProject(brief),history:[],feedback:[]};
  if(canonical(scene.criteria)!==canonical(brief.criteria))throw Error('Scene and brief criteria differ');s.history=[s.current];target=arg;
 }else{
  s=await source(input);
  if(command==='inspect'){console.log(JSON.stringify({reference:{scene_id:s.current.scene.id,revision:s.current.revision,digest:s.current.digest},elements:s.current.scene.elements,criteria:s.current.scene.criteria,directions:s.project.directions.map(d=>({id:d.id,label:d.label,scene_digest:d.scene_digest,identity:d.identity,derivation:d.derivation??null})),selection:s.project.selection,source_digest:await digest(s),brief_change:s.brief_change?{reason:s.brief_change.transition.reason,delta:s.brief_change.transition.delta,prior_source_digest:s.brief_change.source_digest,assessment:'reassessment-required',work_plan:briefPlan(s.brief_change.transition)}:null,feedback:retainedFeedback(s).map(note=>({note,scope:feedbackScope(note,s)})),adopted:false}));process.exit(0);}
  if(command==='svg'){await write(arg,svg(s.current.scene));console.log(JSON.stringify({output:arg,source_digest:s.current.digest,editable:true}));process.exit(0);}
  const request=await read(arg);
  if(command==='steer'){if(request.expected_source_digest!==await digest(s))throw Error('Steering source digest differs');s=await steerSource(s,request.brief,request.reason);}
  else if(command==='merge'){const result=await mergeSources(s,request);if(result.status==='conflict')throw Error('Merge conflicts: '+JSON.stringify(result.conflicts));s=result.source;}
  else if(command==='revise'){s.current=await apply(s.current,request.expected_digest,request.changes);s.history.push(s.current);}
  else if(command==='direction'){s.project=await proposeDirection(s.project,request);}
  else if(command==='reuse-identity'){s.project=await reuseIdentity(s.project,request);}
  else if(command==='select'){s.project=await selectDirection(s.project,request.direction_id,request.reason);s.current=await initial(s.project.directions.find(d=>d.id===request.direction_id).scene);s.history=[s.current];}
  else throw Error('Commands: init, inspect, revise, direction, reuse-identity, select, steer, merge, svg, ui, react');
  target=output;
 }
 s.derived_relations=sourceRelations(s.project,s.brief_change);await verifySource(s);await write(target,JSON.stringify(s,null,2)+'\n');console.log(JSON.stringify({output:target,revision:s.current.revision,digest:s.current.digest,direction_count:s.project.directions.length,adopted:false}));
}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}
