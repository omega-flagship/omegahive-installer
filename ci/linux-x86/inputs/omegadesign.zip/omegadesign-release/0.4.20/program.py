"""Self-contained Design semantic-hook candidate. No side effects.

Uses host validation_context and artifact_revision APIs. Missing records refuse
completion; no worker-supplied witness is accepted.
"""
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys

folder = Path(__file__).parent
key = hashlib.sha256(b''.join(p.name.encode() + b'\0' + p.read_bytes()
                             for p in sorted(folder.glob('*.py')))).hexdigest()
name = '_omegadesign_bundle_' + key
if name not in sys.modules:
    spec = importlib.util.spec_from_file_location(name, folder / '__init__.py',
                                                  submodule_search_locations=[str(folder)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
check = importlib.import_module(name + '.semantics').validate_creative_completion


def describe():
    return {'contract': '0.1', 'kinds': [{'id': 'status', 'label': 'Creative validation',
                                        'role': 'assessment'}], 'relations': [], 'actions': [{'id':op,'label':'Studio '+op,'agents':op!='save-source','person_activity':op=='save-source','effect':'write','binding_params':['goal_id','source','incoming_source'],'revalidate':True,**({'params':{'editable_source_json':'JSON string containing the editable Studio, deck or Model source; exactly one of editable_source_json and editable_source is required','editable_source':'Legacy structured editable source object; exactly one of editable_source and editable_source_json is required','source':'Exact loaded artifact revision reference, or null for a new editable source'}} if op=='save-source' else {})} for op in importlib.import_module(name+'.studio_actions').OPERATIONS+('save-source','motion')+importlib.import_module(name+'.model_actions').OPERATIONS]}


async def view(ctx, focus=None, stage=None):
    if isinstance(focus,str) and focus.startswith("studio-navigation:"):return await importlib.import_module(name+".navigation_actions").view_navigation(ctx,focus)
    if isinstance(focus,str) and focus.startswith('studio-proposals:'):
        return importlib.import_module(name+'.proposal_io').view_proposals(ctx,focus)
    if isinstance(focus,str) and focus.startswith('studio-source:'):
        return importlib.import_module(name+'.source_io').view_source(ctx,focus)
    return {'revision': 'semantic-candidate-v1', 'items': [{'id': 'design-status',
            'kind': 'status', 'label': 'Creative semantic validator candidate; host revision context required'}],
            'links': [], 'focus': 'design-status'}


async def act(ctx, action, items, params=None, base_revision=None):
    if action in importlib.import_module(name+'.model_actions').OPERATIONS:
        if items or base_revision is not None:raise ValueError('Model actions bind exact source in params, not selected item/base overrides')
        return await importlib.import_module(name+'.model_actions').act_model(ctx,action,params)
    if action=='motion':return await importlib.import_module(name+'.motion_actions').act_motion(ctx,params)
    if action=='save-source':return await importlib.import_module(name+'.source_io').save_source(ctx,params)
    return await importlib.import_module(name+'.studio_actions').act(ctx,action,params)


def validate_result(ctx, goal, proposal):
    resolver = getattr(ctx, 'validation_context', None)
    if not callable(resolver):
        return {'errors': ['design_host_context_unavailable']}
    try:
        context = resolver(goal)
        if not isinstance(context, dict) or context.get('goal') != goal:
            return {'errors': ['design_host_goal_mismatch']}
        request = context.get('request')
        if not isinstance(request, dict) or context.get('request_state') not in {'queued', 'working', 'needs-approval'}:
            return {'errors': ['design_host_request_inactive']}
        reader = getattr(ctx, 'artifact_revision', None)
        if not callable(reader):
            return {'errors': ['design_host_revision_context_unavailable']}
        # The proposal selects a reference, but only the host supplies its bytes.
        if not isinstance(proposal, dict) or type(proposal.get('revision')) is not int or proposal['revision'] < 1:
            return {'errors': ['design_proposal_reference_invalid']}
        stored = reader(proposal.get('artifact_id'), proposal['revision'])
        if not isinstance(stored, dict):
            return {'errors': ['design_host_revision_unavailable']}
        artifact = {'id': stored.get('artifact_id'), 'owner_swarm': stored.get('owner_swarm')}
        revision = {**stored, 'n': stored.get('revision')}
        # C39 stores detail on the receiving goal, not on the request record.
        # The pure check binds its canonical digest to request.constraints.
        brief = json.loads(goal['detail'])
        return check(brief, request, goal, proposal, revision, artifact)
    except (ValueError, TypeError, KeyError, AttributeError):
        return {'errors': ['design_host_context_invalid']}


async def validate_finding_target(ctx, artifact_revision, target):
    """r2.10: host request binding selects this hook; reviewer context is read-only."""
    return await importlib.import_module(name + '.finding_targets').validate_bound_target(ctx, artifact_revision, target)


def _attachment_admin(ctx):
    """Trusted internal hook context; the host owns identity and every grant."""
    actor = getattr(ctx, 'actor', None)
    principal = actor.get('principal') if isinstance(actor, dict) else None
    if (not isinstance(principal, str) or not principal.startswith('user:')
            or principal in {'user:', 'user:operator'} or actor.get('kind') != 'person'
            or actor.get('role') != 'admin' or actor.get('local_operator') is not False):
        raise PermissionError('Named signed-in admin attachment context required')


def _attachment_mind(ctx, mind):
    _attachment_admin(ctx)
    if (not isinstance(mind, dict) or set(mind) != {'id', 'swarm_id'}
            or not isinstance(mind.get('id'), str) or not mind['id'].startswith('a_')
            or not 3 <= len(mind['id']) <= 120 or not mind.get('swarm_id')
            or mind['swarm_id'] != getattr(ctx, 'swarm_id', None)):
        raise PermissionError('Existing host-resolved mind in this swarm required')
    return 'agent:' + mind['id']


def _attachment_operation(ctx, attachment_id):
    _attachment_admin(ctx)
    command = getattr(ctx, 'command', None)
    if (not isinstance(attachment_id, str) or not attachment_id.startswith('at_')
            or not 4 <= len(attachment_id) <= 120 or not isinstance(command, dict)
            or command.get('idempotency_key') != attachment_id):
        raise PermissionError('Exact host attachment operation required')


def offer(ctx, mind):
    """No channels or extra actions: Studio uses already authorized source refs."""
    _attachment_mind(ctx, mind)
    return {'actions_offered': [a['id'] for a in describe()['actions'] if a.get('agents') is True],
            'channels_offered': []}


def bind(ctx, mind, scope, attachment_id):
    """Pure/idempotent binding; native ProgramAttachments stores the authority."""
    _attachment_operation(ctx, attachment_id)
    actor = _attachment_mind(ctx, mind)
    offered = offer(ctx, mind)['actions_offered']
    if not isinstance(scope, dict) or set(scope) != {'actions', 'channels'}:
        raise PermissionError('Exact reviewed action scope required')
    actions, channels = scope['actions'], scope['channels']
    if (not isinstance(actions, list) or not actions
            or any(not isinstance(a, str) or a not in offered for a in actions)
            or len(actions) != len(set(actions)) or channels not in (None, [])):
        raise PermissionError('Only offered Studio actions and no channels may be attached')
    return {'actor': actor}


def unbind(ctx, attachment, attachment_id):
    """No app-local grant/resources to remove; never erase retained creations."""
    _attachment_operation(ctx, attachment_id)
    if (not isinstance(attachment, dict) or attachment.get('id') != attachment_id
            or attachment.get('program') != 'omegadesign'
            or attachment.get('swarm_id') != getattr(ctx, 'swarm_id', None)):
        raise PermissionError('Exact host attachment identity required')
    actor = _attachment_mind(ctx, {'id': attachment.get('mind_id'),
                                   'swarm_id': attachment.get('swarm_id')})
    # A host grant commit may have failed before recording the actor. Cleanup
    # remains safe because bind created no app-local authority or side effect.
    if attachment.get('actor') not in (None, actor):
        raise PermissionError('Host attachment actor differs')
    return {'state': 'unbound'}
