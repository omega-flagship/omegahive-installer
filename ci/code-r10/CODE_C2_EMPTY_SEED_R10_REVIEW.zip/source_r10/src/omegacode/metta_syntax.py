"""Non-evaluating, bounded common MeTTa delimiter scan. Not a runtime parser or type checker."""

def scan(source, limit=100):
    issues, stack = [], []
    mode, escaped, atom = 'code', False, False
    line, column, offset = 1, 1, 0
    string_start = None
    def report(start, code, message):
        if len(issues) < limit:
            issues.append(dict(line=start[0], column=start[1], offset_utf16=start[2], code=code, message=message, severity='warning'))
    if len(source.encode('utf-16-le')) > 2000000:
        return dict(profile='metta-common-delimiters-v1', diagnostics=[dict(line=1, column=1, offset_utf16=0, code='scan-limit', message='Delimiter scan skipped: source exceeds 1,000,000 UTF-16 units', severity='warning')], limit=limit, truncated=True, evaluated=False, semantic_validation=False)
    for ch in source:
        position = (line, column, offset)
        if mode == 'comment':
            if ch in '\r\n': mode, atom = 'code', False
        elif mode == 'string':
            if escaped: escaped = False
            elif ch == '\\': escaped = True
            elif ch == '"': mode, atom = 'code', False
        elif ch == ';': mode, atom = 'comment', False
        elif ch.isspace(): atom = False
        elif ch == '"' and not atom: mode, string_start = 'string', position
        elif ch == '(':
            if len(stack) >= 4096:
                report(position, 'scan-limit', 'Delimiter scan stopped: nesting exceeds 4,096')
                return dict(profile='metta-common-delimiters-v1', diagnostics=issues, limit=limit, truncated=True, evaluated=False, semantic_validation=False)
            stack.append(position); atom = False
        elif ch == ')':
            if stack: stack.pop()
            else: report(position, 'unmatched-close', 'Closing parenthesis has no opening parenthesis')
            atom = False
        else: atom = True
        offset += 2 if ord(ch) > 0xffff else 1
        if ch == '\n': line, column = line + 1, 1
        else: column += 1
    if mode == 'string': report(string_start, 'unterminated-string', 'Quoted string has no closing quote')
    for position in stack: report(position, 'unclosed-open', 'Opening parenthesis has no closing parenthesis')
    return dict(profile='metta-common-delimiters-v1', diagnostics=issues, limit=limit,
                truncated=len(issues) >= limit, evaluated=False, semantic_validation=False)
