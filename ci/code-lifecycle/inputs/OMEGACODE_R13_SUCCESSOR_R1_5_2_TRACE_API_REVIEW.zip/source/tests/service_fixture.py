"""Synthetic retained transcript fixture derived verbatim from the frozen Service r1.1 tests.
Real Service/Store/Authority; no native process or source-repository provenance claim.
"""
import base64
import json
import time
import httpx
from omegacode.common import canonical, digest
from omegacode.service import Service

OPERATOR = 'synthetic-symbolic-service-operator-123456789'

class Fixture:
    """Seeded source metadata/host reports are synthetic; storage and guards are actual."""
    def __init__(self, root):
        self.policy = 'allow'
        self.authorizations = []
        def hive(request):
            if request.method == 'GET' and request.url.path == '/api/agent/goals/task-synthetic':
                return httpx.Response(200, json={'swarm_id': 'swarm-synthetic', 'claimed_by': 'agent:synthetic'})
            if request.method == 'POST' and request.url.path == '/api/agent/authorize':
                self.authorizations.append(json.loads(request.content))
                return httpx.Response(200, json={'decision': self.policy})
            raise AssertionError('unexpected mock-host request: ' + str(request.url))
        self.service = Service(root, OPERATOR, {}, hive_url='https://synthetic-hive.invalid',
                               transport=httpx.MockTransport(hive))
        self.principal = self.person()
        store = self.service.store
        with store.transaction():
            raw = b'private_fixture = 1\n'
            tree = self.service._manifest({'private_fixture.py': {'digest': store.blob(raw, 'ws-synthetic', 'source'),
                'size': len(raw), 'executable': False}}, 'ws-synthetic')
            self.workspace = {'id': 'ws-synthetic', 'task_id': 'task-synthetic', 'swarm_id': 'swarm-synthetic',
                'repository_id': 'repo-synthetic', 'generation': 1, 'tree_digest': tree,
                'base_tree_digest': tree, 'base_commit': 'synthetic-no-git-claim',
                'history': [{'generation': 1, 'tree_digest': tree, 'author': self.principal.actor}]}
            store.put('workspace', self.workspace)
        self.run = {'id': 'run-synthetic', 'workspace_id': self.workspace['id'], 'nonce': 'synthetic-nonce',
            'generation': 1, 'tree_digest': tree, 'terminal': True, 'evaluator_digest': '2' * 64,
            'status': 'completed', 'descendants_terminated': True, 'created_at': time.time(),
            'symbolic_session': {'runtime_id': 'synthetic-hyperon', 'identity_digest': '3' * 64,
                'helper_digest': '4' * 64, 'protocol': 'omegacode-symbolic-jsonl-v1',
                'all_inputs_require_run_authority': True, 'sandboxed': False}}
        context = {'run_id': self.run['id'], 'generation': 1, 'tree_digest': tree,
                   'runtime_identity_digest': '3' * 64, 'runtime': 'hyperon'}
        source = '!(+ 1 1)'
        trace = 'step_' + digest(canonical([context, digest(source.encode()), 1]))
        commands = [{'id': 'q1', 'op': 'step-start', 'source': source, 'max_steps': 8},
                    {'id': 'q2', 'op': 'step-next', 'trace_id': trace}]
        self.controls = [self.control(index, command) for index, command in enumerate(commands, 1)]
        ready = {'event': 'ready', 'protocol': 'omegacode-symbolic-jsonl-v1', 'runtime': 'hyperon',
            'persistence': 'resident process only; no automatic replay', 'atom_count': 0, 'context': context,
            'snapshot_representation': 'rendered-atom-multiset-v1',
            'step_protocol': 'omegacode-hyperon-runner-step-v1',
            'step_commands': ['step-start', 'step-next', 'step-status', 'step-clear']}
        common = {'trace_id': trace, 'source_digest': digest(source.encode()), 'context': context,
            'max_steps': 8, 'engine_api': 'hyperon.runner.RunnerState.run_step',
            'substitutions_available': False, 'grounded_call_trace_available': False,
            'persistence': 'resident process only; no automatic replay', 'effects_reversed': False}
        start = {**common, 'step_count': 0, 'status': 'paused', 'results': [], 'observations': [],
                 'observation_total': 0, 'observation_window_limit': 100, 'observation_dropped_prefix': 0,
                 'observation_coverage': 'complete-history', 'first_retained_input_sequence': None,
                 'first_retained_step': None, 'results_currency': 'not yet observed', 'last_observed_step': 0}
        observation = {'input_sequence': 2, 'step_count': 1, 'status': 'complete',
            'results_digest': digest(canonical([['2']])), 'rendered_atoms_digest': digest(canonical([]))}
        complete = {**common, 'step_count': 1, 'status': 'complete', 'results': [['2']],
            'observations': [observation], 'observation_total': 1, 'observation_window_limit': 100,
            'observation_dropped_prefix': 0, 'observation_coverage': 'complete-history',
            'first_retained_input_sequence': 2, 'first_retained_step': 1,
            'results_currency': 'last successful step batch', 'last_observed_step': 1}
        frames = [ready, {'event': 'result', 'id': 'q1', 'op': 'step-start', 'result': start,
                          'atom_count': 0, 'input_sequence': 1},
                  {'event': 'result', 'id': 'q2', 'op': 'step-next', 'result': complete,
                   'atom_count': 0, 'input_sequence': 2}]
        self.output = b''.join(canonical(frame) + b'\n' for frame in frames)
        self.receipt = {'nonce': self.run['nonce'], 'run_id': self.run['id'], 'status': 'completed',
            'terminal': True, 'descendants_terminated': True, 'output_bytes': len(self.output),
            'terminal_controls': [{key: row[key] for key in
                ('id', 'sequence', 'kind', 'input_bytes', 'input_digest', 'actor')} for row in self.controls]}
        self.retain()

    def person(self, **changes):
        config = dict(actor='person:synthetic', kind='human', task_id='task-synthetic',
            swarm_id='swarm-synthetic', repository_id='repo-synthetic', actions=['read', 'events', 'edit'])
        config.update(changes)
        issued = self.service.authority.issue(**config)
        return self.service.authority.authenticate(issued['token'], config.get('member_token'))

    def control(self, sequence, command):
        data = canonical(command) + b'\n'
        return {'id': 'tc-synthetic-' + str(sequence), 'run_id': self.run['id'],
            'workspace_id': self.workspace['id'], 'sequence': sequence, 'actor': self.principal.actor,
            'kind': 'input', 'input_bytes': len(data), 'input_digest': digest(data), 'status': 'queued',
            'created_at': 1.0, 'payload': {'operation_id': 'synthetic-control-' + str(sequence),
                                        'kind': 'input', 'data_base64': base64.b64encode(data).decode()}}

    def retain(self):
        with self.service.store.transaction():
            self.run['output_digest'] = self.service.store.blob(self.output, self.workspace['id'], 'run-output')
            self.run['receipt_digest'] = self.service.store.blob(canonical(self.receipt), self.workspace['id'], 'run-receipt')
            self.service.store.put('run', self.run)
            for control in reversed(self.controls):  # Physical insertion order must not control protocol order.
                self.service.store.put('terminal_control', control)

    def inspect(self, **kwargs):
        return self.service.symbolic_trace_result(self.principal, self.run['id'], **kwargs)

    def mutate_run(self, **changes):
        self.run.update(changes)
        with self.service.store.transaction():
            self.service.store.put('run', self.run)

    def edit_source(self):
        ws = self.service.workspace(self.workspace['id'])
        prior = self.service.manifest(ws)['files']['private_fixture.py']['digest']
        return self.service.edit(self.principal, ws['id'], {'operation_id': 'synthetic-real-edit',
            'expected_generation': ws['generation'], 'expected_tree_digest': ws['tree_digest'],
            'edits': [{'path': 'private_fixture.py', 'expected_digest': prior, 'content': 'private_fixture = 2\n'}]})
