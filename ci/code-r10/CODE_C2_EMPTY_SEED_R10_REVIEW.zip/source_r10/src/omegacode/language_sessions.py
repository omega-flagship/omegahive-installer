"""Grant/snapshot-bound language processes with observed cleanup and bounded leases."""
from contextlib import contextmanager
from pathlib import Path
import tempfile
import threading
import time

from .common import CodeError, ident


class LanguageSessions:
    MAX_SESSIONS = 2
    IDLE_SECONDS = 30
    LIFETIME_SECONDS = 120
    MAX_QUERIES = 40

    def __init__(self, root):
        self.root = Path(root)
        self.entries = {}
        self.lock = threading.Condition(threading.RLock())
        self.stop = threading.Event()
        self.watcher = None
        self.closed = False

    def _discard(self, key, entry):
        # Cleanup is attempted once. An unknown process stop retains its slot and
        # scratch for recovery; retrying a reaped process group could target reuse.
        if entry.get('cleanup_error'):
            raise CodeError(503, 'language_cleanup_unknown', 'language session cleanup requires recovery')
        try:
            if entry['state'].get('client'): entry['state']['client'].close()
            entry['temporary'].cleanup()
        except Exception as error:
            entry.update(invalid=True, cleanup_error=type(error).__name__)
            raise CodeError(503, 'language_cleanup_unknown', 'language session cleanup could not be confirmed') from error
        self.entries.pop(key, None)

    def sweep(self):
        with self.lock: entries = list(self.entries.items())
        for key, entry in entries:
            try: entry['validate']()
            except Exception: invalid = True
            else: invalid = False
            with self.lock:
                if self.entries.get(key) is not entry: continue
                now = time.monotonic()
                entry['invalid'] |= invalid or now >= entry['state']['expires'] or now-entry['last_used'] >= self.IDLE_SECONDS
                if not entry['invalid']: continue
                if entry['busy']:
                    if entry['state'].get('client'): entry['state']['client'].deadline = 0
                elif not entry.get('cleanup_error'):
                    try: self._discard(key, entry)
                    except CodeError: pass  # retained invalid slot; never reported stopped

    def _monitor(self):
        while not self.stop.wait(1): self.sweep()

    @contextmanager
    def lease(self, key, scope, validate, materialize):
        with self.lock:
            if self.closed: raise CodeError(503, 'language_closed', 'language session service is closing')
            now = time.monotonic()
            entry = self.entries.get(key)
            reused = entry is not None
            if entry and entry['busy']:
                raise CodeError(429, 'language_busy', 'language session already has an active query')
            if entry and (entry['invalid'] or now >= entry['state']['expires']
                          or now-entry['last_used'] >= self.IDLE_SECONDS or entry['queries'] >= self.MAX_QUERIES):
                self._discard(key, entry)
                entry, reused = None, False
            for old_key, old in list(self.entries.items()):
                if old_key != key and old['scope'] == scope:
                    old['invalid'] = True
                    if old['busy']:
                        if old['state'].get('client'): old['state']['client'].deadline = 0
                        raise CodeError(429, 'language_busy', 'previous snapshot query is stopping')
                    self._discard(old_key, old)
            validate()
            if entry is None:
                if len(self.entries) >= self.MAX_SESSIONS:
                    idle = [(k,e) for k,e in self.entries.items() if not e['busy'] and not e.get('cleanup_error')]
                    if not idle: raise CodeError(429, 'language_busy', 'language session capacity reached')
                    old_key, old = min(idle, key=lambda pair: pair[1]['last_used'])
                    self._discard(old_key, old)
                temporary = tempfile.TemporaryDirectory(prefix='language-session-',dir=self.root)
                root = Path(temporary.name)
                try:
                    for name in ('home','tmp'): (root/name).mkdir(mode=0o700)
                    materialize(root/'tree')
                except Exception:
                    temporary.cleanup()
                    raise
                entry = {'temporary':temporary,'root':root,'scope':scope,'validate':validate,
                         'state':{'expires':now+self.LIFETIME_SECONDS},'id':ident('ls'),
                         'busy':False,'invalid':False,'queries':0,'last_used':now}
                self.entries[key] = entry
            entry.update(busy=True, last_used=now)
            entry['queries'] += 1
            if self.watcher is None:
                self.watcher = threading.Thread(target=self._monitor,name='omegacode-language-sessions',daemon=True)
                self.watcher.start()
        failed = False
        try:
            yield entry, reused
            validate()
            if entry['invalid']: raise CodeError(409, 'language_session_expired', 'language session was invalidated')
        except BaseException:
            failed = True
            raise
        finally:
            with self.lock:
                entry.update(busy=False,last_used=time.monotonic())
                if failed or entry['invalid'] or entry['queries'] >= self.MAX_QUERIES:
                    self._discard(key, entry)
                self.lock.notify_all()

    def close(self):
        self.stop.set()
        with self.lock:
            self.closed = True
            for entry in self.entries.values():
                entry['invalid'] = True
                if entry['state'].get('client'): entry['state']['client'].deadline = 0
            deadline = time.monotonic()+10
            while any(e['busy'] for e in self.entries.values()) and time.monotonic() < deadline:
                self.lock.wait(.05)
            if any(e['busy'] for e in self.entries.values()):
                raise CodeError(503, 'language_cleanup_unknown', 'active language query did not stop')
            for key, entry in list(self.entries.items()): self._discard(key, entry)
        if self.watcher: self.watcher.join(timeout=5)
        if self.watcher and self.watcher.is_alive():
            raise CodeError(503, 'language_cleanup_unknown', 'language session monitor did not stop')
