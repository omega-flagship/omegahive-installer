// Native parametric operations; host actor/source access is decided outside this module.
import {canonical,digest} from './scene.mjs';
import {MODEL_LIMITS,modelRevision,sourceText,readModelSource} from './model-source.mjs';
export const MODEL_ACTIONS=Object.freeze(['model-init','model-inspect','model-revise','model-glb']);
const plain=value=>value&&Object.getPrototypeOf(value)===Object.prototype;
const keys=(value,names)=>plain(value)&&Object.keys(value).sort().join(',')===names.slice().sort().join(',');
const hash=value=>typeof value==='string'&&/^sha256:[a-f0-9]{64}$/.test(value);
const id=value=>typeof value==='string'&&/^[A-Za-z][A-Za-z0-9_-]{0,79}$/.test(value);
const size=value=>new TextEncoder().encode(typeof value==='string'?value:JSON.stringify(value)).byteLength;
export async function initializeModel(request,arguments_){
 if(!keys(request,['schema','brief','document'])||request.schema!=='omega-model-init-request-1'||!plain(request.brief)||!plain(request.document)||!plain(request.document.metadata)||Object.hasOwn(request.document.metadata,'creative_work'))throw Error('Retained Model init request required');
 if(!keys(arguments_,['creative_work']))throw Error('Native creative context required');
 const record=arguments_.creative_work;
 if(!keys(record,['schema','brief_json','brief_digest','request_source'])||record.schema!=='omega-model-creative-work-1'||typeof record.brief_json!=='string'||!hash(record.brief_digest)||!keys(record.request_source,['artifact_id','revision','digest'])||typeof record.request_source.artifact_id!=='string'||!/^\w[\w-]{0,127}$/.test(record.request_source.artifact_id)||!Number.isSafeInteger(record.request_source.revision)||record.request_source.revision<1||!hash(record.request_source.digest)||canonical(JSON.parse(record.brief_json))!==canonical(request.brief))throw Error('Exact retained creative brief required');
 const document=structuredClone(request.document);document.metadata.creative_work=structuredClone(record);
 return modelRevision(document);
}
export async function inspectModel(source,arguments_={}){
 if(!plain(arguments_)||Object.keys(arguments_).some(name=>!['offset','limit'].includes(name)))throw Error('Model inspection paging fields only');
 const offset=arguments_.offset??0,limit=arguments_.limit??20;
 if(!Number.isInteger(offset)||offset<0||offset>MODEL_LIMITS.objects||!Number.isInteger(limit)||limit<1||limit>20)throw Error('Bounded Model object page required');
 const revision=await readModelSource(source),document=revision.document;
 const answer={schema:'omega-model-action-inspection-1',model_id:document.id,model_digest:revision.digest,metadata_digest:await digest(document.metadata),units:document.units,title:document.title,background:document.background,object_count:document.objects.length,offset,limit,objects:structuredClone(document.objects.slice(offset,offset+limit)),creative_brief_digest:document.metadata.creative_work?.brief_digest??null,adopted:false};
 if(size(answer)>64*1024)throw Error('Model inspection exceeds 64 KiB');return answer;
}
export async function reviseModel(source,arguments_){
 arguments_=structuredClone(arguments_); // Snapshot owned request before the native digest await.
 const revision=await readModelSource(source);
 if(!keys(arguments_,['expected_digest','changes'])||!hash(arguments_.expected_digest)||arguments_.expected_digest!==revision.digest||!Array.isArray(arguments_.changes)||!arguments_.changes.length||arguments_.changes.length>100)throw Error('Exact Model change batch required');
 const document=structuredClone(revision.document),seen=new Set(),fields=['name','geometry','position','rotation','scale','material'];
 for(const change of arguments_.changes){
  if(!plain(change)||!id(change.id)||seen.has(change.id))throw Error('Unique stable Model change target required');seen.add(change.id);
  const index=document.objects.findIndex(object=>object.id===change.id);
  if(change.op==='add-object'){
   if(!keys(change,['op','id','absent','value'])||change.absent!==true||index!==-1||!plain(change.value)||change.value.id!==change.id)throw Error('Model add absence differs');
   document.objects.push(structuredClone(change.value));
  }else if(change.op==='set-object'){
   if(!keys(change,['op','id','prior','value'])||index<0||!plain(change.prior)||!plain(change.value))throw Error('Existing Model object fields required');
   const names=Object.keys(change.prior);
   if(!names.length||names.some(name=>!fields.includes(name))||names.slice().sort().join(',')!==Object.keys(change.value).sort().join(','))throw Error('Exact Model field set required');
   for(const name of names)if(canonical(document.objects[index][name])!==canonical(change.prior[name]))throw Error('Model field prior differs');
   for(const name of names)document.objects[index][name]=structuredClone(change.value[name]);
  }else if(change.op==='remove-object'){
   if(!keys(change,['op','id','prior'])||index<0||canonical(document.objects[index])!==canonical(change.prior))throw Error('Model removal prior differs');
   document.objects.splice(index,1);
  }else throw Error('Unsupported Model operation');
 }
 const next=await modelRevision(document);
 if(next.document.id!==revision.document.id||next.document.units!==revision.document.units||canonical(next.document.metadata)!==canonical(revision.document.metadata))throw Error('Model identity or criteria changed');
 sourceText(next);return next;
}
