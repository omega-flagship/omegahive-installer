"""Owned never-spawning closure; host holds remain liabilities until settled."""
import json, time
from omegacode.common import canonical, digest, stamp
from omegacode.proposal_launch_custody import Custody
from .proposal_host_wire import key, launch_binding, fail
from .launch_admission import scope_binding

def original(service, g, id_):
    row = Custody(service.store).get(id_)
    p = g['proposal_test']
    tid = p['test_id']
    saved = service.store.get('proposal_preparation', tid)
    bound = service.store.get('proposal_preparation_bind', tid)
    if row['test_id'] != tid or saved['binding'] != scope_binding(g) or bound['state'] != 'acknowledged' or (bound['fingerprint'] != digest(canonical(bound['body']))) or (bound['body']['fork_workspace_id'] != saved['fork_workspace_id']) or (bound['body']['preparation_digest'] != 'sha256:' + saved['preparation_digest']):
        fail('purpose_cancel_binding')
    raw = service.store.db.execute('SELECT body FROM grants WHERE id=?', (bound['body']['capability_id'],)).fetchone()
    if raw is None:
        fail('purpose_cancel_original')
    prepare = json.loads(raw[0])
    if scope_binding(prepare) != scope_binding(g) or (p.get('origin_grant_id') if p['stage'] == 'result' else g.get('grant_id')) != prepare.get('grant_id'):
        fail('purpose_cancel_origin_grant')
    for (name, value) in launch_binding(g).items():
        if name == 'fork' and p['stage'] == 'result' and (value['workspace_id'] is None):
            continue
        if row['binding'].get(name) != value:
            fail('purpose_cancel_binding')
    if row['binding']['fork'] != dict(workspace_id=saved['fork_workspace_id'], preparation_digest='sha256:' + saved['preparation_digest']):
        fail('purpose_cancel_binding')
    payload = {n: row[n] for n in ['test_id', 'launch_key', 'binding', 'argv', 'runtime_seconds']}
    if row['id'] != 'pl_' + digest(canonical([tid, row['launch_key']])) or row['fingerprint'] != digest(canonical(payload)) or row['spawn_marker'] != str(service.store.root / 'runs' / row['run_id']):
        fail('purpose_cancel_original')
    if row['ever_spawning'] is not False or row['state'] not in ('requested', 'admitted', 'not_started') or any((r['id'] == row['run_id'] for r in service.store.list('run'))) or any((r['id'] == id_ for r in service.store.list('proposal_dispatch_binding'))):
        fail('purpose_cancel_dispatch_unresolved')
    return (row, saved, bound, raw[0])

def cancel(service, authority, principal, host, launch_key, operation_id):
    key(launch_key)
    key(operation_id)
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    tid = g['proposal_test']['test_id']
    path = '/v1/proposal-tests/' + tid + '/launches/' + launch_key + '/cancel'
    authority.require_route(principal, 'POST', path)
    id_ = 'pl_' + digest(canonical([tid, launch_key]))
    custody = Custody(service.store)
    with service.store.lock:
        initial = original(service, g, id_)
    (row, saved, bound, raw) = initial
    payload = dict(action='proposal-never-spawning-cancel', test_id=tid, launch_id=id_, run_id=row['run_id'], nonce=row['nonce'], binding=scope_binding(g))
    authority.require_route(principal, 'POST', path)
    with service.store.transaction():
        service._check_owner(required=True)
        if canonical(g) != claims or g['exp'] <= time.time() or original(service, g, id_) != initial:
            fail('purpose_cancel_changed')
        ack = service.store.cached(principal.actor, operation_id, payload)
        if ack is None:
            if row['state'] != 'not_started':
                row.update(state='not_started', reason='own_cancel_never_spawning')
                row = custody._put(row)
            ack = dict(test_id=tid, launch_id=id_, run_id=row['run_id'], nonce=row['nonce'], cancel_requested=True, never_spawning=True, descendants_stopped=False, settled=False, at=stamp())
            service.store.remember(principal.actor, operation_id, payload, ack)
    with service.store.lock:
        closed = original(service, g, id_)
    if closed[0]['hold_id'] is None:
        current = host.lookup(tid, launch_key)
        service._check_owner(required=True)
        with service.store.lock:
            if canonical(g) != claims or original(service, g, id_) != closed:
                fail('purpose_cancel_changed')
            if current is not None:
                custody.attach_hold(id_, host.projection(current, closed[0]))
    with service.store.lock:
        retained = original(service, g, id_)
    authority.require_route(principal, 'POST', path)
    with service.store.lock:
        service._check_owner(required=True)
        if canonical(g) != claims or g['exp'] <= time.time() or original(service, g, id_) != retained:
            fail('purpose_cancel_changed')
    return ack
