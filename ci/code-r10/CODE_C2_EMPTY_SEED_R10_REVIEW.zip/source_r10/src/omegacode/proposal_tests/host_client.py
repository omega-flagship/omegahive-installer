"""Draft r3.5 complete read-shape successor; unchanged signed status/admission."""
from omegacode.proposal_tests.proposal_host_wire import HostClient as PreviousClient, canonical, digest, equal, fail, hold_id, key, launch_binding, test_id
from .settlement_wire import WireError, readback

class HostClient(PreviousClient):

    @staticmethod
    def normalized(validated):
        hold = validated['hold']
        return dict(id=hold['hold_id'], test_id=hold['test_id'], launch_key=hold['launch_key'], argv_digest=hold['argv_digest'], runtime_seconds_max=hold['runtime_seconds_max'], state=hold['state'], wire=validated)

    def parse(self, value, tid, launch_key, hid=None):
        try:
            hold = value['hold']
            validated = readback(value, test_id=tid, hold_id=hid if hid is not None else hold['hold_id'] if hold else None, request_id=hold['request_id'] if hold else None, launch_key=launch_key, argv_digest=hold['argv_digest'] if hold else None, runtime_seconds=hold['runtime_seconds_max'] if hold else None)
            return None if validated is None else self.normalized(validated)
        except (WireError, KeyError, TypeError):
            fail('proposal_host_binding')

    def lookup(self, tid, launch_key):
        tid = test_id(tid)
        launch_key = key(launch_key)
        value = self._call('GET', f'/api/services/proposal-tests/{tid}/holds', params={'launch_key': launch_key})
        return self.parse(value, tid, launch_key)

    def hold(self, tid, hid, launch_key):
        tid = test_id(tid)
        hid = hold_id(hid)
        launch_key = key(launch_key)
        value = self._call('GET', f'/api/services/proposal-tests/{tid}/holds/{hid}')
        row = self.parse(value, tid, launch_key, hid)
        if row is None:
            fail('proposal_host_binding')
        return row

    def projection(self, row, launch):
        try:
            validated = readback(row['wire'], test_id=launch['test_id'], hold_id=launch['hold_id'] or row['id'], request_id=launch['binding']['request_id'], launch_key=launch['launch_key'], argv_digest='sha256:' + digest(canonical(launch['argv'])), runtime_seconds=launch['runtime_seconds'])
            if validated is None or not equal(row, self.normalized(validated)):
                fail('proposal_host_binding')
            if validated['hold']['run_id'] not in (None, launch['run_id']):
                fail('proposal_host_binding')
            return dict(hold_id=row['id'], test_id=row['test_id'], launch_key=row['launch_key'], argv_digest=row['argv_digest'][7:], runtime_seconds=row['runtime_seconds_max'], state=row['state'])
        except (WireError, KeyError, TypeError):
            fail('proposal_host_binding')

    def dispatch_gate(self, verified_claims, launch):
        if verified_claims.get('proposal_test', {}).get('stage') != 'run':
            fail('proposal_host_inactive')
        tid = verified_claims['proposal_test']['test_id']
        if launch['test_id'] != tid or not equal(launch.get('binding'), launch_binding(verified_claims)):
            fail('proposal_host_binding')
        self.status(verified_claims)
        row = self.hold(tid, launch['hold_id'], launch['launch_key'])
        self.projection(row, launch)
        return row['state'] == 'dispatched'
