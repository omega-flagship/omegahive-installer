// Derived data for reasoning; these facts grant no execution or adoption authority.
import {relations} from './project.mjs';
import {briefPlan} from './brief-plan.mjs';
export function sourceRelations(project,change=null){
 const base=relations(project);if(!change)return base;
 const plan=briefPlan(change.transition),scope=change.transition.after.brief_digest;
 const facts=[['BriefTransition',change.transition.before.brief_digest,scope,change.source_digest],['PlanCompletion',scope,'unverified']];
 for(const task of plan.tasks){
  facts.push(['PlanTask',scope,task.id,task.action],['TaskState',scope,task.id,'pending']);
  for(const dependency of task.depends_on)facts.push(['TaskDependency',scope,task.id,dependency]);
  if(task.criterion)facts.push(['TaskObligation',scope,task.id,task.criterion,task.obligation],['PriorResultTransfer',scope,task.id,'false']);
  if(task.authority)facts.push(['DecisionOwner',scope,task.id,task.authority]);
 }
 for(const obligation of plan.retired_obligations)facts.push(['RetiredObligation',scope,obligation]);
 return base+facts.map(([name,...values])=>'('+name+' '+values.map(v=>JSON.stringify(v)).join(' ')+')').join('\n')+'\n';
}
