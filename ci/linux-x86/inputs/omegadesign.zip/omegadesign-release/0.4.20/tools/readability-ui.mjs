import {inspectReadability} from './readability.mjs';
export function renderReadability(node,scene,selected){
 const finding=inspectReadability(scene).find(item=>item.element_id===selected);
 node.hidden=!finding;if(!finding){node.textContent='';return;}
 node.textContent=finding.ratio===null?'Contrast needs visual review: '+finding.reason.replaceAll('-',' ')+'.':finding.status==='low-contrast'?'Low contrast: '+finding.ratio.toFixed(2)+' : 1. Inspect the text and background.':'Solid-colour contrast: '+finding.ratio.toFixed(2)+' : 1. Artwork and glyph detail still need visual review.';
 node.dataset.status=finding.status;
}
