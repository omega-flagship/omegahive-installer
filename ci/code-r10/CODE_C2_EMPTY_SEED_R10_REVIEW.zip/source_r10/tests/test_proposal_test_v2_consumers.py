import copy
import pytest

pytest_plugins=['test_service']

from omegacode.common import digest,canonical,CodeError
from omegacode.proposal_test_preparation import prepare,fork_edit_payload
from omegacode.copy_application import CopyEngine
from test_service import service,principal,workspace


def v2_scenario(service, *, units=None):
    person,_=principal(service)
    parent=workspace(service,person)
    scope=service.create_suggestion_scope(person,parent['id'],{
        'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'v2-scope-test',
        'expected_generation':parent['generation'],'expected_tree_digest':parent['tree_digest'],
        'ranges':{},'create_files':{'src/main.py':{'max_bytes':256}},'max_total_create_bytes':256})
    proposal=service.create_suggestion(person,parent['id'],{
        'schema_marker':'omegacode-suggestion-request-v2','operation_id':'v2-proposal-test',
        'scope_id':scope['id'],'hunks':units or [
            {'kind':'create_text','path':'src/main.py','content':'print("new")\n'}]})
    projection=service.suggestion(person,parent['id'],proposal['id'])
    manifest=service.manifest(parent)
    files={path:service.store.read_blob(row['digest'],parent['id'])
           for path,row in manifest['files'].items()}
    plan=prepare(projection,parent,manifest,files,proposal_id=proposal['id'],proposal_digest=proposal['digest'])
    return person,parent,projection,manifest,files,plan


def test_v2_create_preparation_materializes_absent_path_metadata_and_digest(service):
    person,parent,projection,manifest,files,plan=v2_scenario(service)
    assert plan['proposal_digest']==projection['record']['digest']
    assert plan['accepted_source'] is False and plan['execution_authority']=='none'
    assert plan['test_files']['src/main.py']=={
        'digest':digest(b'print("new")\n'),'size':len(b'print("new")\n'),'executable':False}
    assert 'src/main.py' not in manifest['files']
    assert plan['edits']==[{'path':'src/main.py','expected_digest':None,'content':'print("new")\n'}]
    assert plan['test_tree_digest']==digest(canonical({'files':plan['test_files']}))
    fork={'id':'fork-new','task_id':parent['task_id'],'swarm_id':parent['swarm_id'],
          'repository_id':parent['repository_id'],'generation':1,'tree_digest':parent['tree_digest'],
          'fork_origin':{'workspace_id':parent['id'],'generation':parent['generation'],
                         'tree_digest':parent['tree_digest']}}
    payload=fork_edit_payload(plan,fork,operation_id='materialize-v2-test')
    assert payload['edits']==plan['edits']


def test_v2_copy_application_uses_existing_person_edit_authority_and_effect_owner(service):
    person,parent,projection,manifest,files,plan=v2_scenario(service)
    record=projection['record']
    scope_record=service.store.get('suggestion_scope',record['scope_id'])
    service.copy_effect_policy=lambda binding,edits:{'binding':binding,'classification':'non_deleting'}
    engine=CopyEngine(service,verify_binding=lambda principal,workspace_id,payload: True)
    payload={'operation_id':'copy-v2-create','request_id':'request-v2-create',
        'suggestion_id':record['id'],'suggestion_digest':record['digest'],
        'expected_generation':parent['generation'],'expected_tree_digest':parent['tree_digest'],
        'scope_id':record['scope_id'],'scope_digest':'sha256:'+scope_record['digest']}
    result=engine.apply(person,parent['id'],payload)
    after=service.workspace(parent['id'])
    assert after['generation']==parent['generation']+1
    assert service.store.read_blob(service.manifest(after)['files']['src/main.py']['digest'],parent['id'])==b'print("new")\n'
    receipt=engine.application_receipt(result)
    assert receipt['effect']=='workspace-copy-write'
    assert receipt['suggestion_digest']==record['digest']


def test_v2_copy_application_refuses_unresolved_creation_effect_without_write(service):
    person,parent,projection,manifest,files,plan=v2_scenario(service)
    record=projection['record']; scope_record=service.store.get('suggestion_scope',record['scope_id'])
    service.copy_effect_policy=lambda binding,edits:{'binding':binding,'classification':'unresolved'}
    engine=CopyEngine(service,verify_binding=lambda principal,workspace_id,payload: True)
    payload={'operation_id':'copy-v2-unresolved','request_id':'request-v2-unresolved',
        'suggestion_id':record['id'],'suggestion_digest':record['digest'],
        'expected_generation':parent['generation'],'expected_tree_digest':parent['tree_digest'],
        'scope_id':record['scope_id'],'scope_digest':'sha256:'+scope_record['digest']}
    from omegacode.common import CodeError
    with pytest.raises(CodeError) as error:engine.apply(person,parent['id'],payload)
    assert error.value.code=='copy_effect_unresolved'
    assert service.workspace(parent['id'])==parent
    assert not service.store.list('copy_application')


@pytest.mark.parametrize('mutation',['body','manifest','foreign-existing-path','namespace-alias'])
def test_v2_test_preparation_rejects_tampered_or_occupied_create_binding(service,mutation):
    person,parent,projection,manifest,files,plan=v2_scenario(service)
    projection,manifest,files=copy.deepcopy((projection,manifest,files))
    if mutation=='body':projection['content']['hunks'][0]['content']='altered'
    elif mutation=='manifest':manifest['files']['calculator.py']['size']+=1
    else:
        path='src/main.py' if mutation=='foreign-existing-path' else 'SRC'
        data=b''
        files[path]=data;manifest['files'][path]={'digest':digest(data),'size':0,'executable':False}
        manifest['files']=dict(sorted(manifest['files'].items()))
        parent=copy.deepcopy(parent)
        parent['tree_digest']=digest(canonical(manifest))
        body=projection['content']
        body['binding']['tree_digest']=parent['tree_digest']
        projection['record']['digest']=digest(canonical(body))
        projection['currency']='current'
        with pytest.raises(CodeError):
            prepare(projection,parent,manifest,files,proposal_id=plan['proposal_id'],
                    proposal_digest=projection['record']['digest'])
        return
    with pytest.raises(ValueError):
        prepare(projection,parent,manifest,files,proposal_id=plan['proposal_id'],proposal_digest=plan['proposal_digest'])
