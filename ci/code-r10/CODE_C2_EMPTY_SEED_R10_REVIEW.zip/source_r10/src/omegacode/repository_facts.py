"""Bounded Python syntax facts and conservative module impact, without file authority.

Callers supply already authorized source bytes. Facts describe syntax, not runtime
reachability or complete semantics. No embeddings, evidence IDs or effects occur.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, asdict
import hashlib
import json
import sys
from pathlib import PurePosixPath
from typing import Mapping


def _hash(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


@dataclass(frozen=True, order=True)
class Fact:
    path: str
    line: int
    kind: str
    subject: str
    target: str


@dataclass(frozen=True)
class RepositoryFacts:
    sources: tuple[tuple[str, str], ...]
    facts: tuple[Fact, ...]
    dependencies: tuple[tuple[str, str], ...]  # importing path, imported path
    diagnostics: tuple[tuple[str, str], ...]
    parser: str = 'python-ast-module-facts-v1/python-'+'.'.join(map(str,sys.version_info[:3]))

    @property
    def digest(self) -> str:
        return _hash(json.dumps(asdict(self), sort_keys=True, separators=(',', ':'),
                               ensure_ascii=True).encode())

    def assert_current(self, sources: Mapping[str, bytes]) -> None:
        """Require an exact authorized source census, including additions/deletions."""
        current = tuple(sorted((path, _hash(body)) for path, body in _inputs(sources).items()))
        if current != self.sources:
            raise ValueError('repository facts are stale: source census or bytes changed')

    def dependents(self, changed: set[str]) -> dict:
        if not changed <= {p for p, _ in self.sources}:
            raise ValueError('changed path is outside this source snapshot')
        impacted = set(changed)
        while True:
            expanded = impacted | {caller for caller, target in self.dependencies if target in impacted}
            if expanded == impacted:
                break
            impacted = expanded
        return {'snapshot_digest': self.digest, 'changed': sorted(changed),
                'potentially_affected': sorted(impacted), 'diagnostics': list(self.diagnostics),
                'complete_runtime_impact': False,
                'meaning': 'conservative closure of resolved syntactic module imports only'}


def _inputs(sources: Mapping[str, bytes]) -> dict[str, bytes]:
    if not isinstance(sources, Mapping) or len(sources) > 512:
        raise ValueError('source map exceeds 512 files')
    accepted = {}
    total = 0
    for path, body in sources.items():
        if not isinstance(path, str) or not isinstance(body, bytes):
            raise ValueError('source entries require relative paths and exact bytes')
        p = PurePosixPath(path)
        if (not path or p.is_absolute() or '..' in p.parts or str(p) != path
                or '\\' in path or '\x00' in path or p.suffix != '.py'):
            raise ValueError('invalid Python source path')
        if len(body) > 1024*1024:
            raise ValueError('source exceeds one MiB')
        total += len(body)
        if total > 8*1024*1024:
            raise ValueError('source map exceeds eight MiB')
        accepted[path] = body
    return accepted


def _module(path: str) -> str:
    parts = list(PurePosixPath(path).with_suffix('').parts)
    if parts[-1] == '__init__':
        parts.pop()
    return '.'.join(parts)


def build_repository_facts(sources: Mapping[str, bytes]) -> RepositoryFacts:
    accepted = _inputs(sources)
    modules = {}
    for path in accepted:
        module = _module(path)
        if module in modules:
            raise ValueError('ambiguous module paths in supplied source map')
        modules[module] = path
    facts, dependencies, diagnostics = set(), set(), set()
    for path, body in sorted(accepted.items()):
        module = _module(path)
        try:
            # ast.parse(bytes) respects Python source encoding declarations.
            tree = ast.parse(body, filename=path)
        except (SyntaxError, ValueError, UnicodeError, RecursionError):
            diagnostics.add((path, 'source could not be parsed; syntax facts unavailable'))
            continue
        nodes = list(ast.walk(tree))
        if len(nodes) > 100000:
            raise ValueError('source exceeds syntax node limit')
        for node in nodes:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                facts.add(Fact(path, node.lineno, 'defines_name', module, node.name))
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    target = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    target = ast.unparse(node.func)
                else:
                    diagnostics.add((path, 'computed call target; runtime resolution unavailable'))
                    continue
                facts.add(Fact(path, node.lineno, 'calls_expression', module, target))
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                targets = []
                if isinstance(node, ast.Import):
                    targets = [alias.name for alias in node.names]
                else:
                    base = node.module or ''
                    if node.level:
                        package = module.split('.') if path.endswith('/__init__.py') else module.split('.')[:-1]
                        if node.level > len(package):
                            diagnostics.add((path, 'relative import outside supplied package'))
                            continue
                        base = '.'.join(package[:len(package)-node.level+1] + ([base] if base else []))
                    targets = [base] + [base+'.'+a.name if base else a.name for a in node.names if a.name != '*']
                    if any(a.name == '*' for a in node.names):
                        diagnostics.add((path, 'star import; symbol-level resolution unavailable'))
                resolved = False
                for target in targets:
                    facts.add(Fact(path, node.lineno, 'imports_module_candidate', module, target))
                    if target in modules:
                        resolved = True
                        dependencies.add((path, modules[target]))
                    # Importing a submodule can also execute package initializers.
                    for length in range(1,len(target.split('.'))):
                        parent = modules.get('.'.join(target.split('.')[:length]))
                        if parent and parent.endswith('/__init__.py'):
                            dependencies.add((path,parent))
                if not resolved:
                    diagnostics.add((path, 'import outside supplied source map or unresolved'))
        if any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
               and n.func.id in {'eval', 'exec', '__import__'} for n in nodes):
            diagnostics.add((path, 'dynamic code/import; runtime impact incomplete'))
    return RepositoryFacts(tuple(sorted((p, _hash(b)) for p, b in accepted.items())),
                           tuple(sorted(facts)), tuple(sorted(dependencies)), tuple(sorted(diagnostics)))


def changed_impact(before: RepositoryFacts, after: RepositoryFacts) -> dict:
    """Use both graphs so deletion/rename does not lose prior dependents."""
    old, new = dict(before.sources), dict(after.sources)
    changed = {p for p in old.keys() | new.keys() if old.get(p) != new.get(p)}
    affected = set(changed)
    edges = set(before.dependencies) | set(after.dependencies)
    while True:
        expanded = affected | {caller for caller, target in edges if target in affected}
        if expanded == affected:
            break
        affected = expanded
    return {'before_digest': before.digest, 'after_digest': after.digest,
            'changed': sorted(changed), 'potentially_affected': sorted(affected),
            'diagnostics': sorted(set(before.diagnostics) | set(after.diagnostics)),
            'complete_runtime_impact': False}
