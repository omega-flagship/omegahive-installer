"""Owner-store observation with verified original-helper reattachment; no spawn."""
import json,math,os,pathlib,subprocess
from omegacode.common import CodeError,digest,stamp
from .proposal_launch_custody import Custody,execution_binding
from .runner import birth,group_members

TERMINAL={'completed','failed','timed_out','cancelled','output_limit','interrupted','unknown'}

def running_proof(service,row,run):
    """Point-in-time kernel identity, never authority or an absence proof."""
    root=service.store.root/'runs'/row['run_id']
    try:
        if row['spawn_marker']!=str(root) or run.get('launch_custody_id')!=row['id']:
            return None
        if (root/'launch.json').is_symlink() or (root/'spec.json').is_symlink():return None
        launch=json.loads((root/'launch.json').read_text());spec=json.loads((root/'spec.json').read_text())
        if set(launch)!={'pid','pgid','nonce','birth','at'} or launch['nonce']!=row['nonce']:return None
        for key,value in [('run_id',row['run_id']),('nonce',row['nonce']),('generation',run['generation']),
                          ('tree_digest',run['tree_digest']),('timeout_seconds',run['timeout_seconds'])]:
            if spec.get(key)!=value:return None
        pid=launch['pid']
        if type(pid) is not int or pid<=1 or type(launch['pgid']) is not int or launch['pgid']!=pid:return None
        if run.get('pid') is not None and run['pid']!=pid:return None
        if run.get('pgid') is not None and run['pgid']!=pid:return None
        if type(launch['birth']) is not str or not launch['birth'] or birth(pid)!=launch['birth']:return None
        if run.get('process_birth') and run['process_birth']!=launch['birth']:return None
        if os.getsid(pid)!=pid or os.getpgid(pid)!=pid or pid not in group_members(pid):return None
        command=subprocess.run(['/bin/ps','-p',str(pid),'-o','command='],capture_output=True,text=True,timeout=3,check=True).stdout.strip()
        if not command.endswith(' -m omegacode.runner '+str(root)):return None
        # Re-observe after command inspection; disappearance/PID reuse is unknown.
        if birth(pid)!=launch['birth'] or os.getsid(pid)!=pid or os.getpgid(pid)!=pid:return None
        return {'pid':pid,'pgid':pid,'process_birth':launch['birth'],'marker':str(root),
                'observed_at':stamp(),'scope':'point-in-time original helper identity; no authority or cleanup proof'}
    except (OSError,ValueError,KeyError,TypeError,RuntimeError,subprocess.SubprocessError):return None

def observe(service,launch_id):
    service._check_owner(required=True)
    service.reconcile()
    with service.store.transaction():
        c=Custody(service.store);row=c.get(launch_id)
        if not row['ever_spawning']:
            raise CodeError(409,'observation_no_dispatch','no dispatched original run to observe')
        run=service.store.get('run',row['run_id']);binding=execution_binding(service.store,row)
        if (run['nonce']!=row['nonce'] or run['argv']!=row['argv'] or run['timeout_seconds']!=row['runtime_seconds']
                or run['workspace_id']!=binding['workspace_id'] or run['generation']!=binding['generation']
                or run['tree_digest']!=binding['tree_digest'] or run['grant_id']!=binding['grant_id']
                or run['author']!=binding['actor']):
            raise CodeError(409,'observation_binding','retained original run binding mismatch')
        if run['status'] in ('starting','running','cancel_requested','unknown') and not run.get('receipt_digest'):
            proof=running_proof(service,row,run)
            if proof is not None:
                if row['state']=='ended':raise CodeError(409,'observation_final','ended launch cannot be reactivated')
                row.update(state='running',pid=proof['pid'],process_birth=proof['process_birth'],reattachment=proof)
                c._put(row)
                if run['status'] in ('starting','unknown'):
                    run.update(status='running',pid=proof['pid'],pgid=proof['pgid'],process_birth=proof['process_birth'])
                    service.store.put('run',run)
                return {'launch_id':launch_id,'run_id':run['id'],'terminal':False,'status':run['status'],
                        'process_observation':proof,'authority_renewed':False,'descendants_stopped':False}
            if run['status'] not in TERMINAL:
                row.update(state='unknown',reason='original_helper_unconfirmed');c._put(row)
                return {'launch_id':launch_id,'run_id':run['id'],'terminal':False,'status':'unknown',
                        'authority_renewed':False,'descendants_stopped':False}
        if run['status'] not in TERMINAL:
            return {'launch_id':launch_id,'run_id':run['id'],'terminal':False,'status':run['status']}
        receipt=None
        if run.get('receipt_digest'):
            raw=service.store.read_blob(run['receipt_digest'],run['workspace_id'])
            if digest(raw)!=run['receipt_digest']:raise CodeError(409,'observation_receipt','receipt digest mismatch')
            receipt=json.loads(raw)
            if (receipt.get('run_id')!=run['id'] or receipt.get('nonce')!=run['nonce']
                    or receipt.get('status')!=run['status'] or receipt.get('descendants_terminated')!=run['descendants_terminated']):
                raise CodeError(409,'observation_receipt','receipt identity or terminal result mismatch')
        stopped=bool(receipt and receipt.get('descendants_terminated') is True and run['descendants_terminated'] is True)
        seconds=None;duration=receipt.get('duration_seconds') if receipt else None
        if type(duration) in (int,float) and math.isfinite(duration) and 0<duration<=86400:seconds=math.ceil(duration)
        observation={'launch_id':launch_id,'run_id':run['id'],'hold_id':row['hold_id'],'terminal':True,
            'status':run['status'],'receipt_digest':run.get('receipt_digest'),'output_digest':run.get('output_digest'),
            'descendants_stopped':stopped,'runtime_seconds':seconds,
            'runtime_provenance':'executor_measured' if seconds is not None else 'unknown',
            'reservation_policy':'measured_after_observed_cleanup' if stopped and seconds is not None else 'retain_reserved_max',
            'observed_at':stamp()}
        previous=row.get('observation')
        if previous and all(previous[k]==observation[k] for k in observation if k!='observed_at'):return previous
        if row['state']=='ended':raise CodeError(409,'observation_final','terminal observation cannot be rewritten')
        row.update(state='ended' if stopped and run['status']!='unknown' else 'unknown',observation=observation)
        c._put(row);return observation
