import {apply,canonical,clone,digest,svg,validate} from './scene.mjs';
import {verifySource} from './source.mjs';
import {exactReference} from './app-reference.mjs';

const reference=revision=>({scene_id:revision.scene.id,revision:revision.revision,digest:revision.digest});
const keys=(value,expected)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===expected.sort().join(',');
const boundedString=value=>typeof value==='string'&&value.length>0&&value.length<=128;
function checkedChangeShape(change){
 if(change?.op==='add'){if(!keys(change,['op','element','before','value'])||change.before!==null||!change.value||typeof change.value!=='object'||Array.isArray(change.value)||change.value.id!==change.element)throw Error('Exact absent-element precondition required');return;}
 if(change?.op!=='set'||!keys(change,['op','element','before','patch'])||!change.before||!change.patch||Array.isArray(change.before)||Array.isArray(change.patch)||typeof change.before!=='object'||typeof change.patch!=='object'||!Object.keys(change.patch).length||canonical(Object.keys(change.before).sort())!==canonical(Object.keys(change.patch).sort()))throw Error('Exact before-field preconditions required');
}
function checkedSnapshot(input){
 if(!keys(input,['schema','stream_id','scene_id','goal_id','events'])||input.schema!=='omega-maker-proposals-1'||![input.stream_id,input.scene_id,input.goal_id].every(boundedString)||!Array.isArray(input.events)||!input.events.length||input.events.length>20||new TextEncoder().encode(canonical(input)).length>128*1024)throw Error('Bounded exact proposal snapshot required');
 let prior=null;
 for(const event of input.events){
  if(!keys(event,['stream_id','scene_id','sequence','changes'])||event.stream_id!==input.stream_id||event.scene_id!==input.scene_id||!Number.isSafeInteger(event.sequence)||event.sequence<1||event.sequence>1000||(prior!==null&&event.sequence!==prior+1)||!Array.isArray(event.changes)||!event.changes.length||event.changes.length>20)throw Error('Ordered bounded proposal events required');
  const targets=new Set();for(const change of event.changes){checkedChangeShape(change);if(targets.has(change.element))throw Error('One proposal per element per event required');targets.add(change.element);}
  prior=event.sequence;
 }
 return clone(input);
}
export function checkedSuggestionChange(scene,input){
 validate(scene);const change=clone(input);checkedChangeShape(change);
 if(change?.op==='add'){
  if(!keys(change,['op','element','before','value'])||change.before!==null||!change.value||change.value.id!==change.element||scene.elements.some(e=>e.id===change.element))throw Error('Exact absent-element precondition required');
  validate({...clone(scene),elements:[...clone(scene.elements),clone(change.value)]});
  return {op:'add',element:change.element,value:clone(change.value)};
 }
 if(change?.op!=='set'||!keys(change,['op','element','before','patch'])||!change.before||!change.patch||Array.isArray(change.before)||Array.isArray(change.patch)||typeof change.before!=='object'||typeof change.patch!=='object'||!Object.keys(change.patch).length||canonical(Object.keys(change.before).sort())!==canonical(Object.keys(change.patch).sort()))throw Error('Exact before-field preconditions required');
 const element=scene.elements.find(e=>e.id===change.element);if(!element)throw Error('Proposed element is absent');
 for(const field of Object.keys(change.patch))if(canonical(element[field])!==canonical(change.before[field]))throw Error('Current field differs: '+change.element+'/'+field);
 if(Object.keys(change.patch).some(field=>!['x','y','width','height','text','fontSize','fontFamily','color','weight','fill','src','alt'].includes(field)))throw Error('Unsupported proposed field');
 validate({...clone(scene),elements:scene.elements.map(e=>e.id===change.element?{...clone(e),...clone(change.patch)}:clone(e))});
 return {op:'set',element:change.element,patch:clone(change.patch)};
}
const changeKey=(sourceRef,sequence,index)=>canonical([sourceRef,sequence,index]);
export async function previewStudioSuggestions(input,{sourceRef,source,decisions=[]}){
 const proposalRef=exactReference(sourceRef),snapshot=checkedSnapshot(input),verified=await verifySource(source);
 if(snapshot.scene_id!==verified.current.scene.id)throw Error('Proposal scene differs from the working canvas');
 const rows=[];let preview=verified.current;
 for(const event of snapshot.events)for(const [index,change] of event.changes.entries()){
  const key=changeKey(proposalRef,event.sequence,index),decision=decisions.find(d=>d.key===key),changeDigest=await digest(change),row={key,sequence:event.sequence,index,change:clone(change),change_digest:changeDigest,status:decision?.decision??'proposed',decision:decision?clone(decision):null,eligible:false};
  if(decision&&decision.change_digest!==changeDigest)throw Error('Retained decision refers to a different proposal payload');
  try{checkedSuggestionChange(verified.current.scene,change);row.eligible=!decision;}catch(error){row.current_conflict=error.message;}
  if(!decision){try{const checked=checkedSuggestionChange(preview.scene,change);preview=await apply(preview,preview.digest,[checked]);}catch(error){row.status='conflict';row.conflict=error.message;}}
  rows.push(row);
 }
 return {snapshot,source_ref:proposalRef,source:verified,canvas_ref:reference(verified.current),rows,preview,original_svg:svg(verified.current.scene),preview_svg:svg(preview.scene),issuer_authentication:'unverified',execution_admitted:false,adopted:false};
}

const styles=`
.studio-suggestions{padding:16px;border:1px solid var(--studio-line,#ccd8d7);border-radius:12px;background:var(--studio-raised,#fff);margin:18px 0;color:var(--studio-ink,#18352b)}
.studio-suggestions h2{font-size:16px;margin:0 0 6px}.studio-suggestions p{font-size:12px;line-height:1.5;overflow-wrap:anywhere}.studio-suggestions [data-suggestion-status]{color:var(--studio-ink2,#597478)}
.studio-suggestions-visual{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:12px 0}.studio-suggestions-visual figure{margin:0;padding:10px;border:1px solid var(--studio-line,#ccd8d7);border-radius:7px;background:var(--studio-surface,#edf1ef)}
.studio-suggestions-visual figcaption{font-size:12px;margin-bottom:8px}.studio-suggestions-visual svg{display:block;width:100%;height:auto;max-height:240px;pointer-events:none}
.studio-suggestions ol{list-style:none;padding:0;display:grid;gap:10px}.studio-suggestions li{padding:12px;border:1px solid var(--studio-line,#ccd8d7);border-radius:8px}.studio-suggestions li h3{font-size:13px;margin:0 0 6px}
.studio-suggestions li pre{font-size:11px;white-space:pre-wrap;overflow-wrap:anywhere;margin:8px 0;color:var(--studio-ink2,#597478)}.studio-suggestions li label{font-size:12px;margin:8px 0 0}.studio-suggestions li textarea{width:100%;min-height:56px;margin:5px 0 8px;padding:7px;resize:vertical}
.studio-suggestions-actions{display:flex;gap:7px;flex-wrap:wrap}.studio-suggestions-actions button{font-size:12px;min-height:34px}.studio-suggestions-actions button[data-accept]{background:var(--studio-accent,#123d43);color:var(--studio-onAccent,#fff);border-color:var(--studio-accent,#123d43)}
.studio-suggestions [data-error=true]{color:var(--studio-danger,#a33131)}@media(max-width:680px){.studio-suggestions-visual{grid-template-columns:1fr}}
`;
export function mountStudioSuggestions(container,{readSource,readSnapshot,acceptChange,notice}={}){
 if(!container||typeof readSource!=='function'||typeof readSnapshot!=='function'||typeof acceptChange!=='function')throw Error('Suggestion source, snapshot and local acceptance callbacks required');
 const doc=container.ownerDocument,node=(tag,text)=>{const n=doc.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
 const style=node('style',styles),nonce=doc.querySelector('script[nonce]')?.nonce;if(nonce)style.setAttribute('nonce',nonce);doc.head.append(style);
 const section=node('section');section.className='studio-suggestions';section.setAttribute('aria-label','Creative suggestions');
 const title=node('h2','Creative suggestions'),description=node('p','Preview retained maker proposals. Maker authority is unverified; no live execution or project adoption has been admitted.'),status=node('p','Read an exact proposal revision to see local suggestions.');status.dataset.suggestionStatus='';status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 const visual=node('div');visual.className='studio-suggestions-visual';const list=node('ol'),exportButton=node('button','Export suggestion decisions');exportButton.type='button';exportButton.disabled=true;
 section.append(title,description,status,visual,list,exportButton);container.append(section);
 let disposed=false,epoch=0,model=null,retained=null,busy=false,externalCurrent=()=>true;const decisions=[],reasons=new Map();
 const say=(text,error=false)=>{if(disposed)return;status.textContent=text;status.dataset.error=String(error);notice?.(text,error);};
 const isCurrent=ticket=>!disposed&&ticket===epoch&&externalCurrent();
 function previewFigure(label,markup){const figure=node('figure'),caption=node('figcaption',label),preview=node('div');preview.innerHTML=markup;figure.append(caption,preview);visual.append(figure);}
 function summary(change){if(change.op==='add')return 'Add '+change.value.kind+' '+change.element;return Object.keys(change.patch).map(field=>field+': '+JSON.stringify(change.before[field])+' → '+JSON.stringify(change.patch[field])).join('\n').slice(0,4000);}
 function render(){
  if(!model||disposed)return;visual.replaceChildren();previewFigure('Working canvas · r'+model.canvas_ref.revision,model.original_svg);previewFigure('Cumulative proposal preview · unapplied',model.preview_svg);list.replaceChildren();
  for(const row of model.rows){
   const item=node('li'),heading=node('h3','Step '+row.sequence+' · '+row.change.op+' '+row.change.element),details=node('pre',summary(row.change)),state=node('p',row.decision?(row.decision.decision==='accepted'?'Accepted locally':'Rejected locally')+' · '+row.decision.reason:row.conflict??row.current_conflict??'Ready for an explicit local decision');
   const label=node('label','Reason for your decision'),reason=node('textarea');reason.maxLength=2000;reason.value=reasons.get(row.key)??'';reason.setAttribute('aria-label','Decision reason for step '+row.sequence+' change '+(row.index+1));reason.oninput=()=>reasons.set(row.key,reason.value);label.append(reason);
   const actions=node('div');actions.className='studio-suggestions-actions';const accept=node('button','Accept change locally'),reject=node('button','Reject change');accept.type=reject.type='button';accept.dataset.accept='';
   accept.disabled=busy||!!row.decision||!row.eligible||!externalCurrent();reject.disabled=busy||!!row.decision||!externalCurrent();reason.disabled=!!row.decision;
   accept.onclick=()=>decide(row,'accepted',reason.value);reject.onclick=()=>decide(row,'rejected',reason.value);actions.append(accept,reject);item.append(heading,details,state,label,actions);list.append(item);
  }
  exportButton.disabled=decisions.length===0;
 }
 async function reload(ticket=epoch){
  if(!retained||!isCurrent(ticket))return false;
  const snapshotBefore=JSON.stringify(readSnapshot()),input=clone(readSource()),next=await previewStudioSuggestions(retained.snapshot,{sourceRef:retained.sourceRef,source:input,decisions});
  if(!isCurrent(ticket)||JSON.stringify(readSnapshot())!==snapshotBefore)return false;
  model=next;render();return true;
 }
 async function decide(row,decision,reason){
  if(disposed||busy||!retained||decisions.some(d=>d.key===row.key))return false;
  const ticket=epoch;
  try{
   if(!isCurrent(ticket))throw Error('Proposal access changed; read an exact current revision before deciding');
   if(typeof reason!=='string'||!reason.trim()||reason.length>2000)throw Error('Explain why you accept or reject this change');
 const sourceBefore=clone(readSource()),canvasBefore=reference(sourceBefore.current),expectedSnapshot=JSON.stringify(readSnapshot()),proposalReference=clone(retained.sourceRef);
   if(sourceBefore.current.scene.id!==retained.snapshot.scene_id)throw Error('Proposal scene differs from the working canvas');
   busy=true;render();let canvasAfter=null;
   if(decision==='accepted'){
    const checked=checkedSuggestionChange(sourceBefore.current.scene,row.change),expectedAfter=await apply(sourceBefore.current,sourceBefore.current.digest,[checked]);
    if(!isCurrent(ticket)||JSON.stringify(readSnapshot())!==expectedSnapshot)throw Error('Editor changed before acceptance; your current work is retained');
    const result=await acceptChange(clone(row.change),reason.trim(),{expectedSnapshot,isCurrent:()=>isCurrent(ticket),sourceRef:proposalReference,canvasRef:canvasBefore});
    if(result===false)throw Error('Local change was refused');
    const after=readSource().current;if(canonical(after)!==canonical(expectedAfter))throw Error('Local acceptance did not return the exact proposed canvas revision');
    canvasAfter=reference(after);
   }
   decisions.push({schema:'omega-local-suggestion-decision-1',key:row.key,proposal_reference:proposalReference,canvas_before:canvasBefore,canvas_after:canvasAfter,sequence:row.sequence,change_index:row.index,change_digest:row.change_digest,decision,reason:reason.trim(),issuer_authentication:'unverified',execution_admitted:false,adopted:false});
   if(isCurrent(ticket)){say(decision==='accepted'?'Accepted as a local editable revision. Project adoption remains separate.':'Rejected locally. The retained proposal is unchanged.');await reload(ticket);}
   return true;
  }catch(error){say(error.message,true);return false;}finally{busy=false;if(!disposed)render();}
 }
 exportButton.onclick=()=>{const body={schema:'omega-studio-suggestion-decisions-1',decisions:clone(decisions),issuer_authentication:'unverified',execution_admitted:false,adopted:false},url=URL.createObjectURL(new Blob([JSON.stringify(body,null,2)],{type:'application/json'})),a=node('a');a.href=url;a.download='omegadesign-suggestion-decisions.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);};
 return {
  async show(snapshot,{sourceRef,isCurrent:current=()=>true}={}){if(disposed)return false;const ticket=++epoch;externalCurrent=current;retained=null;model=null;visual.replaceChildren();list.replaceChildren();say('Checking the exact proposal against your working canvas…');try{retained={snapshot:checkedSnapshot(snapshot),sourceRef:exactReference(sourceRef)};const result=await reload(ticket);if(!result&&isCurrent(ticket))say('Editor changed while preparing the preview. Read the proposal again.',true);if(result){status.title=JSON.stringify(retained.sourceRef);say('Proposal '+retained.sourceRef.artifact_id+' · r'+retained.sourceRef.revision+' · '+retained.sourceRef.digest.slice(0,23)+'… · local decisions only. Export decisions with your creative source.');}return result;}catch(error){if(isCurrent(ticket))say(error.message,true);return false;}},
  revoke(reason='Proposal access changed. Read an exact current revision before deciding.'){epoch++;externalCurrent=()=>false;if(!disposed){say(reason,true);render();}},
  decisions:()=>clone(decisions),
  refresh:()=>reload(),
  dispose(){if(disposed)return;disposed=true;epoch++;section.remove();style.remove();}
 };
}
