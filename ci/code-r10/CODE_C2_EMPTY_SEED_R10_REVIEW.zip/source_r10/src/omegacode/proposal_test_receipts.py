"""Service-side retained proposal/fork/run evidence, existing store and guards only.

Candidate component, no installed API route or controller grant. A successful
command is not proof of proposal correctness or an independent evaluation.
"""
from .common import CodeError,canonical,digest,ident,stamp
from .proposal_test_preparation import prepare

TERMINAL={'completed','failed','timed_out','cancelled','output_limit','interrupted','unknown'}

def _human(service,p):
    if p.operator or p.grant.get('kind')!='human' or p.grant.get('delegated') is not None:
        raise CodeError(403,'proposal_test_person','this candidate requires existing person authority')
    service._live(p)


def retain(service,p,parent_id,payload):
    """Record already-completed test evidence. Never starts/materializes/accepts."""
    _human(service,p)
    if set(payload)!={'operation_id','proposal_id','proposal_digest','fork_id','run_id'}:
        raise CodeError(400,'proposal_test_shape','exact retained identifiers required')
    parent=service.workspace(parent_id);fork=service.workspace(payload['fork_id'])
    service._authorize(p,'read',parent,{})
    service._authorize(p,'read',fork,{})
    def validate():
        current_parent=service.workspace(parent_id);current_fork=service.workspace(fork['id'])
        service._authorize(p,'read',current_parent,{})
        projection=service.suggestion(p,parent_id,payload['proposal_id'])
        manifest=service.manifest(current_parent)
        allowed,context=service._context_files(p,current_parent)
        if set(allowed)!=set(manifest['files']):
            raise CodeError(403,'proposal_test_source_scope','complete authorized saved source required')
        files={path:service.store.read_blob(meta['digest'],parent_id) for path,meta in manifest['files'].items()}
        try:plan=prepare(projection,current_parent,manifest,files,proposal_id=payload['proposal_id'],proposal_digest=payload['proposal_digest'])
        except (ValueError,KeyError,TypeError):
            raise CodeError(409,'proposal_test_binding','current retained proposal/source mismatch') from None
        origin={'workspace_id':parent_id,'generation':current_parent['generation'],'tree_digest':current_parent['tree_digest']}
        if (current_fork['id']==parent_id or current_fork.get('fork_origin')!=origin or
                current_fork['generation']!=2 or current_fork['tree_digest']!=plan['test_tree_digest'] or
                any(current_fork[k]!=current_parent[k] for k in ('task_id','swarm_id','repository_id'))):
            raise CodeError(409,'proposal_test_fork','exact proposal-applied fork required')
        run=service.run(p,payload['run_id'])
        if (run['workspace_id']!=current_fork['id'] or run['generation']!=2 or run['tree_digest']!=plan['test_tree_digest'] or
                any(run[k]!=current_fork[k] for k in ('task_id','swarm_id'))):
            raise CodeError(409,'proposal_test_run','run is outside the exact proposal test fork')
        if run['status'] not in TERMINAL:
            raise CodeError(409,'proposal_test_incomplete','test command has not reached a terminal observation')
        if (run['profile']!='macos-seatbelt-python-v1' or
                run.get('confinement_observation',{}).get('validated_before_launch') is not True):
            raise CodeError(409,'proposal_test_unconfined','validated confined run required')
        service._context_current(service.workspace(parent_id),context)
        service._authorize(p,'read',current_fork,{})
        service._live(p)
        return plan,run
    # Revalidate before a cached result as well: a checksum or op-id is not permission.
    plan,run=validate()
    operation={**payload,'mutation':'retain-proposal-test','argv':run['argv'],'timeout_seconds':run['timeout_seconds']}
    def apply():
        plan,current=validate()
        result={'id':ident('ptr'),'schema':'omegacode-proposal-test-receipt/1','workspace_id':parent_id,
            'task_id':parent['task_id'],'swarm_id':parent['swarm_id'],'repository_id':parent['repository_id'],
            'proposal_id':payload['proposal_id'],'proposal_digest':payload['proposal_digest'],
            'normalized_hunks_digest':plan['normalized_hunks_digest'],'preparation_digest':plan['preparation_digest'],
            'parent_source':plan['parent'],'fork_id':fork['id'],'test_generation':2,'test_tree_digest':plan['test_tree_digest'],
            'run_id':current['id'],'argv':current['argv'],'run_status':current['status'],'exit_code':current['exit_code'],
            'output_digest':current.get('output_digest'),'run_receipt_digest':current.get('receipt_digest'),
            'confinement_observation':current['confinement_observation'],'input_mutations':current.get('input_mutations',[]),
            'descendants_terminated':current['descendants_terminated'],'cleanup_scope':'ordinary process group; no general escape claim',
            'command_outcome':'succeeded' if current['status']=='completed' and current['exit_code']==0 and current['descendants_terminated'] and not current.get('input_mutations') else 'unknown' if current['status'] in {'unknown','interrupted'} else 'not_succeeded',
            'accepted_source':False,'independent_rsi_evaluation':False,'authority_kind':'existing person grant',
            'author':p.actor,'created_at':stamp(),'operation_id':payload['operation_id']}
        result['evidence_digest']=digest(canonical(result))
        service.store.put('proposal_test_receipt',result)
        service.store.emit(parent,'proposal_test.recorded',result)
        return result
    return service._operation(p,'run',fork,operation,apply)


def read(service,p,receipt_id):
    if p.operator:raise CodeError(403,'proposal_test_scope','scoped coding capability required')
    service._live(p)
    row=service.store.get('proposal_test_receipt',receipt_id)
    parent=service.workspace(row['workspace_id']);fork=service.workspace(row['fork_id'])
    service._authorize(p,'read',parent,{})
    service._authorize(p,'read',fork,{})
    if digest(canonical({k:v for k,v in row.items() if k!='evidence_digest'}))!=row['evidence_digest']:
        raise CodeError(409,'proposal_test_receipt_integrity','retained evidence changed')
    service._live(p)
    current=(parent['generation']==row['parent_source']['generation'] and parent['tree_digest']==row['parent_source']['tree_digest'] and fork['generation']==row['test_generation'] and fork['tree_digest']==row['test_tree_digest'])
    return {**row,'currency':'current' if current else 'stale'}
