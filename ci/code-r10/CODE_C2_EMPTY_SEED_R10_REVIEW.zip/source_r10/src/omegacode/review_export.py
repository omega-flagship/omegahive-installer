"""Code-owned metadata export for Hive's existing immutable artifact route.

Preparation is pure. Publication and cross-swarm request admission require the
member's host authority; neither this digest nor a review grants effects.
"""
import copy

from .common import canonical, digest


def merge_review_export(packet):
    identity = {k: v for k, v in packet.items() if k not in ('packet_digest', 'currency')}
    if (packet.get('schema') != 'omegacode-merge-review-v1' or
            packet.get('currency') != 'current' or
            packet.get('packet_digest') != digest(canonical(identity))):
        raise ValueError('requires an intact current Code merge review packet')
    # Deliberate allowlist: paths, source bytes, commands, author credentials,
    # conflict text, output and privately scoped evidence are not shared here.
    value = {'schema': 'omegacode-merge-review-export-v1',
             'artifact': copy.deepcopy(packet['artifact']),
             'task_id': packet['task_id'], 'author_swarm': packet['author_swarm'],
             'packet_digest': packet['packet_digest'],
             'change_record_digest': packet['change_record_digest'],
             'resolution_digest': packet['resolution_digest'],
             'verification_state': packet['verification_state'],
             'verifications': [{k: v[k] for k in ('id', 'record_digest', 'status')}
                               for v in packet['verifications']],
             'quality_approval': 'not_assessed', 'execution_authority': 'none',
             'scope': 'metadata only; source inspection requires separate access'}
    body = canonical(value).decode('utf-8')
    if len(body.encode()) > 256 * 1024:
        raise ValueError('export exceeds Hive artifact revision bound')
    return {'body': body, 'body_digest': 'sha256:' + digest(body.encode()),
            'kind': 'code-review', 'execution_authority': 'none'}
