import pytest

from omegacode.common import CodeError, digest
from omegacode.context_selection import select, select_destinations


def _snapshot(contents):
    blobs = {digest(data): data for data in contents.values()}
    files = {path: {'digest': digest(data), 'size': len(data)} for path, data in contents.items()}
    return files, lambda blob_digest: blobs[blob_digest]


def test_destination_ignore_rules_cover_reversed_and_mixed_case(tmp_path):
    files, read = _snapshot({'.gitignore': b'Private/\n'})

    results, _ = select_destinations(
        files, {'context_gitignore_enabled': True}, read, tmp_path,
        ['PRIVATE/new.py', 'private/nested/new.py'],
    )

    assert results == {
        'PRIVATE/new.py': {'allowed': False, 'reason': 'gitignore'},
        'private/nested/new.py': {'allowed': False, 'reason': 'gitignore'},
    }


def test_new_unicode_destination_refuses_with_plain_words(tmp_path):
    files, read = _snapshot({'.gitignore': b'Private/\n'})
    with pytest.raises(CodeError) as refused:
        select_destinations(files, {'context_gitignore_enabled': True}, read, tmp_path,
                             ['Private/Café/new.py'])
    assert refused.value.code == 'draft_file_path_ascii'
    assert refused.value.message == 'new file and folder names must use basic keyboard characters for now'


def test_negated_unicode_class_is_evaluated_by_git_without_rewriting(tmp_path):
    files, read = _snapshot({'.gitignore': '*\n![ß]\n'.encode('utf-8')})

    results, _ = select_destinations(
        files, {'context_gitignore_enabled': True}, read, tmp_path, ['s'])
    assert results['s'] == {'allowed': False, 'reason': 'gitignore'}


def test_ascii_character_class_semantics_are_preserved(tmp_path):
    files, read = _snapshot({'.gitignore': b'[A-z]/\n'})

    results, _ = select_destinations(
        files, {'context_gitignore_enabled': True}, read, tmp_path, ['_/new.py'])

    assert results['_/new.py'] == {'allowed': False, 'reason': 'gitignore'}


def test_existing_directory_with_different_spelling_refuses(tmp_path):
    files, read = _snapshot({'package/.gitignore': b'secret.py\n', 'package/kept.py': b'x'})

    with pytest.raises(CodeError) as refused:
        select_destinations(files, {'context_gitignore_enabled': True}, read, tmp_path,
                             ['PACKAGE/secret.py'])

    assert refused.value.code == 'draft_directory_case'


def test_casefold_alias_of_unicode_directory_refuses(tmp_path):
    files, read = _snapshot({'Straße/.gitignore': b'secret.py\n'})

    with pytest.raises(CodeError) as refused:
        select_destinations(files, {'context_gitignore_enabled': True}, read, tmp_path,
                             ['STRASSE/secret.py'])

    assert refused.value.code == 'draft_directory_case'


def test_exact_nested_directory_finds_its_original_ignore_file(tmp_path):
    files, read = _snapshot({'package/.gitignore': b'secret.py\n'})

    results, _ = select_destinations(
        files, {'context_gitignore_enabled': True}, read, tmp_path,
        ['package/secret.py'],
    )

    assert results['package/secret.py'] == {'allowed': False, 'reason': 'gitignore'}


def test_saved_paths_are_excluded_through_case_and_unicode_aliases(tmp_path):
    nfd_saved = 'private/Cafe\u0301.py'
    files, read = _snapshot({'.gitignore': b'Private/\n', nfd_saved: b'secret'})

    selected, _ = select(files, {'context_gitignore_enabled': True}, read, tmp_path)

    assert nfd_saved not in selected
