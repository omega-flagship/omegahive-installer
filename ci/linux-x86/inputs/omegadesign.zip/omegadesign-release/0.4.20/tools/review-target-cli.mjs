// Host sandbox entry point. Input custody/authentication belongs to the host.
import fs from 'node:fs/promises';
import {resolveCreativeTarget} from './review-target.mjs';
try{
 const [sourcePath,targetPath]=process.argv.slice(2);
 if(!sourcePath||!targetPath||process.argv.length!==4)throw Error('Exact source and target files required');
 if((await fs.stat(sourcePath)).size>20*1024*1024||(await fs.stat(targetPath)).size>4096)throw Error('Finding input exceeds limits');
 const source=JSON.parse(await fs.readFile(sourcePath,'utf8')),target=JSON.parse(await fs.readFile(targetPath,'utf8'));
 const location=await resolveCreativeTarget(source,target);
 console.log(JSON.stringify({ok:true,location}));
}catch(error){console.log(JSON.stringify({ok:false,reason:error.message}));process.exitCode=1;}
