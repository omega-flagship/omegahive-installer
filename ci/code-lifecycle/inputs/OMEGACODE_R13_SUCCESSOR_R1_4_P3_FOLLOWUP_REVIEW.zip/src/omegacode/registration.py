"""Narrow, replay-safe Hive service enrolment and acknowledgement."""
from contextlib import contextmanager
import fcntl
import json
import os
import pathlib
import re
import secrets
import threading

import httpx

from .common import CodeError, atomic_write, canonical

_PROCESS_LOCKS = {}
_PROCESS_LOCKS_GUARD = threading.Lock()
_REGISTRATION_LOCK_TIMEOUT_SECONDS = 30
REGISTRATION_RETRY_AFTER_SECONDS = 35


@contextmanager
def _registration_lock(root):
    """Serialize enrollment and recovery across threads and service processes."""
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    key = str(root.resolve())
    with _PROCESS_LOCKS_GUARD:
        process_lock = _PROCESS_LOCKS.setdefault(key, threading.RLock())
    if not process_lock.acquire(timeout=_REGISTRATION_LOCK_TIMEOUT_SECONDS):
        raise CodeError(503, "registration_busy",
                        f"service registration is busy; wait at least {REGISTRATION_RETRY_AFTER_SECONDS} seconds before retrying recovery",
                        {"retry_after_seconds": REGISTRATION_RETRY_AFTER_SECONDS})
    try:
        with _file_registration_lock(root):
            yield
    finally:
        process_lock.release()


@contextmanager
def _file_registration_lock(root):
    lock_path = root / "registration.lock"
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        os.fchmod(fd, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _json(response):
    try:
        value = response.json()
        return value if isinstance(value, dict) else None
    except (ValueError, TypeError):
        return None


def _error_code(value):
    if not isinstance(value, dict):
        return None
    code = value.get("code")
    if isinstance(code, str):
        return code
    error = value.get("error")
    if isinstance(error, dict):
        return error.get("code")
    return error if isinstance(error, str) else None


def _same_receipt(value, expected, status):
    return (isinstance(value, dict) and value.get("operation_id") == expected.get("operation_id")
            and value.get("request_digest") == expected.get("request_digest")
            and value.get("service_id") == expected.get("service_id")
            and value.get("status") == status)


def _valid_registration(value, operation_id, address):
    receipt = value.get("receipt") if isinstance(value, dict) else None
    return (isinstance(value, dict) and isinstance(value.get("service_id"), str) and bool(value["service_id"])
            and isinstance(value.get("service_token"), str) and bool(value["service_token"])
            and isinstance(value.get("capability_secret"), str) and bool(value["capability_secret"])
            and value.get("address") == address and isinstance(receipt, dict)
            and receipt.get("operation_id") == operation_id
            and receipt.get("service_id") == value.get("service_id")
            and re.fullmatch(r"[0-9a-f]{64}", str(receipt.get("request_digest", "")))
            and receipt.get("status") in ("pending", "active"))


def _remove_operation(operation_path, operation_id):
    if not operation_path.exists():
        return
    try:
        saved = json.loads(operation_path.read_text())
    except (OSError, ValueError, TypeError):
        raise CodeError(503, "registration_recovery_required", "saved enrolment state could not be read safely") from None
    if not isinstance(saved, dict):
        raise CodeError(503, "registration_recovery_required", "saved enrolment state has an unsupported shape")
    if saved.get("operation_id") != operation_id:
        raise CodeError(503, "registration_recovery_required", "saved enrolment operation changed during recovery")
    try:
        operation_path.unlink()
    except OSError:
        raise CodeError(503, "registration_cleanup_pending", "registration is active but its saved one-time enrolment token could not be removed") from None


def _clear_expired(path, operation_path, operation_id):
    # Validate both records before deleting either one. A malformed operation
    # file must not leave recovery half-cleared by deleting the registration first.
    if operation_path.exists():
        try:
            operation = json.loads(operation_path.read_text())
        except (OSError, ValueError, TypeError):
            raise CodeError(503, "registration_recovery_required", "expired enrolment operation could not be read safely") from None
        if not isinstance(operation, dict) or operation.get("operation_id") != operation_id:
            raise CodeError(503, "registration_recovery_required", "expired enrolment operation has an unsupported shape or identity")
    if path.exists():
        try:
            saved = json.loads(path.read_text())
        except (OSError, ValueError, TypeError):
            raise CodeError(503, "registration_recovery_required", "expired registration state could not be read safely") from None
        if not isinstance(saved, dict) or not isinstance(saved.get("receipt"), dict):
            raise CodeError(503, "registration_recovery_required", "expired registration state has an unsupported shape")
        if saved["receipt"].get("operation_id") != operation_id:
            raise CodeError(503, "registration_recovery_required", "expired operation does not match saved credentials")
    # Remove the short-lived token record only after all state passed validation.
    _remove_operation(operation_path, operation_id)
    if path.exists():
        try:
            path.unlink()
        except OSError:
            raise CodeError(503, "registration_recovery_required", "expired credentials could not be cleared safely") from None


def _finish(authority, path, operation_path, registration, operation_id, address):
    registration["receipt"] = {**registration["receipt"], "status": "active"}
    if not _valid_registration(registration, operation_id, address):
        raise CodeError(503, "registration_unknown", "Hive returned an invalid active receipt")
    atomic_write(path, canonical(registration))
    _remove_operation(operation_path, operation_id)
    authority.service_token = registration["service_token"]
    authority.registration = registration
    return {k: v for k, v in registration.items() if k in ("service_id", "address", "registered_at")}


def _status(authority, registration, operation_id):
    try:
        response = authority.client.get(authority.hive_url + f"/api/services/operations/{operation_id}",
                                        headers={"Authorization": "Bearer " + registration["service_token"]})
        return _json(response) if response.status_code == 200 else None
    except httpx.HTTPError:
        return None


def _ack(authority, registration, operation_id, expected):
    try:
        response = authority.client.post(authority.hive_url + f"/api/services/operations/{operation_id}/ack",
                                         headers={"Authorization": "Bearer " + registration["service_token"]})
        receipt = _json(response) if response.status_code == 200 else None
    except httpx.HTTPError:
        receipt = None
    if _same_receipt(receipt, expected, "active"):
        return receipt
    # Ack may have committed despite a lost response. Read the receipt before retrying.
    receipt = _status(authority, registration, operation_id)
    if _same_receipt(receipt, expected, "active"):
        return receipt
    return None


def _enrol_locked(authority, root, enrol_token, port):
    if not authority.hive_url:
        raise CodeError(400, "hive_required", "service registration needs the configured Hive")
    path = root / "registration.json"
    operation_path = root / "registration.operation.json"
    address = f"http://127.0.0.1:{port}"

    saved_registration = None
    if path.exists():
        try:
            saved_registration = json.loads(path.read_text())
        except (OSError, ValueError, TypeError):
            raise CodeError(503, "registration_state_invalid", "saved registration state is invalid") from None
        if not isinstance(saved_registration, dict) or not isinstance(saved_registration.get("receipt"), dict):
            raise CodeError(503, "registration_recovery_required", "saved registration state has an unsupported shape")
        receipt = saved_registration["receipt"]
        if isinstance(receipt, dict) and receipt.get("status") == "active":
            raise CodeError(409, "already_registered", "registration exists; rotate through the owner before replacing it")

    body = {"name": "omegacode", "version": "0.1.0", "address": address, "contract": "omegacode/1",
            "surfaces": ["diff", "log", "editor"],
            "capabilities": ["workspaces", "runs", "changesets", "verifications", "events"]}
    try:
        if operation_path.exists():
            operation = json.loads(operation_path.read_text())
            if not isinstance(operation, dict):
                raise CodeError(503, "registration_recovery_required", "saved enrolment operation has an unsupported shape")
            if operation.get("enrol_token") != enrol_token or operation.get("body") != body:
                raise CodeError(409, "registration_in_progress", "a different enrolment is already pending recovery")
        else:
            if saved_registration is not None:
                raise CodeError(503, "registration_recovery_required", "pending credentials have no matching operation record")
            operation = {"operation_id": secrets.token_urlsafe(24), "enrol_token": enrol_token, "body": body}
            atomic_write(operation_path, canonical(operation))
    except (OSError, ValueError, TypeError):
        raise CodeError(503, "registration_state_invalid", "saved enrolment recovery state is invalid") from None

    operation_id = operation.get("operation_id")
    if not isinstance(operation_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,128}", operation_id):
        raise CodeError(503, "registration_state_invalid", "saved enrolment operation is invalid")

    # If credentials were durably written before a crash, recover by status first.
    # The host intentionally returns operation_complete on a post-ack re-register.
    if saved_registration is not None:
        if not _valid_registration(saved_registration, operation_id, address):
            raise CodeError(503, "registration_recovery_required", "pending credentials do not match the saved operation")
        expected = saved_registration["receipt"]
        receipt = _status(authority, saved_registration, operation_id)
        if _same_receipt(receipt, expected, "active"):
            return _finish(authority, path, operation_path, saved_registration, operation_id, address)
        if _same_receipt(receipt, expected, "pending"):
            active = _ack(authority, saved_registration, operation_id, expected)
            if active is not None:
                return _finish(authority, path, operation_path, saved_registration, operation_id, address)
            receipt = _status(authority, saved_registration, operation_id)
            if _same_receipt(receipt, expected, "active"):
                return _finish(authority, path, operation_path, saved_registration, operation_id, address)

        # Status can disappear when the host expires and removes a pending identity.
        # Replay the exact operation to distinguish expiry from a transient status error.
        try:
            replay = authority.client.post(authority.hive_url + "/api/services/register",
                                           json={**body, "operation_id": operation_id},
                                           headers={"Authorization": "Bearer " + enrol_token})
        except httpx.HTTPError:
            raise CodeError(503, "registration_pending", "saved credentials could not resolve the Hive operation; retry recovery") from None
        replay_error = _error_code(_json(replay))
        if replay.status_code == 409 and replay_error == "operation_expired":
            _clear_expired(path, operation_path, operation_id)
            authority.registration = None
            authority.service_token = None
            raise CodeError(409, "operation_expired", "Hive expired this enrolment; request a fresh enrolment token to retry")
        if replay.status_code == 409 and replay_error == "operation_complete":
            receipt = _status(authority, saved_registration, operation_id)
            if _same_receipt(receipt, expected, "active"):
                return _finish(authority, path, operation_path, saved_registration, operation_id, address)
            raise CodeError(503, "registration_pending", "Hive reports a completed operation but its receipt is not yet readable")
        replayed = _json(replay) if replay.status_code in (200, 201) else None
        if not _valid_registration(replayed, operation_id, address):
            raise CodeError(503, "registration_pending", "saved credentials could not resolve the Hive operation; retry recovery")
        if any(replayed.get(key) != saved_registration.get(key) for key in ("service_id", "service_token", "capability_secret")):
            raise CodeError(503, "registration_recovery_required", "Hive replay returned credentials that differ from the saved identity")
        replay_receipt = replayed["receipt"]
        if replay_receipt["status"] == "active":
            saved_registration["receipt"] = replay_receipt
            return _finish(authority, path, operation_path, saved_registration, operation_id, address)
        active = _ack(authority, saved_registration, operation_id, replay_receipt)
        if active is None:
            raise CodeError(503, "registration_pending", "service credentials are saved; retry to finish acknowledgement")
        saved_registration["receipt"] = replay_receipt
        return _finish(authority, path, operation_path, saved_registration, operation_id, address)

    # Replaying this exact request is safe only before credentials have been saved.
    try:
        response = authority.client.post(authority.hive_url + "/api/services/register",
                                         json={**body, "operation_id": operation_id},
                                         headers={"Authorization": "Bearer " + enrol_token})
    except httpx.HTTPError:
        raise CodeError(503, "registration_unknown", "registration response unavailable; retry to recover the same operation") from None
    if response.status_code not in (200, 201):
        error_code = _error_code(_json(response))
        if response.status_code == 409 and error_code == "operation_expired":
            _clear_expired(path, operation_path, operation_id)
            authority.registration = None
            authority.service_token = None
            raise CodeError(409, "operation_expired", "Hive expired this enrolment; request a fresh enrolment token to retry")
        if response.status_code == 409 and error_code == "operation_complete":
            raise CodeError(503, "registration_recovery_required", "Hive says this operation is complete but local credentials are missing; owner recovery is required")
        raise CodeError(403, "registration_refused", "Hive refused service enrolment")

    registration = _json(response)
    if not _valid_registration(registration, operation_id, address):
        raise CodeError(503, "registration_unknown", "invalid registration receipt; retry to recover the same operation")
    atomic_write(path, canonical(registration))
    receipt = registration["receipt"]
    if receipt["status"] == "active":
        return _finish(authority, path, operation_path, registration, operation_id, address)
    active = _ack(authority, registration, operation_id, receipt)
    if active is None:
        raise CodeError(503, "registration_pending", "service credentials are saved; retry to finish acknowledgement")
    return _finish(authority, path, operation_path, registration, operation_id, address)


def enrol(authority, root: pathlib.Path, enrol_token: str, port: int):
    with _registration_lock(root):
        return _enrol_locked(authority, root, enrol_token, port)
