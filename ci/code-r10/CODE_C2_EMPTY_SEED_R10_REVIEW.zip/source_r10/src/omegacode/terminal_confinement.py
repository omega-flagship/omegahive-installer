"""Operator-pinned Bash PTY profile; existing exact-batch authority is unchanged."""
import hashlib
import platform
from pathlib import Path
from .pty_profile import profile

KIND = 'macos-seatbelt-bash-pty-v1'
ARGV = ['/bin/bash', '--noprofile', '--norc', '-i']
GENERATORS = ('pty_profile.py', 'confinement.py', 'terminal_confinement.py',
              'terminal_cleanup.py', 'runner.py', 'common.py')


def identity(config):
    fields = {'kind', 'python', 'python_sha256', 'application_sha256',
              'sandbox_exec_sha256', 'bash_sha256', 'locale_sha256'}
    if platform.system() != 'Darwin' or type(config) is not dict or set(config) != fields or config['kind'] != KIND:
        raise ValueError('exact operator-pinned terminal configuration required')
    python = Path(config['python']).resolve(strict=True)
    app = (python.parent.parent / 'Resources/Python.app/Contents/MacOS/Python').resolve(strict=True)
    binaries = {str(python): config['python_sha256'], str(app): config['application_sha256'],
                '/bin/bash': config['bash_sha256'], '/usr/bin/sandbox-exec': config['sandbox_exec_sha256'],
                '/usr/share/locale/C.UTF-8/LC_CTYPE': config['locale_sha256']}
    validate_binaries(binaries)
    generators = {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                  for name in GENERATORS}
    return {'kind': KIND, 'python': str(python), 'binaries': binaries, 'generators': generators}


def validate_binaries(binaries):
    for path, pin in binaries.items():
        if (type(pin) is not str or len(pin) != 64 or any(c not in '0123456789abcdef' for c in pin)
                or hashlib.sha256(Path(path).read_bytes()).hexdigest() != pin):
            raise ValueError('terminal runtime pin changed')


def prepare(root, spec, slave_fd):
    root = Path(root).resolve(strict=True)
    binding = spec['pty_confinement']
    if (type(binding) is not dict or set(binding) != {'kind', 'python', 'binaries', 'generators'}
            or binding['kind'] != KIND or spec.get('terminal') is not True
            or spec.get('confinement') is not None or spec['argv'] != ARGV):
        raise ValueError('exact confined terminal spec required')
    python = Path(binding['python']).resolve(strict=True)
    app = (python.parent.parent / 'Resources/Python.app/Contents/MacOS/Python').resolve(strict=True)
    expected = {str(python), str(app), '/bin/bash', '/usr/bin/sandbox-exec', '/usr/share/locale/C.UTF-8/LC_CTYPE'}
    if set(binding['binaries']) != expected or set(binding['generators']) != set(GENERATORS):
        raise ValueError('exact runtime and frozen helper set required')
    validate_binaries(binding['binaries'])
    for name, pin in binding['generators'].items():
        if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() != pin:
            raise ValueError('terminal helper changed')
    policy = profile(root / 'tree', python, slave_fd)
    path = root / 'pty-confinement.sb'
    if path.exists() or path.is_symlink():
        raise ValueError('terminal policy already exists')
    with path.open('x') as handle:
        handle.write(policy)
    return ['/usr/bin/sandbox-exec', '-f', str(path), *spec['argv']], {
        'kind': KIND, 'policy_sha256': hashlib.sha256(policy.encode()).hexdigest(),
        'validated_before_launch': True, 'logical_argv': spec['argv'],
        'qualification': 'confined Bash PTY candidate; exact input batches; no raw session authority'}
