# OmegaCode R13 successor R1.5.1 — Hyperon trace read API

Parent: frozen R1.5 source digest `db8036ebd0cc85999deb28aa74031c56f350cf0f11e15e9f1421f506d46074a3`, archive SHA-256 `02155df2e4e30e2aa6054e9dc5e9242bd5310d2b195df9ebb09e3b97005f98c8`.

Transitive base: Dot-selected and Studio-staged R1.4 source digest `4a5737b1296bcb49ff44a002684129c18e95a749d8ce3362cd97df18953b449d`.

Candidate source digest: `892f333ee430c5f10a9985f97109e1fa511b1fa020a925de9c49ac73ed64387d` (92 Python modules; 13 test files).

## Change

R1.5.1 preserves R1.5's bounded, read-only historical Hyperon trace route, NativeClient action, artifact custody and size limits, R13 coverage binding, and retry-delay invariant. This correction rejects **partial R13 observation coverage metadata** instead of treating it as legacy unknown. The earlier structured coverage form is accepted only on its own; it cannot be mixed with R13 fields. Legacy output remains explicitly unknown only when no current or structured coverage fields are present.

The reader does not import Hyperon, execute, restore, or replay code. Cooperative stdout is not presented as authenticated execution or reductions. The route remains read-only and requires full workspace `read` and `events` authority.

No host route, release pin, relay allowlist, live service, worker, engine, provider, or Hive configuration is changed by this source candidate. Host action direction is in `../SYMBOLIC_TRACE_PROXY_ROUTE_DIRECTION.json`.

## Evidence and remaining gates

Against this exact source tree, the focused trace/API and retry-invariant checks passed 25 tests. The full 13-file suite passed twice outside the tool sandbox: 150 passed plus 3 failure-injection subcases per run. The tests use an existing Python 3.12.13 / pytest 9.1.1 environment; no Hive, external provider, or paid service was used.

This is a Code-owned source candidate only. It still needs independent exact-byte review, Dot/Studio staging, host route adoption and interop, x86_64 CI on the exact archive, and Dot's source-selection decision. It does not replace R1.4 or establish live Hive behavior.

## Compatibility note from Dot's owner disposition

Dot reports that R10 is the only Code source pin ever run live and that R10 emits no R13 observation-coverage fields. Its retained transcripts therefore use the zero-field legacy-unknown path, which this change leaves unchanged. The new refusal affects incomplete or mixed R13 coverage metadata; this owner report is not an audit of other archives or a claim that future producers cannot emit such records.
