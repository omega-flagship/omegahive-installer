import {validateUI} from './ui-spec.mjs';
// Pure source locator for host-owned creative finding admission.
// Caller must obtain source via exact authorized revision/asset custody first.
import {verifySource} from './source.mjs';
import {validateSceneDeck} from './scene-deck.mjs';
import {clone,digest} from './scene.mjs';
import {readMotionSource} from './motion-source.mjs';
import {readModelSource} from './model-source.mjs';
export async function resolveCreativeTarget(source,target){
 if(!target||typeof target!=='object'||Array.isArray(target))throw Error('Exact creative target required');
 const keys=Object.keys(target).sort().join(',');
 const whole=keys==='whole'&&target.whole===true;
 const pageTarget=keys==='page_id'&&typeof target.page_id==='string'&&!!target.page_id;
 const elementTarget=keys==='element_id,scene_id'&&typeof target.scene_id==='string'&&!!target.scene_id&&typeof target.element_id==='string'&&!!target.element_id;
 if(!whole&&!pageTarget&&!elementTarget)throw Error('Exact scene element, page or whole target required');
 if(source?.schema==='omega-model-source-1'){
  const revision=await readModelSource(JSON.stringify(source));
  if(!whole)throw Error('Parametric model object/property targets are not admitted by this slice');
  return {whole:true,source_schema:source.schema,model_id:revision.document.id,model_digest:revision.digest,source_digest:await digest(source),authority:'none',source_authentication:'host-required'};
 }
 if(source?.schema==='omega-onboarding-ui-1'){
  const ui=validateUI(source),source_digest=await digest(ui);
  if(whole)return {whole:true,source_schema:ui.schema,source_digest,authority:'none',source_authentication:'host-required'};
  if(pageTarget)throw Error('Onboarding source has no page targets');
  if(target.scene_id!==ui.id)throw Error('Target UI not in reviewed source');
  const fields={title:ui.title,introduction:ui.introduction,criteria:ui.criteria};
  for(const name of ['paper','ink','accent'])fields['identity.'+name]=ui.identity[name];
  for(const name of ['name_label','availability_label','options','button','name_error','availability_error','success'])fields['form.'+name]=ui.form[name];
  if(!Object.hasOwn(fields,target.element_id))throw Error('Target field not in reviewed UI source');
  return {scene_id:ui.id,element_id:target.element_id,kind:'ui-field',source_schema:ui.schema,source_digest,element_digest:await digest({field:target.element_id,value:fields[target.element_id]}),authority:'none',source_authentication:'host-required'};
 }
 let scenes,motion={};
 if(source?.schema==='omega-studio-source-1')scenes=[(await verifySource(source)).current.scene];
 else if(source?.schema==='omega-scene-deck-1')scenes=validateSceneDeck(source).slides;
 else if(source?.schema==='omega-editable-motion-export-1'){source=await readMotionSource(JSON.stringify(source));scenes=[source.scene];motion={motion_digest:await digest(source.timeline)};}
 else throw Error('Validated editable Studio or deck source required');
 if(whole)return {...motion,whole:true,page_count:scenes.length,source_digest:await digest(source),authority:'none',source_authentication:'host-required'};
 const page=scenes.findIndex(s=>s.id===(pageTarget?target.page_id:target.scene_id));if(page<0)throw Error('Target scene not in reviewed source');
 if(pageTarget)return {...motion,page_id:target.page_id,page:page+1,scene_digest:await digest(scenes[page]),authority:'none',source_authentication:'host-required'};
 const element=scenes[page].elements.find(e=>e.id===target.element_id);if(!element)throw Error('Target element not in reviewed scene');
 const targetMotion=source.schema==='omega-editable-motion-export-1'?{target_motion_digest:await digest({duration_ms:source.timeline.duration_ms,tracks:source.timeline.tracks.filter(t=>t.element_id===element.id)})}:{};
 return {...motion,...targetMotion,scene_id:target.scene_id,element_id:element.id,page:page+1,kind:element.kind,element_digest:await digest(element),geometry:clone({x:element.x,y:element.y,width:element.width,height:element.height}),authority:'none',source_authentication:'host-required'};
}
