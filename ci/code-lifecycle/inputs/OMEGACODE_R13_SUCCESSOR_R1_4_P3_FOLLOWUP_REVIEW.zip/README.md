# OmegaCode R13 successor R1.4 — Kimi P3 follow-up candidate

Parent: Dot-selected R13 successor R1.3, source digest `117deeebede5a8a16b1a2bde5a6cd3c6ab414eaceb44392dc136144e279b4cc2`; sealed parent ZIP SHA-256 `010e3e69e1ba783c5e4f076c83cbc2d80c84f88dfb6d1a37a95baf80a2d0ca8d`.

This separate follow-up candidate addresses four non-blocking Kimi P3s from the R1.3 review:

- Registration lock contention now includes a machine-readable `Retry-After: 35`, an error detail with the same delay, and operator-facing guidance. The readme instructs operators to wait at least 35 seconds after a registration request timeout or `registration_busy` before retrying recovery; no automatic retry was added.
- The Hyperon stepper prepares the next retained observation window and count before mutating current result/status, and marks the publication boundary against adding fallible work below it. Failure injection now covers atom inspection, encoded-size calculation, and digest calculation.
- The standalone registration check restores the global lock timeout through `unittest.mock.patch` cleanup.
- The missing-receipt recovery behavior is documented: malformed or receipt-less persisted registration state fails closed with `503 registration_recovery_required`; credentials are retained for operator recovery.

## Test boundary and release state

Source digest: `4a5737b1296bcb49ff44a002684129c18e95a749d8ce3362cd97df18953b449d` (91 modules). All 12 test files passed twice on the exact candidate source under Python 3.12.13 / pytest 9.1.1: 125 passed plus three injected-failure subcases on each run. The four standalone registration checks passed. These are Mac source/component results only; they do not inherit R1.3's review, host interop, or x86 qualification.

This follow-up is prepared for exact-byte review and remains a candidate. It must not replace R1.3's selected source pin without paired review, host interop, x86 CI, and an owner decision. No test fixture or live service was changed; no live registration, Hive, provider, model, or Hyperon runtime was accessed.

