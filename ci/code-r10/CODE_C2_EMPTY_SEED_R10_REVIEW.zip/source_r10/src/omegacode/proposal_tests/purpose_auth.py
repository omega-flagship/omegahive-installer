"""Uninstalled default-off extension of existing Authority; no new issuer/ledger.

Only hc1 signatures verified by the inherited authenticate path can reach this
validation/status branch. Generic source/run actions remain absent.
"""
import re, math, time
from omegacode.auth import Authority
from omegacode.common import CodeError

def invalid():
    raise ValueError('invalid proposal-test claim')

def identifier(value, prefix=None):
    if type(value) is not str or re.fullmatch('[A-Za-z0-9_.:-]{1,200}', value) is None or (prefix and (not value.startswith(prefix))):
        invalid()

def integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        invalid()

def sha(value):
    if type(value) is not str or re.fullmatch('sha256:[a-f0-9]{64}', value) is None:
        invalid()

def exact(value, names):
    if type(value) is not dict or set(value) != set(names):
        invalid()

def workspace(value):
    if type(value) is not str or re.fullmatch('ws_[a-f0-9]{32}', value) is None:
        invalid()

def validate(claims, service_id):
    if claims.get('iss') != 'hive' or claims.get('aud') != service_id or claims.get('kind') != 'agent' or (claims.get('actions') != ['proposal-test']) or ('delegated' in claims) or ('copy_apply' in claims) or (claims.get('paths') != []):
        invalid()
    for name in ['id', 'actor', 'task_id', 'swarm_id', 'repository_id']:
        identifier(claims.get(name))
    if type(claims.get('member_hash')) is not str or re.fullmatch('[a-f0-9]{64}', claims['member_hash']) is None:
        invalid()
    integer(claims.get('max_runs'), 0, 0)
    integer(claims.get('max_runtime_seconds'), 1, 600)
    for name in ['iat', 'exp']:
        if type(claims.get(name)) not in (int, float) or not math.isfinite(claims[name]) or claims[name] <= 0:
            invalid()
    if claims['iat'] >= claims['exp'] or claims['exp'] - claims['iat'] > 900:
        invalid()
    prefixes = claims.get('argv_prefixes')
    if type(prefixes) is not list or not prefixes or any((type(p) is not list or not p or any((type(a) is not str or not a or '\x00' in a for a in p)) for p in prefixes)):
        invalid()
    p = claims.get('proposal_test')
    required = {'purpose', 'stage', 'test_id', 'request_id', 'lease_id', 'controller_id', 'execution_goal', 'issuer', 'origin_scope', 'proposal', 'parent', 'fork', 'allowance'}
    if type(p) is not dict or p.get('stage') not in ('prepare', 'run', 'result'):
        invalid()
    exact(p, required | ({'origin_grant_id'} if p['stage'] == 'result' else set()))
    if p['purpose'] != 'proposal-test' or p['controller_id'] != claims['actor']:
        invalid()
    if re.fullmatch('pt_[a-f0-9]{24}', str(p['test_id'])) is None:
        invalid()
    for name in ['request_id', 'lease_id', 'controller_id', 'execution_goal', 'issuer']:
        identifier(p[name])
    if not p['issuer'].startswith('user:'):
        invalid()
    if p['stage'] == 'result':
        if 'grant_id' not in claims or claims['grant_id'] is not None:
            invalid()
        identifier(p['origin_grant_id'])
    else:
        identifier(claims.get('grant_id'))
    exact(p['origin_scope'], ['scope_id', 'scope_digest', 'generation'])
    identifier(p['origin_scope']['scope_id'])
    sha(p['origin_scope']['scope_digest'])
    integer(p['origin_scope']['generation'], 1, 2 ** 53 - 1)
    exact(p['proposal'], ['proposal_id', 'proposal_digest', 'normalized_hunks_digest'])
    if re.fullmatch('suggestion_[a-f0-9]{32}', str(p['proposal']['proposal_id'])) is None:
        invalid()
    sha(p['proposal']['proposal_digest'])
    sha(p['proposal']['normalized_hunks_digest'])
    exact(p['parent'], ['workspace_id', 'generation', 'tree_digest'])
    workspace(p['parent']['workspace_id'])
    integer(p['parent']['generation'], 1, 2 ** 53 - 1)
    sha(p['parent']['tree_digest'])
    exact(p['fork'], ['workspace_id', 'preparation_digest'])
    if p['fork']['workspace_id'] is None:
        if p['fork']['preparation_digest'] is not None or p['stage'] == 'run':
            invalid()
    else:
        workspace(p['fork']['workspace_id'])
        sha(p['fork']['preparation_digest'])
        if p['fork']['workspace_id'] == p['parent']['workspace_id'] or p['stage'] == 'prepare':
            invalid()
    a = p['allowance']
    exact(a, ['until', 'per_launch_max_runtime_seconds', 'test', 'request', 'usd'])
    if type(a['until']) is not str or not 1 <= len(a['until']) <= 100:
        invalid()
    integer(a['per_launch_max_runtime_seconds'], 1, 600)
    if claims['max_runtime_seconds'] > a['per_launch_max_runtime_seconds']:
        invalid()
    for (name, runs, seconds) in [('test', 4, 600), ('request', 8, 1800)]:
        exact(a[name], ['runs_remaining', 'runtime_seconds_remaining'])
        integer(a[name]['runs_remaining'], 0, runs)
        integer(a[name]['runtime_seconds_remaining'], 0, seconds)
    exact(a['usd'], ['metered', 'status', 'advisory_remaining_usd'])
    if a['usd']['metered'] is not False or a['usd']['status'] != 'unknown' or a['usd']['advisory_remaining_usd'] is not None:
        invalid()

class PurposeAuthority(Authority):

    def __init__(self, *args, purpose_host, proposal_tests_enabled=False, **kwargs):
        super().__init__(*args, **kwargs)
        if type(proposal_tests_enabled) is not bool:
            raise ValueError('explicit boolean enablement required')
        self._purpose_host = purpose_host
        self._proposal_enabled = proposal_tests_enabled

    def authenticate(self, token, hive_token=None):
        principal = super().authenticate(token, hive_token)
        if 'proposal_test' in principal.grant and (not token.startswith('hc1.')):
            raise CodeError(401, 'invalid_capability', 'proposal tests require a host capability')
        return principal

    def _validate_host_claims(self, claims, hive_token=None):
        if 'proposal_test' not in claims:
            return super()._validate_host_claims(claims, hive_token)
        if not self._proposal_enabled:
            invalid()
        validate(claims, self.registration['service_id'])

    def host_live(self, claims):
        if 'proposal_test' not in claims:
            return super().host_live(claims)
        if not self._proposal_enabled:
            raise CodeError(503, 'proposal_tests_off', 'proposal tests are disabled')
        if not self.hive_url or not self.service_token or claims['exp'] <= time.time():
            raise CodeError(403, 'host_capability_inactive', 'registered Hive authority is unavailable or expired')
        try:
            validate(claims, self.registration['service_id'])
        except ValueError:
            raise CodeError(401, 'invalid_capability', 'proposal-test claims are invalid') from None
        return self._purpose_host.status(claims)

    def check_claim(self, principal, *, cancelling=False, historical=False):
        if 'proposal_test' not in principal.grant:
            return super().check_claim(principal, cancelling=cancelling, historical=historical)
        return self.host_live(principal.grant)

    def require_route(self, principal, method, path):
        p = principal.grant.get('proposal_test')
        if not p:
            raise CodeError(403, 'proposal_test_required', 'exclusive proposal test claim required')
        allowed = False
        tid = p['test_id']
        root = '/v1/proposal-tests/' + tid
        if method == 'POST' and path == '/v1/proposal-tests':
            allowed = p['stage'] == 'prepare'
        elif method == 'POST' and path == root + '/launches':
            allowed = p['stage'] == 'run'
        elif method == 'GET' and path == root:
            allowed = True
        elif method == 'POST' and re.fullmatch(re.escape(root) + '/launches/[A-Za-z0-9_.:-]{8,120}/cancel', path):
            allowed = p['stage'] in ('run', 'result')
        if not allowed:
            raise CodeError(403, 'proposal_test_route', 'claim cannot reach this route')
        status = self.host_live(principal.grant)
        if method == 'POST' and path == '/v1/proposal-tests' and (status['test']['bound_fork'] is not None):
            raise CodeError(409, 'already_bound', 'bound prepare permits only service-owned exact bind recovery')
        return status
