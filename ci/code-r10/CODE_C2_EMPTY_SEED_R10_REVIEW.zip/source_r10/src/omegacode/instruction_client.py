"""r2.13 binding: prepare person submission, verify admission, explicitly claim as controller.

The signed-in person's browser sends POST /api/requests. No operator/agent submission,
local request store, authority upgrade, retry, spawn, polling or acceptance is performed here.
"""
from __future__ import annotations
import copy
import hashlib
import re
from datetime import datetime, timezone, timedelta
from .mind_client import _operation, _reference, _money, MindProtocolError


def _until(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[Zz]|[+-]\d{2}:\d{2})',value):
        raise ValueError('until must be RFC3339 with an explicit offset')
    try:return datetime.fromisoformat(value.replace('Z','+00:00').replace('z','+00:00'))
    except ValueError:raise ValueError('invalid until timestamp') from None


def scope_origin(origin):
    """Wire references only. Bare Code digest becomes the host's sha256: spelling."""
    if not isinstance(origin,dict) or set(origin)!={'task_id','repository_id','workspace_id','scope_id','scope_digest','generation'}:
        raise ValueError('exact r2.13 origin reference fields required')
    out={k:_reference(origin[k],k) for k in ('task_id','repository_id','workspace_id','scope_id')}
    d=origin['scope_digest']
    if isinstance(d,str) and re.fullmatch(r'[a-f0-9]{64}',d):d='sha256:'+d
    if not isinstance(d,str) or not re.fullmatch(r'sha256:[a-f0-9]{64}',d):raise ValueError('scope_digest must name a SHA256 artifact')
    if type(origin['generation']) is not int or origin['generation']<1:raise ValueError('generation must be a positive integer')
    return {**out,'scope_digest':d,'generation':origin['generation']}


def prepare_person_instruction(*,operation_id,to_swarm,title,instruction,origin,limit_usd,until,template_ids,max_children,now=None):
    """Prepare once; Surface retains this exact body for retries after an unknown response."""
    if not isinstance(title,str) or not title.strip() or len(title)>200:raise ValueError('title requires 1-200 characters')
    try:title.encode('utf-8')
    except UnicodeEncodeError:raise ValueError('title must be valid UTF8 text') from None
    try:valid=isinstance(instruction,str) and bool(instruction.strip()) and len(instruction.encode('utf-8'))<=8192
    except UnicodeEncodeError:valid=False
    if not valid:raise ValueError('instruction requires nonempty text of at most 8192 UTF-8 bytes')
    amount=_money(limit_usd)
    if amount<=0:raise ValueError('request budget must be positive; host applies person/controller ceilings')
    clock=now if now is not None else datetime.now(timezone.utc)
    if not isinstance(clock,datetime) or clock.tzinfo is None:raise ValueError('aware preparation clock required')
    deadline=_until(until)
    if not clock<deadline<=clock+timedelta(hours=24):raise ValueError('new request until must be future and within 24 hours')
    if not isinstance(template_ids,list) or not 1<=len(template_ids)<=8:raise ValueError('1-8 registered team template references required')
    templates=[_reference(v,'template_id') for v in template_ids]
    if len(set(templates))!=len(templates):raise ValueError('duplicate template reference')
    if type(max_children) is not int or not 1<=max_children<=4:raise ValueError('max_children must be an integer from 1 to 4')
    return {'operation_id':_operation(operation_id),'to_swarm':_reference(to_swarm,'to_swarm'),'kind':'code',
            'title':title,'instruction':instruction,'origin':scope_origin(origin),'budget':{'limit_usd':amount},
            'lifetime':{'until':until},'lease':{'template_ids':templates,'max_children':max_children}}


def accepted_person_instruction(submission,result):
    """201 admission only. No worker acknowledgement or retained result is inferred."""
    try:
        if not isinstance(result,dict) or result.get('state')!='accepted':raise ValueError('accepted state missing')
        for k in ('request_id','receiving_goal','lease_id'):_reference(result.get(k),k)
        budget=result.get('budget')
        if not isinstance(budget,dict) or budget.get('root')!=result['request_id'] or _money(budget.get('limit_usd'))<=0 or _money(budget.get('limit_usd'))!=submission['budget']['limit_usd']:
            raise ValueError('fresh request budget root or amount mismatch')
        if _until(result.get('until'))!=_until(submission['lifetime']['until']):raise ValueError('until mismatch')
    except (ValueError,KeyError,TypeError):raise MindProtocolError('invalid r2.13 admitted request/goal/lease/budget binding') from None
    return copy.deepcopy(result)


def claim_instruction_goal(client,accepted,*,team_id,controller_id):
    """One explicit host claim; only the host authenticates/admits the controller."""
    goal=_reference(accepted.get('receiving_goal'),'receiving_goal');request=_reference(accepted.get('request_id'),'request_id')
    team_id=_reference(team_id,'team_id');controller_id=_reference(controller_id,'controller_id')
    result=client._call('POST',f'/api/agent/goals/{goal}/claim',status={200})
    if result.get('id')!=goal or result.get('swarm_id')!=team_id or result.get('claimed_by')!=controller_id or result.get('status')!='claimed' or not isinstance(result.get('binding'),dict) or result['binding'].get('request_id')!=request:
        raise MindProtocolError('claimed instruction goal/controller/request mismatch')
    return result


def read_person_instruction(client,submission,accepted,*,controller_id):
    """Read the retained r2.13.1 instruction, including after cancellation or expiry.

    Admission replay is historical. This GET's state is current; it never authorizes
    a spawn, marks delivery acknowledged or substitutes for live capability checks.
    """
    admitted=accepted_person_instruction(submission,accepted)
    controller_id=_reference(controller_id,'controller_id')
    result=client.request(admitted['request_id'])
    try:
        if result['receiving_goal']!=admitted['receiving_goal'] or result['to_swarm']!=submission['to_swarm']:
            raise ValueError('request destination mismatch')
        if result['budget']['root']!=admitted['request_id'] or _money(result['budget']['limit_usd'])!=submission['budget']['limit_usd']:
            raise ValueError('request budget mismatch')
        refs=result['context_refs']
        if not isinstance(refs,dict) or scope_origin(refs.get('origin'))!=submission['origin'] or refs['origin']!=submission['origin']:
            raise ValueError('request origin mismatch')
        instruction=refs['instruction']
        text=instruction['text']
        if text!=submission['instruction'] or instruction['digest']!='sha256:'+hashlib.sha256(text.encode('utf-8')).hexdigest():
            raise ValueError('instruction text/digest mismatch')
        lease=result['lease']
        if lease['lease_id']!=admitted['lease_id'] or lease['controller_id']!=controller_id or lease['template_ids']!=submission['lease']['template_ids'] or type(lease['max_children']) is not int or lease['max_children']!=submission['lease']['max_children'] or _until(lease['until'])!=_until(admitted['until']):
            raise ValueError('request lease mismatch')
    except (ValueError,KeyError,TypeError,AttributeError,UnicodeEncodeError):
        raise MindProtocolError('invalid r2.13.1 retained instruction/origin/lease binding') from None
    return copy.deepcopy(result)
