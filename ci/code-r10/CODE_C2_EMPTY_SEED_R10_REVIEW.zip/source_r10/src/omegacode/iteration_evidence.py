"""Read-only decision gate for Hive's iteration controller; never grants effects.

All verification/run/source reads go through Code authority. Host policy/budget
observations are required inputs, not defaults inferred from a scope or test pass.
"""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Limits:
    max_attempts: int
    max_seconds: float
    max_cost: float
    def __post_init__(self):
        if type(self.max_attempts) is not int or not 1 <= self.max_attempts <= 100:
            raise ValueError('finite bounded attempts required')
        for value in (self.max_seconds,self.max_cost):
            if type(value) not in (int,float) or not math.isfinite(value) or value <= 0:
                raise ValueError('positive finite time/cost required')

def decide(service, principal, workspace_id, verification_ids, commands, limits,
           *, attempts, elapsed_seconds, observed_cost, host_admitted, cancelled):
    """Inspect authoritative receipts. Caller must retain returned evidence.

    This gate only recommends stop/wait/repair/completion; every later effect
    still needs fresh host admission and an ordinary exact Code operation.
    """
    def result(state,reason,**evidence):
        return dict(state=state,reason=reason,effect_authority=False,
                    independent_review=False,**evidence)
    if type(host_admitted) is not bool or type(cancelled) is not bool:
        raise ValueError('explicit host admission and cancellation observations required')
    if cancelled:return result('stopped','cancelled')
    if not host_admitted:return result('paused','host_admission_unavailable')
    if type(attempts) is not int or attempts < 0:raise ValueError('invalid attempts')
    if attempts > limits.max_attempts:return result('stopped','attempt_limit')
    for value in (elapsed_seconds,observed_cost):
        if value is None:return result('paused','usage_unknown')
        if type(value) not in (int,float) or not math.isfinite(value) or value < 0:
            raise ValueError('invalid observed usage')
    if elapsed_seconds >= limits.max_seconds or observed_cost >= limits.max_cost:
        return result('stopped','time_or_cost_limit')
    if not isinstance(commands,list) or not commands or len(commands)>20:
        raise ValueError('explicit bounded acceptance commands required')
    if any(not isinstance(c,list) or not c or any(type(x) is not str or not x for x in c) for c in commands):
        raise ValueError('exact command argv required')
    if len({tuple(c) for c in commands}) != len(commands):raise ValueError('duplicate command')
    if not isinstance(verification_ids,list) or len(verification_ids)>20 or len(set(verification_ids))!=len(verification_ids):
        raise ValueError('unique bounded verification IDs required')
    # In-process composition must revalidate the retained Principal, just as
    # the HTTP layer authenticates fresh capabilities on every request.
    service._live(principal)
    ws=service.tree(principal,workspace_id)
    records=[]
    for vid in verification_ids:
        vr=service.verification(principal,vid)
        if vr['workspace_id'] != workspace_id or vr['task_id'] != principal.grant['task_id']:
            return result('paused','foreign_receipt')
        run=service.run(principal,vr['run_id'])
        if vr['generation'] != ws['generation'] or vr['tree_digest'] != ws['tree_digest']:
            return result('paused','stale_source')
        if run['generation'] != vr['generation'] or run['tree_digest'] != vr['tree_digest'] or run['argv'] != vr['argv']:
            return result('paused','receipt_binding_mismatch')
        if run['status'] in ('unknown','interrupted') or run.get('descendants_terminated') is not True:
            return result('paused','cleanup_unconfirmed')
        if run.get('input_mutations'):return result('paused','runtime_input_mutated')
        records.append((vr,run))
    # A concurrent source edit during receipt collection cannot turn an old pass green.
    service._live(principal)
    latest=service.tree(principal,workspace_id)
    if latest['generation'] != ws['generation'] or latest['tree_digest'] != ws['tree_digest']:
        return result('paused','stale_source')
    by_command={}
    for vr,run in records:
        key=tuple(vr['argv'])
        if key not in {tuple(c) for c in commands}:return result('paused','unexpected_command')
        if key in by_command: return result('paused','ambiguous_command_receipts')
        by_command[key]=(vr,run)
    evidence=dict(workspace_id=workspace_id,generation=ws['generation'],tree_digest=ws['tree_digest'],
                  verification_ids=verification_ids,run_ids=[r['id'] for _,r in records])
    if len(by_command)!=len(commands):return result('waiting','acceptance_checks_missing',**evidence)
    if all(v['status']=='passed' and r['status']=='completed' and type(r['exit_code']) is int and r['exit_code']==0 for v,r in records):
        return result('test_green','exact_current_checks_passed',**evidence)
    if attempts >= limits.max_attempts:return result('stopped','attempt_limit',**evidence)
    return result('repair_needed','checks_failed',**evidence)
