"""Person-authored editable source custody through public app context."""
import hashlib,json,math,re
from .studio_actions import read_source,execute


def decode_source_input(params):
    """Accept one bounded object or JSON-text source, preserving legacy custody."""
    if not isinstance(params,dict) or ('editable_source' in params)==('editable_source_json' in params):
        raise ValueError('Exactly one editable source object or JSON string required')
    if 'editable_source_json' in params:
        text=params['editable_source_json']
        if not isinstance(text,str):raise ValueError('Editable source JSON must be a string')
        if len(text.encode())>20*1024*1024:raise ValueError('Editable source exceeds limit')
        def object_pairs(pairs):
            obj={}
            for key,value in pairs:
                if key in obj:raise ValueError('Duplicate editable source JSON key')
                obj[key]=value
            return obj
        def finite_float(value):
            parsed=float(value)
            if not math.isfinite(parsed):raise ValueError('Nonfinite editable source JSON number')
            return parsed
        def nonfinite(value):raise ValueError('Nonfinite editable source JSON number')
        source=json.loads(text,object_pairs_hook=object_pairs,parse_float=finite_float,parse_constant=nonfinite)
    else:source=params['editable_source']
    if not isinstance(source,dict):raise ValueError('Structured editable source required')
    raw=json.dumps(source,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>20*1024*1024:raise ValueError('Editable source exceeds limit')
    return source


async def inspect_deck(ctx,raw):
    """Validate editable deck source using the pinned native tool bundle."""
    runner=getattr(ctx,'sandbox_run',None)
    if not callable(runner):raise ValueError('Host sandbox capability unavailable')
    result=await runner('inspect-deck-cli.mjs',args=['source.json'],inputs={'source.json':raw},outputs=[],runtime='node',bundle='tools',cpu_seconds=10,file_bytes=30*1024*1024,timeout=30)
    if result.get('exit')!=0 or result.get('stdout_truncated') or result.get('missing_outputs'):
        raise ValueError('Deck sandbox validation did not produce complete output')
    inspection=json.loads(result['stdout'])
    if not isinstance(inspection,dict) or inspection.get('schema')!='omega-scene-deck-inspection-1' or inspection.get('adopted') is not False:
        raise ValueError('Deck sandbox inspection differs')
    return inspection


async def inspect_model(ctx,raw):
    """Proposed native parametric-source admission, never a new acting authority."""
    if not isinstance(raw,bytes) or len(raw)>1024*1024:
        raise ValueError('Model source exceeds the 1 MB native inspection limit')
    runner=getattr(ctx,'sandbox_run',None)
    if not callable(runner):raise ValueError('Host sandbox capability unavailable')
    result=await runner('inspect-model-cli.mjs',args=['source.json'],inputs={'source.json':raw},outputs=[],runtime='node',bundle='tools',cpu_seconds=10,file_bytes=30*1024*1024,timeout=30)
    stdout=result.get('stdout') if isinstance(result,dict) else None
    if not isinstance(result,dict) or type(result.get('exit')) is not int or result.get('exit')!=0 or result.get('stdout_truncated') or result.get('missing_outputs') or not isinstance(stdout,bytes) or len(stdout)>4096:
        raise ValueError('Model sandbox validation did not produce complete output')
    inspection=json.loads(stdout.decode('utf-8'))
    if (not isinstance(inspection,dict) or inspection.get('schema')!='omega-model-inspection-1'
            or inspection.get('adopted') is not False or inspection.get('units')!='metres'
            or not isinstance(inspection.get('model_id'),str)
            or not isinstance(inspection.get('model_digest'),str)
            or not re.fullmatch(r'sha256:[0-9a-f]{64}',inspection['model_digest'])
            or not isinstance(inspection.get('metadata_digest'),str)
            or not re.fullmatch(r'sha256:[0-9a-f]{64}',inspection['metadata_digest'])):
        raise ValueError('Model sandbox inspection differs')
    submitted=json.loads(raw)
    if inspection['model_id']!=submitted['document']['id'] or inspection['model_digest']!=submitted['digest']:
        raise ValueError('Model inspection binding differs')
    return inspection


def view_source(ctx,focus):
    ref=json.loads(focus.removeprefix('studio-source:'))
    raw=read_source(ctx,ref)
    source=json.loads(raw)
    if source.get('schema') not in {'omega-studio-source-1','omega-scene-deck-1','omega-model-source-1'}:raise ValueError('Supported Studio, deck or parametric model source required')
    return {'revision':ref['digest'],'items':[{'id':'editable-source','kind':'status','label':'Editable source','meta':{'design_source':{'schema':source['schema'],'reference':ref}},'data':{'source':source,'reference':ref}}],'links':[],'focus':'editable-source'}


async def save_source(ctx,params):
    actor=getattr(ctx,'actor',None) or {}
    command=getattr(ctx,'command',None) or {}
    if actor.get('kind')!='person' or not actor.get('principal') or not command.get('record_id'):
        raise ValueError('Trusted person action required')
    source=decode_source_input(params);base=params.get('source')
    raw=json.dumps(source,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    if actor.get('recovery'):
        recorded=command.get('recorded_result')
        if not isinstance(recorded,dict) or recorded.get('status')!='done':
            raise ValueError('Unknown person save effects require custody reconciliation')
        out=recorded['data']['output']
        from .protocol import revision_ref
        revision_ref(out)
        revision=ctx.read_revision(out['artifact_id'],out['revision'])
        body=revision['body'].encode()
        if revision['digest']!=out['digest'] or 'sha256:'+hashlib.sha256(body).hexdigest()!=out['digest']:
            raise ValueError('Recorded person save revision differs')
        manifest=json.loads(body);asset=manifest['asset']
        if manifest.get('action_record')!=command['record_id'] or manifest.get('source')!=base or manifest.get('operation')!='save-source' or manifest.get('adopted') is not False or asset['sha256']!=hashlib.sha256(raw).hexdigest():
            raise ValueError('Recorded person save binding differs')
        if recorded['data'].get('assets')!=[asset] or recorded['data'].get('adopted') is not False:
            raise ValueError('Recorded person save manifest differs')
        stored=ctx.read_asset(asset['sha256'],out['artifact_id'],out['revision'])
        if stored['data']!=raw or stored['mime']!='application/json' or stored['bytes']!=len(raw):
            raise ValueError('Recorded person save asset differs')
        if base:read_source(ctx,base)
        return recorded
    deck=source.get('schema')=='omega-scene-deck-1'
    model=source.get('schema')=='omega-model-source-1'
    # Real pinned verifiers validate either Studio lineage or each editable deck scene.
    if model:model_inspection=await inspect_model(ctx,raw)
    elif deck:await inspect_deck(ctx,raw)
    else:await execute(ctx,'inspect',raw)
    if base:
        prior=json.loads(read_source(ctx,base))
        if prior.get('schema')!=source.get('schema'):raise ValueError('Save must retain the loaded source kind')
        if model:
            prior_inspection=await inspect_model(ctx,json.dumps(prior,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
            old,new=prior['document'],source['document']
            # Conservative proposed model admission: loaded identity, units and
            # metadata stay exact. This adds no brief/goal/permission authority.
            if old['id']!=new['id'] or old['units']!=new['units'] or prior_inspection['metadata_digest']!=model_inspection['metadata_digest']:
                raise ValueError('Model save must retain loaded identity, units and exact metadata')
        elif deck:
            await inspect_deck(ctx,json.dumps(prior,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
            old={slide['id']:slide['criteria'] for slide in prior['slides']}
            new={slide['id']:slide['criteria'] for slide in source['slides']}
            if old!=new:raise ValueError('Save must retain exact slide identities and hard criteria')
        else:
            if prior['current']['digest'] not in [r['digest'] for r in source['history']]:
                raise ValueError('Save must retain the loaded source revision')
            if prior['current']['scene']['criteria']!=source['current']['scene']['criteria'] or prior['project']['brief']!=source['project']['brief']:
                raise ValueError('Save must retain hard criteria and brief')
    asset={'sha256':hashlib.sha256(raw).hexdigest(),'mime':'application/json','bytes':len(raw)}
    manifest={'schema':'omega-studio-source-pointer-1','asset':asset,'originals':[asset],'source':base,'operation':'save-source','action_record':command['record_id'],'adopted':False}
    if base:read_source(ctx,base)
    published=ctx.publish('studio-source','Studio editable source',json.dumps(manifest,sort_keys=True,separators=(',',':')),assets=[{'data':raw,'mime':'application/json','name':'source.json'}],artifact_id=base['artifact_id'] if base else None,parent=base['revision'] if base else None)
    return {'status':'done','data':{'output':{k:published[k] for k in ['artifact_id','revision','digest']},'assets':published['assets'],'adopted':False}}
