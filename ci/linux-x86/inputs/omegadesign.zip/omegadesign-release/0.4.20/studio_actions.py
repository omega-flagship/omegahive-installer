"""Studio action execution through the platform's public sandbox:run API.

Inputs must first be resolved and authorized by host context. Raw caller bytes
are not accepted as evidence of source access. Output custody is a separate
host commit; this function never adopts results or impersonates a maker.
"""
import json

OPERATIONS=('init','inspect','revise','direction','reuse-identity','select','svg','ui','react','merge')


async def execute(ctx, operation, source, params=None, incoming=None):
    if operation not in OPERATIONS:raise ValueError('Unknown Studio operation')
    if not isinstance(source,bytes) or not source or len(source)>20*1024*1024:
        raise ValueError('Bounded host-resolved source bytes required')
    params={} if params is None else params
    if not isinstance(params,dict):raise ValueError('Structured parameters required')
    if operation=='merge':
        if params or not isinstance(incoming,bytes) or not incoming or len(incoming)>20*1024*1024:
            raise ValueError('Merge needs two host-resolved sources and no inline parameters')
    elif incoming is not None:raise ValueError('Incoming source belongs only to merge')
    inputs={'source.json':source,'params.json':json.dumps(params,allow_nan=False).encode()}
    suffix='svg' if operation=='svg' else 'html' if operation=='ui' else 'json'
    output='output.'+suffix
    args=[operation,'source.json']
    if operation=='merge':inputs['incoming.json']=incoming;args+=['incoming.json',output]
    elif operation in {'init','svg','ui','react'}:args+=[output]
    elif operation!='inspect':args+=['params.json',output]
    runner=getattr(ctx,'sandbox_run',None)
    if not callable(runner):raise ValueError('Host sandbox capability unavailable')
    result=await runner('scene-cli.mjs',args=args,inputs=inputs,outputs=[] if operation=='inspect' else [output],runtime='node',bundle='tools',cpu_seconds=10,file_bytes=30*1024*1024,timeout=30)
    if result.get('exit')!=0 or result.get('stdout_truncated') or result.get('missing_outputs'):
        raise ValueError('Studio sandbox execution did not produce complete output')
    if operation=='inspect':return {'inspection':json.loads(result['stdout']),'adopted':False}
    raw=result.get('outputs',{}).get(output)
    if not isinstance(raw,bytes) or not raw or len(raw)>30*1024*1024:raise ValueError('Bounded sandbox output bytes missing')
    return {'output_name':output,'bytes':raw,'custody':'host-commit-required','adopted':False}


def held(ctx, goal_id):
    import datetime
    actor=getattr(ctx,'actor',None) or {}
    if actor.get('kind') not in {'mind','agent'} or not actor.get('id'):
        raise ValueError('Trusted acting mind required')
    goal=ctx.goal(goal_id)
    now=datetime.datetime.now(datetime.timezone.utc)
    def expired(value):
        parsed=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.tzinfo is None:parsed=parsed.replace(tzinfo=datetime.timezone.utc)
        return parsed<now
    if goal.get('status')!='claimed' or goal.get('claimed_by')!=actor['id'] or goal.get('swarm_id')!=ctx.swarm_id or any(goal.get(k) and expired(goal[k]) for k in ['lease_until','deadline_at']):
        raise ValueError('Studio needs your current held goal')


def read_source(ctx, ref):
    import hashlib
    from .protocol import revision_ref
    revision_ref(ref)
    stored=ctx.read_revision(ref['artifact_id'],ref['revision'])
    raw=stored['body'].encode()
    if stored.get('digest')!=ref['digest'] or 'sha256:'+hashlib.sha256(raw).hexdigest()!=ref['digest']:
        raise ValueError('Exact source digest differs')
    pointer=json.loads(raw)
    if isinstance(pointer,dict) and pointer.get('schema')=='omega-studio-source-pointer-1':
        asset=pointer['asset'];record=ctx.read_asset(asset['sha256'],ref['artifact_id'],ref['revision']);raw=record['data']
        if record['mime']!='application/json' or record['bytes']!=asset['bytes'] or record['mime']!=asset['mime'] or len(raw)!=asset['bytes'] or hashlib.sha256(raw).hexdigest()!=asset['sha256']:
            raise ValueError('Source asset custody differs')
    elif isinstance(pointer,dict) and pointer.get('schema')=='omega-model-artifact-1':
        # A GLB delivery reopens only its exact retained parametric JSON, after
        # all declared assets are verified through original host custody.
        from .model_delivery import read_delivery
        raw=read_delivery(ctx,pointer,ref)['editable-model.json']
    if len(raw)>20*1024*1024:raise ValueError('Source too large')
    return raw


async def act(ctx, operation, params):
    import asyncio,contextlib,hashlib
    if not isinstance(params,dict) or operation not in OPERATIONS:raise ValueError('Invalid Studio action')
    command=getattr(ctx,'command',None) or {}
    if not command.get('record_id') or not command.get('idempotency_key'):raise ValueError('Host action identity required')
    goal=params['goal_id'];ref=params['source'];incoming=params.get('incoming_source')
    if operation!='merge' and incoming is not None:raise ValueError('Incoming source belongs only to merge')
    held(ctx,goal);raw=read_source(ctx,ref);other=read_source(ctx,incoming) if incoming is not None else None
    if (getattr(ctx,'actor',None) or {}).get('recovery'):
        recorded=command.get('recorded_result')
        if not isinstance(recorded,dict) or recorded.get('status')!='done':
            raise ValueError('Unknown prior effects require custody reconciliation; no replay')
        if operation!='inspect':
            data=recorded['data'];out=data['output']
            from .protocol import revision_ref
            revision_ref(out)
            revision=ctx.read_revision(out['artifact_id'],out['revision'])
            body=revision['body'].encode()
            if revision['digest']!=out['digest'] or 'sha256:'+hashlib.sha256(body).hexdigest()!=out['digest']:
                raise ValueError('Recorded output revision differs')
            manifest=json.loads(body)
            if manifest.get('action_record')!=command['record_id'] or manifest.get('source')!=ref or manifest.get('goal_id')!=goal or manifest.get('operation')!=operation or manifest.get('incoming_source')!=incoming or manifest.get('adopted') is not False:
                raise ValueError('Recorded output binding differs')
            asset=manifest['asset']
            if data.get('assets')!=[asset] or data.get('adopted') is not False:
                raise ValueError('Recorded asset manifest differs')
            stored=ctx.read_asset(asset['sha256'],out['artifact_id'],out['revision'])
            if stored['mime']!=asset['mime'] or stored['bytes']!=asset['bytes'] or len(stored['data'])!=asset['bytes'] or hashlib.sha256(stored['data']).hexdigest()!=asset['sha256']:
                raise ValueError('Recorded asset custody differs')
        held(ctx,goal);read_source(ctx,ref)
        if incoming is not None:read_source(ctx,incoming)
        return recorded
    task=asyncio.create_task(execute(ctx,operation,raw,params.get('params'),other))
    try:
        while not task.done():
            held(ctx,goal);read_source(ctx,ref)
            if incoming is not None:read_source(ctx,incoming)
            await asyncio.wait({task},timeout=.1)
        output=await task
        held(ctx,goal);read_source(ctx,ref)
        if incoming is not None:read_source(ctx,incoming)
        if operation=='inspect':return {'status':'done','data':output}
        data=output['bytes'];mime='image/svg+xml' if operation=='svg' else 'text/html' if operation=='ui' else 'application/json'
        asset={'sha256':hashlib.sha256(data).hexdigest(),'mime':mime,'bytes':len(data)}
        manifest={'schema':'omega-studio-export-1' if operation in {'svg','ui','react'} else 'omega-studio-source-pointer-1','asset':asset,'originals':[asset],'source':ref,'goal_id':goal,'operation':operation,'action_record':command['record_id'],'renderer':'app-studio','adopted':False}
        if incoming is not None:manifest['incoming_source']=incoming
        body=json.dumps(manifest,sort_keys=True,separators=(',',':'))
        published=ctx.publish('studio-export' if operation in {'svg','ui','react'} else 'studio-source','Studio '+operation,body,assets=[{'data':data,'mime':mime,'name':output['output_name']}])
        return {'status':'done','data':{'output':{k:published[k] for k in ['artifact_id','revision','digest']},'assets':published['assets'],'adopted':False}}
    finally:
        if not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):await task
