"""One disposable native run helper. No service credentials or database connection.

This trusted-native profile is not an OS sandbox. The helper confirms termination
of ordinary descendants that remain in its process group, and records uncertainty
instead of pretending it can contain deliberately detached processes.
"""

from __future__ import annotations

import base64
import errno
import fcntl
import termios
import json
import os
import pathlib
import selectors
import signal
import subprocess
import sys
import time

from .common import MAX_FILE, MAX_LOG, atomic_write, canonical, digest


def group_members(pgid: int) -> list[int]:
    inspector = subprocess.Popen(["/bin/ps", "-axo", "pid=,pgid=,stat="], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True)
    try:
        output, _ = inspector.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        inspector.kill()
        inspector.communicate()
        raise RuntimeError("process observation timed out")
    if inspector.returncode:
        raise RuntimeError("cannot observe process group")
    found = []
    for line in output.splitlines():
        parts = line.split()
        if len(parts) >= 3 and int(parts[0]) != inspector.pid and int(parts[1]) == pgid and not parts[2].startswith("Z"):
            found.append(int(parts[0]))
    return found


def birth(pid: int) -> str:
    return subprocess.run(["/bin/ps", "-p", str(pid), "-o", "lstart="], capture_output=True, text=True, timeout=5).stdout.strip()


def clean_children(pgid: int, grace=1.0):
    me = os.getpid()
    for sig, wait in ((signal.SIGTERM, grace), (signal.SIGKILL, 2.0)):
        children = [p for p in group_members(pgid) if p != me]
        for pid in children:
            try:
                os.kill(pid, sig)
            except ProcessLookupError:
                pass
        end = time.monotonic() + wait
        while time.monotonic() < end:
            if not [p for p in group_members(pgid) if p != me]:
                return True
            time.sleep(0.05)
    return not [p for p in group_members(pgid) if p != me]


def execute(root: pathlib.Path):
    spec = json.loads((root / "spec.json").read_text())
    pgid = os.getpgrp()
    atomic_write(root / "launch.json", canonical({"pid": os.getpid(), "pgid": pgid, "nonce": spec["nonce"],
                                                 "birth": birth(os.getpid()), "at": time.time()}))
    cancelled = False
    def stop(_sig, _frame):
        nonlocal cancelled
        cancelled = True
    signal.signal(signal.SIGTERM, stop)
    start, reason, returncode = time.monotonic(), "completed", None
    output_bytes = 0
    proc = None
    observed = False
    master = slave = None
    consumed = []
    confinement_observation = None
    terminal_cleanup = None
    try:
        if spec.get("confinement") is not None:
            from .confinement import validate
            confinement_observation = validate(root,spec)
        home = root / "home"
        home.mkdir(exist_ok=True)
        env = {"PATH": os.defpath, "LANG": "C.UTF-8", "HOME": str(home), "TMPDIR": str(root / "tmp"),
               "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}
        # Only the already validated pinned profile determines interpreter identity.
        if (spec.get('confinement') or {}).get('kind') == 'macos-seatbelt-python-v1':
            env['PYTHONEXECUTABLE'] = spec['confinement']['python']
        (root / "tmp").mkdir(exist_ok=True)
        if spec.get('pinned_executable_digest') is not None:
            frozen = pathlib.Path(spec['argv'][0])
            if (frozen != root / 'executor/LeaTTa' or frozen.is_symlink() or not frozen.is_file()
                    or not 0 < frozen.stat().st_size <= 128*1024*1024
                    or digest(frozen.read_bytes()) != spec['pinned_executable_digest']):
                raise ValueError('Frozen interpreter executable digest mismatch')
        if spec.get("terminal"):
            master, slave = os.openpty()
            termios.tcsetwinsize(slave, (spec["rows"], spec["cols"]))
            # This helper is a fresh session leader; the command shares its group.
            # Handlers protect the helper from terminal signals, while exec resets
            # caught signals to defaults in the child.
            for sig in (signal.SIGINT, signal.SIGQUIT, signal.SIGHUP, signal.SIGTSTP):
                signal.signal(sig, lambda *_: None)
            # Trusted PTY controller may be background after the shell takes foreground.
            signal.signal(signal.SIGTTOU, signal.SIG_IGN)
            fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
            os.tcsetpgrp(slave, pgid)
            env["TERM"] = "xterm-256color"
            launch_argv = spec['argv']
            if spec.get('pty_confinement') is not None:
                from .terminal_confinement import prepare as prepare_terminal
                launch_argv, confinement_observation = prepare_terminal(root,spec,slave)
                env['PS1'] = 'OMEGA-PROMPT> '
                env['BASH_SILENCE_DEPRECATION_WARNING'] = '1'
            proc = subprocess.Popen(launch_argv, cwd=root / "tree", env=env,
                                    stdin=slave, stdout=slave, stderr=slave)
            os.close(slave)
            slave = None
            output_fd = master
        else:
            proc = subprocess.Popen(spec["argv"], cwd=root / "tree", env=env, stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output_fd = proc.stdout.fileno()
        os.set_blocking(output_fd, False)
        selector = selectors.DefaultSelector()
        selector.register(output_fd, selectors.EVENT_READ)
        next_sequence, pending, offset = 1, None, 0
        with open(root / "output.log", "wb", buffering=0) as log:
            while True:
                if cancelled:
                    reason = "cancelled"
                    break
                if time.monotonic() - start > spec["timeout_seconds"]:
                    reason = "timed_out"
                    break
                if (root / "cancel.request").exists():
                    reason = "cancelled"
                    break
                if master is not None and proc.poll() is None:
                    if pending is None:
                        paths = sorted((root / "terminal-requests").glob(f"{next_sequence:06d}-*.json"))
                        if paths:
                            request = json.loads(paths[0].read_text())
                            if request["nonce"] != spec["nonce"] or request["sequence"] != next_sequence:
                                raise ValueError("terminal request identity mismatch")
                            pending, offset = request, 0
                    if pending is not None:
                        complete = False
                        if pending["kind"] == "resize":
                            termios.tcsetwinsize(master, (pending["payload"]["rows"], pending["payload"]["cols"]))
                            complete = True
                        else:
                            data = base64.b64decode(pending["payload"]["data_base64"], validate=True)
                            if len(data) != pending["input_bytes"] or digest(data) != pending["input_digest"]:
                                raise ValueError("terminal input digest mismatch")
                            try:
                                offset += os.write(master, data[offset:])
                            except BlockingIOError:
                                pass
                            complete = offset == len(data)
                        if complete:
                            atomic_write(root / "terminal-receipts" / (pending["id"] + ".json"),
                                         canonical({"id": pending["id"], "nonce": spec["nonce"],
                                                    "status": "consumed", "at": time.time()}))
                            consumed.append({k: pending[k] for k in ("id", "sequence", "kind", "input_bytes", "input_digest", "actor")})
                            pending, next_sequence = None, next_sequence + 1
                ready = selector.select(timeout=0.05)
                for key, _ in ready:
                    try:
                        chunk = os.read(key.fd, 65536)
                    except BlockingIOError:
                        continue
                    except OSError as exc:
                        if master is not None and exc.errno == errno.EIO:
                            chunk = b""  # Linux PTYs signal hangup this way.
                        else:
                            raise
                    if chunk:
                        room = MAX_LOG - output_bytes
                        log.write(chunk[:room])
                        output_bytes += min(room, len(chunk))
                        if len(chunk) > room:
                            reason = "output_limit"
                            break
                    elif master is not None or proc.poll() is not None:
                        selector.unregister(output_fd)
                if reason != "completed":
                    break
                if proc.poll() is not None and not selector.get_map():
                    returncode = proc.returncode
                    break
        selector.close()
        if spec.get('pty_confinement') is not None:
            from .terminal_cleanup import capture,clean
            terminal_cleanup = capture(master,proc,pgid)
        if master is not None:
            os.close(master)
            master = None
        observed = clean_children(pgid, 8.0 if spec.get("debugger_session") else 1.0)
        if terminal_cleanup is not None:
            terminal_cleanup = clean(terminal_cleanup)
            observed = observed and terminal_cleanup['observed_stopped']
        try:
            returncode = proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            observed = False
        if reason == "completed" and returncode != 0:
            reason = "failed"
    except Exception as exc:
        reason = "failed"
        atomic_write(root / "helper-error.txt", type(exc).__name__.encode())
        if spec.get('pty_confinement') is not None:
            from .terminal_cleanup import capture,clean
            terminal_cleanup = capture(master,proc,pgid)
        if master is not None:
            os.close(master)
            master = None
        try:
            observed = clean_children(pgid, 8.0 if spec.get("debugger_session") else 1.0)
        except Exception:
            observed = False
        if terminal_cleanup is not None:
            terminal_cleanup = clean(terminal_cleanup)
            observed = observed and terminal_cleanup['observed_stopped']
    finally:
        for fd in (master, slave):
            if fd is not None:
                os.close(fd)
    debugger_cleanup = None
    if spec.get('debugger_session'):
        try:
            raw = (root/'debugger-stop.json').read_bytes()
            if len(raw)>4096: raise ValueError()
            debugger_cleanup = json.loads(raw)
            if (debugger_cleanup.get('nonce') != spec['nonce'] or debugger_cleanup.get('run_id') != spec['run_id']
                    or debugger_cleanup.get('observed') is not True): raise ValueError()
            groups = debugger_cleanup['target_pgids']
            if debugger_cleanup['adapter_pid'] is not None: groups = [debugger_cleanup['adapter_pid'], *groups]
            if type(groups) is not list or any(type(p) is not int or p<=1 for p in groups): raise ValueError()
            if any(group_members(p) for p in groups): raise ValueError()
        except (OSError, ValueError, TypeError, KeyError, RuntimeError, subprocess.SubprocessError):
            observed = False
    mutations = []
    for name, entry in spec["files"].items():
        path = root / "tree" / name
        try:
            if path.is_symlink() or not path.is_file():
                mutations.append(name)
                continue
            with path.open("rb") as handle:
                data = handle.read(MAX_FILE + 1)
            if len(data) > MAX_FILE or digest(data) != entry["digest"]:
                mutations.append(name)
        except OSError:
            mutations.append(name)
    receipt = {"nonce": spec["nonce"], "run_id": spec["run_id"], "status": reason if observed else "unknown",
               "exit_code": returncode, "duration_seconds": round(time.monotonic() - start, 4),
               "descendants_terminated": observed, "input_mutations": mutations,
               "output_bytes": output_bytes, "finished_at": time.time(),
               "terminal": spec.get("terminal", False), "terminal_controls": consumed}
    if terminal_cleanup is not None: receipt["terminal_cleanup"] = terminal_cleanup
    if confinement_observation is not None: receipt["confinement_observation"] = confinement_observation
    if spec.get("debugger_session"): receipt["debugger_cleanup"] = debugger_cleanup
    atomic_write(root / "receipt.json", canonical(receipt))


if __name__ == "__main__":
    execute(pathlib.Path(sys.argv[1]).resolve())
