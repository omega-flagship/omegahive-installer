"""Revision-bound workspaces, durable operations, frozen native runs and observed receipts."""

from __future__ import annotations

import concurrent.futures
import difflib
from collections import OrderedDict
from contextlib import nullcontext
import base64
import math
import io
import json
import os
import pathlib
import platform
import signal
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import time

from .auth import Authority, Principal
from .common import (CodeError, MAX_FILE, MAX_FILES, MAX_TREE, MAX_LOG, atomic_write, canonical,
                     digest, ident, safe_path, stamp)
from .runner import birth, group_members
from .store import Store


from .suggestions import Suggestions
from .iterations import Iterations
from .run_results import RunResults


class Service(Suggestions, Iterations, RunResults):
    def __init__(self, root: pathlib.Path, operator_token: str, repositories: dict,
                 hive_url=None, transport=None, service_token=None, toolchains=None, language_servers=None, owner=None):
        self._owner = owner
        self._owner_required = owner is not None
        if owner is not None:
            from .service_lock import ServiceLock
            if type(owner) is not ServiceLock:
                raise CodeError(409,'service_owner_type','validated daemon ownership is required')
            owner.check()
            if owner.root != pathlib.Path(root).resolve():
                raise CodeError(409,'service_owner_root','daemon owner is for another data root')
        self.store = Store(root, effect_guard=self._check_owner)
        self.repositories = repositories
        self.toolchains = toolchains or {}
        self.language_servers = language_servers or {}
        self._language_slots = threading.BoundedSemaphore(2)
        self._function_scope_slots = threading.BoundedSemaphore(2)
        self._metta_search_slots = threading.BoundedSemaphore(2)
        from .language_sessions import LanguageSessions
        self._language_sessions = LanguageSessions(self.store.root)
        self._retrieval_cache = OrderedDict()
        self._retrieval_lock = threading.RLock()
        self.authority = Authority(self.store, operator_token, hive_url, transport, service_token)
        registration = self.store.root / "registration.json"
        self.authority.registration = json.loads(registration.read_text()) if registration.exists() else None
        if self.authority.registration:
            self.authority.service_token = self.authority.registration["service_token"]
        self.processes = {}
        self.run_principals = {}
        self.recovering = True
        self._stop = threading.Event()
        self._watcher = None
        self._proposal_watchdog = None
        self._proposal_unavailable_watchdog = None
        self._proposal_status_pool = None
        self._proposal_status_pending = {}
        self._proposal_status_capacity = 0
        self.reconcile()
        if owner is not None:
            self._check_owner()
            from .proposal_launch_custody import Custody
            Custody(self.store).recover_before_serving()
        self.recovering = False

    def _check_owner(self, required=False):
        if self._owner is None:
            if self._owner_required: raise CodeError(503,'service_owner_lost','daemon ownership is no longer valid')
            if required: raise CodeError(409,'service_owner_required','reserved execution requires daemon ownership')
            return
        try:
            from .service_lock import ServiceLock
            if type(self._owner) is not ServiceLock: raise ValueError('invalid owner')
            self._owner.check()
        except Exception:
            raise CodeError(503,'service_owner_lost','daemon ownership is no longer valid') from None

    def install_proposal_watchdog(self, status_adapter, *, capacity=8):
        """Internal owner setup; retained originals must fit before pool setup."""
        self._check_owner(required=True)
        if type(capacity) is not int or not 1<=capacity<=64:
            raise CodeError(409,'watchdog_capacity','owner capacity must be from1 to64')
        from .proposal_watchdog import Watchdog
        from .proposal_launch_custody import Custody
        with self.store.lock:
            self._check_owner(required=True)
            if not callable(status_adapter) or self._proposal_watchdog is not None:
                raise CodeError(409,'watchdog_adapter','one explicit owner adapter required')
            active=[r for r in self.store.list('proposal_watch_binding')
                    if Custody(self.store).get(r['id'])['state'] not in ('ended','not_started')]
            if len(active)>capacity:
                raise CodeError(429,'watchdog_capacity','restored capacity cannot cover retained originals')
            # Publish setup together; concurrent trusted setup cannot replace it.
            watchdog=Watchdog(self,status_adapter,time.monotonic)
            pool=concurrent.futures.ThreadPoolExecutor(max_workers=capacity,thread_name_prefix='code-status')
            self._proposal_watchdog=watchdog
            self._proposal_status_capacity=capacity
            self._proposal_status_pool=pool

    def bind_proposal_watchdog(self, launch_id, verified_claims):
        """Trusted adapter retains verified claims; this issues no capability."""
        self._check_owner(required=True)
        if self._proposal_watchdog is None or type(verified_claims) is not dict or not verified_claims or len(canonical(verified_claims))>16384:
            raise CodeError(409,'watchdog_adapter','installed adapter and bounded verified claims required')
        from .proposal_launch_custody import Custody
        with self.store.transaction():
            row=Custody(self.store).get(launch_id)
            existing={r['id']:r for r in self.store.list('proposal_watch_binding')}.get(launch_id)
            binding={'id':launch_id,'run_id':row['run_id'],'nonce':row['nonce'],'claims':verified_claims}
            if not existing:
                active=[r for r in self.store.list('proposal_watch_binding')
                        if Custody(self.store).get(r['id'])['state'] not in ('ended','not_started')]
                if len(active)>=self._proposal_status_capacity:
                    raise CodeError(429,'watchdog_capacity','all original monitor slots are retained')
            if existing and canonical(existing)!=canonical(binding):
                raise CodeError(409,'watchdog_claim_binding','original binding cannot change')
            self.store.put('proposal_watch_binding',binding)
        return binding

    def _proposal_watchdog_guard(self, launch_id):
        if not launch_id:return
        binding={r['id']:r for r in self.store.list('proposal_watch_binding')}.get(launch_id)
        if not binding:return  # existing ordinary human path is unchanged
        if self._proposal_watchdog is None:
            raise CodeError(503,'watchdog_adapter_unavailable','original purpose adapter is unavailable')
        status=self._proposal_watchdog.tick(launch_id,binding['claims'])
        if status['input_launch_closed']:
            raise CodeError(403,'proposal_test_withdrawn','original proposal input and replay are closed')

    def _proposal_monitor_fault(self, binding, code):
        """Diagnostic only, deduped in the existing task-scoped event journal."""
        self._check_owner(required=True)
        try:
            from .proposal_launch_custody import Custody,execution_binding
            row=Custody(self.store).get(binding['id'])
            if row['run_id']!=binding['run_id'] or row['nonce']!=binding['nonce']:return
            ws=self.store.get('workspace',execution_binding(self.store,row)['workspace_id'])
            payload={'launch_id':row['id'],'run_id':row['run_id'],'code':code}
            body=canonical(payload).decode()
            with self.store.transaction():
                if not self.store.db.execute(
                        'SELECT 1 FROM events WHERE workspace=? AND kind=? AND body=? LIMIT 1',
                        (ws['id'],'proposal.watchdog_failure',body)).fetchone():
                    self.store.emit(ws,'proposal.watchdog_failure',payload)
        except CodeError as error:
            if error.code in ('service_owner_lost','service_owner_required'):raise
            # No verified attribution: preserve the binding without inventing it.
        except (KeyError,TypeError,ValueError):
            pass

    def _poll_proposal_watchdog(self):
        if self._stop.is_set():return
        self._check_owner(required=True)
        # Missing setup is unavailability, never a cached positive status.
        # This is the existing monitor's bounded local cancellation path.
        with self.store.lock:
            if self._proposal_watchdog is None:
                bindings=self.store.list('proposal_watch_binding')
                if not bindings:return
                from .proposal_launch_custody import Custody
                if self._proposal_unavailable_watchdog is None:
                    from .proposal_watchdog import Watchdog
                    self._proposal_unavailable_watchdog=Watchdog(self,lambda *a,**k:None,time.monotonic)
                unavailable=self._proposal_unavailable_watchdog
            else:bindings=None
        if bindings is not None:
            for binding in bindings:
                # Release between originals so trusted setup is not held behind
                # the whole retained set. No unavailable tick follows setup.
                with self.store.lock:
                    if self._proposal_watchdog is not None:return
                    try:
                        row=Custody(self.store).get(binding['id'])
                        if row['state'] not in ('ended','not_started'):
                            unavailable.tick(binding['id'],binding['claims'])
                    except CodeError as error:
                        if error.code in ('service_owner_lost','service_owner_required'):raise
                        self._proposal_monitor_fault(binding,error.code)
                    except (KeyError,TypeError,ValueError):
                        self._proposal_monitor_fault(binding,'watchdog_binding_unreadable')
            return
        # Work belongs to the existing monitor, not another scheduler/goal queue.
        # One pending check per original; never queue more than owned capacity.
        from .proposal_launch_custody import Custody
        with self.store.lock:
            self._check_owner(required=True)
            bindings=self.store.list('proposal_watch_binding')
            # Used only to attribute a completed worker's expected fault.
            by_id={b['id']:b for b in bindings if type(b) is dict and type(b.get('id')) is str}
            for id_,future in list(self._proposal_status_pending.items()):
                if not future.done():continue
                try:future.result()
                except CodeError as error:
                    if error.code in ('service_owner_lost','service_owner_required'):raise
                    if id_ in by_id:self._proposal_monitor_fault(by_id[id_],error.code)
                except (KeyError,TypeError,ValueError):
                    if id_ in by_id:self._proposal_monitor_fault(by_id[id_],'watchdog_binding_unreadable')
                except Exception:pass  # uncertainty never becomes positive authority
                del self._proposal_status_pending[id_]
            for binding in bindings:
                try:
                    if binding['id'] in self._proposal_status_pending:continue
                    row=Custody(self.store).get(binding['id'])
                    if row['state'] in ('ended','not_started'):continue
                    run=self.store.get('run',row['run_id'])
                    if run.get('proposal_purpose_test') and run['status']=='prepared':
                        # Explicit purpose launch performs its own fresh check.
                        # No native process exists yet; concurrent background
                        # ticks must not supersede that admission check.
                        continue
                    if len(self._proposal_status_pending)>=self._proposal_status_capacity:break
                    self._check_owner(required=True)
                    self._proposal_status_pending[binding['id']]=self._proposal_status_pool.submit(
                        self._proposal_watchdog.tick,binding['id'],binding['claims'])
                except CodeError as error:
                    if error.code in ('service_owner_lost','service_owner_required'):raise
                    self._proposal_monitor_fault(binding,error.code)
                except (KeyError,TypeError,ValueError):
                    self._proposal_monitor_fault(binding,'watchdog_binding_unreadable')

    def proposal_settlement_evidence(self, launch_id):
        self._check_owner(required=True)
        from .proposal_settlement_evidence import capture_service
        return capture_service(self,launch_id)

    def start_monitor(self):
        if self._watcher:
            return
        def watch():
            while not self._stop.wait(0.2):
                try:
                    self.reconcile()
                    self._poll_proposal_watchdog()
                except Exception:
                    # A corrupt/missing receipt is represented by reconcile, not a false completion.
                    continue
        self._watcher = threading.Thread(target=watch, name="omegacode-reconcile", daemon=True)
        self._watcher.start()

    def close(self):
        self._stop.set()
        if self._watcher:
            self._watcher.join(timeout=5)
        if self._proposal_status_pool is not None:
            # Installed owner adapter must honor its real bounded deadline. A
            # timed-out future is not proof its provider thread has stopped.
            self._proposal_status_pool.shutdown(wait=True,cancel_futures=True)
        self._language_sessions.close()
        self.authority.client.close()
        self.store.close()

    def _live(self, principal):
        self.authority.host_live(principal.grant)
        row = self.store.db.execute("SELECT revoked FROM grants WHERE id=?", (principal.grant["id"],)).fetchone()
        if not row or row[0] or principal.grant["exp"] <= time.time():
            raise CodeError(401, "invalid_capability", "capability is expired or revoked")

    def workspace(self, id_: str):
        return self.store.get("workspace", id_)

    def task_workspaces(self, principal, task_id):
        """Discover only capability-visible source snapshots, never other tasks' metadata."""
        if principal.operator or task_id != principal.grant.get('task_id'):
            raise CodeError(403, 'task_forbidden', 'workspace discovery requires a coding capability for this task')
        self._live(principal)
        g = principal.grant
        bound_workspace = None
        scope_workspace = None
        # Human collaboration can be workspace-bound. Resolve that existing scope
        # before ordinary authorization; never weaken scope(None) for discovery.
        if g.get('iss') == 'hive' and g['kind'] == 'human' and g.get('grant_id'):
            grants = self.authority._call(self.authority.service_token, 'GET', f'/api/goals/{task_id}/grants', list_result=True)
            grant = next((x for x in grants if isinstance(x, dict) and x.get('id') == g['grant_id']), None)
            if grant and grant.get('active') is True and grant.get('principal') == principal.actor and grant.get('goal_id') == task_id:
                bound_workspace = grant.get('workspace_id')
                if bound_workspace:
                    scope_workspace = self.workspace(bound_workspace)
        self._authorize(principal, 'read', scope_workspace, {})
        self.authority.gate(principal, 'read', {'task_id': task_id, 'repository_id': g['repository_id'],
                                               'workspace_id': bound_workspace, 'operation': 'workspace-discovery'})
        with self.store.lock:
            rows = self.store.db.execute("""SELECT body FROM records WHERE kind='workspace'
                AND json_extract(body,'$.task_id')=? AND json_extract(body,'$.swarm_id')=?
                AND json_extract(body,'$.repository_id')=? AND (? IS NULL OR id=?) ORDER BY rowid LIMIT 1001""",
                (task_id, g['swarm_id'], g['repository_id'], bound_workspace, bound_workspace)).fetchall()
            workspaces = [json.loads(row[0]) for row in rows]
        if len(workspaces) > 1000:
            raise CodeError(413, 'discovery_limit', 'task workspace discovery exceeds 1000 results; no partial list returned')
        result = []
        for ws in workspaces:
            self._authorize(principal, 'read', ws, {})
            result.append({**{key: ws[key] for key in ('id', 'repository_id', 'base_commit', 'generation', 'tree_digest', 'created_at')},
                           'status': 'ready'})
        self._live(principal)
        self._authorize(principal, 'read', scope_workspace, {})
        return result

    def manifest(self, workspace: dict, hash_=None):
        return json.loads(self.store.read_blob(hash_ or workspace["tree_digest"], workspace["id"]))

    def _manifest(self, files: dict, ws: str):
        if len(files) > MAX_FILES or sum(v["size"] for v in files.values()) > MAX_TREE:
            raise CodeError(413, "workspace_limit", "workspace exceeds file or byte limits")
        return self.store.blob(canonical({"files": dict(sorted(files.items()))}), ws, "tree")

    def _materialize(self, files: dict, ws: str, root: pathlib.Path):
        root.mkdir(parents=True, exist_ok=False, mode=0o700)
        for name, meta in files.items():
            name = safe_path(name)
            data = self.store.read_blob(meta["digest"], ws)
            atomic_write(root / name, data, 0o700 if meta["executable"] else 0o600)

    def _repository_files(self, repository_id, commit, workspace):
        config = self.repositories.get(repository_id)
        if not config:
            raise CodeError(403, "repository_unregistered", "repository is not registered by the operator")
        source = pathlib.Path(config["path"]).resolve()
        if not source.is_dir():
            raise CodeError(404, "repository_missing", "registered repository is missing")
        result = subprocess.run(["git", "-C", str(source), "rev-parse", "--verify", "--end-of-options", f"{commit}^{{commit}}"],
                                capture_output=True, text=True, timeout=15)
        if result.returncode:
            raise CodeError(400, "invalid_revision", "base revision does not resolve to a commit")
        resolved = result.stdout.strip()
        entries = subprocess.run(["git", "-C", str(source), "ls-tree", "-r", "-z", resolved],
                                 capture_output=True, timeout=15)
        if entries.returncode or any(row.startswith(b"160000 ") for row in entries.stdout.split(b"\0")):
            raise CodeError(403, "submodule_unqualified", "submodule contents require a separately pinned repository registration")
        archive = subprocess.Popen(["git", "-C", str(source), "archive", "--format=tar", resolved],
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        timer = threading.Timer(30, archive.kill)
        timer.start()
        try:
            data = archive.stdout.read(MAX_TREE * 2 + 1)
            if len(data) > MAX_TREE * 2:
                archive.kill()
            archive.wait(timeout=5)
        finally:
            timer.cancel()
            if archive.poll() is None:
                archive.kill()
                archive.wait(timeout=5)
            archive.stdout.close()
        if archive.returncode or len(data) > MAX_TREE * 2:
            raise CodeError(413, "repository_limit", "repository archive is unavailable or too large")
        files = {}
        if not entries.stdout:
            # A valid empty tree can produce a PAX global header without any file entries.
            # Python's tar reader rejects that stream; the independent ls-tree inventory
            # is authoritative for the empty result.
            return files, resolved
        if not data:
            raise CodeError(503, "repository_archive_invalid", "repository archive is unavailable")
        with tarfile.open(fileobj=io.BytesIO(data)) as handle:
            for entry in handle:
                if entry.isdir():
                    continue
                name = safe_path(entry.name)
                if not entry.isfile() or entry.size > MAX_FILE:
                    raise CodeError(403, "repository_entry_refused", "symlinks, special files and oversized inputs are refused")
                data = handle.extractfile(entry).read(MAX_FILE + 1)
                files[name] = {"digest": self.store.blob(data, workspace, "source"), "size": len(data),
                               "executable": bool(entry.mode & 0o111)}
        return files, resolved

    def _authorize(self, principal, action, workspace, payload):
        self.authority.scope(principal, action, workspace, payload)
        self.authority.check_claim(principal, cancelling=action == "cancel",
                                   historical=action in ("read", "events", "artifact"))

    def _operation(self, principal, action, workspace, payload, apply, validate_result=None):
        self._check_owner()
        self._authorize(principal, action, workspace, payload)
        op = {"action": action, "workspace_id": workspace["id"] if workspace else None,
              **{k: v for k, v in payload.items() if k != "approval_id"}}
        with self.store.transaction():
            self._live(principal)
            cached = self.store.cached(principal.actor, payload["operation_id"], op)
            if cached is not None:
                if validate_result:
                    validate_result(cached)
                return cached
            self.authority.gate(principal, action, dict(op, approval_id=payload.get("approval_id")))
            self._check_owner()
            result = apply()
            # Preparation can take time. Expired/revoked authority must not commit a late write.
            self._live(principal)
            self.authority.scope(principal, action, workspace, payload)
            self.authority.check_claim(principal, cancelling=action == "cancel")
            if validate_result:
                validate_result(result)
            self.store.remember(principal.actor, payload["operation_id"], op, result)
            return result

    def create_workspace(self, principal, payload):
        self.authority.scope(principal, "workspace")
        g = principal.grant
        if payload["repository_id"] != g["repository_id"] or payload["task_id"] != g["task_id"]:
            raise CodeError(403, "task_forbidden", "creation is outside capability task/repository scope")
        def apply():
            id_ = ident("ws")
            files, base = self._repository_files(payload["repository_id"], payload["base_commit"], id_)
            tree = self._manifest(files, id_)
            ws = {"id": id_, "repository_id": payload["repository_id"], "task_id": payload["task_id"],
                  "swarm_id": g["swarm_id"], "base_commit": base, "base_ref":payload["base_commit"], "generation": 1, "tree_digest": tree,
                  "base_tree_digest": tree, "created_by": principal.actor, "created_at": stamp(),
                  "profile": "trusted-native", "environment": {"python": sys.version, "platform": platform.platform()},
                  "history": [{"generation": 1, "tree_digest": tree, "author": principal.actor}]}
            self.store.put("workspace", ws)
            self.store.emit(ws, "workspace.created", ws)
            return ws
        return self._operation(principal, "workspace", None, payload, apply)

    def _fork_snapshot(self, current, actor):
        """Internal copy under caller's transaction/admission; no grant or row publication."""
        ws_id=current['id']
        id_ = ident('ws')
        # Preserve the original Git baseline separately from the edited fork origin.
        for tree_digest in {current['tree_digest'],current['base_tree_digest']}:
            manifest = self.manifest(current, tree_digest)
            for meta in manifest['files'].values():
                data = self.store.read_blob(meta['digest'], ws_id)
                self.store.blob(data, id_, 'source')
            if self._manifest(manifest['files'], id_) != tree_digest:
                raise CodeError(409, 'fork_integrity', 'fork manifest differs from retained parent')
        ws = {key:current[key] for key in ('repository_id','task_id','swarm_id','base_commit','base_ref','base_tree_digest','profile','environment')}
        ws.update(id=id_,generation=1,tree_digest=current['tree_digest'],created_by=actor,created_at=stamp(),
                  fork_origin={'workspace_id':ws_id,'generation':current['generation'],'tree_digest':current['tree_digest']},
                  history=[{'generation':1,'tree_digest':current['tree_digest'],'author':actor}])
        return ws

    def fork_workspace(self, principal, ws_id, payload):
        """Isolated saved candidate, same task authority/budget; no Git/source writes."""
        parent = self.workspace(ws_id)
        self._authorize(principal, 'read', parent, {})
        self._authorize(principal, 'workspace', None, {})
        if principal.grant['paths']:
            raise CodeError(403, 'fork_scope', 'workspace fork requires full task source scope')
        operation = {**payload, 'mutation':'fork-workspace'}
        def apply():
            current = self.workspace(ws_id)
            self._authorize(principal, 'read', current, {})
            self._fresh(current, payload['expected_generation'], payload['expected_tree_digest'])
            if sum(w['task_id']==current['task_id'] and w['swarm_id']==current['swarm_id'] for w in self.store.list('workspace')) >= 1000:
                raise CodeError(429, 'workspace_budget', 'task workspace limit reached')
            _, context = self._context_files(principal, current)
            ws = self._fork_snapshot(current, principal.actor)
            self._authorize(principal, 'workspace', ws, {})
            self._context_current(self.workspace(ws_id), context)
            self.store.put('workspace', ws)
            self.store.emit(ws, 'workspace.forked', ws)
            return ws
        return self._operation(principal, 'workspace', parent, operation, apply)

    def read(self, principal, ws_id, path, expected_generation=None):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {"paths": [path]})
        self._fresh(ws, expected_generation)
        name = safe_path(path)
        entry = self.manifest(ws)["files"].get(name)
        if not entry:
            raise CodeError(404, "file_missing", "file is not in this workspace generation")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "path": name, "generation": ws["generation"]})
        data = self.store.read_blob(entry["digest"], ws_id)
        try:
            content = data.decode()
        except UnicodeDecodeError:
            raise CodeError(415, "binary_file", "file is binary; use the scoped artifact endpoint")
        return {"path": name, "content": content, "digest": entry["digest"], "generation": ws["generation"],
                "tree_digest": ws["tree_digest"]}

    def metta_diagnostics(self, principal, ws_id, path, expected_generation=None):
        # Reuse file-read authority, immutable blob custody and generation checks.
        file = self.read(principal, ws_id, path, expected_generation)
        if not file["path"].lower().endswith(".metta"):
            raise CodeError(415, "language_unsupported", "delimiter diagnostics support .metta files only")
        from .metta_syntax import scan
        result = scan(file["content"])
        result.update(workspace_id=ws_id, path=file["path"], generation=file["generation"],
                      tree_digest=file["tree_digest"], source_digest=file["digest"])
        return result

    def language_server_inventory(self, principal, ws_id):
        from .language import METHODS
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "language_scope", "language inventory requires full workspace read scope")
        self.authority.gate(principal, "read", {"workspace_id":ws_id, "resource":"language-servers"})
        servers = [{"id":id_, "language_id":c.get("language_id"), "extensions":c.get("extensions", []),
                    "configured":True, "executable_present": bool(c.get("argv") and pathlib.Path(c["argv"][0]).is_file()),
                    "qualified":False, "position_profile":c.get("position_encoding", "utf-16")}
                   for id_,c in sorted(self.language_servers.items())]
        return {"servers":servers, "workspace_id":ws_id, "generation":ws["generation"],
                "selection_policy":"operator configuration only", "request_features":list(METHODS)}

    def _context_files(self, principal, ws):
        from .context_selection import select
        return select(self.manifest(ws)['files'], self.repositories[ws['repository_id']],
                      lambda value: self.store.read_blob(value, ws['id']), self.store.root, principal.grant['paths'])

    def _context_current(self, ws, expected):
        from .context_selection import binding
        actual = digest(canonical(binding(self.manifest(ws)['files'], self.repositories[ws['repository_id']])))
        if actual != expected['policy_digest']:
            raise CodeError(409, 'context_policy_changed', 'context policy changed; request fresh analysis')

    def language_query(self, principal, ws_id, payload):
        from .language import METHODS, offset, query, runtime_identity
        self._check_owner()
        try:payload=json.loads(canonical(payload))
        except (UnicodeError,TypeError,ValueError):raise CodeError(400,'language_payload','language query requires canonical UTF-8 data') from None
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "language_scope", "language analysis requires full workspace read scope")
        self._fresh(ws, payload["expected_generation"], payload["expected_tree_digest"])
        config = self.language_servers.get(payload["server_id"])
        if not config:
            raise CodeError(415, "language_unsupported", "language server is not configured by the operator")
        path = safe_path(payload["path"])
        if payload["feature"] not in METHODS or type(payload.get("limit", 50)) is not int or not 1 <= payload.get("limit",50) <= 100:
            raise CodeError(400, "language_feature", "language feature or limit is unsupported")
        if pathlib.Path(path).suffix not in config.get("extensions", []):
            raise CodeError(415, "language_unsupported", "configured server does not support this file extension")
        manifest=self.manifest(ws)['files']
        from .language_buffers import new_files,new_view
        additions,new_texts,new_writes=new_files(manifest,payload.get('draft_files'),payload.get('buffers'),payload.get('buffer_revision'))
        if len(manifest)+len(additions)>MAX_FILES:raise CodeError(413,'draft_file_limit','analysis file count exceeds limit')
        from .context_selection import select
        files,context=select({**manifest,**additions},self.repositories[ws['repository_id']],
            lambda value:self.store.read_blob(value,ws_id),self.store.root,principal.grant['paths'])
        if path not in manifest and path not in additions:
            raise CodeError(404,'file_missing','language target is not in this snapshot or new draft view')
        if path not in files:raise CodeError(403,'context_excluded','language target unavailable under context selection')
        saved_files={name:entry for name,entry in files.items() if name in manifest}
        texts={}
        for name,entry in saved_files.items():
            try:texts[name]=self.store.read_blob(entry['digest'],ws_id).decode()
            except UnicodeDecodeError:pass
        if path in saved_files and path not in texts:raise CodeError(415,'binary_file','language target is not UTF-8 source')
        files,texts,buffer_view,buffer_writes=new_view(files,texts,payload.get('buffers'),payload.get('buffer_revision'),new_texts,new_writes)
        def materialize_view(target):
            self._check_owner()
            try:
                self._materialize(saved_files,ws_id,target)
                for name,data in buffer_writes.items():atomic_write(target/name,data)
            except OSError:raise CodeError(503,'language_materialization','language snapshot could not be prepared') from None
        if payload["feature"] not in ("diagnostics", "document_symbols"):
            offset(texts[path], {"line":payload["line"], "character":payload["character"]})
        if payload["feature"] == "rename":
            name = payload.get("new_name")
            if not isinstance(name, str) or not name or len(name) > 160 or not name.isidentifier():
                raise CodeError(400, "rename_name", "rename needs a valid identifier")
            if config.get("language_id") == "python":
                import keyword
                if keyword.iskeyword(name): raise CodeError(400, "rename_name", "Python keyword cannot be a name")
        elif payload.get("new_name") is not None:
            raise CodeError(400, "rename_name", "new_name is only valid for rename")
        gate_payload={k:v for k,v in payload.items() if k not in ('buffers','buffer_revision','draft_files')}
        if buffer_view is not None:gate_payload['buffer_view']=buffer_view
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource":"language-query", **gate_payload})
        if not self._language_slots.acquire(blocking=False):
            raise CodeError(429, "language_busy", "language query concurrency limit reached")
        try:
            with self.store.transaction():
                self._live(principal)
                row = self.store.db.execute("SELECT body FROM records WHERE kind='language_budget' AND id=?", (ws_id,)).fetchone()
                count = json.loads(row[0])["count"] if row else 0
                maximum = self.repositories[ws["repository_id"]].get("max_task_language_queries", 200)
                if count >= maximum: raise CodeError(429, "language_budget", "workspace language query budget exhausted")
                self.store.put("language_budget", {"id":ws_id, "count":count+1})
            persistent = config.get('persistent_sessions_enabled', False)
            if type(persistent) is not bool:
                raise CodeError(503, 'language_configuration', 'persistent_sessions_enabled must be a boolean')
            if persistent:
                frozen_config = json.loads(canonical(config))
                _, executable, executable_digest, config_digest, _, _ = runtime_identity(frozen_config)
                server_id = payload['server_id']
                def validate_session():
                    self._check_owner()
                    self._live(principal)
                    self._authorize(principal, 'read', ws, {})
                    self._fresh(self.workspace(ws_id), ws['generation'], ws['tree_digest'])
                    self._context_current(ws, context)
                    runtime_identity(frozen_config)
                    if (digest(canonical(self.language_servers.get(server_id))) != config_digest
                            or digest(executable.read_bytes()) != executable_digest):
                        raise CodeError(409, 'language_runtime_changed', 'language session runtime changed')
                scope = (principal.grant['id'], ws_id, payload['server_id'])
                key = digest(canonical({'grant':principal.grant,'scope':scope,'generation':ws['generation'],
                    'tree_digest':ws['tree_digest'],'context_policy':context['policy_digest'],
                    'config_digest':config_digest,'executable_digest':executable_digest,'buffer_view':buffer_view}))
                with self._language_sessions.lease(key, scope, validate_session,
                        materialize_view) as (entry, reused):
                    result = query(entry['root'], frozen_config, payload, files, texts, session=entry['state'])
                    result['session'] = {'id':entry['id'],'reused':reused,'persistent':True,
                        'query_count':entry['queries'],'max_queries':self._language_sessions.MAX_QUERIES,
                        'idle_seconds':self._language_sessions.IDLE_SECONDS,
                        'lifetime_seconds':self._language_sessions.LIFETIME_SECONDS,
                        'resumable_after_restart':False}
            else:
                with tempfile.TemporaryDirectory(prefix="language-", dir=self.store.root) as directory:
                    root = pathlib.Path(directory)
                    for name in ("home", "tmp"): (root/name).mkdir(mode=0o700)
                    materialize_view(root/"tree")
                    result = query(root, config, payload, files, texts)
            self._check_owner()
            self._live(principal)
            if digest(canonical(self.language_servers.get(payload['server_id']))) != result['server_config_digest']:
                raise CodeError(409, 'language_runtime_changed', 'configured language server changed during query')
            if runtime_identity(config)[2] != result['server_executable_digest']:
                raise CodeError(409,'language_runtime_changed','language executable changed after query')
            self._authorize(principal, "read", ws, {})
            self._fresh(self.workspace(ws_id), ws["generation"], ws["tree_digest"])
            self._context_current(ws, context)
            result.update(context_selection=context, workspace_id=ws_id, generation=ws["generation"], tree_digest=ws["tree_digest"],
                          path=path, source_digest=saved_files[path]["digest"] if path in saved_files else None, server_id=payload["server_id"],
                          feature=payload["feature"], profile="trusted-native-analysis", applied=False,
                          unsaved_buffers=buffer_view is not None, observed_at=stamp())
            if buffer_view is not None:result.update(buffer_view=buffer_view,analyzed_source_digest=files[path]["digest"],saved_apply_eligible=False)
            if len(canonical(result)) > 4 * MAX_FILE:
                raise CodeError(413, "language_limit", "normalized language response exceeds limit")
            if payload["feature"] == "rename" and buffer_view is None:
                edits = result["result"]["edits"]
                if not edits: raise CodeError(422, "rename_unavailable", "rename returned no source changes")
                with self.store.transaction():
                    self._live(principal)
                    self._fresh(self.workspace(ws_id), ws["generation"], ws["tree_digest"])
                    self._context_current(ws, context)
                    blob = self.store.blob(canonical(edits), ws_id, "language-rename-preview")
                    preview = {"id":ident("rp"), "workspace_id":ws_id, "generation":ws["generation"],
                               "tree_digest":ws["tree_digest"], "edit_digest":blob, "paths":[e["path"] for e in edits],
                               "server_id":payload["server_id"], "server_config_digest":result["server_config_digest"],
                               "server_executable_digest":result['server_executable_digest'],
                               "server_runtime_files_digest":result.get('server_runtime_files_digest'),
                               "server_dependency_identity_profile":result.get('server_dependency_identity_profile','not-pinned'),
                               "context_selection":context, "created_by":principal.actor, "created_at":stamp()}
                    self.store.put("rename_preview", preview)
                result["result"].update(preview_id=preview["id"], edit_digest=blob, paths=preview["paths"])
            if payload['feature'] == 'completion' and buffer_view is None:
                with self.store.transaction():
                    self._live(principal)
                    self._authorize(principal, 'read', ws, {})
                    self._fresh(self.workspace(ws_id), ws['generation'], ws['tree_digest'])
                    self._context_current(ws, context)
                    blob = self.store.blob(canonical(result['result']), ws_id, 'language-completion-query')
                    saved = {'id': ident('cq'), 'workspace_id': ws_id, 'generation': ws['generation'],
                             'tree_digest': ws['tree_digest'], 'path': path, 'source_digest': files[path]['digest'],
                             'result_digest': blob, 'server_id': payload['server_id'],
                             'server_config_digest': result['server_config_digest'],
                             'server_executable_digest':result['server_executable_digest'],
                             'server_runtime_files_digest':result.get('server_runtime_files_digest'),
                             'server_dependency_identity_profile':result.get('server_dependency_identity_profile','not-pinned'),
                             'context_selection': context, 'language_id': config.get('language_id'),
                             'position': {'line': payload['line'], 'character': payload['character']},
                             'created_by': principal.actor, 'created_at': stamp()}
                    self.store.put('completion_query', saved)
                result.update(completion_query_id=saved['id'], completion_result_digest=blob)
            return result
        finally:
            self._language_slots.release()

    def apply_language_rename(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        self._authorize(principal, "edit", ws, {})
        self._live(principal)
        preview = self.store.get("rename_preview", payload["preview_id"])
        if preview["workspace_id"] != ws_id:
            raise CodeError(403, "rename_scope", "rename preview belongs to another workspace")
        if preview["generation"] != payload["expected_generation"] or preview["tree_digest"] != payload["expected_tree_digest"]:
            raise CodeError(409, "stale_workspace", "rename preview does not match the expected workspace")
        if preview.get("context_selection"): self._context_current(ws, preview["context_selection"])
        edits = json.loads(self.store.read_blob(preview["edit_digest"], ws_id))
        context_binding = {"context_policy_digest":preview["context_selection"]["policy_digest"]} if preview.get("context_selection") else {}
        return self.edit(principal, ws_id, {**payload, **context_binding, "mutation":"language-rename", "preview_digest":preview["edit_digest"], "edits":edits})

    def completion_preview(self, principal, ws_id, payload):
        from .completion import preview
        from .snippet_preview import template_preview
        profile = payload.get("profile")
        if profile not in (None, "editor-snippet-template-v1"):
            raise CodeError(422, "completion_profile", "unsupported completion preview profile")
        ws = self.workspace(ws_id)
        self._authorize(principal, 'read', ws, {})
        self._live(principal)
        if principal.grant['paths']:
            raise CodeError(403, 'completion_scope', 'completion preview requires full workspace read scope')
        query = self.store.get('completion_query', payload['query_id'])
        if query['workspace_id'] != ws_id:
            raise CodeError(403, 'completion_scope', 'completion query belongs to another workspace')
        self._fresh(ws, payload['expected_generation'], payload['expected_tree_digest'])
        self._fresh(ws, query['generation'], query['tree_digest'])
        self.authority.gate(principal, 'read', {'workspace_id': ws_id, 'resource': 'completion-preview', **payload})
        if query.get('context_selection'): self._context_current(ws, query['context_selection'])
        data = json.loads(self.store.read_blob(query['result_digest'], ws_id))
        index = payload['item_index']
        if type(index) is not int or not 0 <= index < len(data['items']):
            raise CodeError(422, 'completion_selection', 'select an exact retained completion item index')
        text = self.store.read_blob(query['source_digest'], ws_id).decode()
        build = template_preview if profile else preview
        result = build(data['items'][index], text, query['position'], query['language_id'],
                         query['path'], query['source_digest'], payload.get('selection_mode'))
        with self.store.transaction():
            self._live(principal)
            self._authorize(principal, 'read', ws, {})
            self._fresh(self.workspace(ws_id), query['generation'], query['tree_digest'])
            encoded = canonical(result['template'] if profile else result['edits'])
            key = {'query': query['id'], 'item': index, 'edit': digest(encoded)}
            if profile: key['profile'] = profile
            if result['selection_mode'] is not None: key['selection_mode'] = result['selection_mode']
            if query.get('context_selection'): self._context_current(ws, query['context_selection'])
            preview_id = 'cp_' + digest(canonical(key))
            row = self.store.db.execute("SELECT body FROM records WHERE kind='completion_preview' AND id=?", (preview_id,)).fetchone()
            if row:
                saved = json.loads(row[0])
                return {**saved, **result, 'label': data['items'][index].get('label'),
                        'profile': profile or 'saved-source-completion-preview', 'provider_generated_next_edit': False}
            budget_row = self.store.db.execute("SELECT body FROM records WHERE kind='completion_preview_budget' AND id=?", (ws_id,)).fetchone()
            budget = json.loads(budget_row[0]) if budget_row else {'id': ws_id, 'bytes': 0, 'count': 0}
            maximum = self.repositories[ws['repository_id']].get('max_task_completion_preview_bytes', 8 * MAX_FILE)
            if type(maximum) is not int or not 1 <= maximum <= 64 * MAX_FILE:
                raise CodeError(503, 'completion_configuration', 'completion preview byte budget is invalid')
            if budget['bytes'] + len(encoded) > maximum or budget['count'] >= 200:
                raise CodeError(429, 'completion_budget', 'retained completion preview budget exhausted')
            blob = self.store.blob(encoded, ws_id, 'language-completion-preview')
            budget.update(bytes=budget['bytes'] + len(encoded), count=budget['count'] + 1)
            self.store.put('completion_preview_budget', budget)
            saved = {'id': preview_id, 'workspace_id': ws_id, 'generation': query['generation'],
                     'tree_digest': query['tree_digest'], 'edit_digest': blob, 'path': query['path'],
                     'source_digest': query['source_digest'], 'query_id': query['id'],
                     'item_index': index, 'selection_mode': result['selection_mode'], 'result_digest': query['result_digest'],
                     'context_selection': query.get('context_selection'),
                     'server_id': query['server_id'], 'server_config_digest': query['server_config_digest'],
                     'created_by': principal.actor, 'created_at': stamp()}
            if profile:
                saved['profile'] = profile
                saved['template_digest'] = saved.pop('edit_digest')
            self.store.put('completion_preview', saved)
        return {**saved, **result, 'label': data['items'][index].get('label'),
                'profile': profile or 'saved-source-completion-preview', 'provider_generated_next_edit': False}

    def apply_completion_preview(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        self._authorize(principal, 'edit', ws, {})
        self._live(principal)
        saved = self.store.get('completion_preview', payload['preview_id'])
        if saved['workspace_id'] != ws_id:
            raise CodeError(403, 'completion_scope', 'completion preview belongs to another workspace')
        if saved.get('profile') == 'editor-snippet-template-v1':
            raise CodeError(422, 'completion_editor_only', 'snippet template is an unsaved editor preparation, not a saved-source application')
        if saved['generation'] != payload['expected_generation'] or saved['tree_digest'] != payload['expected_tree_digest']:
            raise CodeError(409, 'stale_workspace', 'completion preview differs from expected saved source')
        if saved.get('context_selection'): self._context_current(ws, saved['context_selection'])
        edits = json.loads(self.store.read_blob(saved['edit_digest'], ws_id))
        selection = {'completion_selection_mode': saved['selection_mode']} if saved.get('selection_mode') is not None else {}
        context_binding = {'context_policy_digest':saved['context_selection']['policy_digest']} if saved.get('context_selection') else {}
        return self.edit(principal, ws_id, {**payload, **selection, **context_binding, 'mutation': 'language-completion',
                         'query_id': saved['query_id'], 'item_index': saved['item_index'],
                         'result_digest': saved['result_digest'], 'preview_digest': saved['edit_digest'], 'edits': edits})

    @staticmethod
    def _fresh(ws, generation, tree_digest=None):
        if generation is not None and generation != ws["generation"] or tree_digest is not None and tree_digest != ws["tree_digest"]:
            raise CodeError(409, "stale_workspace", "workspace changed; read current generation before editing or running")

    def tree(self, principal, ws_id, expected_generation=None):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._fresh(ws, expected_generation)
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "tree", "generation": ws["generation"]})
        paths = principal.grant["paths"]
        files = [{"path": name, **entry} for name, entry in self.manifest(ws)["files"].items()
                 if not paths or any(name == p or name.startswith(p.rstrip("/") + "/") for p in paths)]
        return {"workspace_id": ws_id, "generation": ws["generation"], "tree_digest": ws["tree_digest"], "files": files}

    def repository_facts(self, principal, ws_id, expected_generation, expected_tree_digest, changed_paths=None,
                         base_generation=None, base_tree_digest=None):
        """Read-only, grant-filtered syntax index over an exact workspace snapshot."""
        from dataclasses import asdict
        from .repository_facts import build_repository_facts, changed_impact
        ws = self.workspace(ws_id)
        self._authorize(principal, 'read', ws, {})
        self._fresh(ws, expected_generation, expected_tree_digest)
        historical = base_generation is not None or base_tree_digest is not None
        if historical:
            if (type(base_generation) is not int or base_generation < 1 or
                    not isinstance(base_tree_digest, str) or changed_paths is not None):
                raise CodeError(400, 'facts_base', 'historical impact needs exact base generation/tree and no changed_paths')
            if principal.grant['paths']:
                raise CodeError(403, 'facts_scope', 'historical impact requires full workspace path scope')
            if not any(row['generation']==base_generation and row['tree_digest']==base_tree_digest for row in ws['history']):
                raise CodeError(403, 'facts_base', 'base is not a retained generation of this workspace')
        self.authority.gate(principal, 'read', {'workspace_id':ws_id, 'resource':'repository-facts',
                                              'generation':ws['generation'],
                                              **({'base_generation':base_generation,'base_tree_digest':base_tree_digest} if historical else {})})
        selected, context = self._context_files(principal, ws)
        files = {name:entry for name,entry in selected.items() if name.endswith('.py')}
        if len(files) > 512 or sum(entry['size'] for entry in files.values()) > 8*1024*1024:
            raise CodeError(413, 'facts_limit', 'authorized Python source map exceeds analysis limits')
        if changed_paths is not None and (not isinstance(changed_paths,list) or len(changed_paths)>512
                                         or any(not isinstance(p,str) or p not in files for p in changed_paths)):
            raise CodeError(400, 'facts_paths', 'impact inputs must be visible Python paths in this snapshot')
        try:
            graph = build_repository_facts({name:self.store.read_blob(entry['digest'],ws_id) for name,entry in files.items()})
        except ValueError as error:
            raise CodeError(413, 'facts_limit', str(error)) from None
        result = {**asdict(graph), 'snapshot_digest':graph.digest, 'workspace_id':ws_id,
                  'generation':ws['generation'], 'tree_digest':ws['tree_digest'],
                  'context_selection':context, 'scope':'authorized context-selected Python files only', 'complete_runtime_impact':False,
                  'semantic_search':False, 'symbolic_publication':False}
        if changed_paths is not None:
            result['impact'] = graph.dependents(set(changed_paths))
        if historical:
            base_ws = {**ws, 'generation':base_generation, 'tree_digest':base_tree_digest}
            base_selected, base_context = self._context_files(principal, base_ws)
            if base_context['policy_digest'] != context['policy_digest']:
                raise CodeError(409, 'facts_context_changed', 'historical impact requires matching context rules')
            base_files = {name:entry for name,entry in base_selected.items() if name.endswith('.py')}
            if len(base_files) > 512 or sum(entry['size'] for entry in base_files.values()) > 8*1024*1024:
                raise CodeError(413, 'facts_limit', 'historical Python source map exceeds analysis limits')
            try:
                before = build_repository_facts({name:self.store.read_blob(entry['digest'],ws_id) for name,entry in base_files.items()})
            except ValueError as error:
                raise CodeError(413, 'facts_limit', str(error)) from None
            result['impact'] = changed_impact(before, graph)
            result['impact']['meaning'] = 'potential reverse-import closure across both exact authorized Python snapshots'
            result['base'] = {'generation':base_generation, 'tree_digest':base_tree_digest,
                              'snapshot_digest':before.digest, 'context_selection':base_context}
            self._context_current(base_ws, base_context)
        if len(canonical(result)) > 4*MAX_FILE:
            raise CodeError(413, 'facts_limit', 'syntax fact response exceeds limit')
        self._live(principal)
        self._authorize(principal, 'read', ws, {})
        self._fresh(self.workspace(ws_id), expected_generation, expected_tree_digest)
        self._context_current(ws, context)
        return result

    def repository_retrieval(self, principal, ws_id, expected_generation, expected_tree_digest,
                             query, limit=20, path_prefix=None, fact_kind=None, fact_target=None,
                             corpus='python', runtime_id=None):
        """Read-only local retrieval; vector/provider disclosure is not exposed."""
        if corpus=='text':
            return self._text_retrieval(principal,ws_id,expected_generation,expected_tree_digest,
                                        query,limit,path_prefix,fact_kind,fact_target,runtime_id)
        if corpus=='metta':
            return self._metta_retrieval(principal,ws_id,expected_generation,expected_tree_digest,
                                         query,limit,path_prefix,fact_kind,fact_target,runtime_id)
        if corpus!='python' or runtime_id is not None:
            raise CodeError(400,'retrieval_input','Python retrieval does not accept a native runtime')
        from .repository_retrieval import build_retrieval_index
        from . import retrieval_cache
        facts = self.repository_facts(principal, ws_id, expected_generation, expected_tree_digest)
        ws = self.workspace(ws_id)
        self._fresh(ws, expected_generation, expected_tree_digest)
        self.authority.gate(principal, 'read', {'workspace_id':ws_id,'resource':'repository-retrieval',
                                              'generation':ws['generation'],'query':query})
        try:
            sources = {path:self.store.read_blob(digest,ws_id) for path,digest in facts['sources']}
            cache_key = (ws_id, principal.actor, tuple(sorted(principal.grant['paths'])))
            if facts['context_selection']['active']: cache_key += (facts['context_selection']['policy_digest'],)
            with self._retrieval_lock:
                previous = self._retrieval_cache.get(cache_key)
            restored = False
            if previous is None:
                previous = retrieval_cache.load(self.store, cache_key)
                restored = previous is not None
            cache_refused = False
            try:
                index = build_retrieval_index(sources, previous=previous)
            except ValueError:
                if previous is None:
                    raise
                # Cache corruption/incompatibility cannot replace source or make
                # an otherwise valid current query unavailable.
                previous = None
                restored = False
                cache_refused = True
                index = build_retrieval_index(sources)
            before = {} if previous is None else dict(previous.graph.sources)
            after = dict(index.graph.sources)
            unchanged = {p for p in after if before.get(p)==after[p]}
            incremental = {'previous_index_digest':previous.digest if previous else None,
                'reused_chunks':sum(c.path in unchanged for c in index.chunks),
                'rebuilt_chunks':sum(c.path not in unchanged for c in index.chunks),
                'added_paths':sorted(after.keys()-before.keys()),
                'changed_paths':sorted(p for p in after.keys() & before.keys() if before[p]!=after[p]),
                'removed_paths':sorted(before.keys()-after.keys()),
                'syntax_facts_rebuilt':True, 'persistent':True, 'restored_after_memory_miss':restored,
                'cache_refused_rebuilt':cache_refused}
            result = index.search(query,limit=limit,path_prefix=path_prefix,fact_kind=fact_kind,fact_target=fact_target)
        except ValueError as error:
            raise CodeError(400, 'retrieval_input', str(error)) from None
        result.update(workspace_id=ws_id,generation=ws['generation'],tree_digest=ws['tree_digest'],
                      context_selection=facts['context_selection'], scope='authorized context-selected Python source only',provider_calls=0,symbolic_publication=False,
                      incremental=incremental)
        if len(canonical(result))>4*MAX_FILE:
            raise CodeError(413,'retrieval_limit','retrieval response exceeds limit')
        self._live(principal)
        self._authorize(principal,'read',ws,{})
        self._fresh(self.workspace(ws_id),expected_generation,expected_tree_digest)
        self._context_current(ws, facts['context_selection'])
        # Cache admission follows final authority/freshness checks. Entries never
        # supply file authority and remain separated by actor and exact path scope.
        with self._retrieval_lock:
            size = sum(len(c.text.encode()) for c in index.chunks)
            if size <= 8*1024*1024:
                self._retrieval_cache[cache_key] = index
                self._retrieval_cache.move_to_end(cache_key)
                while len(self._retrieval_cache)>4 or sum(len(c.text.encode()) for i in self._retrieval_cache.values() for c in i.chunks)>8*1024*1024:
                    self._retrieval_cache.popitem(last=False)
            result['incremental']['persisted_current_index'] = retrieval_cache.save(self.store, cache_key, index)
        return result

    def _text_retrieval(self, principal, ws_id, generation, tree, query, limit, prefix, kind, target, runtime_id):
        from .repository_text_retrieval import build_text_index
        if any(v is not None for v in (kind,target,runtime_id)):
            raise CodeError(400,'retrieval_input','text retrieval has no syntax predicates or native runtime')
        ws=self.workspace(ws_id)
        self._authorize(principal,'read',ws,{})
        self._fresh(ws,generation,tree)
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'repository-retrieval','generation':generation,'query':query,'corpus':'text'})
        selected,context=self._context_files(principal,ws)
        if len(selected)>512 or sum(e['size'] for e in selected.values())>8*1024*1024:
            raise CodeError(413,'retrieval_limit','authorized text source map exceeds analysis limits')
        try:
            index=build_text_index({path:self.store.read_blob(e['digest'],ws_id) for path,e in selected.items()})
            result=index.search(query,limit=limit,path_prefix=prefix)
        except ValueError as error:
            raise CodeError(400,'retrieval_input',str(error)) from None
        result.update(workspace_id=ws_id,generation=generation,tree_digest=tree,
                      context_selection=context,scope='authorized context-selected UTF-8 text only',
                      corpus='text',provider_calls=0,symbolic_publication=False,
                      incremental={'persistent':False,'meaning':'fresh bounded text index; no cached source authority'})
        if len(canonical(result))>4*MAX_FILE:
            raise CodeError(413,'retrieval_limit','text retrieval response exceeds limit')
        self._live(principal)
        self._authorize(principal,'read',ws,{})
        self._fresh(self.workspace(ws_id),generation,tree)
        self._context_current(ws,context)
        return result

    def _metta_retrieval(self, principal, ws_id, generation, tree, query, limit, prefix, kind, target, runtime_id):
        ws=self.workspace(ws_id)
        self._authorize(principal,'read',ws,{})
        self._fresh(ws,generation,tree)
        if (type(query) is not str or not query or len(query.encode())>256 or type(limit) is not int or not 1<=limit<=100
                or target is not None or kind not in (None,'expression_head','equation_subject','type_declared_subject')
                or (prefix is not None and (type(prefix) is not str or len(prefix)>1000))):
            raise CodeError(400,'retrieval_input','MeTTa search needs an exact bounded symbol and no fact_target')
        config=self.toolchains.get(runtime_id) if type(runtime_id) is str else None
        if not config or config.get('kind')!='hyperon' or config.get('source_search_enabled') is not True:
            raise CodeError(409,'retrieval_runtime_unavailable','MeTTa source search needs an operator-enabled Hyperon profile')
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'repository-retrieval','generation':generation,'corpus':'metta','query':query,'runtime_id':runtime_id})
        selected,context=self._context_files(principal,ws)
        files={p:e for p,e in selected.items() if p.endswith('.metta')}
        if len(files)>128 or any(e['size']>1024*1024 for e in files.values()) or sum(e['size'] for e in files.values())>8*1024*1024:
            raise CodeError(413,'retrieval_limit','authorized MeTTa corpus exceeds parser bounds')
        if prefix is not None and not any(p.startswith(prefix) for p in files):
            raise CodeError(400,'retrieval_input','prefix must select authorized MeTTa source')
        if not self._metta_search_slots.acquire(blocking=False):
            raise CodeError(429,'retrieval_busy','MeTTa parser slots are busy')
        try:
            from .metta_facts_process import search
            result=search({p:self.store.read_blob(e['digest'],ws_id) for p,e in files.items()},kind or 'expression_head',query,config,self.store.root)
        except (ValueError,OSError,subprocess.SubprocessError) as error:
            raise CodeError(409,'retrieval_unavailable',str(error)) from None
        finally:self._metta_search_slots.release()
        matches=[r for r in result.pop('matches') if prefix is None or r['path'].startswith(prefix)]
        result.update(results=matches[:limit],total_matches=len(matches),truncated=len(matches)>limit,
                      workspace_id=ws_id,generation=generation,tree_digest=tree,context_selection=context,
                      corpus='metta',runtime_id=runtime_id,protocol='omegacode-metta-source-retrieval-v1',
                      scope='authorized context-selected MeTTa syntax only',provider_calls=0,
                      semantic_search=False,symbolic_publication=False)
        if len(canonical(result))>4*MAX_FILE:raise CodeError(413,'retrieval_limit','MeTTa response bound')
        self._live(principal)
        self._authorize(principal,'read',ws,{})
        self._fresh(self.workspace(ws_id),generation,tree)
        self._context_current(ws,context)
        return result

    def search(self, principal, ws_id, query, limit=100):
        ws = self.workspace(ws_id)
        self._authorize(principal, "search", ws, {})
        self.authority.gate(principal, "search", {"workspace_id": ws_id, "query": query, "generation": ws["generation"]})
        files, context = self._context_files(principal, ws)
        matches = []
        allowed = principal.grant["paths"]
        for name, entry in files.items():
            if allowed and not any(name == p or name.startswith(p + "/") for p in allowed):
                continue
            try:
                text = self.store.read_blob(entry["digest"], ws_id).decode()
            except UnicodeDecodeError:
                continue
            for n, line in enumerate(text.splitlines(), 1):
                if query in line or query in name:
                    matches.append({"path": name, "line": n, "text": line[:1000], "digest": entry["digest"]})
                    if len(matches) >= limit:
                        self._live(principal)
                        self._context_current(ws, context)
                        return {"matches": matches, "truncated": True, "generation": ws["generation"], "context_selection":context}
        self._live(principal)
        self._context_current(ws, context)
        return {"matches": matches, "truncated": False, "generation": ws["generation"], "context_selection":context}

    def edit(self, principal, ws_id, payload, *, _after_edit=None, _action="edit", _create_paths=(), _authorization_paths=None):
        ws = self.workspace(ws_id)
        edit_paths=[e["path"] for e in payload["edits"]]
        if _authorization_paths is None:
            operation_paths=edit_paths
        else:
            if (type(_authorization_paths) not in (tuple,list) or len(_authorization_paths)>100 or
                    any(type(path) is not str for path in _authorization_paths) or
                    not set(edit_paths)<=set(_authorization_paths)):
                raise CodeError(400,'edit_authorization_paths','bounded authorization paths must contain all edits')
            operation_paths=sorted(set(_authorization_paths))
        payload = dict(payload, paths=operation_paths)
        def apply():
            current = self.workspace(ws_id)
            if payload.get("context_policy_digest") is not None:
                self._context_current(current, {"policy_digest":payload["context_policy_digest"]})
            self._fresh(current, payload["expected_generation"], payload["expected_tree_digest"])
            files = dict(self.manifest(current)["files"])
            if _create_paths:
                from .language_buffers import validate_new_path_namespace
                from .context_selection import select_destinations
                if (type(_create_paths) not in (tuple,list) or len(_create_paths)>100 or
                        any(type(path) is not str for path in _create_paths)):
                    raise CodeError(400,'suggestion_create_paths','bounded exact create paths are required')
                actual_new={e['path'] for e in payload['edits'] if e.get('expected_digest') is None and e.get('content') is not None}
                if actual_new!=set(_create_paths):
                    raise CodeError(409,'suggestion_create_paths','retained create units differ from the selected edit descriptors')
                validate_new_path_namespace(files,_create_paths,max_paths=100)
                destinations, _ = select_destinations(
                    files,self.repositories[current['repository_id']],
                    lambda value:self.store.read_blob(value,current['id']),self.store.root,
                    list(_create_paths),principal.grant['paths'])
                if any(destinations.get(path,{}).get('allowed') is not True for path in _create_paths):
                    raise CodeError(403,'context_excluded','create destination is excluded or unavailable under saved context policy')
            seen = set()
            for edit in payload["edits"]:
                name = safe_path(edit["path"])
                if name in seen:
                    raise CodeError(400, "duplicate_edit", "each path may appear only once")
                seen.add(name)
                old = files.get(name)
                if (old["digest"] if old else None) != edit.get("expected_digest"):
                    raise CodeError(409, "stale_file", "file content digest differs from expected_digest")
                if edit["content"] is None:
                    if not old:
                        raise CodeError(404, "file_missing", "cannot delete a missing file")
                    del files[name]
                else:
                    data = edit["content"].encode()
                    if len(data) > MAX_FILE:
                        raise CodeError(413, "file_limit", "file exceeds the coding artifact size limit")
                    files[name] = {"digest": self.store.blob(data, ws_id, "source"), "size": len(data),
                                   "executable": old["executable"] if old else False}
            # Reject file/directory collisions before a run ever materializes this tree.
            names = set(files)
            if any(str(p) in names for n in names for p in pathlib.PurePosixPath(n).parents if str(p) != "."):
                raise CodeError(400, "path_collision", "a file cannot also be a directory")
            tree = self._manifest(files, ws_id)
            changes = {"id": ident("cs"), "workspace_id": ws_id, "task_id": current["task_id"], "author": principal.actor,
                       "base_commit": current["base_commit"], "before_digest": current["tree_digest"], "tree_digest": tree,
                       "generation": current["generation"] + 1, "paths": sorted(seen), "created_at": stamp()}
            changes["diff_digest"] = self.store.blob(self._diff(current, current["tree_digest"], tree).encode(), ws_id, "diff")
            current.update(generation=changes["generation"], tree_digest=tree)
            current["history"].append({"generation": current["generation"], "tree_digest": tree, "author": principal.actor,
                                       "change_id": changes["id"]})
            self.store.put("workspace", current)
            self.store.put("change", changes)
            self.store.emit(current, "workspace.edited", changes)
            result = {"workspace": current, "change": changes}
            if _after_edit is not None:
                result = _after_edit(result)
            return result
        return self._operation(principal, _action, ws, payload, apply)

    def _diff(self, ws, before, after):
        a, b = self.manifest(ws, before)["files"], self.manifest(ws, after)["files"]
        result = []
        for path in sorted(set(a) | set(b)):
            if a.get(path) == b.get(path):
                continue
            def lines(files):
                return self.store.read_blob(files[path]["digest"], ws["id"]).decode(errors="replace").splitlines(keepends=True) if path in files else []
            result.extend(difflib.unified_diff(lines(a), lines(b), fromfile="a/" + path, tofile="b/" + path))
        return "".join(result)

    def changes(self, principal, ws_id):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        records = [c for c in self.store.list("change") if c["workspace_id"] == ws_id]
        # Path-limited capabilities cannot read a full diff through this shortcut.
        if principal.grant["paths"]:
            raise CodeError(403, "full_diff_forbidden", "full diff requires unrestricted file-read scope")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "changes", "generation": ws["generation"]})
        return {"workspace": ws, "changes": records, "diff": self._diff(ws, ws["base_tree_digest"], ws["tree_digest"])}

    def git_context(self, principal, ws_id):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "review_scope", "repository context needs full workspace read scope")
        self.authority.gate(principal, "read", {"workspace_id":ws_id, "resource":"git-context"})
        source = pathlib.Path(self.repositories[ws["repository_id"]]["path"])
        def git(args):
            result = subprocess.run(["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(source), *args],
                                    capture_output=True, timeout=10, env={"PATH":os.defpath, "LANG":"C.UTF-8", "GIT_CONFIG_NOSYSTEM":"1"})
            if result.returncode: return None
            if len(result.stdout)>65536: raise CodeError(413,"git_context_limit","repository context output exceeds limit")
            return result.stdout.decode("utf-8", "replace").strip()
        try:
            # References are observations of the registered source, never a checkout command.
            head = git(["rev-parse", "--verify", "HEAD"])
            branch = git(["symbolic-ref", "--quiet", "--short", "HEAD"])
            refs = git(["for-each-ref", "--count=201", "--format=%(refname)", "--points-at="+ws["base_commit"], "refs/heads", "refs/tags"])
        except (OSError, subprocess.TimeoutExpired):
            raise CodeError(503,"git_context_unavailable","registered source Git context could not be observed") from None
        self._live(principal)
        return {"workspace_id":ws_id,"generation":ws["generation"],"tree_digest":ws["tree_digest"],
                "base_commit":ws["base_commit"],"base_ref":ws.get("base_ref"), "base_refs":refs.splitlines()[:200] if refs else [], "base_refs_truncated":bool(refs and len(refs.splitlines())>200),
                "observed_source_head":head,"observed_source_branch":branch,"source_matches_base":head==ws["base_commit"] if head else None,
                "workspace_kind":"manifest-snapshot", "git_index":False,"mutated_source":False,"observed_at":stamp()}

    def create_git_export(self, principal, ws_id, payload):
        from .git_export import export, validate_branch
        import tempfile
        ws=self.workspace(ws_id)
        self._authorize(principal,"read",ws,{})
        self._live(principal)
        if principal.grant["paths"]: raise CodeError(403,"git_export_scope","Git export needs full workspace read/edit scope")
        validate_branch(payload["branch"])
        history_mode=payload.get('history_mode','snapshot')
        if history_mode not in ('snapshot','original'):
            raise CodeError(400,'git_history_mode','unknown Git history mode')
        if history_mode=='original' and self.repositories[ws['repository_id']].get('history_export_enabled') is not True:
            raise CodeError(403,'git_history_disabled','original history requires explicit operator repository opt-in')
        self.authority.gate(principal,"read",{"workspace_id":ws_id,"resource":"git-export-source"})
        exact={**payload,"mutation":"git-review-export","source_base_commit":ws["base_commit"],
               "base_tree_digest":ws["base_tree_digest"]}
        def apply():
            current=self.workspace(ws_id)
            self._fresh(current,payload["expected_generation"],payload["expected_tree_digest"])
            records=[r for r in self.store.list("git_export") if r["workspace_id"]==ws_id]
            config=self.repositories[current["repository_id"]]
            if len(records)>=config.get("max_workspace_git_exports",20):
                raise CodeError(429,"git_export_budget","workspace Git export count exhausted")
            before=self.manifest(current,current["base_tree_digest"])["files"]
            after=self.manifest(current)["files"]
            total=sum(e["size"] for files in (before,after) for e in files.values())
            free=shutil.disk_usage(self.store.root).free
            if free<max(512*1024**2,total*8) or (free<10*1024**3 and total>1024**2):
                raise CodeError(507,"git_export_disk","insufficient free disk for this Git review export")
            when=time.time()
            with tempfile.TemporaryDirectory(prefix="git-export-",dir=self.store.root) as scratch:
                result=export(pathlib.Path(scratch),before,after,
                    lambda files,root:self._materialize(files,ws_id,root),payload["branch"],payload["message"],principal.actor,when,
                    source=pathlib.Path(config['path']).resolve() if history_mode=='original' else None,
                    parent=current['base_commit'] if history_mode=='original' else None)
            self._fresh(self.workspace(ws_id),current["generation"],current["tree_digest"])
            size=len(result["patch"])+len(result["bundle"])
            if size+sum(r["patch_bytes"]+r["bundle_bytes"] for r in records)>config.get("max_workspace_git_export_bytes",200*1024**2):
                raise CodeError(429,"git_export_budget","workspace Git export byte budget exhausted")
            record={"id":ident("gx"),"workspace_id":ws_id,"generation":current["generation"],"tree_digest":current["tree_digest"],
                "source_base_commit":current["base_commit"],"base_tree_digest":current["base_tree_digest"],
                "history_kind":"original-parent-ancestry" if history_mode=='original' else "reconstructed-manifest-snapshots",
                "original_history_included":history_mode=='original',
                "source_repository_mutated":False,"published":False,"author":principal.actor,"created_at":stamp(),
                "committed_at":int(when),"message":payload["message"],
                **{k:v for k,v in result.items() if k not in ("patch","bundle")},
                "patch_bytes":len(result["patch"]),"bundle_bytes":len(result["bundle"]),
                "paths":sorted(p for p in set(before)|set(after) if before.get(p)!=after.get(p))}
            record["patch_digest"]=self.store.blob(result["patch"],ws_id,"git-review-patch")
            record["bundle_digest"]=self.store.blob(result["bundle"],ws_id,"git-review-bundle")
            self.store.put("git_export",record)
            self.store.emit(current,"git.export-created",record)
            return record
        return self._operation(principal,"edit",ws,exact,apply)

    def git_export(self, principal, ws_id, export_id, verify_bundle=True):
        ws=self.workspace(ws_id)
        self._authorize(principal,"read",ws,{})
        self._live(principal)
        if principal.grant["paths"]: raise CodeError(403,"git_export_scope","Git export needs full workspace read scope")
        self.authority.gate(principal,"read",{"workspace_id":ws_id,"resource":"git-export","export_id":export_id})
        record=self.store.get("git_export",export_id)
        if record["workspace_id"]!=ws_id: raise CodeError(403,"git_export_scope","export belongs to another workspace")
        # Metadata alone does not prove preserved artifact bytes.
        for key in (("patch","bundle") if verify_bundle else ("patch",)):
            data=self.store.read_blob(record[key+"_digest"],ws_id)
            if len(data)!=record[key+"_bytes"]: raise CodeError(409,"artifact_corrupt","Git export artifact size differs")
        self._live(principal)
        return {**record,"currency":"current" if record["tree_digest"]==ws["tree_digest"] and record["generation"]==ws["generation"] else "stale"}

    def git_export_patch(self, principal, ws_id, export_id, after=0, limit=1024):
        record=self.git_export(principal,ws_id,export_id,verify_bundle=False)
        if type(after) is not int or after<0 or type(limit) is not int or not 1<=limit<=16384:
            raise CodeError(400,"git_export_cursor","invalid patch byte cursor")
        data=self.store.read_blob(record["patch_digest"],ws_id)
        if after>len(data): raise CodeError(416,"git_export_cursor","patch cursor beyond artifact")
        chunk=data[after:after+limit]
        try: text=chunk.decode()
        except UnicodeDecodeError: text=None
        self._live(principal)
        return {"export_id":export_id,"workspace_id":ws_id,"generation":record["generation"],"tree_digest":record["tree_digest"],
            "currency":record["currency"],"digest":record["patch_digest"],"encoding":"base64","data":base64.b64encode(chunk).decode(),
            "content_text":text,"after":after,"cursor":after+len(chunk),"size_bytes":len(data),"eof":after+len(chunk)==len(data)}

    def create_source_review(self, principal, ws_id, payload):
        from .review import plan
        ws=self.workspace(ws_id)
        self._authorize(principal,"read",ws,{})
        self._live(principal)
        if principal.grant["paths"]: raise CodeError(403,"review_scope","source review needs full workspace read scope")
        self._fresh(ws,payload["expected_generation"],payload["expected_tree_digest"])
        target=payload.get("target","base")
        if target=="base":
            if payload.get("checkpoint_id"): raise CodeError(400,"review_target","base review cannot name a checkpoint")
            after_digest=ws["base_tree_digest"]
        elif target=="checkpoint":
            if not payload.get("checkpoint_id"): raise CodeError(400,"review_target","checkpoint review needs a checkpoint ID")
            cp=self.store.get("checkpoint",payload["checkpoint_id"])
            if cp["workspace_id"]!=ws_id: raise CodeError(403,"checkpoint_forbidden","checkpoint belongs to another workspace")
            after_digest=cp["tree_digest"]
        else: raise CodeError(400,"review_target","unsupported review target")
        self.authority.gate(principal,"read",{"workspace_id":ws_id,"resource":"source-review",**payload})
        before=self.manifest(ws)["files"]; after=self.manifest(ws,after_digest)["files"]
        id_=ident("review")
        hunks=plan(id_,before,after,lambda hash_:self.store.read_blob(hash_,ws_id))
        with self.store.transaction():
            self._live(principal)
            self._authorize(principal,"read",ws,{})
            self._fresh(self.workspace(ws_id),ws["generation"],ws["tree_digest"])
            if sum(r["workspace_id"]==ws_id for r in self.store.list("source_review"))>=200:
                raise CodeError(429,"review_budget","workspace source review budget exhausted")
            hash_=self.store.blob(canonical(hunks),ws_id,"source-review-hunks")
            record={"id":id_,"workspace_id":ws_id,"generation":ws["generation"],"tree_digest":ws["tree_digest"],
                    "target_tree_digest":after_digest,"target":target,"checkpoint_id":payload.get("checkpoint_id"),
                    "hunks_digest":hash_,"hunk_count":len(hunks),"paths":sorted({h["path"] for h in hunks}),
                    "author":principal.actor,"created_at":stamp(),"applied":False,"direction":"current-to-target"}
            self.store.put("source_review",record)
        return record

    def source_review(self, principal, ws_id, review_id, after=0, limit=20):
        ws=self.workspace(ws_id)
        self._authorize(principal,"read",ws,{})
        self._live(principal)
        if principal.grant["paths"]: raise CodeError(403,"review_scope","source review needs full workspace read scope")
        self.authority.gate(principal,"read",{"workspace_id":ws_id,"resource":"source-review","review_id":review_id})
        record=self.store.get("source_review",review_id)
        if record["workspace_id"]!=ws_id: raise CodeError(403,"review_scope","review belongs to another workspace")
        if type(after) is not int or after<0 or type(limit) is not int or not 1<=limit<=100:
            raise CodeError(400,"review_cursor","invalid review hunk cursor")
        hunks=json.loads(self.store.read_blob(record["hunks_digest"],ws_id))
        if after>len(hunks): raise CodeError(416,"review_cursor","review cursor beyond hunk count")
        page=hunks[after:after+limit];cursor=after+len(page)
        self._live(principal)
        return {**record,"hunks":page,"after":after,"cursor":cursor,"eof":cursor==len(hunks),
                "currency":"current" if ws["generation"]==record["generation"] and ws["tree_digest"]==record["tree_digest"] else "stale"}

    def source_review_content(self, principal, ws_id, review_id, hunk_id, side, after=0, limit=1024):
        from .review import side_bytes
        record=self.source_review(principal,ws_id,review_id,0,1)
        if side not in ("before","after") or type(after) is not int or after<0 or type(limit) is not int or not 1<=limit<=16384:
            raise CodeError(400,"review_cursor","invalid review content side/cursor")
        hunks=json.loads(self.store.read_blob(record["hunks_digest"],ws_id))
        hunk=next((h for h in hunks if h["id"]==hunk_id),None)
        if hunk is None: raise CodeError(403,"review_selection","hunk is not in this review")
        data=side_bytes(hunk,side,lambda hash_:self.store.read_blob(hash_,ws_id))
        if after>len(data): raise CodeError(416,"review_cursor","review content cursor beyond source")
        chunk=data[after:after+limit]
        try: text=chunk.decode()
        except UnicodeDecodeError: text=None
        self._live(principal)
        return {"review_id":review_id,"hunk_id":hunk_id,"path":hunk["path"],"kind":hunk["kind"],"side":side,
                "generation":record["generation"],"tree_digest":record["tree_digest"],"currency":record["currency"],
                "encoding":"base64","data":base64.b64encode(chunk).decode(),"content_text":text,
                "after":after,"cursor":after+len(chunk),"size_bytes":len(data),"eof":after+len(chunk)==len(data)}

    def apply_source_review(self, principal, ws_id, payload):
        from .review import selected_files
        ws=self.workspace(ws_id)
        self._authorize(principal,"edit",ws,{})
        self._live(principal)
        record=self.store.get("source_review",payload["review_id"])
        if record["workspace_id"]!=ws_id: raise CodeError(403,"review_scope","review belongs to another workspace")
        if record["generation"]!=payload["expected_generation"] or record["tree_digest"]!=payload["expected_tree_digest"]:
            raise CodeError(409,"stale_workspace","selection does not match the reviewed source generation")
        hunks=json.loads(self.store.read_blob(record["hunks_digest"],ws_id))
        selected=payload["hunk_ids"]
        if not selected or len(selected)!=len(set(selected)): raise CodeError(400,"review_selection","select unique nonempty hunk IDs")
        index={h["id"]:h for h in hunks}
        if not set(selected)<=set(index): raise CodeError(403,"review_selection","selected hunk is not in this review")
        paths=sorted({index[id_]["path"] for id_ in selected})
        exact={**payload,"hunk_ids":sorted(selected),"mutation":"source-review-selection","review_digest":record["hunks_digest"],
               "target_tree_digest":record["target_tree_digest"],"paths":paths}
        def apply():
            current=self.workspace(ws_id)
            self._fresh(current,payload["expected_generation"],payload["expected_tree_digest"])
            before=self.manifest(current)["files"];after=self.manifest(current,record["target_tree_digest"])["files"]
            files,paths_=selected_files(hunks,selected,before,after,lambda h:self.store.read_blob(h,ws_id),
                                        lambda data:self.store.blob(data,ws_id,"source"))
            tree=self._manifest(files,ws_id)
            change={"id":ident("cs"),"workspace_id":ws_id,"task_id":current["task_id"],"author":principal.actor,
                    "base_commit":current["base_commit"],"before_digest":current["tree_digest"],"tree_digest":tree,
                    "generation":current["generation"]+1,"paths":paths_,"review_id":record["id"],
                    "hunk_ids":sorted(selected),"file_changes":{p:{"before":before.get(p),"after":files.get(p)} for p in paths_},"created_at":stamp()}
            change["diff_digest"]=self.store.blob(self._diff(current,current["tree_digest"],tree).encode(),ws_id,"diff")
            current.update(generation=change["generation"],tree_digest=tree)
            current["history"].append({"generation":current["generation"],"tree_digest":tree,"author":principal.actor,
                                       "change_id":change["id"],"review_id":record["id"]})
            self.store.put("workspace",current);self.store.put("change",change)
            self.store.emit(current,"workspace.review-applied",change)
            return {"workspace":current,"change":change}
        return self._operation(principal,"edit",ws,exact,apply)

    def _fork_merge_sources(self, principal, destination, checkpoints):
        from .workspace_ancestry import common_base, ancestor
        sources = {destination['id']:destination}
        def get(id_):
            ws = self.workspace(id_)
            sources[id_] = ws
            return ws
        authorize = lambda ws:self._authorize(principal,'read',ws,{})
        base, incoming_checkpoint = checkpoints
        incoming = get(incoming_checkpoint['workspace_id'])
        ancestor(incoming,incoming_checkpoint,get,authorize)
        ancestry = common_base(destination,incoming,base,get,authorize)
        bindings=[]
        for ws in sources.values():
            _, context = self._context_files(principal,ws)
            bindings.append({'workspace_id':ws['id'],'context_selection':context})
        return sources, bindings, ancestry

    def _fork_merge_live(self, principal, record):
        for binding in record.get('source_bindings',[]):
            ws=self.workspace(binding['workspace_id'])
            self._authorize(principal,'read',ws,{})
            self._context_current(ws,binding['context_selection'])
        self._live(principal)

    def create_merge_preview(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        self._authorize(principal, 'read', ws, {})
        self._live(principal)
        if principal.grant['paths']:
            raise CodeError(403, 'merge_scope', 'merge preview needs full workspace read scope')
        checkpoints = [self.store.get('checkpoint', payload[k]) for k in ('base_checkpoint_id', 'incoming_checkpoint_id')]
        if all(cp['workspace_id'] == ws_id for cp in checkpoints) and payload.get('operation_id') is None:
            return self._create_merge_preview(principal, ws_id, payload)
        # Copying source custody publishes bytes through destination artifacts.
        # Read authorizes comparison; checkpoint authorizes retained capture.
        self._authorize(principal, 'checkpoint', ws, {})
        self._fork_merge_sources(principal, ws, checkpoints)
        operation_id = payload.get('operation_id')
        if not isinstance(operation_id, str) or not 1 <= len(operation_id) <= 160:
            raise CodeError(400, 'merge_capture_operation', 'cross-fork capture needs an original operation_id')
        exact = {**payload, 'mutation':'cross-fork-merge-capture'}
        return self._operation(principal, 'checkpoint', ws, exact,
            lambda:self._create_merge_preview(principal, ws_id, payload, in_operation=True),
            validate_result=lambda record:self._fork_merge_live(principal, record))

    def _create_merge_preview(self, principal, ws_id, payload, *, in_operation=False):
        from .merge import combine
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "merge_scope", "merge preview needs full workspace read scope")
        self._fresh(ws, payload["expected_generation"], payload["expected_tree_digest"])
        checkpoints = [self.store.get("checkpoint", payload[k]) for k in ("base_checkpoint_id", "incoming_checkpoint_id")]
        cross_fork = any(c['workspace_id']!=ws_id for c in checkpoints)
        sources, source_bindings, ancestry = self._fork_merge_sources(principal,ws,checkpoints) if cross_fork else ({ws_id:ws},[],None)
        if not cross_fork:
            if checkpoints[0]['generation']>checkpoints[1]['generation']:
                raise CodeError(400,'merge_base','base checkpoint must not postdate incoming checkpoint')
            if any(not any(h['generation']==c['generation'] and h['tree_digest']==c['tree_digest'] for h in ws['history']) for c in checkpoints):
                raise CodeError(409,'checkpoint_corrupt','checkpoint does not match workspace source history')
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "merge-preview", **payload})
        with (nullcontext() if in_operation else self.store.transaction()):
            self._live(principal)
            self._authorize(principal, "read", ws, {})
            self._fresh(self.workspace(ws_id), ws["generation"], ws["tree_digest"])
            old = [r for r in self.store.list("merge_preview") if r["workspace_id"] == ws_id]
            config = self.repositories[ws["repository_id"]]
            if len(old) >= config.get("max_workspace_merge_previews", 100):
                raise CodeError(429, "merge_budget", "workspace merge preview count exhausted")
            staged = {}
            def stage(data):
                key = digest(data)
                staged[key] = data
                return key
            if cross_fork:
                self._fork_merge_live(principal,{'source_bindings':source_bindings})
                for cp in checkpoints:
                    source=sources[cp['workspace_id']]
                    manifest=self.manifest(source,cp['tree_digest'])
                    for entry in manifest['files'].values():
                        self.store.blob(self.store.read_blob(entry['digest'],source['id']),ws_id,'source')
                    self._manifest(manifest['files'],ws_id)
            rows = combine(self.manifest(ws, checkpoints[0]["tree_digest"])["files"], self.manifest(ws)["files"],
                           self.manifest(ws, checkpoints[1]["tree_digest"])["files"],
                           lambda d: self.store.read_blob(d, ws_id),
                           stage, self.store.root)
            data = canonical(rows)
            charged = len(data) + sum(r["merged"]["size"] for r in rows if r["merged"])
            if sum(r["charged_bytes"] for r in old) + charged > config.get("max_workspace_merge_preview_bytes", 100 * 1024**2):
                raise CodeError(429, "merge_budget", "workspace merge preview byte budget exhausted")
            self._live(principal)
            self._authorize(principal, "read", ws, {})
            self._fresh(self.workspace(ws_id), ws["generation"], ws["tree_digest"])
            for value in staged.values():
                self.store.blob(value, ws_id, "source")
            record = {"id": ident("merge"), "workspace_id": ws_id, "generation": ws["generation"],
                      "tree_digest": ws["tree_digest"], "base_checkpoint_id": checkpoints[0]["id"],
                      "base_tree_digest": checkpoints[0]["tree_digest"], "incoming_checkpoint_id": checkpoints[1]["id"],
                      "incoming_tree_digest": checkpoints[1]["tree_digest"],
                      "files_digest": self.store.blob(data, ws_id, "merge-preview-files"),
                      "file_count": len(rows), "conflict_count": sum(r["conflict"] for r in rows),
                      "charged_bytes": charged, "author": principal.actor, "created_at": stamp(),
                      "kind": "manifest-three-way", "source_repository_mutated": False,
                      "history_ancestry_verified": False, "resolution_scope": "whole-file"}
            if cross_fork:
                record.update(source_bindings=source_bindings,fork_ancestry=ancestry,kind='fork-manifest-three-way')
                self._fork_merge_live(principal,record)
            self.store.put("merge_preview", record)
            self.store.emit(ws, "merge.preview-created", record)
        return record

    def merge_preview(self, principal, ws_id, preview_id, after=0, limit=20):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "merge_scope", "merge review needs full workspace read scope")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "merge-preview", "preview_id": preview_id})
        record = self.store.get("merge_preview", preview_id)
        if record["workspace_id"] != ws_id:
            raise CodeError(403, "merge_scope", "merge preview belongs to another workspace")
        if type(after) is not int or after < 0 or type(limit) is not int or not 1 <= limit <= 100:
            raise CodeError(400, "merge_cursor", "invalid merge file cursor")
        self._fork_merge_live(principal,record)
        rows = json.loads(self.store.read_blob(record["files_digest"], ws_id))
        if after > len(rows):
            raise CodeError(416, "merge_cursor", "merge cursor beyond files")
        page = rows[after:after + limit]
        self._live(principal)
        return {**record, "files": page, "cursor": after + len(page), "eof": after + len(page) == len(rows),
                "currency": "current" if (ws["generation"], ws["tree_digest"]) == (record["generation"], record["tree_digest"]) else "stale"}

    def merge_content(self, principal, ws_id, preview_id, path, side, after=0, limit=1024):
        record = self.merge_preview(principal, ws_id, preview_id, 0, 1)
        if side not in ("base", "ours", "incoming", "merged") or type(after) is not int or after < 0 or type(limit) is not int or not 1 <= limit <= 16384:
            raise CodeError(400, "merge_cursor", "invalid merge content side/cursor")
        self._fork_merge_live(principal,record)
        rows = json.loads(self.store.read_blob(record["files_digest"], ws_id))
        row = next((r for r in rows if r["path"] == safe_path(path)), None)
        if row is None:
            raise CodeError(403, "merge_selection", "file is not in this merge preview")
        entry = row[side]
        data = self.store.read_blob(entry["digest"], ws_id) if entry else b""
        if after > len(data):
            raise CodeError(416, "merge_cursor", "merge cursor beyond content")
        chunk = data[after:after + limit]
        self._live(principal)
        return {"preview_id": preview_id, "path": row["path"], "side": side, "entry": entry,
                "conflict": row["conflict"], "currency": record["currency"], "generation": record["generation"],
                "tree_digest": record["tree_digest"], "encoding": "base64", "data": base64.b64encode(chunk).decode(),
                "size_bytes": len(data), "cursor": after + len(chunk), "eof": after + len(chunk) == len(data)}

    def apply_merge_preview(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._authorize(principal, "edit", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "merge_scope", "merge apply needs full workspace read/edit scope")
        record = self.store.get("merge_preview", payload["preview_id"])
        if record["workspace_id"] != ws_id:
            raise CodeError(403, "merge_scope", "merge preview belongs to another workspace")
        if (record["generation"], record["tree_digest"]) != (payload["expected_generation"], payload["expected_tree_digest"]):
            raise CodeError(409, "stale_workspace", "merge apply must match the reviewed source")
        self._fork_merge_live(principal,record)
        rows = json.loads(self.store.read_blob(record["files_digest"], ws_id))
        if not rows:
            raise CodeError(409, "merge_no_changes", "merge has no changes to apply")
        resolutions = payload.get("resolutions", [])
        index = {}
        manual_bytes = 0
        for resolution in resolutions:
            path = safe_path(resolution["path"])
            if path in index or resolution.get("choice") not in ("ours", "incoming", "base", "manual", "delete"):
                raise CodeError(400, "merge_resolution", "use unique paths and supported choices")
            supplied = set(resolution) - {"path", "choice"}
            if supplied - {"content_base64", "executable"} or (resolution["choice"] != "manual" and supplied):
                raise CodeError(400, "merge_resolution", "unexpected resolution fields")
            if resolution["choice"] == "manual":
                try:
                    raw = base64.b64decode(resolution["content_base64"], validate=True)
                    if len(raw) > MAX_FILE or type(resolution["executable"]) is not bool:
                        raise ValueError()
                    manual_bytes += len(raw)
                except (KeyError, TypeError, ValueError):
                    raise CodeError(400, "merge_resolution", "manual resolution needs bounded base64 bytes and executable flag") from None
            if manual_bytes > MAX_TREE:
                raise CodeError(413, "merge_limit", "manual resolutions exceed workspace byte budget")
            index[path] = resolution
        conflicts = {r["path"] for r in rows if r["conflict"]}
        if set(index) != conflicts:
            raise CodeError(400, "merge_unresolved", "resolve every conflicting file exactly once; clean files need no choice")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "merge-apply-source", "preview_id": record["id"]})
        exact = {**payload, "resolutions": sorted(resolutions, key=lambda r: r["path"]),
                 "mutation": "source-three-way-merge", "files_digest": record["files_digest"],
                 "base_tree_digest": record["base_tree_digest"], "incoming_tree_digest": record["incoming_tree_digest"],
                 "paths": sorted(r["path"] for r in rows)}
        def apply():
            current = self.workspace(ws_id)
            self._fresh(current, payload["expected_generation"], payload["expected_tree_digest"])
            self._fork_merge_live(principal,record)
            before = self.manifest(current)["files"]
            files = dict(before)
            for row in rows:
                entry = row["merged"]
                if row["conflict"]:
                    resolution = index[row["path"]]
                    choice = resolution["choice"]
                    if choice == "manual":
                        data = base64.b64decode(resolution["content_base64"], validate=True)
                        entry = {"digest": self.store.blob(data, ws_id, "source"), "size": len(data),
                                 "executable": resolution["executable"]}
                    else:
                        entry = None if choice == "delete" else row[choice]
                if entry:
                    data = self.store.read_blob(entry["digest"], ws_id)
                    if len(data) != entry["size"] or len(data) > MAX_FILE:
                        raise CodeError(409, "merge_corrupt", "merged content size differs from preview")
                    files[row["path"]] = entry
                else:
                    files.pop(row["path"], None)
            paths = sorted(p for p in set(before) | set(files) if before.get(p) != files.get(p))
            # Independent additions can produce file/directory or case aliases on
            # this Mac. Refuse the combined tree instead of recording an unusable merge.
            from .git_export import validate_paths
            validate_paths(files, code="merge_path")
            if not paths:
                self._fork_merge_live(principal,record)
                return {"workspace": current, "change": None, "preview_id": record["id"], "no_change": True}
            tree = self._manifest(files, ws_id)
            change = {"id": ident("cs"), "workspace_id": ws_id, "task_id": current["task_id"], "author": principal.actor,
                      "base_commit": current["base_commit"], "before_digest": current["tree_digest"], "tree_digest": tree,
                      "generation": current["generation"] + 1, "paths": paths, "merge_preview_id": record["id"],
                      "merge_files_digest": record["files_digest"],
                      "merge_resolutions_digest": digest(canonical(exact["resolutions"])),
                      "merge_resolution_choices": [{"path": r["path"], "choice": r["choice"],
                          "result": files.get(r["path"])} for r in exact["resolutions"]], "created_at": stamp(),
                      "file_changes": {p: {"before": before.get(p), "after": files.get(p)} for p in paths}}
            change["diff_digest"] = self.store.blob(self._diff(current, current["tree_digest"], tree).encode(), ws_id, "diff")
            current.update(generation=change["generation"], tree_digest=tree)
            current["history"].append({"generation": current["generation"], "tree_digest": tree, "author": principal.actor,
                                       "change_id": change["id"], "merge_preview_id": record["id"]})
            self._fork_merge_live(principal,record)
            self.store.put("workspace", current)
            self.store.put("change", change)
            self.store.emit(current, "workspace.merge-applied", change)
            return {"workspace": current, "change": change, "preview_id": record["id"], "no_change": False}
        return self._operation(principal, "edit", ws, exact, apply)

    def merge_review_packet(self, principal, ws_id, change_id, verification_ids=None):
        """Current merged-source evidence for an authenticated host Review bridge.

        Does not dispatch reviewers, admit findings, transfer grants or award quality.
        The platform must separately derive reviewer identity, mandates and evidence access.
        """
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "merge_scope", "merge review needs full workspace read scope")
        ids = [] if verification_ids is None else verification_ids
        if (type(ids) is not list or len(ids) > 100 or any(type(v) is not str or not 1 <= len(v) <= 160 for v in ids)
                or len(ids) != len(set(ids))):
            raise CodeError(400, "merge_review_ids", "use at most 100 unique verification IDs")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "merge-review-packet",
                                              "change_id": change_id, "verification_ids": sorted(ids)})
        with self.store.lock:
            ws = self.workspace(ws_id)
            self._authorize(principal, "read", ws, {})
            change = self.store.get("change", change_id)
            if change["workspace_id"] != ws_id or change["task_id"] != ws["task_id"]:
                raise CodeError(403, "merge_scope", "change belongs to another workspace")
            if not change.get("merge_preview_id"):
                raise CodeError(422, "merge_review_kind", "review packet requires an applied merge change")
            if (change["generation"], change["tree_digest"]) != (ws["generation"], ws["tree_digest"]):
                raise CodeError(409, "stale_workspace", "merged source changed; create a new review target")
            if not any(h.get("change_id") == change_id and h["generation"] == change["generation"]
                       and h["tree_digest"] == change["tree_digest"] for h in ws["history"]):
                raise CodeError(409, "merge_corrupt", "merge change does not match source history")
            preview = self.store.get("merge_preview", change["merge_preview_id"])
            if (preview["workspace_id"] != ws_id or preview["files_digest"] != change["merge_files_digest"]
                    or preview["tree_digest"] != change["before_digest"] or preview["generation"] + 1 != change["generation"]):
                raise CodeError(409, "merge_corrupt", "merge preview and applied change differ")
            self.store.read_blob(preview["files_digest"], ws_id)
            self.store.read_blob(change["diff_digest"], ws_id)
            files = self.manifest(ws)["files"]
            for path, delta in change["file_changes"].items():
                if files.get(path) != delta["after"]:
                    raise CodeError(409, "merge_corrupt", "merged file differs from applied change")
                for entry in (delta["before"], delta["after"]):
                    if entry and len(self.store.read_blob(entry["digest"], ws_id)) != entry["size"]:
                        raise CodeError(409, "merge_corrupt", "merge content size differs from source custody")
            verifications = []
            for id_ in sorted(ids):
                vr = self.store.get("verification", id_)
                if vr["workspace_id"] != ws_id or vr["task_id"] != ws["task_id"]:
                    raise CodeError(403, "merge_scope", "verification belongs to another workspace")
                if (vr["generation"], vr["tree_digest"]) != (change["generation"], change["tree_digest"]):
                    raise CodeError(409, "stale_verification", "verification is not from the reviewed merge generation")
                verifications.append({"id": id_, "record_digest": digest(canonical(vr)), **{k: vr.get(k) for k in
                    ("run_id", "status", "argv", "exit_code", "evaluator_digest", "output_digest", "receipt_digest",
                     "independent_rsi_evaluation")}})
            states = [v["status"] for v in verifications]
            state = "missing" if not states else "failed" if "failed" in states else "passed" if all(s == "passed" for s in states) else "unknown"
            artifact = {"kind": "code", "workspace_id": ws_id, "generation": change["generation"],
                        "tree_digest": change["tree_digest"], "changeset_id": change_id, "verification_ids": sorted(ids)}
            packet = {"schema": "omegacode-merge-review-v1", "artifact": artifact, "task_id": ws["task_id"],
                      "author_swarm": ws["swarm_id"], "author": change["author"],
                      "change_record_digest": digest(canonical(change)),
                      "merge": {k: preview[k] for k in ("id", "kind", "generation", "tree_digest", "base_checkpoint_id",
                          "base_tree_digest", "incoming_checkpoint_id", "incoming_tree_digest", "files_digest",
                          "file_count", "conflict_count", "history_ancestry_verified")},
                      "resolution_digest": change.get("merge_resolutions_digest"),
                      "resolution_choices": change.get("merge_resolution_choices"),
                      "changed_files": change["file_changes"], "diff_digest": change["diff_digest"],
                      "verifications": verifications, "verification_state": state,
                      "quality_approval": "not_assessed", "execution_authority": "none",
                      "review_dispatch": "host_bridge_required", "purple_assessment": "not_requested",
                      "limitations": ["Passing commands do not prove quality or independent review",
                          "Purple scope and Review identities, mandates, evidence grants and findings are platform-owned",
                          "Missing legacy conflict-decision identity stays unknown",
                          "Saved-source merge does not establish original Git ancestry"]}
            from .quality_evidence import merge_facts
            packet["symbolic_evidence"] = merge_facts(artifact, packet["change_record_digest"], verifications)
            self._live(principal)
            self._fresh(self.workspace(ws_id), ws["generation"], ws["tree_digest"])
            return {**packet, "packet_digest": digest(canonical(packet)), "currency": "current"}

    def start_reserved_run(self, principal, payload, launch_id):
        """Internal candidate adapter; no API route or controller-purpose authority."""
        self._check_owner(required=True)
        return self.start_run(principal, payload, _launch_id=launch_id)

    def start_run(self, principal, payload, *, _launch_id=None):
        self._check_owner(required=_launch_id is not None)
        reserved = None
        if _launch_id is not None:
            from .proposal_launch_custody import Custody
            reserved = Custody(self.store).get(_launch_id)
            ws = self.workspace(payload['workspace_id'])
            expected = {'workspace_id':ws['id'],'generation':payload['expected_generation'],
                        'tree_digest':payload['expected_tree_digest'],'grant_id':principal.grant.get('id'), 'actor':principal.actor}
            if (principal.operator or principal.grant.get('kind') != 'human'
                    or reserved['state'] not in ('spawning','running','ended','unknown') or reserved['ever_spawning'] is not True
                    or reserved['binding'] != expected or reserved['argv'] != payload['argv']
                    or reserved['runtime_seconds'] != payload['timeout_seconds']
                    or reserved['launch_key'] != payload['operation_id']
                    or reserved['spawn_marker'] != str(self.store.root/'runs'/reserved['run_id'])):
                raise CodeError(403,'reserved_launch_binding','exact original human run binding required')
            if any(r['id']==reserved['run_id'] for r in self.store.list('run')):
                self._proposal_watchdog_guard(_launch_id)
            payload = {**payload, '_custody_id':_launch_id}

        if payload.get('proof_project_paths') is None:
            payload = {k: v for k, v in payload.items() if k != 'proof_project_paths'}
        elif payload.get('proof_runtime_id') is None:
            raise CodeError(400, 'invalid_proof_project', 'project selection requires an explicit proof runtime')
        ws = self.workspace(payload["workspace_id"])
        if type(payload.get("terminal", False)) is not bool or any(type(payload.get(k, d)) is not int or not 1 <= payload.get(k, d) <= 500 for k, d in (("rows", 24), ("cols", 80))):
            raise CodeError(400, "invalid_terminal", "terminal needs a boolean mode and dimensions from 1 to 500")
        proof = proof_source = proof_path = proof_project = None
        leatta = leatta_path = None
        if payload.get('leatta_runtime_id') is not None:
            self._authorize(principal, 'run', ws, payload)
            self._live(principal)
            leatta_config = self.toolchains.get(payload['leatta_runtime_id']) if type(payload['leatta_runtime_id']) is str else None
            if not leatta_config or leatta_config.get('kind') != 'leatta' or leatta_config.get('execution_enabled') is not True:
                raise CodeError(400, 'leatta_runtime_disabled', 'LeaTTa needs an operator-enabled runtime')
            if (payload.get('terminal', False) or any(payload.get(k) is not None for k in
                    ('proof_runtime_id','symbolic_runtime_id','debugger_runtime_id'))
                    or len(payload['argv']) != 3 or payload['argv'][:2] != [str(pathlib.Path(leatta_config['executable']).absolute()), '--file']
                    or not 1 <= payload['timeout_seconds'] <= 120):
                raise CodeError(400, 'invalid_leatta_run', 'Use exact enabled LeaTTa executable --file saved.metta, batch mode, no other runtime and at most 120 seconds')
            leatta_path = safe_path(payload['argv'][2])
            entry = self.manifest(ws)['files'].get(leatta_path)
            if not leatta_path.endswith('.metta') or not entry or entry['size'] > 1024**2:
                raise CodeError(400, 'invalid_leatta_source', 'LeaTTa needs a saved MeTTa file of at most one MiB')
            from .leatta import runtime_identity as leatta_identity
            try: leatta = leatta_identity(leatta_config)
            except (OSError, ValueError) as error:
                raise CodeError(409, 'leatta_runtime_unavailable', str(error)) from None
            payload = {**payload, 'leatta_identity_digest':digest(canonical(leatta))}
        if payload.get('proof_runtime_id') is not None:
            self._authorize(principal, 'run', ws, payload)
            self._live(principal)
            runtime_id = payload['proof_runtime_id']
            proof_config = self.toolchains.get(runtime_id) if type(runtime_id) is str else None
            if not proof_config or proof_config.get('kind') != 'lean' or proof_config.get('check_enabled') is not True:
                raise CodeError(400, 'proof_runtime_disabled', 'proof checking needs an operator-enabled Lean runtime')
            if (payload.get('terminal', False) or payload.get('symbolic_runtime_id') is not None
                    or payload.get('debugger_runtime_id') is not None or len(payload['argv']) != 2
                    or payload['argv'][0] != str(pathlib.Path(proof_config['executable']).absolute())
                    or not 1 <= payload['timeout_seconds'] <= 120):
                raise CodeError(400, 'invalid_proof_run', 'proof checking needs exact Lean executable/source argv, batch mode, no other runtime and timeout at most 120 seconds')
            proof_path = safe_path(payload['argv'][1])
            entry = self.manifest(ws)['files'].get(proof_path)
            if not proof_path.endswith('.lean') or not entry or entry['size'] > 1024**2:
                raise CodeError(400, 'invalid_proof_source', 'proof needs a saved Lean source of at most one MiB')
            if payload.get('proof_project_paths') is not None:
                if proof_config.get('project_check_enabled') is not True:
                    raise CodeError(400, 'proof_project_disabled', 'project checking needs a separate operator opt-in')
                from .proof_checker import project_manifest
                try: proof_project = project_manifest(payload['proof_project_paths'], self.manifest(ws)['files'])
                except ValueError as error: raise CodeError(400, 'invalid_proof_project', str(error)) from None
                if proof_project[-1]['path'] != proof_path:
                    raise CodeError(400, 'invalid_proof_project', 'entry module must be last in declared dependency order')
                payload = {**payload, 'proof_project_digest': digest(canonical(proof_project))}
            from .proof_checker import runtime_identity as proof_identity
            try: proof = proof_identity(proof_config)
            except (OSError, ValueError) as error:
                raise CodeError(409, 'proof_runtime_unavailable', str(error)) from None
            proof_source = pathlib.Path(__file__).with_name('proof_checker.py').read_bytes()
            payload = {**payload, 'proof_identity_digest': digest(canonical(proof)),
                       'proof_helper_digest': digest(proof_source)}
        debugging = None
        debugger_sources = None
        if payload.get('debugger_runtime_id') is not None:
            self._authorize(principal, 'run', ws, payload)
            self._live(principal)
            runtime_id = payload['debugger_runtime_id']
            debugger_config = self.toolchains.get(runtime_id) if type(runtime_id) is str else None
            if (not debugger_config or debugger_config.get('kind') != 'debugpy'
                    or debugger_config.get('session_enabled') is not True):
                raise CodeError(400, 'debugger_runtime_disabled', 'debugger needs operator-enabled debugpy runtime')
            if (payload.get('symbolic_runtime_id') is not None or payload.get('terminal') is not True
                    or payload['argv'] != [str(pathlib.Path(debugger_config['executable']).absolute())]
                    or not 1 <= payload['timeout_seconds'] <= 120):
                raise CodeError(400, 'invalid_debugger_run', 'debugger needs terminal, exact interpreter argv, no symbolic mode and timeout at most 120 seconds')
            from .debug_session import runtime_identity as debugger_identity
            try: debugging = debugger_identity(debugger_config)
            except (OSError, ValueError) as error:
                raise CodeError(409, 'debugger_runtime_unavailable', str(error)) from None
            debugger_sources = {name:pathlib.Path(__file__).with_name(name).read_bytes()
                                for name in ('debugger.py','debug_session.py')}
            payload = {**payload, 'debugger_identity_digest':digest(canonical(debugging)),
                       'debugger_helper_digest':digest(canonical({name:digest(raw) for name,raw in debugger_sources.items()}))}
        symbolic = None
        symbolic_source = None
        if payload.get('symbolic_runtime_id') is not None:
            self._authorize(principal, 'run', ws, payload)
            self._live(principal)
            runtime_id = payload['symbolic_runtime_id']
            symbolic_config = self.toolchains.get(runtime_id) if type(runtime_id) is str else None
            if not symbolic_config or symbolic_config.get('kind') != 'hyperon' or symbolic_config.get('session_enabled') is not True:
                raise CodeError(400, 'symbolic_runtime_disabled', 'symbolic sessions require an operator-enabled Hyperon runtime')
            if payload.get('terminal') is not True or payload['argv'] != [str(pathlib.Path(symbolic_config['executable']).absolute())]:
                raise CodeError(400, 'invalid_symbolic_run', 'symbolic runs need terminal mode and exactly the configured interpreter argv')
            from .symbolic import runtime_identity
            try:
                symbolic = runtime_identity(symbolic_config)
            except (OSError, ValueError) as error:
                raise CodeError(409, 'symbolic_runtime_unavailable', str(error)) from None
            symbolic_source = pathlib.Path(__file__).with_name('symbolic.py').read_bytes()
            # These server-derived pins participate in the exact execution approval.
            payload = {**payload, 'symbolic_identity_digest': digest(canonical(symbolic)),
                       'symbolic_helper_digest': digest(symbolic_source)}
        def apply():
            current = self.workspace(ws["id"])
            self._fresh(current, payload["expected_generation"], payload["expected_tree_digest"])
            runs = self.store.list("run")
            g, config = principal.grant, self.repositories[current["repository_id"]]
            terminal_config = config.get('terminal_confinement') if payload.get('terminal') else None
            terminal_binding = None
            if terminal_config is not None:
                from .terminal_confinement import identity as terminal_identity, ARGV
                try:
                    terminal_binding = terminal_identity(terminal_config)
                    if payload['argv'] != ARGV or any(payload.get(k) is not None for k in
                            ('proof_runtime_id','leatta_runtime_id','symbolic_runtime_id','debugger_runtime_id')):
                        raise ValueError('only the pinned interactive Bash terminal is supported')
                except (ValueError,OSError,KeyError,TypeError) as error:
                    raise CodeError(409,'confinement_unavailable',str(error)) from None
            confinement_config = config.get('execution_confinement') if terminal_config is None else None
            if confinement_config is not None:
                from .confinement import identity as confinement_identity
                try:
                    pinned = confinement_identity(confinement_config)
                    if (payload.get('terminal') or any(payload.get(k) is not None for k in
                            ('proof_runtime_id','leatta_runtime_id','symbolic_runtime_id','debugger_runtime_id'))
                            or str(pathlib.Path(payload['argv'][0]).resolve(strict=True)) != pinned['python']):
                        raise ValueError('only pinned Python batch commands supported by this candidate')
                except (ValueError,OSError,KeyError,TypeError) as error:
                    raise CodeError(409,'confinement_unavailable',str(error)) from None
            if sum(r["grant_id"] == g["id"] for r in runs) >= g["max_runs"]:
                raise CodeError(429, "run_budget", "capability run budget exhausted")
            task_runs = [r for r in runs if r["task_id"] == current["task_id"] and r["swarm_id"] == current["swarm_id"]]
            if len(task_runs) >= config.get("max_task_runs", 20) or sum(r["timeout_seconds"] for r in task_runs) + payload["timeout_seconds"] > config.get("task_runtime_budget_seconds", 600):
                raise CodeError(429, "task_budget", "aggregate task run/runtime budget exhausted")
            if proof is not None:
                active_config = self.toolchains.get(payload['proof_runtime_id'])
                try:
                    if (not active_config or active_config.get('kind') != 'lean' or active_config.get('check_enabled') is not True
                            or (proof_project is not None and active_config.get('project_check_enabled') is not True)
                            or proof_identity(active_config) != proof):
                        raise ValueError('runtime changed')
                except (OSError, ValueError):
                    raise CodeError(409, 'proof_runtime_changed', 'Lean changed or was disabled during preparation') from None
            if symbolic is not None and runtime_identity(symbolic_config) != symbolic:
                raise CodeError(409, 'symbolic_runtime_changed', 'symbolic runtime changed during preparation')
            if leatta is not None:
                active_config = self.toolchains.get(payload['leatta_runtime_id'])
                try:
                    if (not active_config or active_config.get('kind') != 'leatta'
                            or active_config.get('execution_enabled') is not True
                            or leatta_identity(active_config) != leatta):
                        raise ValueError('runtime changed')
                except (OSError, ValueError):
                    raise CodeError(409, 'leatta_runtime_changed', 'LeaTTa changed or was disabled during preparation') from None
            if debugging is not None and debugger_identity(debugger_config) != debugging:
                raise CodeError(409, 'debugger_runtime_changed', 'debugger runtime changed during preparation')
            if reserved is not None:
                if reserved['state'] != 'spawning' or any(r['id']==reserved['run_id'] for r in self.store.list('run')):
                    raise CodeError(409,'reserved_run_uncertain','only an original unstarted dispatch can prepare')
            return self._prepare_run_snapshot(principal, payload, ws, current, reserved, confinement_config=confinement_config, terminal_binding=terminal_binding, leatta=leatta, leatta_path=leatta_path, symbolic=symbolic, symbolic_source=symbolic_source if symbolic is not None else None, proof=proof, proof_source=proof_source, proof_project=proof_project, proof_path=proof_path, debugging=debugging, debugger_sources=debugger_sources)
        result = self._operation(principal, "run", ws, payload, apply)
        if reserved is not None and result['id'] != reserved['run_id']:
            raise CodeError(409,'reserved_run_conflict','operation returned a different original run')
        self.run_principals[result["id"]] = principal
        # Launch after the prepared record commits; retries/restarts never launch a duplicate.
        self._launch(result["id"])
        return self.store.get("run", result["id"])

    def _prepare_run_snapshot(self, principal, payload, ws, current, reserved, *, confinement_config=None,
                              terminal_binding=None, leatta=None, leatta_path=None, symbolic=None, symbolic_source=None,
                              proof=None, proof_source=None, proof_project=None, proof_path=None, debugging=None,
                              debugger_sources=None, purpose_id=None):
        """Shared internal materialization under caller authorization/transaction; no launch."""
        g = principal.grant
        id_, nonce = (reserved["run_id"], reserved["nonce"]) if reserved is not None else (ident("run"), ident("launch"))
        run = {"id": id_, "workspace_id": ws["id"], "task_id": current["task_id"], "swarm_id": current["swarm_id"],
               "tree_digest": current["tree_digest"], "generation": current["generation"], "argv": payload["argv"],
               "timeout_seconds": payload["timeout_seconds"], "grant_id": g["id"], "author": principal.actor,
               "status": "prepared", "nonce": nonce, "created_at": stamp(), "environment": current["environment"],
               "profile": "trusted-native", "exit_code": None, "descendants_terminated": False,
               "terminal": payload.get("terminal", False), "rows": payload.get("rows", 24), "cols": payload.get("cols", 80)}
        evaluator = {name: pathlib.Path(__file__).with_name(name).read_bytes() for name in ("runner.py", "common.py")}
        if confinement_config is not None:
            evaluator['confinement.py'] = pathlib.Path(__file__).with_name('confinement.py').read_bytes()
        if terminal_binding is not None:
            from .terminal_confinement import GENERATORS
            evaluator.update({name: pathlib.Path(__file__).with_name(name).read_bytes() for name in GENERATORS})
            if any(digest(evaluator[name]) != terminal_binding['generators'][name] for name in GENERATORS):
                raise CodeError(409,'confinement_unavailable','terminal helper changed while freezing')
        if proof is not None:
            evaluator['proof_checker.py'] = proof_source
        if symbolic is not None:
            evaluator['symbolic.py'] = symbolic_source
        if debugger_sources is not None: evaluator.update(debugger_sources)
        run["evaluator_digest"] = digest(canonical({name: digest(data) for name, data in evaluator.items()}))
        if reserved is not None: run["launch_custody_id"] = reserved["id"]
        run["authority_kind"] = g["kind"]
        root = self.store.root / "runs" / id_
        root.mkdir(parents=True, mode=0o700)
        for name, data in evaluator.items():
            atomic_write(root / "executor" / "omegacode" / name, data)
        atomic_write(root / "executor" / "omegacode" / "__init__.py", b"")
        execution_argv = payload['argv']
        if leatta is not None:
            frozen = root / 'executor/LeaTTa'
            binary = pathlib.Path(leatta['executable']).read_bytes()
            if digest(binary) != leatta['executable_digest']:
                raise CodeError(409, 'leatta_runtime_changed', 'LeaTTa changed while freezing executable')
            atomic_write(frozen,binary);frozen.chmod(0o700)
            execution_argv = [str(frozen),'--file',leatta_path]
            entry = self.manifest(current)['files'][leatta_path]
            run['execution_argv'] = execution_argv
            run['leatta_execution'] = {**leatta,'runtime_id':payload['leatta_runtime_id'],
                'identity_digest':payload['leatta_identity_digest'],'source_path':leatta_path,
                'source_digest':entry['digest'],'executable_frozen':True}
        if symbolic is not None:
            atomic_write(root / 'symbolic-runtime.json', canonical(symbolic))
            execution_argv = [symbolic['executable'], '-I', '-u', str(root / 'executor' / 'omegacode' / 'symbolic.py'),
                              str(root / 'symbolic-runtime.json')]
            run['symbolic_session'] = {'runtime_id': payload['symbolic_runtime_id'],
                'identity_digest': payload['symbolic_identity_digest'], 'helper_digest': payload['symbolic_helper_digest'],
                'protocol': 'omegacode-symbolic-jsonl-v1', 'persistence': 'resident process only; no automatic replay',
                'all_inputs_require_run_authority': True, 'sandboxed': False}
            run['execution_argv'] = execution_argv
        if proof is not None:
            execution_argv = [sys.executable, '-I', str(root / 'executor/omegacode/proof_checker.py'),
                              str(root / 'proof-spec.json')]
            entry = self.manifest(current)['files'][proof_path]
            atomic_write(root / 'proof-spec.json', canonical({'runtime': proof,
                'source_path': str(root / 'tree' / proof_path), 'source_digest': entry['digest'],
                'context': {'run_id': id_, 'workspace_id': ws['id'], 'generation': current['generation'],
                            'tree_digest': current['tree_digest'], 'source_path': proof_path}}))
            if proof_project is not None:
                spec_path = root / 'proof-spec.json'
                spec = json.loads(spec_path.read_bytes())
                spec.update(project_root=str(root / 'tree'), project_files=proof_project,
                            project_digest=payload['proof_project_digest'])
                atomic_write(spec_path, canonical(spec))
            run['execution_argv'] = execution_argv
            run['proof_check'] = {'runtime_id': payload['proof_runtime_id'],
                'identity_digest': payload['proof_identity_digest'], 'helper_digest': payload['proof_helper_digest'],
                'source_path': proof_path, 'source_digest': entry['digest'],
                'protocol': 'omegacode-lean-check-v1', 'sandboxed': False,
                'implementation_correspondence_proved': False}
            if proof_project is not None:
                run['proof_check'].update(protocol='omegacode-lean-project-check-v1', project_files=proof_project,
                                          project_digest=payload['proof_project_digest'])
        if debugging is not None:
            atomic_write(root / 'debugger-runtime.json', canonical(debugging))
            execution_argv = [debugging['executable'], '-I', '-u', str(root / 'executor/omegacode/debug_session.py'),
                              str(root / 'debugger-runtime.json')]
            run['execution_argv'] = execution_argv
            run['debugger_session'] = {'runtime_id':payload['debugger_runtime_id'],
                'identity_digest':payload['debugger_identity_digest'], 'helper_digest':payload['debugger_helper_digest'],
                'protocol':'omegacode-debugger-jsonl-v1', 'all_inputs_require_run_authority':True,
                'persistence':'resident process only; no automatic replay', 'sandboxed':False}
        executable = shutil.which(payload["argv"][0], path=os.defpath)
        run["environment"] = {**current["environment"], "executor_python": sys.executable,
                              "executor_python_digest": digest(pathlib.Path(sys.executable).read_bytes()),
                              "command_executable": executable,
                              "command_executable_digest": digest(pathlib.Path(executable).read_bytes()) if executable else None}
        files = self.manifest(current)["files"]
        self._materialize(files, ws["id"], root / "tree")
        confinement = None
        if confinement_config is not None:
            from .confinement import prepare as prepare_confined
            try: execution_argv, confinement = prepare_confined(root,confinement_config,execution_argv)
            except (ValueError,OSError,KeyError,TypeError) as error:
                raise CodeError(409,'confinement_unavailable',str(error)) from None
            run['profile'] = confinement['kind']
            run['execution_confinement'] = confinement
        if terminal_binding is not None:
            run['profile'] = terminal_binding['kind']
            run['execution_confinement'] = terminal_binding
        atomic_write(root / "spec.json", canonical({"run_id": id_, "nonce": nonce, "argv": execution_argv,
                                                    "generation": run['generation'], "tree_digest": run['tree_digest'],
                                                    "timeout_seconds": payload["timeout_seconds"], "files": files,
                                                    "pinned_executable_digest": leatta['executable_digest'] if leatta else None,
                                                    "terminal": run["terminal"], "rows": run["rows"], "cols": run["cols"],
                                                    "debugger_session": debugging is not None, "confinement": confinement, "pty_confinement": terminal_binding}))
        if purpose_id is not None: run["proposal_purpose_test"] = purpose_id
        self.store.put("run", run)
        self.store.emit(current, "run.prepared", run)
        return run

    def terminal_control(self, principal, run_id, payload):
        """Queue an exact authorized terminal effect; acceptance is not consumption."""
        self.reconcile()
        run = self.store.get("run", run_id)
        ws = self.workspace(run["workspace_id"])
        self._proposal_watchdog_guard(run.get("launch_custody_id"))
        kind = payload.get("kind")
        data = b""
        if kind == "input":
            if any(k in payload for k in ("rows", "cols")):
                raise CodeError(400, "invalid_terminal_control", "input cannot resize")
            try:
                data = base64.b64decode(payload.get("data_base64", ""), validate=True)
            except (ValueError, TypeError):
                raise CodeError(400, "invalid_terminal_input", "input needs valid base64 bytes")
            if not 1 <= len(data) <= 8192:
                raise CodeError(400, "invalid_terminal_input", "input must contain 1 to 8192 bytes")
        elif kind == "resize":
            if "data_base64" in payload or any(type(payload.get(k)) is not int or not 1 <= payload[k] <= 500 for k in ("rows", "cols")):
                raise CodeError(400, "invalid_terminal_resize", "resize needs dimensions from 1 to 500 and no input")
        else:
            raise CodeError(400, "invalid_terminal_control", "unknown terminal operation")
        exact = {**payload, "run_id": run_id, "argv": run["argv"], "timeout_seconds": run["timeout_seconds"],
                 "run_generation": run["generation"], "run_tree_digest": run["tree_digest"]}
        def apply():
            current = self.store.get("run", run_id)
            if not current.get("terminal") or current["status"] not in ("starting", "running"):
                raise CodeError(409, "terminal_inactive", "run has no active interactive terminal")
            controls = [x for x in self.store.list("terminal_control") if x["run_id"] == run_id]
            if len(controls) >= 1024 or sum(x["input_bytes"] for x in controls) + len(data) > 65536:
                raise CodeError(429, "terminal_budget", "terminal control or input byte budget exhausted")
            record = {"id": ident("tc"), "run_id": run_id, "workspace_id": ws["id"],
                      "sequence": len(controls) + 1, "actor": principal.actor, "kind": kind,
                      "input_bytes": len(data), "input_digest": digest(data) if data else None,
                      "status": "queued", "created_at": stamp(), "payload": payload}
            self.store.put("terminal_control", record)
            self.store.emit(ws, "terminal.queued", {k: v for k, v in record.items() if k != "payload"})
            return {k: v for k, v in record.items() if k != "payload"}
        result = self._operation(principal, "run", ws, exact, apply)
        self._proposal_watchdog_guard(run.get("launch_custody_id"))
        # Publish only after the operation and final live authority check commit.
        root = self.store.root / "runs" / run_id
        path = root / "terminal-requests" / f'{result["sequence"]:06d}-{result["id"]}.json'
        if not path.exists() and not (root / "terminal-receipts" / (result["id"] + ".json")).exists():
            record = self.store.get("terminal_control", result["id"])
            atomic_write(path, canonical({**record, "nonce": run["nonce"]}))
        return result

    def terminal_control_status(self, principal, run_id, control_id):
        self.reconcile()
        run = self.store.get("run", run_id)
        ws = self.workspace(run["workspace_id"])
        self._authorize(principal, "read", ws, {})
        self._live(principal)
        if principal.grant["paths"]:
            raise CodeError(403, "terminal_scope", "terminal state requires full workspace read scope")
        self.authority.gate(principal, "read", {"workspace_id": ws["id"], "run_id": run_id, "control_id": control_id})
        record = self.store.get("terminal_control", control_id)
        if record["run_id"] != run_id:
            raise CodeError(403, "terminal_scope", "control belongs to another run")
        result = {k: v for k, v in record.items() if k != "payload"}
        path = self.store.root / "runs" / run_id / "terminal-receipts" / (control_id + ".json")
        if path.exists():
            try:
                receipt = json.loads(path.read_text())
                if receipt.get("id") != control_id or receipt.get("nonce") != run["nonce"] or receipt.get("status") != "consumed" or type(receipt.get("at")) not in (int, float):
                    raise ValueError()
            except (ValueError, AttributeError):
                raise CodeError(409, "terminal_receipt_invalid", "terminal receipt is corrupt or mismatched") from None
            result.update(status=receipt["status"], consumed_at=receipt["at"])
        elif run["status"] not in ("starting", "running", "prepared"):
            result["status"] = "unconfirmed"
        self._live(principal)
        return result

    def _launch(self, run_id):
        self._check_owner()
        with self.store.transaction():
            run = self.store.get("run", run_id)
            if run["status"] != "prepared":
                return
            if run.get("proposal_purpose_test") is not None:
                # Purpose launch must have its own final admission/watchdog path.
                return
            if run.get("launch_custody_id"):
                from .proposal_launch_custody import Custody
                custody = Custody(self.store).get(run["launch_custody_id"])
                if (custody["state"] != "spawning" or not custody["ever_spawning"]
                        or custody["run_id"] != run["id"] or custody["nonce"] != run["nonce"]):
                    run.update(status="unknown", descendants_terminated=False, launch_error="custody_unresolved")
                    self.store.put("run",run)
                    return
            grant = self.store.db.execute("SELECT body,revoked FROM grants WHERE id=?", (run["grant_id"],)).fetchone()
            if not grant or grant[1] or json.loads(grant[0])["exp"] <= time.time():
                run.update(status="cancelled", descendants_terminated=True, observed_at=stamp())
                self.store.put("run", run)
                return
            try:
                self.authority.host_live(json.loads(grant[0]))
            except CodeError:
                run.update(status="cancelled", descendants_terminated=True, observed_at=stamp())
                self.store.put("run", run)
                return
            root = self.store.root / "runs" / run_id
            if run.get('execution_confinement') is not None:
                try:
                    retained = run['execution_confinement']
                    repository = self.repositories[self.workspace(run['workspace_id'])['repository_id']]
                    if retained['kind'] == 'macos-seatbelt-bash-pty-v1':
                        from .terminal_confinement import identity as terminal_identity
                        active = terminal_identity(repository['terminal_confinement'])
                        if active != retained: raise ValueError('terminal profile changed')
                    else:
                        from .confinement import identity as confinement_identity
                        active = confinement_identity(repository['execution_confinement'])
                        if any(active[k] != retained[k] for k in ('kind','python','binaries','generator_sha256')):
                            raise ValueError('profile changed')
                except (ValueError,OSError,KeyError,TypeError):
                    run.update(status='failed', launch_error='confinement_changed', descendants_terminated=True)
                    self.store.put('run',run)
                    return
            # Persist intent before spawning. Recovery of 'starting' never blindly relaunches.
            run["status"] = "starting"
            self.store.put("run", run)
        self._spawn_run_executor(run_id)

    def _start_purpose_executor(self, launch_id, verified_claims):
        """Called only by the owned purpose adapter's synchronous final fence."""
        from .proposal_launch_custody import Custody, execution_binding
        self._check_owner(required=True)
        with self.store.transaction():
            row=Custody(self.store).get(launch_id)
            run=self.store.get('run',row['run_id'])
            native=execution_binding(self.store,row)
            binding=self.store.get('proposal_watch_binding',launch_id)
            watch=self.store.get('proposal_watchdog',launch_id)
            grant=self.store.db.execute('SELECT body,revoked FROM grants WHERE id=?',(verified_claims['id'],)).fetchone()
            if (not grant or grant[1] or canonical(json.loads(grant[0]))!=canonical(verified_claims)
                    or verified_claims['exp']<=time.time() or self._stop.is_set() or self._watcher is None or not self._watcher.is_alive()
                    or self._proposal_watchdog is None or self._proposal_status_pool is None
                    or binding != {'id':launch_id,'run_id':row['run_id'],'nonce':row['nonce'],'claims':verified_claims}
                    or watch['claims']!=canonical(verified_claims).decode()
                    or watch['input_launch_closed'] is not False or watch['cancel_initiated'] is not False
                    or row['state']!='spawning' or row['ever_spawning'] is not True
                    or run['status']!='prepared' or run.get('proposal_purpose_test')!=row['test_id']
                    or run.get('launch_custody_id')!=launch_id or run['nonce']!=row['nonce']
                    or any(run[k]!=native[n] for k,n in [('workspace_id','workspace_id'),('generation','generation'),('tree_digest','tree_digest'),('grant_id','grant_id'),('author','actor')])):
                raise CodeError(409,'purpose_executor_gate','original monitor and prepared run required')
            run['status']='starting'
            self.store.put('run',run)
        # The adapter still holds the existing Store lock; no automatic purpose replay.
        def final_guard():
            self._check_owner(required=True)
            if (self._stop.is_set() or self._watcher is None or not self._watcher.is_alive()
                    or self._proposal_watchdog is None or self._proposal_status_pool is None
                    or verified_claims['exp']<=time.time()):
                raise CodeError(503,'purpose_monitor_required','original owner monitor must remain running')
        self._spawn_run_executor(run['id'], _purpose_guard=final_guard)
        return self.store.get('run',run['id'])

    def _spawn_run_executor(self, run_id, *, _purpose_guard=None):
        """Private native effect; caller owns admission and persisted starting intent."""
        root = self.store.root / "runs" / run_id
        env = {"PATH": os.defpath, "LANG": "C.UTF-8", "PYTHONPATH": str(root / "executor"),
               "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1"}
        self._check_owner()
        try:
            if _purpose_guard is not None: _purpose_guard()
            proc = subprocess.Popen([sys.executable, "-m", "omegacode.runner", str(root)], cwd=root,
                                    env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, start_new_session=True)
            self.processes[run_id] = proc
            with self.store.transaction():
                run = self.store.get("run", run_id)
                run.update(pid=proc.pid, pgid=proc.pid, process_birth=birth(proc.pid))
                if run["status"] == "starting":
                    run["status"] = "running"
                self.store.put("run", run)
                self.store.emit(self.workspace(run["workspace_id"]), "run.started", run)
        except OSError:
            with self.store.transaction():
                run = self.store.get("run", run_id)
                run.update(status="failed", launch_error="executor_launch_failed")
                self.store.put("run", run)

    def _group_live(self, run):
        pgid = run.get("pgid")
        if not pgid:
            return None
        try:
            members = group_members(pgid)
            if pgid in members and run.get("process_birth"):
                observed_birth = birth(pgid)
                if not observed_birth:
                    # The leader may exit between ps snapshots. Reobserve rather
                    # than confuse disappearance with an observed PID reuse.
                    members = group_members(pgid)
                    if pgid in members:
                        return None
                elif observed_birth != run["process_birth"]:
                    return None
        except (RuntimeError, subprocess.SubprocessError, OSError):
            return None
        return bool(members)

    def reconcile(self):
        self._check_owner()
        def retain(run):
            # Caller holds the existing Store transaction. Native uncertainty
            # must close the custody gate before any result reader is involved.
            if run.get('launch_custody_id') and run['status']=='unknown':
                from .proposal_launch_custody import Custody
                c=Custody(self.store);row=c.get(run['launch_custody_id'])
                if row['run_id']!=run['id'] or row['nonce']!=run['nonce']:
                    raise CodeError(409,'observation_binding','original launch identity mismatch')
                if row['state']=='ended':
                    raise CodeError(409,'observation_final','ended launch cannot be rewritten')
                if row['state']!='unknown':
                    row.update(state='unknown',reason='executor_unknown');c._put(row)
                run['descendants_terminated']=False
            self.store.put('run',run)
        for item in self.store.list("run"):
            if item["status"] not in ("prepared", "starting", "running", "cancel_requested"):
                if not (item['status']=='unknown' and item.get('launch_custody_id')
                        and (self.store.root/'runs'/item['id']/'receipt.json').exists()):
                    continue
            root = self.store.root / "runs" / item["id"]
            receipt_path = root / "receipt.json"
            launch_path = root / "launch.json"
            with self.store.transaction():
                run = self.store.get("run", item["id"])
                if run["status"] not in ("prepared", "starting", "running", "cancel_requested"):
                    if not (run['status']=='unknown' and run.get('launch_custody_id') and receipt_path.exists()):
                        continue
                ws = self.workspace(run["workspace_id"])
                if not run.get("pgid") and launch_path.exists():
                    try:
                        launch = json.loads(launch_path.read_text())
                        if launch["nonce"] != run["nonce"] or type(launch["pgid"]) is not int or launch["pgid"] <= 1:
                            raise ValueError()
                        run.update(pgid=launch["pgid"], pid=launch["pid"], process_birth=launch["birth"])
                    except (ValueError, KeyError, TypeError):
                        run["status"] = "unknown"
                        retain(run)
                        self.store.emit(ws, "run.unknown", run)
                        continue
                if receipt_path.exists():
                    try:
                        receipt = json.loads(receipt_path.read_text())
                        if receipt["nonce"] != run["nonce"] or receipt["run_id"] != run["id"]:
                            raise ValueError()
                    except (ValueError, KeyError):
                        run["status"] = "unknown"
                    else:
                        live = self._group_live(run)
                        # The helper can still be exiting immediately after writing its receipt.
                        if live:
                            continue
                        run.update(receipt)
                        run["observed_at"] = stamp()
                        if live is None or not receipt["descendants_terminated"]:
                            run["status"] = "unknown"
                        output = (root / "output.log").read_bytes() if (root / "output.log").exists() else b""
                        run["output_digest"] = self.store.blob(output, ws["id"], "run-output")
                        run["receipt_digest"] = self.store.blob(canonical(receipt), ws["id"], "run-receipt")
                    retain(run)
                    self.store.emit(ws, "run.finished", run)
                elif run.get("pgid") and self._group_live(run) is False:
                    # Receipt may have been written after the earlier exists() check
                    # but before wrapper exit. Re-read next pass, never overwrite it
                    # with an inferred interruption from that stale observation.
                    if receipt_path.exists():
                        continue
                    run.update(status="unknown" if run.get("debugger_session") else "cancelled" if run["status"] == "cancel_requested" else "interrupted",
                               descendants_terminated=not bool(run.get("debugger_session") or run.get("profile") == "macos-seatbelt-bash-pty-v1"), observed_at=stamp())
                    if run.get("profile") == "macos-seatbelt-bash-pty-v1" or run.get("launch_custody_id"):
                        # Reserved launches require the original helper's positive
                        # receipt. Empty group is never a settlement/cleanup proof.
                        run["status"] = "unknown"
                        run["descendants_terminated"] = False
                    retain(run)
                    self.store.emit(ws, "run.interrupted", run)
                elif run.get("pgid") and self._group_live(run) is None:
                    run["status"] = "unknown"
                    retain(run)
                    self.store.emit(ws, "run.unknown", run)
                elif run["status"] in ("prepared", "starting") and stamp() - run["created_at"] > 15:
                    run["status"] = "unknown"
                    retain(run)
                    self.store.emit(ws, "run.unknown", run)
                else:
                    retain(run)
                proc = self.processes.get(run["id"])
                if proc and proc.poll() is not None:
                    del self.processes[run["id"]]
                grant = self.store.db.execute("SELECT body,revoked FROM grants WHERE id=?", (run["grant_id"],)).fetchone()
                authority_ended = not grant or grant[1] or json.loads(grant[0])["exp"] <= time.time()
                host_claims = json.loads(grant[0]) if grant else {}
                if run["status"] == "running" and not run.get("proposal_purpose_test") and host_claims.get("iss") == "hive" and stamp() - run.get("last_host_check", 0) >= 1:
                    try:
                        self.authority.scope(Principal(host_claims["actor"], host_claims), "run", self.workspace(run["workspace_id"]),
                                             {"argv": run["argv"], "timeout_seconds": run["timeout_seconds"]})
                    except CodeError:
                        authority_ended = True
                    run["last_host_check"] = stamp()
                if run["status"] == "running" and not run.get("proposal_purpose_test") and run.get("authority_kind") == "agent":
                    # Member credentials live only in service memory, never in the executor or journal.
                    # A restarted service cannot revalidate these grants, so it stops agent runs.
                    p = self.run_principals.get(run["id"])
                    if not p:
                        authority_ended = True
                    elif stamp() - run.get("last_authority_check", 0) >= 1:
                        try:
                            self.authority.check_claim(p)
                        except CodeError:
                            authority_ended = True
                        run["last_authority_check"] = stamp()
                if run["status"] == "running" and authority_ended:
                    atomic_write(root / "cancel.request", b"grant ended")
                    run["status"] = "cancel_requested"
                    run["cancel_requested_at"] = stamp()
                    retain(run)
                if run["status"] == "cancel_requested" and stamp() - run.get("cancel_requested_at", run["created_at"]) > (12 if run.get("debugger_session") else 5):
                    if self._group_live(run):
                        try:
                            os.killpg(run["pgid"], signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                if run["status"] not in ("prepared", "starting", "running", "cancel_requested"):
                    self.run_principals.pop(run["id"], None)

    def run(self, principal, run_id):
        self.reconcile()
        run = self.store.get("run", run_id)
        self._authorize(principal, "read", self.workspace(run["workspace_id"]), {})
        return run

    def run_source(self, principal, run_id, source_path, after=0, limit=16384):
        """Custody-checked saved input, not a claim about runtime-mutated target bytes."""
        if type(source_path) is not str or not 1 <= len(source_path) <= 4096:
            raise CodeError(400, "invalid_source_path", "source needs a bounded saved path")
        if type(after) is not int or not 0 <= after <= MAX_TREE or type(limit) is not int or not 1 <= limit <= 16384:
            raise CodeError(400, "invalid_source_cursor", "source needs a bounded byte cursor/page")
        self._live(principal)
        record = self.store.get("run", run_id)
        ws = self.workspace(record["workspace_id"])
        # DAP supplies an absolute frozen-tree path; never resolve/read it on the host.
        prefix = str(self.store.root / "runs" / run_id / "tree") + "/"
        relative = source_path[len(prefix):] if source_path.startswith(prefix) else source_path
        name = safe_path(relative)
        self._authorize(principal, "read", ws, {"paths": [name]})
        self.authority.gate(principal, "read", {"workspace_id": ws["id"], "run_id": run_id,
            "resource": "run-saved-source", "path": name, "generation": record["generation"]})
        entry = self.manifest(ws, record["tree_digest"])["files"].get(name)
        if not entry:
            raise CodeError(404, "file_missing", "file is absent from the run saved source")
        raw = self.store.read_blob(entry["digest"], ws["id"])
        if len(raw) != entry["size"]:
            raise CodeError(409, "artifact_corrupt", "saved source size differs from its manifest")
        if after > len(raw):
            raise CodeError(416, "source_offset", "byte offset is beyond saved source")
        data = raw[after:after+limit]
        self._live(principal)
        current = self.workspace(ws["id"])
        self._authorize(principal, "read", current, {"paths": [name]})
        return {"run_id": run_id, "workspace_id": ws["id"], "generation": record["generation"],
            "tree_digest": record["tree_digest"], "path": name, "file_digest": entry["digest"],
            "size_bytes": len(raw), "after": after, "cursor": after+len(data), "eof": after+len(data) == len(raw),
            "encoding": "base64", "data": base64.b64encode(data).decode(), "source": "run-saved-input",
            "runtime_file_bytes_verified": False, "currency": "current" if current["generation"] == record["generation"] and current["tree_digest"] == record["tree_digest"] else "historical"}

    def run_output(self, principal, run_id, after=0, limit=16384):
        """A byte-preserving, bounded page of an authorized run's current log."""
        if type(after) is not int or not 0 <= after <= MAX_LOG or type(limit) is not int or not 1 <= limit <= 65536:
            raise CodeError(400, "invalid_output_cursor", "output needs a byte offset from 0 to 4 MiB and a limit from 1 to 65536")
        record = self.run(principal, run_id)
        ws = self.workspace(record["workspace_id"])
        self._authorize(principal, "events", ws, {})
        if principal.grant["paths"]:
            raise CodeError(403, "log_scope", "run output requires unrestricted workspace file scope")
        self.authority.gate(principal, "events", {"workspace_id": ws["id"], "run_id": run_id,
                                                 "resource": "run-output", "after": after, "limit": limit})
        path = self.store.root / "runs" / run_id / "output.log"
        data, size = b"", 0
        terminal = record["status"] not in ("prepared", "starting", "running", "cancel_requested")
        artifact = record.get("output_digest") if terminal else None
        if artifact:
            # Completed output is custody-checked evidence, independent of mutable log files.
            frozen = self.store.read_blob(artifact, ws["id"])
            size = len(frozen)
            if after > size:
                raise CodeError(416, "output_offset", "byte offset is beyond the available output")
            data = frozen[after:min(after + limit, MAX_LOG)]
        elif path.exists():
            with path.open("rb") as log:
                size = os.fstat(log.fileno()).st_size
                if after > size:
                    raise CodeError(416, "output_offset", "byte offset is beyond the available output")
                log.seek(after)
                data = log.read(min(limit, size - after, MAX_LOG - after))
        elif after:
            raise CodeError(416, "output_offset", "byte offset is beyond the available output")
        self._live(principal)
        cursor = after + len(data)
        try:
            content_text = data.decode("utf-8")
        except UnicodeDecodeError:
            content_text = None
        terminal = record["status"] not in ("prepared", "starting", "running", "cancel_requested")
        return {"run_id": run_id, "workspace_id": ws["id"], "generation": record["generation"],
                "tree_digest": record["tree_digest"], "after": after, "cursor": cursor, "size_bytes": size,
                "encoding": "base64", "data": base64.b64encode(data).decode(), "content_text": content_text,
                "source": "verified-artifact" if artifact else "unverified-run-log" if terminal else "live-run-log",
                "truncated": size > MAX_LOG, "readable_bytes": min(size, MAX_LOG),
                "eof": cursor == size, "complete": terminal and record["descendants_terminated"] and cursor == size,
                "status": record["status"], "exit_code": record["exit_code"],
                "descendants_terminated": record["descendants_terminated"], "observed_at": record.get("observed_at"),
                "output_digest": artifact}

    def proof_result(self, principal, run_id):
        """Typed immutable checker output; native process integrity remains cooperative."""
        record = self.run(principal, run_id)
        ws = self.workspace(record['workspace_id'])
        self._authorize(principal, 'events', ws, {})
        self._live(principal)
        if principal.grant['paths']:
            raise CodeError(403, 'proof_scope', 'proof evidence requires full workspace read/event scope')
        self.authority.gate(principal, 'events', {'workspace_id':ws['id'], 'run_id':run_id,
                                                'resource':'proof-result'})
        proof = record.get('proof_check')
        if not proof:
            raise CodeError(409, 'not_proof_run', 'run has no frozen proof checker')
        envelope = {'run_id':run_id, 'workspace_id':ws['id'], 'generation':record['generation'],
            'tree_digest':record['tree_digest'], 'run_status':record['status'],
            'checker':proof, 'output_digest':record.get('output_digest'),
            'implementation_applicability':'unverified', 'sandboxed':False}
        if record['status'] in ('prepared','starting','running','cancel_requested'):
            result = {'status':'pending', 'result':None}
        elif not record['descendants_terminated'] or not record.get('output_digest'):
            result = {'status':'unconfirmed', 'result':None,
                      'reason':'terminal checker output or process termination is unconfirmed'}
        else:
            raw = self.store.read_blob(record['output_digest'], ws['id'])
            from .proof_result import validate
            try: checked = validate(raw, record)
            except (ValueError, TypeError, KeyError, UnicodeError) as error:
                raise CodeError(409, 'proof_result_invalid', str(error)) from None
            result = {'status':checked['status'], 'result':checked}
        self._live(principal)
        current = self.workspace(ws['id'])
        self._authorize(principal, 'read', current, {})
        self._authorize(principal, 'events', current, {})
        currency = 'current' if current['generation']==record['generation'] and current['tree_digest']==record['tree_digest'] else 'historical'
        return {**envelope, **result, 'currency':currency}

    def evidence_history(self, principal, ws_id, kind, limit=50, cursor=None):
        """Bounded workspace evidence page; cursor binds its workspace and evidence kind."""
        if kind not in ("run", "verification") or type(limit) is not int or not 1 <= limit <= 100:
            raise CodeError(400, "invalid_history", "history needs a supported kind and limit from 1 to 100")
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        if principal.grant["paths"]:
            raise CodeError(403, "history_scope", "full evidence history requires unrestricted workspace file scope")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": kind + "-history"})
        after = None
        if cursor:
            try:
                if not isinstance(cursor, str) or len(cursor) > 512:
                    raise ValueError()
                after = json.loads(base64.b64decode(cursor + "=" * (-len(cursor) % 4), altchars=b"-_", validate=True))
                if after["workspace_id"] != ws_id or after["kind"] != kind or type(after["at"]) not in (int, float) or not math.isfinite(after["at"]) or not isinstance(after["id"], str) or not 1 <= len(after["id"]) <= 100:
                    raise ValueError()
            except (ValueError, KeyError, TypeError):
                raise CodeError(400, "invalid_cursor", "history cursor is invalid for this workspace and evidence kind") from None
        query = "SELECT body FROM records WHERE kind=? AND json_extract(body,'$.workspace_id')=?"
        params = [kind, ws_id]
        if after:
            query += " AND (json_extract(body,'$.created_at') < ? OR (json_extract(body,'$.created_at') = ? AND id < ?))"
            params.extend([after["at"], after["at"], after["id"]])
        query += " ORDER BY json_extract(body,'$.created_at') DESC,id DESC LIMIT ?"
        params.append(limit + 1)
        with self.store.lock:
            ws = self.workspace(ws_id)
            rows = [json.loads(row[0]) for row in self.store.db.execute(query, params)]
        more, rows = len(rows) > limit, rows[:limit]
        next_cursor = None
        if more:
            last = rows[-1]
            next_cursor = base64.urlsafe_b64encode(canonical({"workspace_id": ws_id, "kind": kind, "at": last["created_at"], "id": last["id"]})).decode().rstrip("=")
        return {"workspace_id": ws_id, "generation": ws["generation"], "tree_digest": ws["tree_digest"],
                "items": [{**row, "currency": "current" if row["tree_digest"] == ws["tree_digest"] else "stale"} for row in rows],
                "next_cursor": next_cursor}

    def cancel(self, principal, run_id, payload):
        run = self.store.get("run", run_id)
        ws = self.workspace(run["workspace_id"])
        def apply():
            current = self.store.get("run", run_id)
            if current["status"] == "prepared":
                current.update(status="cancelled", descendants_terminated=True, observed_at=stamp())
                self.store.put("run", current)
                self.store.emit(ws, "run.cancelled", {"run_id": run_id, "by": principal.actor, "launched": False})
            if current["status"] in ("prepared", "starting", "running", "cancel_requested"):
                root = self.store.root / "runs" / run_id
                atomic_write(root / "cancel.request", b"cancel requested")
                current["status"] = "cancel_requested"
                current["cancel_requested_at"] = stamp()
                self.store.put("run", current)
                self.store.emit(ws, "run.cancel_requested", {"run_id": run_id, "by": principal.actor})
            return {"run_id": run_id, "status": current["status"], "acknowledged": current.get("descendants_terminated", False)}
        return self._operation(principal, "cancel", ws, dict(payload, run_id=run_id), apply)

    def verify(self, principal, payload):
        self.reconcile()
        run = self.store.get("run", payload["run_id"])
        ws = self.workspace(run["workspace_id"])
        def apply():
            current_run = self.store.get("run", run["id"])
            if current_run["status"] not in ("completed", "failed", "timed_out", "cancelled", "output_limit", "interrupted", "unknown"):
                raise CodeError(409, "run_incomplete", "execution has not finished")
            status = "passed" if current_run["status"] == "completed" and current_run["exit_code"] == 0 and current_run["descendants_terminated"] and not current_run.get("input_mutations") else "failed"
            if current_run["status"] in ("unknown", "interrupted"):
                status = "unknown"
            vr = {"id": ident("vr"), "workspace_id": ws["id"], "task_id": ws["task_id"], "run_id": run["id"],
                  "tree_digest": current_run["tree_digest"], "generation": current_run["generation"],
                  "status": status, "run_status": current_run["status"], "argv": current_run["argv"],
                  "exit_code": current_run["exit_code"], "environment": current_run["environment"],
                  "evaluator_digest": current_run["evaluator_digest"],
                  "evaluator_kind": "trusted-native-command", "created_at": stamp(), "author": principal.actor,
                  "output_digest": current_run.get("output_digest"), "receipt_digest": current_run.get("receipt_digest"),
                  "input_mutations": current_run.get("input_mutations", []), "independent_rsi_evaluation": False}
            self.store.put("verification", vr)
            self.store.emit(ws, "verification.recorded", vr)
            # Return this operation's receipt under its existing verify authority.
            # A separate read gate here would roll back valid verify-only approvals.
            current = self.workspace(ws["id"])
            return {**vr, "currency": "current" if vr["tree_digest"] == current["tree_digest"] else "stale"}
        return self._operation(principal, "verify", ws, payload, apply)

    def verification(self, principal, id_):
        vr = self.store.get("verification", id_)
        ws = self.workspace(vr["workspace_id"])
        self._authorize(principal, "read", ws, {})
        return {**vr, "currency": "current" if vr["tree_digest"] == ws["tree_digest"] else "stale"}

    def checkpoint(self, principal, ws_id, payload):
        ws = self.workspace(ws_id)
        def apply():
            current = self.workspace(ws_id)
            self._fresh(current, payload.get("expected_generation"), payload.get("expected_tree_digest"))
            cp = {"id": ident("cp"), "workspace_id": ws_id, "task_id": current["task_id"],
                  "generation": current["generation"], "tree_digest": current["tree_digest"],
                  "label": payload["label"], "decision": payload.get("decision", ""),
                  "created_at": stamp(), "author": principal.actor}
            self.store.put("checkpoint", cp)
            self.store.emit(current, "checkpoint.created", cp)
            return cp
        return self._operation(principal, "checkpoint", ws, payload, apply)

    def checkpoints(self, principal, ws_id):
        ws = self.workspace(ws_id)
        self._authorize(principal, "read", ws, {})
        if principal.grant["paths"]:
            raise CodeError(403, "checkpoint_scope", "checkpoint decisions require full workspace scope")
        self.authority.gate(principal, "read", {"workspace_id": ws_id, "resource": "checkpoints"})
        return {"checkpoints": [c for c in self.store.list("checkpoint") if c["workspace_id"] == ws_id]}

    def restore_checkpoint(self, principal, ws_id, payload):
        """Restore source as a new CAS generation; never rewind journal, runs or authority."""
        ws = self.workspace(ws_id)
        self._authorize(principal, "edit", ws, {})
        if principal.grant["paths"]:
            raise CodeError(403, "restore_scope", "whole-workspace restore requires unrestricted file scope")
        def apply():
            current = self.workspace(ws_id)
            self._fresh(current, payload["expected_generation"], payload["expected_tree_digest"])
            cp = self.store.get("checkpoint", payload["checkpoint_id"])
            if cp["workspace_id"] != ws_id or cp["task_id"] != current["task_id"]:
                raise CodeError(403, "checkpoint_forbidden", "checkpoint belongs to another workspace")
            before = self.manifest(current)["files"]
            files = self.manifest(current, cp["tree_digest"])["files"]
            # Read and hash every referenced source blob before committing restoration.
            for name, entry in files.items():
                safe_path(name)
                content = self.store.read_blob(entry["digest"], ws_id)
                if len(content) != entry["size"] or len(content) > MAX_FILE:
                    raise CodeError(409, "checkpoint_corrupt", "checkpoint source size differs from its manifest")
            tree = self._manifest(files, ws_id)
            if tree != cp["tree_digest"]:
                raise CodeError(409, "checkpoint_corrupt", "checkpoint manifest differs from its recorded tree")
            changes = {"id": ident("cs"), "workspace_id": ws_id, "task_id": current["task_id"],
                       "author": principal.actor, "base_commit": current["base_commit"],
                       "before_digest": current["tree_digest"], "tree_digest": tree,
                       "generation": current["generation"] + 1,
                       "paths": sorted(n for n in set(before) | set(files) if before.get(n) != files.get(n)),
                       "restored_checkpoint_id": cp["id"], "created_at": stamp()}
            changes["diff_digest"] = self.store.blob(self._diff(current, current["tree_digest"], tree).encode(), ws_id, "diff")
            current.update(generation=changes["generation"], tree_digest=tree)
            current["history"].append({"generation": current["generation"], "tree_digest": tree,
                                       "author": principal.actor, "change_id": changes["id"],
                                       "restored_checkpoint_id": cp["id"]})
            self.store.put("workspace", current)
            self.store.put("change", changes)
            self.store.emit(current, "workspace.restored", changes)
            return {"workspace": current, "change": changes, "checkpoint": cp}
        return self._operation(principal, "edit", ws, dict(payload, mutation="restore-checkpoint"), apply)

    def retain_proposal_test_receipt(self, principal, ws_id, payload):
        from .proposal_test_receipts import retain
        return retain(self, principal, ws_id, payload)

    def proposal_test_receipt(self, principal, ws_id, receipt_id):
        # Route identity is checked before revealing the retained record.
        record = self.store.get('proposal_test_receipt', receipt_id)
        if record['workspace_id'] != ws_id:
            raise CodeError(403, 'proposal_test_scope', 'receipt belongs to another workspace')
        from .proposal_test_receipts import read
        return read(self, principal, receipt_id)
