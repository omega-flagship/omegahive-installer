"""Disposable, default-off preparation route; never installed in a release.

Uses the existing authority, preparation custody and host binding. No launch,
person derivative grant, generic principal conversion or source acceptance.
"""
import time
from typing import Annotated
from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel, ConfigDict
from omegacode.common import CodeError, canonical, digest
from .purpose_auth import PurposeAuthority
from .preparation_bind import bind, BIND
from .launch_admission import scope_binding

class PrepareBody(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)

def install(app, service, authority, host, *, enabled=False):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    if not enabled:
        return False
    if app.state.service is not service or not isinstance(authority, PurposeAuthority) or authority.store is not service.store or (authority.registration != service.authority.registration) or (not authority._proposal_enabled):
        raise ValueError('purpose authority must bind this registered service and Store')
    if getattr(app.state, '_code_purpose_preparation_installed', False) or any((getattr(route, 'path', None) == '/v1/proposal-tests' for route in app.routes)):
        raise ValueError('purpose preparation route already installed')

    def principal(authorization: Annotated[str | None, Header()]=None, x_hive_token: Annotated[str | None, Header()]=None):
        if not authorization or not authorization.startswith('Bearer '):
            raise CodeError(401, 'authentication_required', 'a scoped bearer capability is required')
        return authority.authenticate(authorization[7:], x_hive_token)
    router = APIRouter()

    @router.post('/v1/proposal-tests', status_code=201)
    def prepare(body: PrepareBody, p=Depends(principal)):
        service._check_owner(required=True)
        g = p.grant
        purpose = g.get('proposal_test')
        if not purpose or purpose['stage'] != 'prepare':
            raise CodeError(403, 'proposal_test_route', 'prepare capability required')
        tid = purpose['test_id']
        claims = canonical(g)
        with service.store.lock:
            owned = any((row['id'] == tid for row in service.store.list(BIND)))
        authority.require_route(p, 'GET' if owned else 'POST', '/v1/proposal-tests/' + tid if owned else '/v1/proposal-tests')
        result = bind(service, authority, p, host)
        authority.require_route(p, 'GET', '/v1/proposal-tests/' + tid)
        with service.store.lock:
            service._check_owner(required=True)
            retained = service.store.get(BIND, tid)
            preparation = service.store.get('proposal_preparation', tid)
            if canonical(g) != claims or g['exp'] <= time.time() or retained['state'] != 'acknowledged' or (retained['body']['capability_id'] != g['id']) or (retained['fingerprint'] != digest(canonical(retained['body']))) or (retained['ack'] != result['ack']) or (preparation['binding'] != scope_binding(g)):
                raise CodeError(409, 'proposal_bind_custody', 'original preparation binding changed')
        return result
    app.include_router(router)
    app.state._code_purpose_preparation_installed = True
    return True
