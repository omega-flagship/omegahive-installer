// Bounded native parametric validation for proposed person save-source support.
// Access, actor, source reference and publication remain the host/program's work.
import fs from 'node:fs/promises';
import {readModelSource,MODEL_LIMITS,geometryBudget} from './model-source.mjs';
import {digest} from './scene.mjs';
try{
 const [input,...extra]=process.argv.slice(2);
 if(!input||extra.length)throw Error('One model source input path required');
 const stat=await fs.stat(input);
 if(!stat.isFile()||stat.size>MODEL_LIMITS.sourceBytes)throw Error('Model source exceeds 1 MB');
 const bytes=await fs.readFile(input);
 if(bytes.byteLength>MODEL_LIMITS.sourceBytes)throw Error('Model source exceeds 1 MB');
 const revision=await readModelSource(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 const budgets=revision.document.objects.map(geometryBudget);
 console.log(JSON.stringify({schema:'omega-model-inspection-1',model_id:revision.document.id,model_digest:revision.digest,metadata_digest:await digest(revision.document.metadata),units:revision.document.units,objects:revision.document.objects.length,vertices:budgets.reduce((n,b)=>n+b.vertices,0),indices:budgets.reduce((n,b)=>n+b.indices,0),adopted:false}));
}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}
