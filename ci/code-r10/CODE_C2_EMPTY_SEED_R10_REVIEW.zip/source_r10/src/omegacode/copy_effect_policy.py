"""Bounded pure owner classification, outside SQL; no deletion authority is minted.

Adapter is read-only classification of immutable supplied source/edit bindings.
It must be replaced/removed on owner policy withdrawal/revision. Stalled work is
bounded to four live workers per Service across adapter generations; timeout
does not imply termination. A replacement adapter can recover until that cap.
Production has no adapter and refuses automatic application.
"""
import json
import threading
import time
from .common import CodeError, canonical, digest

DEADLINE_SECONDS = 2.0
MAX_LIVE_WORKERS = 4

def unavailable(message):
    return CodeError(503, 'copy_effect_policy_unavailable', message)

class Admission:
    def __init__(self, service, adapter, binding):
        self.service, self.adapter, self.binding = service, adapter, binding
        self.until = time.monotonic() + DEADLINE_SECONDS
    def assert_current(self):
        # No adapter invocation, lock wait, network or worker wait in the transaction.
        if (getattr(self.service, 'copy_effect_policy', None) is not self.adapter
                or time.monotonic() >= self.until):
            raise unavailable('classification expired or original policy changed')

def check_effect(service, ws_id, payload, edits):
    if getattr(service.store.transaction_local, 'active', False):
        raise unavailable('classification may not wait inside a database transaction')
    adapter = getattr(service, 'copy_effect_policy', None)
    if not callable(adapter):
        raise unavailable('original deletion policy is not connected')
    binding = {'workspace_id': ws_id, 'request_id': payload['request_id'], 'operation_id': payload['operation_id'],
               'suggestion_id': payload['suggestion_id'],
               'suggestion_digest': payload['suggestion_digest'], 'scope_id': payload['scope_id'],
               'scope_digest': payload['scope_digest'], 'generation': payload['expected_generation'],
               'tree_digest': payload['expected_tree_digest'], 'edits_digest': digest(canonical(edits))}
    # Single-flight shares only an identical immutable classification. Live
    # capability checks and the mutation's idempotency/CAS remain per request.
    fingerprint = digest(canonical(binding))
    with service.store.lock:
        jobs = [job for job in getattr(service, '_copy_policy_jobs', [])
                if not job['ready'].is_set()]
        service._copy_policy_jobs = jobs
        # Adapter object identity is the owner policy generation. An abandoned
        # generation cannot launch more work, but a replacement gets capacity.
        same = next((job for job in jobs if job['adapter'] is adapter), None)
        if same is not None:
            if same['abandoned'] or same['fingerprint'] != fingerprint:
                raise unavailable('original policy generation is still occupied')
            job, launch = same, False
        else:
            if len(jobs) >= MAX_LIVE_WORKERS:
                raise unavailable('original policy worker capacity is exhausted')
            job = {'ready': threading.Event(), 'result': {}, 'adapter': adapter,
                   'fingerprint': fingerprint, 'abandoned': False}
            jobs.append(job)
            launch = True
        service._copy_policy_job = job
    def work():
        try:
            answer = adapter(json.loads(canonical(binding)), json.loads(canonical(edits)))
            job['result']['answer'] = json.loads(canonical(answer))
        except BaseException:
            job['result']['failed'] = True
        finally:
            job['ready'].set()
    if launch:
        try:
            threading.Thread(target=work, daemon=True, name='code-effect-policy').start()
        except BaseException:
            # Wake identical waiters and clear only this failed launch; never
            # remove another generation's retained job.
            with service.store.lock:
                job['result']['failed'] = True
                job['ready'].set()
                service._copy_policy_jobs = [other for other in service._copy_policy_jobs
                                            if other is not job]
                if getattr(service, '_copy_policy_job', None) is job:
                    service._copy_policy_job = None
            raise unavailable('original policy worker could not start') from None
    if not job['ready'].wait(DEADLINE_SECONDS):
        job['abandoned'] = True
        raise unavailable('original policy deadline expired; worker termination is unconfirmed')
    if job['abandoned']:
        raise unavailable('classification completed after its caller deadline')
    result = job['result']
    if result.get('failed'):
        raise unavailable('original deletion policy could not resolve this effect')
    answer = result['answer']
    if (not isinstance(answer, dict) or set(answer) != {'binding', 'classification'}
            or answer['binding'] != binding or answer['classification'] != 'non_deleting'):
        raise CodeError(403, 'copy_effect_unresolved', 'deleting or unresolved effects cannot enter automatic application')
    admission = Admission(service, adapter, binding)
    admission.assert_current()
    return admission
