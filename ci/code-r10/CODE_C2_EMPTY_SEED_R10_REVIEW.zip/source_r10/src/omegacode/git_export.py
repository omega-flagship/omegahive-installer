"""Portable Git review history built from authorized source manifests.

Fixed commands, stripped Git configuration, no registered-source repository writes.
Default reconstructed history is distinct from original history. Operator-enabled
original mode validates and imports only the pinned parent's bounded ancestry.
"""
import os
import pathlib
import subprocess
import time
import shutil
import signal
import hashlib

from .common import CodeError, MAX_TREE, safe_path

MAX_EXPORT = MAX_TREE * 3


def validate_branch(branch):
    import re
    if not isinstance(branch, str) or len(branch)>120 or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._/-]*',branch):
        raise CodeError(400,'git_branch','invalid review branch name')
    if '..' in branch or any(p in ('','.') or p.startswith('.') or p.endswith(('.','.lock')) for p in branch.split('/')) or branch in ('HEAD','omegacode-baseline'):
        raise CodeError(400,'git_branch','invalid review branch name')
    return branch


def validate_paths(files, code='git_export_path'):
    seen=set()
    for name in files:
        safe_path(name)
        parts=pathlib.PurePosixPath(name).parts
        if any(p.casefold()=='.git' for p in parts) or name.casefold() in seen:
            raise CodeError(403,code,'Git metadata or case-colliding paths are refused')
        seen.add(name.casefold())
    for name in files:
        parts=pathlib.PurePosixPath(name).parts
        if any('/'.join(parts[:i]).casefold() in seen for i in range(1,len(parts))):
            raise CodeError(403,code,'file/directory paths collide')


def export(root, before, after, materialize, branch, message, actor, when, source=None, parent=None):
    validate_branch(branch)
    if not isinstance(message,str) or not 1<=len(message)<=4000 or '\0' in message:
        raise CodeError(400,'git_message','commit message needs 1 to 4000 non-NUL characters')
    for files in (before,after):
        validate_paths(files)
    tree=root/'tree'
    materialize(before,tree)
    home=root/'home';home.mkdir()
    # No global/system config, hooks, credential helpers or source-repository settings.
    env={'PATH':os.defpath,'HOME':str(home),'LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1',
         'GIT_ATTR_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_NO_REPLACE_OBJECTS':'1','GIT_TERMINAL_PROMPT':'0','GIT_NO_LAZY_FETCH':'1',
         'GIT_AUTHOR_NAME':'OmegaCode','GIT_AUTHOR_EMAIL':'omegacode@local.invalid',
         'GIT_COMMITTER_NAME':'OmegaCode','GIT_COMMITTER_EMAIL':'omegacode@local.invalid',
         'GIT_AUTHOR_DATE':f'@{int(when)} +0000','GIT_COMMITTER_DATE':f'@{int(when)} +0000'}
    deadline=time.monotonic()+30
    def git(args, data=None, directory=None):
        remaining=deadline-time.monotonic()
        if remaining<=0: raise CodeError(504,'git_export_timeout','Git review export deadline exceeded')
        try:
            proc=subprocess.Popen(['git','--no-pager','-c','core.hooksPath='+os.devnull,'-c','core.autocrlf=false',
                '-c','core.attributesFile='+os.devnull,'-c','core.safecrlf=false','-c','core.filemode=true','-c','commit.gpgsign=false','-C',str(directory or tree),*args],
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True)
            stdout,stderr=proc.communicate(data,timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL)
            proc.communicate()
            raise CodeError(504,'git_export_timeout','Git review export deadline exceeded') from None
        except OSError:
            raise CodeError(503,'git_export_unavailable','Git review export could not finish') from None
        if proc.returncode: raise CodeError(409,'git_export_failed','fixed Git review command failed')
        if len(stdout)>MAX_EXPORT: raise CodeError(413,'git_export_limit','Git export exceeds byte budget')
        return stdout
    version=git(['--version']).decode().strip()
    history = None
    if source is not None:
        # Bind fixed commands to operator source, never a client path/revision.
        history = original_history(lambda args, data=None: git(args, data, directory=source), pathlib.Path(source), parent, before)
    init=['init','--quiet','--initial-branch=omegacode-baseline']
    if history: init.append('--object-format='+history['object_format'])
    git(init)
    (tree/'.git/info/attributes').write_text('* -text -filter -ident -working-tree-encoding !diff\n')
    if history:
        git(['index-pack','--stdin'],history['pack'])
        git(['update-ref','refs/heads/omegacode-baseline',parent])
        git(['read-tree',parent])
    else:
        git(['add','--all','--force','--','.'])
        git(['commit','--quiet','--allow-empty','--no-verify','--no-gpg-sign','-F','-'],b'OmegaCode reconstructed source snapshot baseline\n')
    baseline=git(['rev-parse','HEAD']).decode().strip()
    git(['symbolic-ref','HEAD','refs/heads/'+branch])
    git(['update-ref','refs/heads/'+branch,baseline])
    # Remove exactly the old source paths, keeping only generated .git metadata.
    for name in before: (tree/name).unlink()
    # Empty old directories can collide with newly created file paths.
    for path in sorted((p for p in tree.rglob('*') if p.is_dir() and '.git' not in p.relative_to(tree).parts),key=lambda p:len(p.parts),reverse=True):
        try: path.rmdir()
        except OSError: pass
    materialize(after,root/'candidate')
    shutil.copytree(root/'candidate',tree,dirs_exist_ok=True)
    git(['add','--all','--force','--','.'])
    git(['commit','--quiet','--allow-empty','--no-verify','--no-gpg-sign','-F','-'],message.encode())
    commit=git(['rev-parse','HEAD']).decode().strip()
    git_tree=git(['rev-parse','HEAD^{tree}']).decode().strip()
    patch=git(['diff','--binary','--full-index','--no-ext-diff','--no-textconv',baseline,commit,'--','.'])
    bundle=root/'review.bundle'
    git(['bundle','create',str(bundle),'refs/heads/'+branch,'HEAD'])
    if bundle.stat().st_size>MAX_EXPORT: raise CodeError(413,'git_export_limit','Git review bundle exceeds byte budget')
    return {'baseline_commit':baseline,'commit':commit,'branch_ref':'refs/heads/'+branch,
            'git_tree':git_tree,'git_version':version,'patch':patch,'bundle':bundle.read_bytes(),
            'git_author':'OmegaCode <omegacode@local.invalid>','request_actor':actor,
            **({'history_commits':history['commits'],'history_objects':history['objects'],
                'history_uncompressed_bytes':history['bytes'],'object_format':history['object_format']} if history else {})}


def original_history(git, source, parent, before):
    import re
    if not isinstance(parent,str) or not re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}',parent):
        raise CodeError(400,'git_history_parent','history needs the workspace pinned full commit identity')
    if git(['rev-parse','--is-shallow-repository']).strip()!=b'false':
        raise CodeError(409,'git_history_incomplete','shallow history is unsupported')
    keys=git(['config','--local','--name-only','--list']).decode().casefold().splitlines()
    if any(k=='extensions.partialclone' or k.endswith('.promisor') for k in keys):
        raise CodeError(409,'git_history_incomplete','partial-clone configuration is unsupported')
    common=pathlib.Path(git(['rev-parse','--git-common-dir']).decode().strip())
    if not common.is_absolute(): common=source/common
    if (common/'info/grafts').exists() or (common/'objects/info/alternates').exists() or list((common/'objects/pack').glob('*.promisor')):
        raise CodeError(409,'git_history_incomplete','grafted, alternate or partial-clone history is unsupported')
    commits=git(['rev-list','--max-count=1001',parent]).decode().splitlines()
    if len(commits)>1000: raise CodeError(413,'git_history_limit','original history exceeds 1000 commits')
    baseline=[]
    for commit in commits:
        entries=git(['ls-tree','-rz','--full-tree',commit]).split(b'\0')
        files={}
        for entry in entries:
            if not entry: continue
            description,name=entry.split(b'\t',1)
            mode,kind,object_id=description.decode().split()
            try: name=name.decode('utf-8')
            except UnicodeError:
                raise CodeError(403,'git_history_path','non-UTF-8 history paths are unsupported') from None
            if kind!='blob' or mode not in ('100644','100755'):
                raise CodeError(403,'git_history_special','history contains symlink, submodule or special entries')
            files[name]={'object_id':object_id,'executable':mode=='100755'}
        if len(files)>2000: raise CodeError(413,'git_history_limit','history tree exceeds 2000 files')
        validate_paths(files,code='git_history_path')
        if commit==parent: baseline=list(files.items())
    if set(name for name,_ in baseline)!=set(before):
        raise CodeError(409,'git_history_baseline_mismatch','original parent paths differ from saved workspace baseline')
    raw=git(['cat-file','--batch'],''.join(entry['object_id']+'\n' for _,entry in baseline).encode())
    offset=0
    for name,entry in baseline:
        end=raw.index(b'\n',offset); oid,kind,size=raw[offset:end].decode().split(); size=int(size)
        data=raw[end+1:end+1+size]; offset=end+size+2
        if oid!=entry['object_id'] or kind!='blob' or len(data)!=size or hashlib.sha256(data).hexdigest()!=before[name]['digest'] or entry['executable']!=before[name]['executable']:
            raise CodeError(409,'git_history_baseline_mismatch','original parent bytes or mode differ from saved baseline')
    objects=git(['rev-list','--objects','--no-object-names',parent]).decode().splitlines()
    if len(objects)>10000: raise CodeError(413,'git_history_limit','original history exceeds 10000 objects')
    sizes=git(['cat-file','--batch-check'],('\n'.join(objects)+'\n').encode()).decode().splitlines()
    total=0
    for row in sizes:
        _,kind,size=row.split()
        if kind not in ('blob','tree','commit'): raise CodeError(409,'git_history_incomplete','history has missing or unsupported objects')
        total+=int(size)
    if total>MAX_TREE: raise CodeError(413,'git_history_limit','original history exceeds 32 MiB uncompressed object budget')
    pack=git(['-c','pack.threads=1','-c','pack.windowMemory=8m','pack-objects','--stdout','--no-reuse-delta','--no-reuse-object'],('\n'.join(objects)+'\n').encode())
    return {'pack':pack,'commits':len(commits),'objects':len(objects),'bytes':total,
            'object_format':git(['rev-parse','--show-object-format']).decode().strip()}
