"""Saved-source context selection; ignore rules narrow analysis, never grant access."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from .common import CodeError, canonical, digest, safe_path
from .language_buffers import portable_path_alias, validate_new_path_namespace


def binding(files, config):
    enabled = config.get('context_gitignore_enabled', False)
    excluded = config.get('context_excluded_paths', [])
    if type(enabled) is not bool or type(excluded) is not list or len(excluded) > 256:
        raise CodeError(503, 'context_configuration', 'invalid context exclusion configuration')
    if any(type(p) is not str or len(p) > 1000 for p in excluded):
        raise CodeError(503, 'context_configuration', 'invalid context exclusion path')
    try: excluded = sorted(set(safe_path(p.rstrip('/')) for p in excluded))
    except CodeError:
        raise CodeError(503, 'context_configuration', 'context exclusions must be relative file/directory paths') from None
    rules = {p: e['digest'] for p, e in sorted(files.items()) if enabled and Path(p).name == '.gitignore'}
    return {'gitignore_enabled': enabled, 'excluded_paths': excluded, 'rule_sources': rules}


def _select(files, config, read, scratch_root, allowed=(), destinations=()):
    for p in files: safe_path(p)
    if (type(destinations) not in (tuple, list) or len(destinations) > 100 or
            any(type(path) is not str for path in destinations) or len(set(destinations)) != len(destinations)):
        raise CodeError(400, 'context_destinations', 'up to 100 distinct destination paths are required')
    destinations = tuple(sorted(destinations))
    for path in destinations:
        safe_path(path)
        if len(path.encode('utf-8')) > 1000 or any(len(part.encode('utf-8')) > 255 for part in path.split('/')):
            raise CodeError(413, 'context_limit', 'destination path exceeds source path bounds')
        if allowed and not any(path == a or path.startswith(a.rstrip('/') + '/') for a in allowed):
            raise CodeError(403, 'context_scope', 'destination is outside the authorized path scope')
    policy = binding(files, config)
    visible = {p:e for p,e in files.items() if not allowed or any(p == a or p.startswith(a.rstrip('/') + '/') for a in allowed)}
    if policy['gitignore_enabled']:
        # Parent rules must be read under the same grant; do not silently omit them.
        if any(p not in visible for p in policy['rule_sources']):
            raise CodeError(403, 'context_scope', 'Git ignore selection requires access to its rule sources')
    ignored = set()
    if policy['rule_sources'] and (visible or destinations):
        if len(files) + len(destinations) > 4096 or sum(len(p.encode()) + 1 for p in files) + sum(len(p.encode()) + 1 for p in destinations) > 2 * 1024**2:
            raise CodeError(413, 'context_limit', 'context ignore path map exceeds limits')
        if len(policy['rule_sources']) > 128 or sum(files[p]['size'] for p in policy['rule_sources']) > 256 * 1024:
            raise CodeError(413, 'context_limit', 'context ignore rule budget exceeded')
        rules = {}
        for p in policy['rule_sources']:
            if files[p]['size'] > 65536:
                raise CodeError(413, 'context_limit', 'context ignore file exceeds 64 KiB')
            raw = read(files[p]['digest'])
            if len(raw) != files[p]['size'] or len(raw) > 65536 or digest(raw) != files[p]['digest'] or b'\0' in raw:
                raise CodeError(409, 'context_rules', 'context ignore source is invalid')
            try: raw.decode('utf-8')
            except UnicodeDecodeError:
                raise CodeError(422, 'context_rules', 'context ignore source must be UTF-8') from None
            # Preserve the exact saved pattern language. Rewriting range or
            # negated classes can broaden exclusions or turn an exclusion into
            # an allow.
            rules[p] = raw
        if len(rules) > 128 or sum(map(len, rules.values())) > 256 * 1024:
            raise CodeError(413, 'context_limit', 'context ignore rule budget exceeded')
        git = shutil.which('git', path=os.defpath)
        if not git: raise CodeError(503, 'context_unavailable', 'Git context matcher unavailable')
        with tempfile.TemporaryDirectory(prefix='context-ignore-', dir=scratch_root) as temporary:
            root = Path(temporary); (root/'home').mkdir(); (root/'tmp').mkdir(); tree = root/'tree'; tree.mkdir()
            for p in visible: (tree/p).parent.mkdir(parents=True, exist_ok=True)
            for p, raw in rules.items(): (tree/p).write_bytes(raw)
            env = {'PATH':os.defpath, 'LANG':'C.UTF-8', 'HOME':str(root/'home'), 'TMPDIR':str(root/'tmp'),
                   'GIT_CONFIG_NOSYSTEM':'1', 'GIT_CONFIG_GLOBAL':os.devnull, 'GIT_CONFIG_SYSTEM':os.devnull}
                # Delegate case-insensitive ignore semantics to Git and query
                # each destination using its exact spelling.
            argv = [git, '-c', 'core.excludesFile=/dev/null', '-c', 'core.ignorecase=true',
                    '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false']
            try:
                init = subprocess.run(argv + ['init','-q','--template='],cwd=tree,env=env,
                                      capture_output=True,timeout=5)
                if init.returncode: raise CodeError(503, 'context_unavailable', 'Git context setup failed')
                candidate_names = set(visible) | set(destinations)
                candidates = sorted(candidate_names)
                if sum(len(path.encode('utf-8')) + 1 for path in candidates) > 2 * 1024**2:
                    raise CodeError(413, 'context_limit', 'context path map exceeds limits')
                result = subprocess.run(argv + ['check-ignore','--no-index','--stdin','-z'],cwd=tree,env=env,
                    input=b''.join(p.encode()+b'\0' for p in candidates),capture_output=True,timeout=5)
            except (OSError, subprocess.TimeoutExpired):
                raise CodeError(503, 'context_unavailable', 'Git context matcher failed') from None
            if result.returncode not in (0,1) or len(result.stdout) > 2 * 1024**2:
                raise CodeError(503, 'context_unavailable', 'Git context matcher refused')
            try: ignored = {p.decode('utf-8') for p in result.stdout.split(b'\0') if p}
            except UnicodeDecodeError:
                raise CodeError(502, 'context_protocol', 'Git context matcher returned invalid paths') from None
            if not ignored <= (visible.keys() | set(destinations)):
                raise CodeError(502, 'context_protocol', 'Git context matcher returned foreign paths')
    selected = {p:e for p,e in visible.items() if p not in ignored and not any(
        p == excluded or p.startswith(excluded + '/') for excluded in policy['excluded_paths'])}
    context = {'policy_digest':digest(canonical(policy)), 'active':bool(policy['gitignore_enabled'] or policy['excluded_paths']),
               'excluded_count':len(visible)-len(selected), 'profile':'saved-gitignore-and-explicit-paths-v1',
               'authority':'does not widen grants or change direct file/execution authority'}
    return selected, context, ignored, policy


def select(files, config, read, scratch_root, allowed=()):
    selected, context, _, _ = _select(files, config, read, scratch_root, allowed)
    return selected, context


def select_destinations(files, config, read, scratch_root, destinations, allowed=()):
    """Evaluate exact absent-path names under the existing context policy.

    Destination names are only streamed to Git's existing matcher. No placeholder
    source files are materialized in the matcher worktree.
    """
    if destinations:
        validate_new_path_namespace(files, destinations, max_paths=100)
    selected, context, ignored, policy = _select(files, config, read, scratch_root, allowed, destinations)
    excludes = [portable_path_alias(p) for p in policy['excluded_paths']]
    results = {}
    for path in destinations:
        alias = portable_path_alias(path)
        explicitly_excluded = any(alias == excluded or alias.startswith(excluded + '/') or
                                  excluded.startswith(alias + '/') for excluded in excludes)
        if explicitly_excluded:
            results[path] = {'allowed':False, 'reason':'explicit_exclusion'}
        elif (path in ignored or
              any(parent in ignored for hit in ignored for parent in _path_parents(hit))):
            results[path] = {'allowed':False, 'reason':'gitignore'}
        else:
            results[path] = {'allowed':True, 'reason':None}
    return results, context


def _path_parents(path):
    """Yield lexical parent paths for an ignored manifest/matcher result."""
    parts=path.split('/')
    return ('/'.join(parts[:index]) for index in range(1,len(parts)))
