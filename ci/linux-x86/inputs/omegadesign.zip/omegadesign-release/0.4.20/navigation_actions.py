"""Read-only candidate; exact artifact custody precedes separate-process analysis."""
import hashlib,json
from .protocol import revision_ref
async def inspect_navigation(ctx, reference, query=None):
    revision_ref(reference);record=ctx.read_revision(reference['artifact_id'],reference['revision']);body=record['body'].encode()
    if len(body)>4*1024*1024 or record['digest']!=reference['digest'] or 'sha256:'+hashlib.sha256(body).hexdigest()!=reference['digest']:raise ValueError('Exact source bundle differs')
    bundle=json.loads(body)
    if bundle.get('schema')!='omega-python-source-bundle-1' or not isinstance(bundle.get('sources'),dict):raise ValueError('Python source bundle required')
    query={} if query is None else query
    if not isinstance(query,dict) or set(query)-{'file','symbol','index'}:raise ValueError('Bounded navigation query required')
    request=json.dumps({'sources':bundle['sources'],**query},allow_nan=False).encode()
    if len(request)>4*1024*1024:raise ValueError('Navigation request exceeds limit')
    result=await ctx.sandbox_run('navigation_cli.py',inputs={'request.json':request},outputs=['navigation.json'],runtime='python',bundle='tools',cpu_seconds=5,file_bytes=4*1024*1024,timeout=10)
    if result.get('exit')!=0 or result.get('missing_outputs') or result.get('stdout_truncated'):raise ValueError('Navigation sandbox refused or incomplete')
    raw=result.get('outputs',{}).get('navigation.json')
    if not isinstance(raw,bytes) or len(raw)>4*1024*1024:raise ValueError('Bounded navigation output required')
    # Recheck source access after execution; retained artifact is immutable.
    after=ctx.read_revision(reference['artifact_id'],reference['revision'])
    if after['digest']!=reference['digest']:raise ValueError('Source access or revision differs')
    analysis=json.loads(raw);selected=(analysis.get('location') or {}).get('definition',{}).get('file') or query.get('file')
    selected_source=None
    if selected in bundle['sources']:
        text=bundle['sources'][selected];selected_source={'file':selected,'text':text,'digest':'sha256:'+hashlib.sha256(text.encode()).hexdigest()}
    return {'source':dict(reference),'analysis':analysis,'selected_source':selected_source,'adopted':False,'scope':'Static Python navigation; no runtime or repair execution'}


async def view_navigation(ctx, focus):
    if not isinstance(focus,str) or not focus.startswith('studio-navigation:') or len(focus.encode())>4*1024*1024:raise ValueError('Bounded navigation focus required')
    request=json.loads(focus[len('studio-navigation:'):])
    if not isinstance(request,dict) or set(request)-{'source','query'} or 'source' not in request:raise ValueError('Exact navigation reference required')
    data=await inspect_navigation(ctx,request['source'],request.get('query'))
    return {'revision':data['source']['digest'],'items':[{'id':'python-navigation','kind':'status','label':'Python source navigation','data':data}],'links':[],'focus':'python-navigation'}
