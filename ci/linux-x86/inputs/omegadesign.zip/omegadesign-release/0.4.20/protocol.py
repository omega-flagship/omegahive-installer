"""Creative contracts, without a scheduler, artifact store or execution authority.

Digests bind JSON metadata. Asset bytes and access grants are verified by the host,
not by these pure functions. Media names are intentionally open-ended.
"""
import copy
import hashlib
import json
import math
import re

VERSION = "0.1"
SERVICE = "design"
MODES = {"create", "review", "evolve"}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(value):
    return "sha256:" + hashlib.sha256(canonical(value).encode()).hexdigest()


def text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be nonempty text")
    return value


def strings(value, name, required=False):
    if not isinstance(value, list) or (required and not value):
        raise ValueError(f"{name} must be a list" + (" with entries" if required else ""))
    for item in value:
        text(item, name)
    if len(set(value)) != len(value):
        raise ValueError(f"{name} has duplicate entries")
    return value


def revision_ref(value):
    if not isinstance(value, dict):
        raise ValueError("revision reference must be an object")
    text(value.get("artifact_id"), "artifact_id")
    n = value.get("revision")
    if type(n) is not int or n < 1:
        raise ValueError("revision must be a positive integer")
    if not isinstance(value.get("digest"), str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", value["digest"]):
        raise ValueError("revision digest must be SHA256")


def validate_brief(brief):
    if not isinstance(brief, dict) or brief.get("contract") != VERSION:
        raise ValueError("unsupported creative brief contract")
    for name in ("project", "title", "purpose", "audience", "medium"):
        text(brief.get(name), name)
    if brief.get("mode") not in MODES:
        raise ValueError("mode must be create, review or evolve")
    for name in ("constraints", "context_refs", "feedback_refs"):
        strings(brief.get(name), name)
    strings(brief.get("acceptance"), "acceptance", required=True)
    budget = brief.get("budget_usd")
    if type(budget) not in (int, float) or not math.isfinite(budget) or budget < 0:
        raise ValueError("budget_usd must be finite and nonnegative")
    # Authority is obtained separately from authenticated host policy.
    if brief.get("delivery") != "proposal":
        raise ValueError("this contract delivers proposals; it grants no apply/publish authority")
    target = brief.get("subject")
    if brief["mode"] != "create" and target is None:
        raise ValueError("review and evolve need an exact subject revision")
    if target is not None:
        revision_ref(target)
    references = brief.get("references", [])
    if not isinstance(references, list):
        raise ValueError("references must name artifact revisions")
    for reference in references:
        revision_ref(reference)
    if brief.get("brand_artifact") is not None:
        revision_ref(brief["brand_artifact"])
    deliverables = brief.get("deliverables")
    if not isinstance(deliverables, list) or not deliverables:
        raise ValueError("deliverables are required")
    ids = []
    for item in deliverables:
        if not isinstance(item, dict):
            raise ValueError("deliverable must be an object")
        for name in ("id", "format", "description"):
            text(item.get(name), name)
        if type(item.get("editable")) is not bool:
            raise ValueError("editable must be boolean")
        ids.append(item["id"])
    strings(ids, "deliverable IDs", required=True)
    canonical(brief)
    return copy.deepcopy(brief)


def request_payload(brief, held_goal, target_swarm):
    """C39 payload; host authenticates identity, held goal, grants and budget."""
    brief = validate_brief(brief)
    text(held_goal, "held_goal")
    text(target_swarm, "target_swarm")
    return {
        "kind": SERVICE, "from_goal": held_goal, "to_swarm": target_swarm,
        "title": brief["title"], "detail": canonical(brief),
        "subject": brief.get("subject"), "context_refs": brief["context_refs"] + brief["feedback_refs"],
        "constraints": {
            "creative_contract": VERSION, "brief_digest": digest(brief), "delivery": "proposal",
            "mode": brief["mode"], "purpose": brief["purpose"], "audience": brief["audience"],
            "medium": brief["medium"], "formats": brief["deliverables"],
            "references": brief.get("references", []), "brand_artifact": brief.get("brand_artifact"),
            "acceptance": brief["acceptance"], "authorized_actions": ["propose"],
            "requirements": brief["constraints"],
        },
        "acceptance": brief["acceptance"], "budget_usd": brief["budget_usd"],
    }


def validate_result(result, brief):
    """Validate completeness and provenance declarations, not artistic quality."""
    brief = validate_brief(brief)
    if not isinstance(result, dict) or result.get("contract") != VERSION:
        raise ValueError("unsupported creative result contract")
    if result.get("brief_digest") != digest(brief):
        raise ValueError("result belongs to another brief revision")
    if result.get("status") != "proposal":
        raise ValueError("creative results cannot claim adoption or publication")
    text(result.get("direction"), "direction")
    for name in ("rationale", "alternatives", "limitations", "feedback_refs", "open_findings"):
        strings(result.get(name), name)
    # Existing UI/creative-work observations stay bound to the exact baseline.
    if result.get("subject") != brief.get("subject"):
        raise ValueError("result subject differs from brief subject")
    outputs = result.get("outputs")
    if not isinstance(outputs, list):
        raise ValueError("outputs must be a list")
    expected = {item["id"]: item for item in brief["deliverables"]}
    seen = set()
    for output in outputs:
        if not isinstance(output, dict) or output.get("deliverable_id") not in expected:
            raise ValueError("unknown deliverable")
        key = output["deliverable_id"]
        if key in seen:
            raise ValueError("duplicate deliverable")
        seen.add(key)
        declaration = expected[key]
        if output.get("format") != declaration["format"]:
            raise ValueError("output format differs from requested format")
        if output.get("editable") is not declaration["editable"]:
            raise ValueError("output editability differs from request")
        revision_ref(output.get("revision"))
        for name in ("source_ref", "preview_ref"):
            text(output.get(name), name)
        strings(output.get("provenance_refs"), "provenance_refs")
    if seen != set(expected):
        raise ValueError("missing requested deliverables")
    checks = result.get("checks")
    if not isinstance(checks, list) or len(checks) != len(brief["acceptance"]):
        raise ValueError("each acceptance criterion needs an assessment")
    indices = set()
    for check in checks:
        if not isinstance(check, dict):
            raise ValueError("check must be an object")
        index = check.get("criterion")
        if type(index) is not int or index not in range(len(brief["acceptance"])) or index in indices:
            raise ValueError("invalid or duplicate criterion")
        indices.add(index)
        if check.get("verdict") not in {"supported", "unmet", "unverified"}:
            raise ValueError("unknown assessment verdict")
        strings(check.get("evidence_refs"), "evidence_refs", required=check["verdict"] == "supported")
        text(check.get("note"), "assessment note")
    canonical(result)
    return copy.deepcopy(result)


def result_envelope(result, brief, proposal_revision, cost_usd=0, alternatives=None):
    """Return a stored proposal reference; declared cost is not metered spend.

    Independent findings stay separate from the maker's acceptance assessments.
    The adapter must verify that the proposal revision contains this exact result.
    """
    result = validate_result(result, brief)
    revision_ref(proposal_revision)
    if type(cost_usd) not in (int, float) or not math.isfinite(cost_usd) or cost_usd < 0:
        raise ValueError("cost_usd must be finite and nonnegative")
    if cost_usd > brief["budget_usd"]:
        raise ValueError("declared cost exceeds brief budget")
    alternatives = copy.deepcopy(alternatives or [])
    for alternative in alternatives:
        revision_ref(alternative)
        text(alternative.get("rationale"), "alternative rationale")
    return {
        "contract": VERSION, "brief_digest": digest(brief), "status": "proposal",
        "proposal": copy.deepcopy(proposal_revision), "alternatives": alternatives,
        "rationale": result["rationale"], "author_claims": result["checks"],
        "limitations": result["limitations"], "open_findings": result["open_findings"],
        "cost_usd": cost_usd, "cost_evidence": "declared-unverified",
    }
