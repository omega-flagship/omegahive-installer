"""Validate the bounded output contract of the frozen cooperative checker."""
import json
import math
import re

ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate proof result field')
        result[key] = value
    return result


def validate(raw, run):
    if len(raw) > 1048576:
        raise ValueError('proof result exceeds one MiB')
    value = json.loads(raw, object_pairs_hook=unique)
    protocol = run['proof_check']['protocol']
    if protocol not in ('omegacode-lean-check-v1', 'omegacode-lean-project-check-v1'):
        raise ValueError('unknown frozen checker protocol')
    if type(value) is not dict or value.get('protocol') != protocol:
        raise ValueError('proof checker protocol mismatch')
    status = value.get('status')
    observations = value.get('stage_observations')
    if observations is not None:
        if type(observations) is not list or len(observations) > 33:
            raise ValueError('invalid proof stage observations')
        for row in observations:
            if (type(row) is not dict or type(row.get('stage')) is not str
                    or not re.fullmatch(r'compile(?:-[0-9]{1,2})?|audit', row['stage'])
                    or row.get('outcome') not in ('start_failed', 'interrupted', 'time_budget_exhausted', 'output_budget_exhausted', 'completed')
                    or type(row.get('output_bytes')) is not int or row['output_bytes'] < 0
                    or type(row.get('process_reaped')) is not bool
                    or (row.get('exit_code') is not None and type(row['exit_code']) is not int)):
                raise ValueError('invalid proof stage observation')
            for field in ('budget_seconds', 'elapsed_seconds'):
                number = row.get(field)
                if type(number) not in (int, float) or not math.isfinite(number) or number < 0:
                    raise ValueError('invalid proof stage timing')
            cpu = row.get('cpu_seconds')
            if row.get('cpu_scope') == 'unavailable':
                if cpu is not None:
                    raise ValueError('unavailable proof CPU observation')
            elif row.get('cpu_scope') == 'waited-checker-child-processes':
                if type(cpu) not in (int, float) or not math.isfinite(cpu) or cpu < 0:
                    raise ValueError('invalid proof CPU timing')
            else:
                raise ValueError('invalid proof CPU scope')
    if status == 'unconfirmed':
        reason = value.get('reason')
        if type(reason) is not str or len(reason) > 1024:
            raise ValueError('invalid unconfirmed proof reason')
        return {'status': status, 'reason': reason, 'theorems': [],
                **({'stage_observations': observations} if observations is not None else {})}
    if status not in ('checked', 'compile-failed', 'audit-refused'):
        raise ValueError('unknown proof outcome')
    proof = run['proof_check']
    context = {'run_id':run['id'], 'workspace_id':run['workspace_id'], 'generation':run['generation'],
               'tree_digest':run['tree_digest'], 'source_path':proof['source_path']}
    if (value.get('context') != context or value.get('source_digest') != proof['source_digest']
            or value.get('runtime_identity_digest') != proof['identity_digest']
            or value.get('implementation_correspondence_proved') is not False
            or value.get('sandboxed') is not False or value.get('scratch_removed') is not True
            or value.get('integrity_profile') != 'cooperative trusted-native source and process'
            or value.get('allowed_axioms') != ['propext','Classical.choice','Quot.sound']):
        raise ValueError('proof result binding or trust scope mismatch')
    if protocol == 'omegacode-lean-project-check-v1':
        if value.get('project_files') != proof['project_files'] or value.get('project_digest') != proof['project_digest']:
            raise ValueError('proof project source binding mismatch')
        stages = value.get('compile_stages')
        if type(stages) is not list or not 1 <= len(stages) <= len(proof['project_files']):
            raise ValueError('invalid project compile stages')
        for stage, source in zip(stages, proof['project_files']):
            if (type(stage) is not dict or stage.get('path') != source['path'] or stage.get('module') != source['module']
                    or type(stage.get('exit_code')) is not int):
                raise ValueError('project compile stage source mismatch')
        if status != 'compile-failed' and (len(stages) != len(proof['project_files']) or any(stage['exit_code'] != 0 for stage in stages)):
            raise ValueError('project audit contradicts compile stages')
        if status == 'compile-failed' and (stages[-1]['exit_code'] == 0 or any(stage['exit_code'] != 0 for stage in stages[:-1])):
            raise ValueError('project failure stage mismatch')
        if value.get('compile_exit') != stages[-1]['exit_code']:
            raise ValueError('project compile exit contradicts final stage')
    rows = value.get('theorems')
    dependencies = value.get('declaration_dependencies', [])
    if type(rows) is not list or type(dependencies) is not list or len(rows)+len(dependencies) > 1000:
        raise ValueError('invalid proof declaration collection')
    names = set()
    for kind, entries in [('theorem', rows), ('declaration', dependencies)]:
        for row in entries:
            if type(row) is not dict or type(row.get(kind)) is not str or not 1 <= len(row[kind]) <= 8192:
                raise ValueError('invalid proof declaration name')
            if row[kind] in names:
                raise ValueError('duplicate proof declaration')
            names.add(row[kind])
            axioms = row.get('axioms')
            if type(axioms) is not list or len(axioms) > 4096 or any(type(a) is not str or not 1 <= len(a) <= 8192 for a in axioms):
                raise ValueError('invalid proof axiom collection')
            if kind == 'theorem' and (type(row.get('type_expression')) is not str or len(row['type_expression']) > 131072):
                raise ValueError('invalid theorem expression')
            if status == 'checked' and not set(axioms) <= ALLOWED:
                raise ValueError('checked proof contains a forbidden dependency')
    for field in ('compile_output', 'audit_output'):
        if field in value and (type(value[field]) is not str or len(value[field].encode()) > 262144):
            raise ValueError('proof diagnostics exceed limit')
    compile_exit, audit_exit = value.get('compile_exit'), value.get('audit_exit')
    if type(compile_exit) is not int or (audit_exit is not None and type(audit_exit) is not int):
        raise ValueError('invalid proof exit codes')
    if status == 'checked' and (not rows or compile_exit != 0 or audit_exit != 0 or run['status'] != 'completed' or run['exit_code'] != 0):
        raise ValueError('checked proof contradicts run completion')
    if status != 'checked' and (run['status'] != 'failed' or run['exit_code'] != 1):
        raise ValueError('proof refusal contradicts run completion')
    if status == 'compile-failed' and (compile_exit == 0 or audit_exit is not None or rows or dependencies):
        raise ValueError('compile refusal contradicts checker stages')
    if status == 'audit-refused' and (compile_exit != 0 or audit_exit is None or audit_exit == 0):
        raise ValueError('audit refusal contradicts checker stages')
    return value
