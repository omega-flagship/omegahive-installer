"""Non-evaluating Hyperon syntax facts and ephemeral typed metadata matching.

Caller supplies already authorized bytes. No custom tokenizer, runner, interpreter,
grounded call, imported module, evidence publication or effect authority.
"""
import hashlib,json
from pathlib import PurePosixPath
from hyperon.base import SExprParser,GroundingSpaceRef
from hyperon.atoms import E,S,V,ValueAtom

sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()


def _preflight(text):
    depth=0;mode='code';escaped=False;in_token=False
    for ch in text:
        if mode=='comment':
            if ch in '\r\n':mode='code';in_token=False
        elif mode=='string':
            if escaped:escaped=False
            elif ch=='\\':escaped=True
            elif ch=='"':mode='code';in_token=False
        elif ch==';':mode='comment';in_token=False
        elif ch.isspace():in_token=False
        elif ch=='"' and not in_token:mode='string'
        elif ch=='(':
            depth+=1;in_token=False
            if depth>64:raise ValueError('syntax depth exceeds64')
        elif ch==')':
            depth-=1;in_token=False
            if depth<0:raise ValueError('unmatched closing parenthesis')
        else:in_token=True
    if depth or mode=='string':raise ValueError('incomplete common syntax')


def _forms(raw):
    text=raw.decode('utf-8');_preflight(text);parser=SExprParser(text);forms=[];visited=0
    while True:
        root=parser.parse_to_syntax_tree()
        if root is None:break
        if str(root.get_type())=='SyntaxNodeType.ERROR_GROUP':raise ValueError('native parser refused source')
        leaves=root.unroll();visited+=len(leaves)
        if visited>4096:raise ValueError('syntax token census exceeds4096')
        stack=[];parsed=[]
        for leaf in leaves:
            kind=str(leaf.get_type()).split('.')[-1];span=leaf.src_range();start,end=span.start,span.stop
            if not 0<=start<=end<=len(raw):raise ValueError('native source range invalid')
            raw[:start].decode('utf-8');value=raw[start:end].decode('utf-8')
            if kind in ('WHITESPACE','COMMENT'):continue
            if kind=='OPEN_PAREN':stack.append({'items':[],'start':start})
            elif kind=='CLOSE_PAREN':
                if not stack:raise ValueError('native expression close mismatch')
                form=stack.pop();form.update(end=end,kind='expression')
                (stack[-1]['items'] if stack else parsed).append(form)
            elif kind in ('WORD_TOKEN','VARIABLE_TOKEN','STRING_TOKEN'):
                token={'kind':kind,'value':value,'start':start,'end':end}
                (stack[-1]['items'] if stack else parsed).append(token)
            else:raise ValueError('unsupported native syntax token')
        if stack:raise ValueError('native expression incomplete')
        forms.extend(parsed)
    return forms


def build(sources):
    if type(sources) is not dict or len(sources)>128:raise ValueError('bounded source map required')
    census={};total=0
    for path,raw in sources.items():
        if type(path) is not str or type(raw) is not bytes:raise ValueError('exact named bytes required')
        p=PurePosixPath(path)
        if p.is_absolute() or str(p)!=path or not path.endswith('.metta') or any(x in ('','.','..','.git') for x in path.split('/')) or '\\' in path or '\0' in path:
            raise ValueError('relative MeTTa source path required')
        if len(path.encode())>4096 or len(raw)>1024*1024:raise ValueError('path/source bound')
        total+=len(raw)
        if total>8*1024*1024:raise ValueError('source map byte bound')
        census[path]=sha(raw)
    facts=[];diagnostics=[]
    for path,raw in sorted(sources.items()):
        try:forms=_forms(raw)
        except (ValueError,UnicodeError):
            diagnostics.append({'path':path,'reason':'source syntax unavailable; no facts emitted'})
            continue
        observed=[]
        def emit(kind,symbol,node):
            if len(symbol.encode())>256:
                diagnostics.append({'path':path,'reason':'symbol exceeds256 UTF-8 bytes; fact omitted', 'start_byte':node['start']})
                return
            observed.append({'path':path,'source_digest':census[path],'kind':kind,'symbol':symbol,
                'start_byte':node['start'],'end_byte':node['end'],
                'line':raw[:node['start']].count(b'\n')+1,'range_digest':sha(raw[node['start']:node['end']])})
        pending=list(forms)
        while pending:
            node=pending.pop()
            if node['kind']!='expression':continue
            items=node['items'];pending.extend(items)
            if items and items[0]['kind']=='WORD_TOKEN':
                emit('expression_head',items[0]['value'],items[0])
        for node in forms:
            if node['kind']!='expression' or not node['items']:continue
            items=node['items']
            if items[0]['kind']!='WORD_TOKEN':continue
            head=items[0]['value']
            if head=='=' and len(items)==3:
                left=items[1]
                name=left['items'][0] if left['kind']=='expression' and left['items'] else left
                if name['kind']=='WORD_TOKEN':emit('equation_subject',name['value'],name)
            elif head==':' and len(items)==3 and items[1]['kind']=='WORD_TOKEN':
                emit('type_declared_subject',items[1]['value'],items[1])
        facts.extend(observed)
        if len(facts)>4096:raise ValueError('fact census exceeds4096')
    facts=sorted(facts,key=lambda f:(f['path'],f['start_byte'],f['kind'],f['symbol']))
    result={'schema':'omegacode-metta-source-facts-poc-v1','sources':census,'facts':facts,'diagnostics':diagnostics,
            'parser':'hyperon-syntax-tree/no-custom-tokenizer','position_unit':'utf8-byte',
            'evaluated':False,'effect_authority':False,'runtime_bindings_verified':False,'atom_publication':False}
    result['digest']=sha(canonical(result))
    return result


def query(snapshot,kind,symbol,sources):
    rebuilt=build(sources)
    if type(snapshot) is not dict or snapshot!=rebuilt:raise ValueError('source facts differ from current bounded syntax census')
    unsigned={k:v for k,v in snapshot.items() if k!='digest'}
    if sha(canonical(unsigned))!=snapshot['digest']:raise ValueError('fact snapshot corrupt')
    if kind not in ('expression_head','equation_subject','type_declared_subject') or type(symbol) is not str or len(symbol.encode())>256:
        raise ValueError('bounded exact symbolic filter required')
    # Only metadata atoms are loaded; the repository program is never evaluated.
    space=GroundingSpaceRef()
    for fact in snapshot['facts']:
        space.add_atom(E(S('CodeSourceFact'),ValueAtom(fact['path']),ValueAtom(fact['source_digest']),
                         ValueAtom(fact['kind']),ValueAtom(fact['symbol']),ValueAtom(fact['start_byte']),
                         ValueAtom(fact['end_byte']),ValueAtom(fact['range_digest'])))
    pattern=E(S('CodeSourceFact'),V('path'),V('source_digest'),ValueAtom(kind),ValueAtom(symbol),
              V('start_byte'),V('end_byte'),V('range_digest'))
    rows=[{key:value.get_object().value for key,value in binding.items()} for binding in space.query(pattern)]
    return {'snapshot_digest':snapshot['digest'],'kind':kind,'symbol':symbol,
            'matches':sorted(rows,key=lambda r:(r['path'],r['start_byte'])),
            'engine':'hyperon-grounding-space-metadata-query','evaluated':False,'effect_authority':False,
            'atom_publication':False,'semantic_call_resolution':False}
