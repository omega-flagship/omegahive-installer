"""Disposable four-route composition. No production wiring or monitor setup."""
from .preparation_api import install as preparation
from .launch_api import install as launching
from .result_api import install as results
from .purpose_auth import PurposeAuthority

def install(app, service, authority, host, *, enabled=False):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    if not enabled:
        return False
    if app.state.service is not service or not isinstance(authority, PurposeAuthority) or authority.store is not service.store or (not authority._proposal_enabled) or (authority.registration != service.authority.registration):
        raise ValueError('same enabled registered purpose service required')
    if any((getattr(app.state, name, False) for name in ['_code_purpose_preparation_installed', '_code_purpose_launch_installed', '_code_purpose_result_installed'])):
        raise ValueError('compose only on an uninstalled app')
    for name in ['_call', 'status', 'admit', 'lookup', 'projection', 'dispatch_gate']:
        if not callable(getattr(host, name, None)):
            raise ValueError('existing complete purpose host adapter required')
    preparation(app, service, authority, host, enabled=True)
    launching(app, service, authority, host, enabled=True)
    results(app, service, authority, host, enabled=True)
    return True
