// Local editable parametric models. This is not a Hive source/admission schema.
import {canonical,digest} from './scene.mjs';
export {canonical};
export const MODEL_LIMITS=Object.freeze({objects:100,vertices:200000,indices:1000000,sourceBytes:1024*1024,history:40,recoveryBytes:20*1024*1024});
const bytes=value=>new TextEncoder().encode(typeof value==='string'?value:JSON.stringify(value)).length;
const keys=(value,names)=>value&&Object.getPrototypeOf(value)===Object.prototype&&Object.keys(value).length===names.length&&names.every(name=>Object.hasOwn(value,name));
const finite=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&!Object.is(n,-0)&&n>=min&&n<=max;
const identifier=s=>typeof s==='string'&&/^[A-Za-z][A-Za-z0-9_-]{0,79}$/.test(s);
const color=s=>typeof s==='string'&&/^#[0-9a-fA-F]{6}$/.test(s);
function jsonValue(value,depth=0,seen=new Set()){
 if(depth>8)throw Error('Metadata nesting exceeds limit');
 if(value===null||typeof value==='boolean'||typeof value==='string'&&value.length<=32000||finite(value,-1e12,1e12))return;
 if(!value||typeof value!=='object'||seen.has(value))throw Error('Finite JSON metadata required');
 seen.add(value);
 if(Array.isArray(value)){if(value.length>1000)throw Error('Metadata array exceeds limit');for(const item of value)jsonValue(item,depth+1,seen);}
 else {if(Object.getPrototypeOf(value)!==Object.prototype||Object.keys(value).length>1000)throw Error('Plain JSON metadata required');for(const[key,item]of Object.entries(value)){if(key.length>200||['__proto__','constructor','prototype'].includes(key))throw Error('Unsupported metadata key');jsonValue(item,depth+1,seen);}}
 seen.delete(value);
}
export function geometryBudget(object){
 if(object.kind==='box')return{vertices:24,indices:36};
 if(object.kind==='sphere'){const{widthSegments:w,heightSegments:h}=object.geometry;return{vertices:(w+1)*(h+1),indices:6*w*(h-1)};}
 const n=object.geometry.radialSegments;return{vertices:6*n+4,indices:12*n};
}
export function validateModel(input){
 if(!keys(input,['schema','id','title','units','background','metadata','objects'])||input.schema!=='omega-model-1'||!identifier(input.id)||typeof input.title!=='string'||input.title.length>200||input.units!=='metres'||!color(input.background))throw Error('Invalid local model document');
 jsonValue(input.metadata);if(bytes(input.metadata)>32000)throw Error('Metadata exceeds limit');
 if(!Array.isArray(input.objects)||input.objects.length>MODEL_LIMITS.objects)throw Error('Object limit exceeded');
 let vertices=0,indices=0;const ids=new Set();
 for(const object of input.objects){
  if(!keys(object,['id','name','kind','geometry','position','rotation','scale','material'])||!identifier(object.id)||ids.has(object.id)||typeof object.name!=='string'||object.name.length>200)throw Error('Invalid model object identity');ids.add(object.id);
  for(const[field,min,max]of[['position',-10000,10000],['rotation',-36000,36000],['scale',0.001,1000]])if(!Array.isArray(object[field])||object[field].length!==3||object[field].some(n=>!finite(n,min,max)))throw Error('Invalid '+field);
  if(!keys(object.material,['color','metalness','roughness'])||!color(object.material.color)||!finite(object.material.metalness,0,1)||!finite(object.material.roughness,0,1))throw Error('Invalid material');
  const g=object.geometry;
  if(object.kind==='box'){if(!keys(g,['width','height','depth'])||Object.values(g).some(n=>!finite(n,0.001,1000)))throw Error('Invalid box geometry');}
  else if(object.kind==='sphere'){if(!keys(g,['radius','widthSegments','heightSegments'])||!finite(g.radius,0.001,1000)||!Number.isInteger(g.widthSegments)||g.widthSegments<3||g.widthSegments>128||!Number.isInteger(g.heightSegments)||g.heightSegments<2||g.heightSegments>128)throw Error('Invalid sphere geometry');}
  else if(object.kind==='cylinder'){if(!keys(g,['radiusTop','radiusBottom','height','radialSegments'])||!finite(g.radiusTop,0,1000)||!finite(g.radiusBottom,0,1000)||g.radiusTop+g.radiusBottom===0||!finite(g.height,0.001,1000)||!Number.isInteger(g.radialSegments)||g.radialSegments<3||g.radialSegments>128)throw Error('Invalid cylinder geometry');}
  else throw Error('Unsupported primitive');
  const budget=geometryBudget(object);vertices+=budget.vertices;indices+=budget.indices;
 }
 if(vertices>MODEL_LIMITS.vertices||indices>MODEL_LIMITS.indices)throw Error('Aggregate geometry limit exceeded');
 if(bytes(input)>MODEL_LIMITS.sourceBytes)throw Error('Model source exceeds limit');
 return structuredClone(input);
}
export async function modelRevision(document){document=validateModel(document);return{document,digest:await digest(document)};}
export function sourceText(revision){const text=JSON.stringify({schema:'omega-model-source-1',document:revision.document,digest:revision.digest},null,2);if(bytes(text)>MODEL_LIMITS.sourceBytes)throw Error('Editable JSON exceeds reopen limit');return text;}
export async function readModelSource(text){
 if(typeof text!=='string'||bytes(text)>MODEL_LIMITS.sourceBytes)throw Error('Bounded model JSON required');
 const value=JSON.parse(text);if(!keys(value,['schema','document','digest'])||value.schema!=='omega-model-source-1')throw Error('Editable model source required');
 const revision=await modelRevision(value.document);if(revision.digest!==value.digest)throw Error('Altered model digest');return revision;
}
export function modelBytes(value){return bytes(value);}
export function defaultObject(kind,id){
 const geometry=kind==='box'?{width:1,height:1,depth:1}:kind==='sphere'?{radius:0.6,widthSegments:32,heightSegments:20}:kind==='cylinder'?{radiusTop:0.5,radiusBottom:0.5,height:1.4,radialSegments:32}:null;
 if(!geometry)throw Error('Unsupported primitive');return{id,name:kind[0].toUpperCase()+kind.slice(1),kind,geometry,position:[0,0.5,0],rotation:[0,0,0],scale:[1,1,1],material:{color:'#D69856',metalness:0.15,roughness:0.4}};
}
export function initialModel(){
 const base=defaultObject('box','pedestal');base.name='Stone pedestal';base.geometry={width:2.6,height:0.25,depth:2.2};base.position=[0,0.125,0];base.material={color:'#D9D1C4',metalness:0,roughness:0.8};
 const column=defaultObject('cylinder','column');column.name='Ochre column';column.geometry={radiusTop:0.46,radiusBottom:0.58,height:1.65,radialSegments:48};column.position=[-0.22,1.075,0.12];
 const globe=defaultObject('sphere','globe');globe.name='Ink sphere';globe.geometry={radius:0.68,widthSegments:48,heightSegments:32};globe.position=[0.44,2.17,-0.12];globe.material={color:'#23483F',metalness:0.28,roughness:0.3};
 return{schema:'omega-model-1',id:'orbit_form_01',title:'Orbit form 01',units:'metres',background:'#F1EEE7',metadata:{description:'An invented local study of form, colour and balance.'},objects:[base,column,globe]};
}
