"""Stdlib-only regression check for malformed R13 coverage shapes."""
from __future__ import annotations

from copy import deepcopy
import importlib.util
from pathlib import Path

READER = Path(__file__).parents[1] / "src" / "omegacode" / "symbolic_trace_reader.py"
SPEC = importlib.util.spec_from_file_location("r13_coverage_reader", READER)
reader = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reader)

context = {"run_id": "run_synthetic", "generation": 1, "tree_digest": "1" * 64,
           "runtime_identity_digest": "2" * 64, "runtime": "hyperon"}
trace_id = "step_synthetic"
source_digest = "3" * 64
base = {
    "trace_id": trace_id,
    "source_digest": source_digest,
    "context": context,
    "step_count": 0,
    "max_steps": 8,
    "status": "paused",
    "results": [],
    "observations": [],
    "results_currency": "not yet observed",
    "last_observed_step": 0,
    "engine_api": "hyperon.runner.RunnerState.run_step",
    "substitutions_available": False,
    "grounded_call_trace_available": False,
    "persistence": "resident process only; no automatic replay",
    "effects_reversed": False,
    "observation_coverage": "complete-history",
    "observation_total": 0,
    "observation_window_limit": 100,
    "observation_dropped_prefix": 0,
    "first_retained_input_sequence": None,
    "first_retained_step": None,
}
request = {"op": "step-start"}
catalog = {trace_id: {"source_digest": source_digest, "start_sequence": 1, "max_steps": 8}}
coverage_fields = ("observation_total", "observation_window_limit", "observation_dropped_prefix",
                   "first_retained_input_sequence", "first_retained_step")


def refused_as_coverage_invalid(label: str, result: dict) -> None:
    try:
        reader._trace_result(result, request, 1, context, catalog, {}, {}, {1: {"request": request}}, set())
    except reader.TraceReadError as error:
        if error.code != "coverage_invalid":
            raise AssertionError(f"{label}: expected coverage_invalid, got {error.code}") from error
    else:
        raise AssertionError(f"{label}: malformed coverage was accepted")


only_total = deepcopy(base)
only_total.pop("observation_coverage")
for key in coverage_fields:
    if key != "observation_total":
        only_total.pop(key)
refused_as_coverage_invalid("observation_total-only", only_total)

marker_without_counters = deepcopy(base)
for key in coverage_fields:
    marker_without_counters.pop(key)
refused_as_coverage_invalid("marker-with-zero-counters", marker_without_counters)

mixed = deepcopy(base)
mixed["observation_coverage"] = {}
refused_as_coverage_invalid("mixed-legacy-and-R13", mixed)

print("PASS: 3 malformed R13 coverage shapes refused as coverage_invalid")
