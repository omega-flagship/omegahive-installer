// Prepare a verified, user-picked raster for the existing editable scene model.
// This retains the picker digest; it grants no host storage or publication rights.
import {validate} from './scene.mjs';
import {verifiedPickedImage} from './studio-assets.mjs';

export async function pickedImageInsertion(scene,image,{id,document=globalThis.document,isCurrent=()=>true}={}){
 scene=validate(scene);
 const check=()=>{if(!isCurrent())throw Error('Editor changed while preparing image; your work is retained');};
 check();
 if(!(image?.bytes instanceof Uint8Array)||!image.bytes.length||image.bytes.length>8*1024*1024)throw Error('Picked image exceeds the 8 MB input limit');
 // Copy before hashing/decoding so later mutation of the picker buffer cannot
 // change the embedded bytes while retaining an earlier digest.
 const bytes=new Uint8Array(image.bytes),mime=image.mime,sha256=image.sha256,name=image.name;
 const selected={handle:sha256,mime,size:bytes.length,name};
 await verifiedPickedImage({handle:sha256,mime,size:bytes.length,bytes:bytes.buffer},selected);
 check();
 const bitmap=await createImageBitmap(new Blob([bytes],{type:mime}));
 let embedded=bytes,embeddedMime=mime,width,height;
 try{
  check();width=bitmap.width;height=bitmap.height;
  if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>8192||height>8192)throw Error('Image dimensions exceed 8192 pixels');
  if(!['image/png','image/jpeg'].includes(mime)){
   const canvas=document?.createElement('canvas');
   if(!canvas)throw Error('Image conversion is unavailable');
   canvas.width=width;canvas.height=height;
   const context=canvas.getContext('2d');if(!context)throw Error('Image conversion is unavailable');
   context.drawImage(bitmap,0,0);
   const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
   check();
   if(!blob||!Number.isInteger(blob.size)||blob.size<1||blob.size>10*1024*1024)throw Error('Converted image exceeds the 10 MB limit or conversion failed');
   embedded=new Uint8Array(await blob.arrayBuffer());embeddedMime='image/png';
   check();
   if(embedded.length!==blob.size||embedded.length>10*1024*1024||[...embedded.slice(0,8)].join(',')!=='137,80,78,71,13,10,26,10')throw Error('Image conversion did not produce a bounded PNG');
  }
 }finally{bitmap.close();}
 check();
 let encoded='';for(let i=0;i<embedded.length;i+=32768)encoded+=String.fromCharCode(...embedded.subarray(i,i+32768));
 const scale=Math.min(1,400/width,300/height,(scene.width-20)/width,(scene.height-20)/height);
 const value={id,kind:'image',x:10,y:10,width:width*scale,height:height*scale,alt:String(name||'Picked image').slice(0,2000),src:`data:${embeddedMime};base64,${btoa(encoded)}`,provenance:{schema:'omega-picked-image-provenance-1',sha256,original_mime:mime,conversion:embeddedMime===mime?'none':'first-frame-png'}};
 validate({...scene,elements:[...scene.elements,value]});
 return {op:'add',element:id,value};
}
