"""Bounded internal SQLite retrieval cache; never an exported artifact or authority."""
from dataclasses import asdict
import hashlib
import json
from .common import canonical, stamp
from .repository_facts import RepositoryFacts, Fact
from .repository_retrieval import RetrievalIndex, Chunk

MAX_BYTES = 12 * 1024 * 1024
MAX_ENTRIES = 4


def key_for(scope):
    return hashlib.sha256(canonical(scope)).hexdigest()


def load(store, scope):
    with store.lock:
        store.db.execute('CREATE TABLE IF NOT EXISTS retrieval_cache(key TEXT PRIMARY KEY, digest TEXT, body BLOB, at REAL)')
        row = store.db.execute('SELECT digest,body FROM retrieval_cache WHERE key=? AND length(body)<=?', (key_for(scope),MAX_BYTES)).fetchone()
    if row is None:
        return None
    try:
        raw = row['body']
        if not isinstance(raw, bytes) or len(raw)>MAX_BYTES or hashlib.sha256(raw).hexdigest()!=row['digest']:
            return None
        body = json.loads(raw)
        if body['scope'] != json.loads(canonical(scope)) or body['format'] != 'retrieval-cache-v1':
            return None
        value = body['index']; graph = value['graph']
        if len(value['chunks'])>4096 or len(graph['sources'])>512 or len(graph['facts'])>100000:
            return None
        if value['version'] != RetrievalIndex.version or graph['parser'] != RepositoryFacts.parser:
            return None
        for field in ('sources','dependencies','diagnostics'):
            if type(graph[field]) is not list or len(graph[field])>100000 or any(
                    type(pair) is not list or len(pair)!=2 or any(type(x) is not str for x in pair)
                    for pair in graph[field]):
                return None
        if len({p for p,_ in graph['sources']})!=len(graph['sources']):
            return None
        for fact in graph['facts']:
            if type(fact) is not dict or set(fact)!={'path','line','kind','subject','target'} or type(fact['line']) is not int or any(
                    type(fact[k]) is not str for k in ('path','kind','subject','target')):
                return None
        for chunk in value['chunks']:
            if type(chunk) is not dict or set(chunk)!={'id','path','source_digest','start_line','end_line','text'} or any(
                    type(chunk[k]) is not str for k in ('id','path','source_digest','text')) or any(
                    type(chunk[k]) is not int for k in ('start_line','end_line')):
                return None
        facts = RepositoryFacts(tuple(tuple(x) for x in graph['sources']),
            tuple(Fact(**f) for f in graph['facts']), tuple(tuple(x) for x in graph['dependencies']),
            tuple(tuple(x) for x in graph['diagnostics']), graph['parser'])
        index = RetrievalIndex(facts,tuple(Chunk(**c) for c in value['chunks']),value['version'])
        if index.digest != body['index_digest'] or sum(len(c.text.encode()) for c in index.chunks)>8*1024*1024:
            return None
        return index
    except (ValueError,TypeError,KeyError,AttributeError,RecursionError):
        return None  # Corrupt cache is a miss; current source is read and rebuilt.


def save(store, scope, index):
    raw = canonical({'format':'retrieval-cache-v1','scope':scope,'index':asdict(index),'index_digest':index.digest})
    if len(raw)>MAX_BYTES:
        return False
    with store.transaction():
        store.db.execute('CREATE TABLE IF NOT EXISTS retrieval_cache(key TEXT PRIMARY KEY, digest TEXT, body BLOB, at REAL)')
        store.db.execute('INSERT OR REPLACE INTO retrieval_cache VALUES(?,?,?,?)',
                         (key_for(scope),hashlib.sha256(raw).hexdigest(),raw,stamp()))
        # Serialized bytes bound disk retention, including syntax metadata, not just source text.
        rows = store.db.execute('SELECT key,length(body) AS size FROM retrieval_cache ORDER BY at DESC,key').fetchall()
        retained = 0
        for position,row in enumerate(rows):
            if position>=MAX_ENTRIES or retained+row['size']>MAX_BYTES:
                store.db.execute('DELETE FROM retrieval_cache WHERE key=?',(row['key'],))
            else:
                retained += row['size']
    return True
