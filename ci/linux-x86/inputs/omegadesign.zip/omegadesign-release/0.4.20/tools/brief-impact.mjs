import {briefPlan} from './brief-plan.mjs';
// Render exact recorded steering impact; this is not a model or review verdict.
export function renderBriefImpact(container,change){
 container.replaceChildren();container.hidden=!change;if(!change)return;
 const doc=container.ownerDocument,transition=change.transition;
 const add=text=>{const p=doc.createElement('p');p.textContent=text;container.append(p);};
 add('Requirement change: '+transition.reason);
 if(transition.delta.purpose_changed)add('Purpose changed. Prior work requires reassessment.');
 if(transition.delta.audience_changed)add('Audience changed. Prior work requires reassessment.');
 for(const [key,label] of [['retained_criteria','Preserved obligation'],['added_criteria','New obligation'],['removed_criteria','Removed from current brief']])for(const criterion of transition.delta[key])add(label+': '+criterion);
 const plan=briefPlan(transition);
 add('Work plan — completion unverified');
 const steps=new Map(plan.tasks.map((task,index)=>[task.id,index+1]));
 for(const [index,task] of plan.tasks.entries())add('Step '+(index+1)+': '+task.action+' · pending'+(task.depends_on.length?' · after '+(task.depends_on.length===1?'step ':'steps ')+task.depends_on.map(id=>steps.get(id)).join(', '):''));
 add('Prior editable source retained: '+change.source_digest);
 add('Prior alternatives retained for reassessment: '+transition.retained_work.length);
 if(transition.previous_selection)add('Previous selection is historical: '+transition.previous_selection.direction_id+'. It does not approve the revised brief.');
 add('Artwork and copy have not been assessed against the revised brief. Adoption belongs to the receiving project.');
}
