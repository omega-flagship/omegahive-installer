// Editable deterministic geometry timeline, not a video/model/provider service.
import {validate,clone,digest} from './scene.mjs';
export async function sampleMotion(scene,timeline,timeMs){
 validate(scene);
 if(!timeline||Object.keys(timeline).sort().join(',')!=='duration_ms,scene_digest,schema,tracks'||timeline.schema!=='omega-scene-motion-1'||timeline.scene_digest!==await digest(scene))throw Error('Exact motion scene binding required');
 if(!Number.isInteger(timeline.duration_ms)||timeline.duration_ms<1||timeline.duration_ms>60000||!Number.isFinite(timeMs)||timeMs<0||timeMs>timeline.duration_ms||!Array.isArray(timeline.tracks)||!timeline.tracks.length||timeline.tracks.length>100)throw Error('Bounded motion timeline required');
 const targets=new Set(),times=new Set([0,timeline.duration_ms]);let frameCount=0;
 for(const track of timeline.tracks){
  if(!track||Object.keys(track).sort().join(',')!=='element_id,field,keyframes'||!['x','y','width','height'].includes(track.field)||!scene.elements.some(e=>e.id===track.element_id))throw Error('Existing geometry target required');
  const key=track.element_id+'/'+track.field;if(targets.has(key))throw Error('Duplicate motion field');targets.add(key);
  if(!Array.isArray(track.keyframes)||track.keyframes.length<2||track.keyframes.length>100)throw Error('Bounded keyframes required');
  frameCount+=track.keyframes.length;if(frameCount>1000)throw Error('Total keyframe limit');
  let previous=-1;
  for(const frame of track.keyframes){if(!frame||Object.keys(frame).sort().join(',')!=='time_ms,value'||!Number.isInteger(frame.time_ms)||frame.time_ms<=previous||frame.time_ms>timeline.duration_ms||!Number.isFinite(frame.value))throw Error('Ordered finite keyframes required');previous=frame.time_ms;times.add(frame.time_ms);}
  if(track.keyframes[0].time_ms!==0||track.keyframes.at(-1).time_ms!==timeline.duration_ms)throw Error('Keyframes must cover full duration');
 }
 const at=time=>{
  const output=clone(scene);
  for(const track of timeline.tracks){const frames=track.keyframes;let i=1;while(i<frames.length-1&&frames[i].time_ms<time)i++;const a=frames[i-1],b=frames[i],f=(time-a.time_ms)/(b.time_ms-a.time_ms);output.elements.find(e=>e.id===track.element_id)[track.field]=a.value+(b.value-a.value)*f;}
  return validate(output);
 };
 // Geometry is piecewise linear. Validate every breakpoint of combined tracks,
 // including times where another field changes: valid independent tracks can conflict.
 for(const time of times)at(time);
 return {scene:clone(at(timeMs)),time_ms:timeMs,source_scene_digest:timeline.scene_digest,editable:true,adopted:false};
}
