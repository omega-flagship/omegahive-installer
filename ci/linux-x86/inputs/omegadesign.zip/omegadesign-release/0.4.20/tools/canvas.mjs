import {verifyStudioSnapshot} from './studio-snapshot.mjs';
import {serializeStudioRecovery} from './studio-drafts.mjs';
import {checkedSuggestionChange} from './studio-suggestions.mjs';
import {exactReference} from './app-reference.mjs';
import {sourceRelations} from './source-relations.mjs';
import {briefFromFields} from './brief-form.mjs';
import {renderBriefImpact} from './brief-impact.mjs';
import {steerSource} from './source-steering.mjs';
import {renderReadability} from './readability-ui.mjs';
import {retainedMakerTrace,STUDIO_MAKER_TRACE_LIMIT,STUDIO_MAKER_TRACE_BYTES} from './maker-trace.mjs';
import {liveEdits} from './live-edits.mjs';
import {imageInsertion} from './image-insertion.mjs';
import {pickedImageInsertion} from './studio-picked-image.mjs';
import {inspectTextLayout} from './layout.mjs';
import {verifySource,feedbackScope,retainedFeedback,mergeSources,STUDIO_SOURCE_HISTORY_LIMIT,STUDIO_SOURCE_FEEDBACK_LIMIT} from './source.mjs';
import {initial,apply,feedback,svg,wrapText,validate,clone,digest,canonical,alignElement,resizeElement} from './scene.mjs';
import {createProject,proposeDirection,reuseIdentity,validateIdentity,identityImpact,selectDirection,verifyProject,relations} from './project.mjs';
const $ = selector => document.querySelector(selector);
const starter = {schema:'omega-scene-1',id:'garden-invitation',title:'Grow together',width:1280,height:720,background:'#F5F1E8',criteria:['Invite neighbours to a concrete trial session','Preserve readable editable text','Retain an inclusive, warm voice'],elements:[
 {id:'accent',kind:'rect',x:70,y:76,width:110,height:10,fill:'#A45D36'},
 {id:'headline',kind:'text',x:70,y:125,width:1070,height:225,text:'A little ground.\nA shared beginning.',fontSize:78,color:'#18352B',weight:'bold'},
 {id:'invitation',kind:'text',x:74,y:426,width:1080,height:110,text:'Come to a trial planting session.\nNo experience needed. Bring your curiosity.',fontSize:32,color:'#365747',weight:'normal'},
 {id:'next-step',kind:'text',x:74,y:620,width:1100,height:54,text:'Tell us when you can join — we will agree a time together.',fontSize:24,color:'#18352B',weight:'normal'}]};
let history=[await initial(starter)],cursor=0,selected='headline',comments=[],busy=false,drag;
let layoutObservation=null;
let mergeRecords=[],makerTrace=[],briefChange=null;
let provenance=null,loadedIdentity=null,identityImpactNotes=[];
let storageUnavailable=false,storageLoadWarning='',hostDraftCapability=false;
let project=await createProject({id:'garden-brief',purpose:'Invite neighbours to a trial planting session',audience:'New neighbours',criteria:starter.criteria});
const current = () => history[cursor];
function status(text,error=false){$('#status').textContent=text+(storageLoadWarning?' · '+storageLoadWarning:'')+(storageUnavailable&&!hostDraftCapability?' · Draft save unavailable — Save to Hive or Export to keep this work.':'');$('#status').className=error?'error':'';}
const sourceObservers=new Set();
let studioRecoverySourceRefReader=()=>null;
export function hasEditableDraft(){
 if($('#want-purpose').value!==project.brief.purpose||$('#want-audience').value!==project.brief.audience||$('#want-criteria').value!==project.brief.criteria.join('\n')||$('#want-reason').value.trim())return true;
 return hasCanvasFieldDraft();
}
function hasCanvasFieldDraft(){
 const element=current().scene.elements.find(e=>e.id===selected);
 if($('#note').value.trim())return true;
 return !!element&&[...$('#properties').elements].some(input=>input.name&&input.name in element&&String(input.value)!==String(input.type==='color'?element[input.name].toLowerCase():element[input.name]));
}
function editableDraftSnapshot(){return JSON.stringify({selected,note:$('#note').value,properties:[...$('#properties').elements].filter(input=>input.name).map(input=>[input.name,input.value]),brief:['purpose','audience','criteria','reason'].map(name=>$('#want-'+name).value)});}
function boundStudioField(input,limit){
 input.maxLength=limit;let lastSupported=input.value;
 input.addEventListener('beforeinput',()=>{if(input.value.length<=limit)lastSupported=input.value;});
 input.addEventListener('input',()=>{if(input.value.length<=limit)lastSupported=input.value;else{input.value=lastSupported;status('This field exceeds its retained draft limit. Your prior field value is retained.',true);}});
}
for(const input of $('#properties').elements)if(input.name)boundStudioField(input,32000);
boundStudioField($('#note'),16000);
for(const name of ['purpose','audience','criteria','reason'])boundStudioField($('#want-'+name),32000);
export function observeEditableSource(listener){sourceObservers.add(listener);listener(editableSource());return ()=>sourceObservers.delete(listener);}
function save(){try{if(!hostDraftCapability)localStorage.setItem('omega-studio-v1',JSON.stringify({history,cursor,selected,comments,project,provenance,mergeRecords,makerTrace,briefChange}));storageUnavailable=false;storageLoadWarning='';}catch{storageUnavailable=true;}for(const listener of sourceObservers)listener(editableSource());}
function renderIdentity(){
 const picker=$('#identity-direction'),previous=picker.value;picker.replaceChildren();
 for(const d of project.directions){const option=document.createElement('option');option.value=d.id;option.textContent=d.label;picker.append(option);}if(project.directions.some(d=>d.id===previous))picker.value=previous;
 const prior=new Map([...document.querySelectorAll('#identity-bindings select')].map(s=>[s.dataset.binding,s.value]));$('#identity-bindings').replaceChildren();
 const direction=project.directions.find(d=>d.id===picker.value);$('#reuse-identity').disabled=!loadedIdentity||!direction||busy;
 if(!loadedIdentity||!direction)return;
 $('#identity-summary').textContent=`${loadedIdentity.id} · r${loadedIdentity.revision}. Voice: ${loadedIdentity.voice.join('; ')}. ${identityImpactNotes.length} retained alternatives need reassessment against this identity.`;
 const targets=[{element:null,field:'background',label:'Canvas background'},...direction.scene.elements.filter(e=>['text','rect'].includes(e.kind)).flatMap(e=>e.kind==='text'?[{element:e.id,field:'color',label:e.id+' colour'},{element:e.id,field:'fontFamily',label:e.id+' font'}]:[{element:e.id,field:'fill',label:e.id+' fill'}])];
 for(const target of targets){const label=document.createElement('label');label.textContent=target.label;const select=document.createElement('select');select.dataset.binding=JSON.stringify([target.element,target.field]);const none=document.createElement('option');none.value='';none.textContent='Keep original value';select.append(none);for(const [name,color] of Object.entries(target.field==='fontFamily'?(loadedIdentity.fonts??{}):loadedIdentity.tokens)){const option=document.createElement('option');option.value=name;option.textContent=name+' · '+color;select.append(option);}if(prior.has(select.dataset.binding))select.value=prior.get(select.dataset.binding);label.append(select);$('#identity-bindings').append(label);}
}
function render(){
 renderIdentity();
 const c=current();$('#canvas').innerHTML=svg(c.scene);$('#elements').replaceChildren();
 for(const e of c.scene.elements){const b=document.createElement('button');b.textContent=e.id+' · '+e.kind;b.onclick=()=>{try{selectStudioElement(e.id);}catch(error){status(error.message,true);}};$('#elements').append(b);}
 const e=c.scene.elements.find(e=>e.id===selected);
 renderReadability($('#readability'),c.scene,selected);
 $('#canvas').querySelector(`[data-element="${selected}"]`)?.classList.add('selected');
 if(e){const root=$('#canvas svg'),ns='http://www.w3.org/2000/svg';const outline=document.createElementNS(ns,'rect');for(const [k,v] of Object.entries({x:e.x,y:e.y,width:e.width,height:e.height,fill:'none',stroke:'#3578E5','stroke-width':2,'pointer-events':'none','data-selection-box':''}))outline.setAttribute(k,v);root.append(outline);const handle=document.createElementNS(ns,'rect');for(const [k,v] of Object.entries({x:e.x+e.width-12,y:e.y+e.height-12,width:12,height:12,fill:'#3578E5','data-element':e.id,'data-resize':'true'}))handle.setAttribute(k,v);handle.style.cursor='nwse-resize';root.append(handle);}

 for(const input of $('#properties').elements){if(!input.name)continue;input.closest('label').hidden=!e||!(input.name in e);if(e&&input.name in e)input.value=input.type==='color'?e[input.name].toLowerCase():e[input.name];}
 $('#properties button').disabled=!e||busy;$('#remove').disabled=!e||busy;$('#comment').disabled=!e||busy;
 renderBriefImpact($('#brief-impact'),briefChange);
 $('#criteria').replaceChildren();for(const criterion of c.scene.criteria){const li=document.createElement('li');li.textContent=criterion;$('#criteria').append(li);}
 $('#comments').replaceChildren();for(const comment of retainedFeedback(editableSource())){const li=document.createElement('li');const scope=feedbackScope(comment,{current:c,history,project,merge_sources:mergeRecords,...(briefChange?{brief_change:briefChange}:{})});const labels={'prior-brief-source':'Prior brief — reassessment required','current-revision':'Current revision','earlier-or-other-revision':'Other retained revision','retained-direction':'Another retained direction','missing-element':'Referenced element missing','source-not-retained':'Source no longer retained','retained-merge-source':'Retained merge source'};li.textContent=`${labels[scope]} · ${comment.subject.scene_id} / ${comment.subject.element_id} · r${comment.subject.revision}: ${comment.note}`;li.title=comment.subject.digest;$('#comments').append(li);}
 for(const button of document.querySelectorAll('[data-layer]'))button.disabled=!e||busy;
 $('#undo').disabled=cursor===0||busy;$('#redo').disabled=cursor===history.length-1||busy;
 $('#directions').replaceChildren();for(const d of project.directions){const card=document.createElement('div');const label=document.createElement('strong');label.textContent=d.label;const preview=document.createElement('div');preview.innerHTML=svg(d.scene);preview.querySelector('svg').style.width='100%';const why=document.createElement('p');why.textContent=d.rationale;why.className='hint';const choose=document.createElement('button');choose.textContent='Choose direction';choose.onclick=async()=>{try{await chooseStudioDirection(d.id,$('#selection-reason').value);}catch(error){status(error.message,true);}};card.append(label,preview,why,choose);$('#directions').append(card);}
 $('#selection-status').textContent=project.selection?`Selected ${project.directions.find(d=>d.id===project.selection.direction_id).label}: ${project.selection.reason}. Further canvas edits remain a new proposal.`:'Retained alternatives stay available. Selection here does not adopt a design in Hive.';
 layoutObservation=inspectTextLayout($('#canvas'),c);
 const overflowing=layoutObservation.results.filter(r=>r.status==='overflow').map(r=>r.element_id);
 const unavailable=layoutObservation.results.filter(r=>r.status==='measurement-unavailable').length;
 status(`Revision ${c.revision} · ${c.digest.slice(0,23)}… · ${c.scene.elements.length} editable elements${overflowing.length?" · Text box overflow: "+overflowing.join(", "):unavailable?" · Layout measurement unavailable":""}`,overflowing.length>0);
 for(const listener of sourceObservers)listener(editableSource());
}
// Project the complete state before changing any editor-owned value. Recovery
// retains redo, project alternatives, feedback and trace as well as the canvas.
function preflightStudioState(overrides={}, {fields=null,refreshBrief=false,refreshProperties=true,sourceRef=studioRecoverySourceRefReader()}={}){
 const state={history,cursor,selected,comments,project,provenance,mergeRecords,makerTrace,briefChange,...overrides},active=state.history[state.cursor];
 if(!active)throw Error('Recovery requires an active retained revision');
 if(state.history.length>STUDIO_SOURCE_HISTORY_LIMIT)throw Error('Retained source exceeds '+STUDIO_SOURCE_HISTORY_LIMIT+' revisions. Your current work is retained.');
 if(state.comments.length>STUDIO_SOURCE_FEEDBACK_LIMIT)throw Error('Retained feedback exceeds '+STUDIO_SOURCE_FEEDBACK_LIMIT+' notes. Your current work is retained.');
 const trace=retainedMakerTrace(state.makerTrace,state.history);
 if(trace.length>STUDIO_MAKER_TRACE_LIMIT||new TextEncoder().encode(canonical(trace)).length>STUDIO_MAKER_TRACE_BYTES)throw Error('Retained maker trace exceeds its native recovery bounds. Your current work is retained.');
 const pending=clone(fields??JSON.parse(editableDraftSnapshot()));
 pending.selected=state.selected&&active.scene.elements.some(e=>e.id===state.selected)?state.selected:'';
 const element=active.scene.elements.find(e=>e.id===pending.selected);
 if(refreshProperties&&element)for(const field of pending.properties)if(field[0] in element)field[1]=String(['color','fill'].includes(field[0])?element[field[0]].toLowerCase():element[field[0]]);
 if(refreshBrief)pending.brief=[state.project.brief.purpose,state.project.brief.audience,state.project.brief.criteria.join('\n'),''];
 if(typeof pending.note!=='string'||pending.note.length>16000||pending.properties.some(field=>typeof field[1]!=='string'||field[1].length>32000)||pending.brief.some(value=>typeof value!=='string'||value.length>32000))throw Error('Pending fields exceed the supported recovery bounds. Your current work is retained.');
 const snapshot={schema:'omega-studio-draft-1',source:{schema:'omega-studio-source-1',current:clone(active),history:clone(state.history),feedback:clone(state.comments),project:clone(state.project),provenance:clone(state.provenance),merge_sources:clone(state.mergeRecords),maker_trace:clone(trace),derived_relations:sourceRelations(state.project,state.briefChange),...(state.briefChange?{brief_change:clone(state.briefChange)}:{})},fields:pending};
 try{
  serializeStudioRecovery(()=>clone(snapshot),()=>sourceRef);
  // Each validator-accepted field may grow after this commit. Six JSON bytes
  // per UTF-16 code unit cover escaped control characters and lone surrogates.
  // Reserve that exact worst case with the existing recovery serializer.
  const reserved=clone(snapshot),maximum='\0'.repeat(32000);
  reserved.fields={selected:'s'.repeat(80),note:'\0'.repeat(16000),properties:pending.properties.map(([name])=>[name,maximum]),brief:Array(4).fill(maximum)};
  serializeStudioRecovery(()=>clone(reserved),()=>sourceRef);
  // A successful save can replace a null/short reference. Keep conservative
  // headroom for a future host ID and every positive fixed-form JSON integer;
  // the actual incoming/current reference is checked separately above.
  serializeStudioRecovery(()=>clone(reserved),()=>({artifact_id:'r'.repeat(1024),revision:1e20,digest:'sha256:'+'f'.repeat(64)}));
 }catch(error){if(/20 MB/.test(error.message))throw Error('This change exceeds the complete 20 MB recovery budget, including retained history and pending fields. Your current work is retained.');throw error;}
 return snapshot;
}
async function commit(changes,expected=current().digest,{isCurrent=()=>true,selected:nextSelected=selected}={}){if(busy)return false;const original=current(),draftBefore=editableDraftSnapshot();busy=true;let failure,accepted=false;try{const next=await apply(original,expected,changes);if(!isCurrent()||current()!==original||editableDraftSnapshot()!==draftBefore)throw Error('Editor changed during edit; your newer work is retained');const nextHistory=[...history.slice(0,cursor+1),next],snapshot=preflightStudioState({history:nextHistory,cursor:nextHistory.length-1,selected:nextSelected});history=nextHistory;cursor=nextHistory.length-1;selected=snapshot.fields.selected;save();accepted=true;}catch(error){failure=error.message;}finally{busy=false;if(accepted)render();if(failure)status(failure,true);}return accepted;}
function clearStudioDragPreview(id){
 const root=$('#canvas');root.querySelector(`[data-element="${id}"]`)?.removeAttribute('transform');
 const element=current().scene.elements.find(e=>e.id===id),box=root.querySelector('[data-selection-box]');
 if(element&&selected===id)for(const name of ['x','y','width','height'])box?.setAttribute(name,element[name]);
}

try{const stored=JSON.parse(localStorage.getItem('omega-studio-v1'));if(stored){if(!Number.isInteger(stored.cursor)||!stored.history?.[stored.cursor])throw Error('Invalid saved cursor');await verifySource({schema:'omega-studio-source-1',current:stored.history[stored.cursor],history:stored.history,project:stored.project,feedback:stored.comments??[],merge_sources:stored.mergeRecords??[],maker_trace:stored.makerTrace??[],...(stored.briefChange?{brief_change:stored.briefChange}:{})});const snapshot=preflightStudioState({project:stored.project,history:stored.history,cursor:stored.cursor,selected:stored.selected??'',comments:stored.comments??[],provenance:stored.provenance??null,mergeRecords:stored.mergeRecords??[],makerTrace:stored.makerTrace??[],briefChange:stored.briefChange??null},{refreshBrief:true});project=stored.project;history=stored.history;cursor=stored.cursor;selected=snapshot.fields.selected;comments=stored.comments??[];provenance=stored.provenance??null;mergeRecords=stored.mergeRecords??[];makerTrace=stored.makerTrace??[];briefChange=stored.briefChange??null;}}catch(error){if(error.name==='SecurityError')storageUnavailable=true;else storageLoadWarning='Saved state could not be loaded: '+error.message;}
render();
$('#properties').onsubmit=event=>{event.preventDefault();const e=current().scene.elements.find(e=>e.id===selected);if(!e)return;const patch={};for(const input of event.target.elements){if(input.name&&input.name in e)patch[input.name]=['x','y','width','height','fontSize'].includes(input.name)?Number(input.value):input.value;}commit([{op:'set',element:selected,patch}]);};
$('#properties button').type='button';
$('#properties button').onclick=()=>$('#properties').onsubmit({preventDefault(){},target:$('#properties')});
$('#remove').onclick=()=>{if(hasEditableDraft()){status('Apply or clear fields before removing an element',true);return;}void commit([{op:'remove',element:selected}]);};
for(const button of document.querySelectorAll('[data-layer]'))button.onclick=()=>{if(hasEditableDraft()){status('Apply or clear fields before changing layers',true);return;}void commit([{op:'layer',element:selected,position:button.dataset.layer}]);};
for(const button of document.querySelectorAll('[data-align]'))button.onclick=()=>{try{if(hasEditableDraft())throw Error('Apply or clear fields before aligning an element');void commit([alignElement(current().scene,selected,button.dataset.align)]);}catch(error){status(error.message,true);}};
$('#undo').onclick=()=>{try{if(hasEditableDraft())throw Error('Apply or clear fields before Undo');if(cursor>0&&!busy&&!drag){const snapshot=preflightStudioState({cursor:cursor-1});pauseMakerStream();cursor--;selected=snapshot.fields.selected;save();render();}}catch(error){status(error.message,true);}};
$('#redo').onclick=()=>{try{if(hasEditableDraft())throw Error('Apply or clear fields before Redo');if(cursor<history.length-1&&!busy&&!drag){const snapshot=preflightStudioState({cursor:cursor+1});pauseMakerStream();cursor++;selected=snapshot.fields.selected;save();render();}}catch(error){status(error.message,true);}};
const newId=()=> 'element-'+crypto.randomUUID();
$('#add-text').onclick=()=>{if(busy||hasEditableDraft()){status('Apply or clear field edits before adding text',true);return;}const id=newId();void commit([{op:'add',element:id,value:{id,kind:'text',x:80,y:80,width:500,height:120,text:'Your words here',fontSize:36,color:'#18352B',weight:'normal'}}],current().digest,{selected:id});};
$('#add-rect').onclick=()=>{if(busy||hasEditableDraft()){status('Apply or clear field edits before adding a block',true);return;}const id=newId();void commit([{op:'add',element:id,value:{id,kind:'rect',x:80,y:80,width:250,height:150,fill:'#DCCEB7'}}],current().digest,{selected:id});};
$('#add-image').onclick=()=>$('#image').click();
$('#image').onchange=async event=>{const file=event.target.files[0];if(!file)return;if(file.size>10*1024*1024){status('Image exceeds 10 MB',true);return;}try{if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before adding an image');const before=JSON.stringify(readStudioSnapshot()),expected=current().digest,src=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});if(busy||drag||JSON.stringify(readStudioSnapshot())!==before)throw Error('Editor changed while reading image; your work is retained');const id=newId();await commit([{op:'add',element:id,value:{id,kind:'image',x:80,y:80,width:400,height:300,src,alt:file.name}}],expected,{selected:id,isCurrent:()=>JSON.stringify(readStudioSnapshot())===before});}catch(error){status(error.message,true);}finally{event.target.value='';}};
$('#add-recovered-image').onclick=()=>$('#recovered-image').click();
$('#recovered-image').onchange=async event=>{
 const files=[...event.target.files],expected=current().digest,scene=clone(current().scene),before=JSON.stringify(readStudioSnapshot());
 try{
  if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before adding an image');
  if(files.length!==2)throw Error('Choose an image and its JSON receipt together');
  const receiptFile=files.find(f=>f.name.toLowerCase().endsWith('.json')),imageFile=files.find(f=>f!==receiptFile);
  if(!receiptFile||!imageFile||receiptFile.size>8192||imageFile.size>10*1024*1024)throw Error('Choose a bounded image and receipt');
  const receipt=JSON.parse(await receiptFile.text()),bytes=new Uint8Array(await imageFile.arrayBuffer());
  const bitmap=await createImageBitmap(new Blob([bytes],{type:receipt.mime}));
  const width=bitmap.width,height=bitmap.height;bitmap.close();
  if(width!==receipt.width||height!==receipt.height||Math.min(width,height)<64||Math.max(width,height)>4096)throw Error('Decoded image dimensions differ from receipt');
  const scale=Math.min(1,400/width,300/height,(scene.width-20)/width,(scene.height-20)/height);
  const id=newId(),change=await imageInsertion(scene,{id,x:20,y:20,width:width*scale,height:height*scale,alt:imageFile.name},bytes,receipt);
  if(current().digest!==expected||busy||drag||JSON.stringify(readStudioSnapshot())!==before)throw Error('Canvas changed while reading image. Your current work is retained.');
  await commit([change],expected,{selected:id,isCurrent:()=>JSON.stringify(readStudioSnapshot())===before});
 }catch(error){status(error.message,true);}finally{event.target.value='';}
};
$('#comment').onclick=()=>{try{if(busy||drag)throw Error('Finish the current canvas edit');const fields=JSON.parse(editableDraftSnapshot()),element=current().scene.elements.find(e=>e.id===selected);if(fields.properties.some(([name,value])=>element&&name in element&&value!==String(['color','fill'].includes(name)?element[name].toLowerCase():element[name]))||fields.brief[0]!==project.brief.purpose||fields.brief[1]!==project.brief.audience||fields.brief[2]!==project.brief.criteria.join('\n')||fields.brief[3].trim())throw Error('Apply or clear property and requirement edits before attaching feedback');const nextComments=[...comments,feedback(current(),selected,$('#note').value)];fields.note='';preflightStudioState({comments:nextComments},{fields});comments=nextComments;$('#note').value='';save();render();}catch(error){status(error.message,true);}};
function download(name,type,body){const url=URL.createObjectURL(new Blob([body],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);}
$('#export-source').onclick=()=>download(current().scene.id+'.json','application/json',JSON.stringify({schema:'omega-studio-source-1',current:current(),history,feedback:comments,project,provenance,merge_sources:mergeRecords,maker_trace:retainedMakerTrace(makerTrace,history),layout_observation:layoutObservation,derived_relations:sourceRelations(project,briefChange),...(briefChange?{brief_change:clone(briefChange)}:{})},null,2));
$('#export-svg').onclick=()=>download(current().scene.id+'.svg','image/svg+xml',svg(current().scene));
$('#import').onclick=()=>$('#file').click();
$('#file').onchange=async event=>{const file=event.target.files[0];if(!file)return;try{if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before importing a source');if(file.size>20*1024*1024)throw Error('Source exceeds 20 MB');const before=JSON.stringify(editableSource()),draftBefore=editableDraftSnapshot();await loadEditableSource(JSON.parse(await file.text()),before,{protectDrafts:true,expectedDraft:draftBefore});}catch(error){status(error.message,true);}finally{event.target.value='';}};
$('#retain-direction').onclick=async()=>{try{if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before retaining a direction');const before=JSON.stringify(readStudioSnapshot()),label=$('#direction-name').value,rationale=$('#direction-rationale').value,next=await proposeDirection(project,{id:'direction-'+crypto.randomUUID(),label,rationale,scene:current().scene});if(busy||drag||JSON.stringify(readStudioSnapshot())!==before||$('#direction-name').value!==label||$('#direction-rationale').value!==rationale)throw Error('Editor changed while retaining direction; your current work is retained');preflightStudioState({project:next});project=next;save();render();}catch(error){status(error.message,true);}};
$('#canvas').onpointerdown=event=>{const element=event.target.closest('[data-element]');if(!element||busy)return;if(hasEditableDraft()){status('Apply or clear field edits before dragging another element',true);return;}try{const id=element.dataset.element,e=current().scene.elements.find(e=>e.id===id);if(!e)throw Error('Element is absent');preflightStudioState({selected:id});selected=id;drag={mode:element.dataset.resize?'resize':'move',id:selected,x:event.clientX,y:event.clientY,origin:clone(e),digest:current().digest,scale:current().scene.width/$('#canvas').getBoundingClientRect().width};$('#canvas').setPointerCapture(event.pointerId);render();drag.fields=editableDraftSnapshot();}catch(error){status(error.message,true);}};
$('#canvas').onpointerup=event=>{if(!drag)return;const d=drag;drag=null;try{if(editableDraftSnapshot()!==d.fields){clearStudioDragPreview(d.id);status('Fields changed during the drag. Your pending fields are retained; retry after applying or clearing them.',true);return;}const s=current().scene;let changes;if(d.mode==='resize'){const change=resizeElement(s,d.id,Math.round(d.origin.width+(event.clientX-d.x)*d.scale),Math.round(d.origin.height+(event.clientY-d.y)*d.scale));if(change.patch.width!==d.origin.width||change.patch.height!==d.origin.height)changes=[change];}else{const x=Math.max(0,Math.min(s.width-d.origin.width,Math.round(d.origin.x+(event.clientX-d.x)*d.scale))),y=Math.max(0,Math.min(s.height-d.origin.height,Math.round(d.origin.y+(event.clientY-d.y)*d.scale)));if(x!==d.origin.x||y!==d.origin.y)changes=[{op:'set',element:d.id,patch:{x,y}}];}if(changes)void commit(changes,d.digest,{isCurrent:()=>editableDraftSnapshot()===d.fields}).then(ok=>{if(!ok)clearStudioDragPreview(d.id);});else clearStudioDragPreview(d.id);}catch(error){clearStudioDragPreview(d.id);status(error.message,true);}};
$('#canvas').onpointermove=event=>{if(!drag)return;if(drag.mode==='resize'){const patch=resizeElement(current().scene,drag.id,Math.round(drag.origin.width+(event.clientX-drag.x)*drag.scale),Math.round(drag.origin.height+(event.clientY-drag.y)*drag.scale)).patch;const box=$('#canvas [data-selection-box]');for(const [k,v] of Object.entries(patch))box?.setAttribute(k,v);return;}const e=$('#canvas').querySelector(`[data-element="${drag.id}"]`);e?.setAttribute('transform',`translate(${(event.clientX-drag.x)*drag.scale} ${(event.clientY-drag.y)*drag.scale})`);};
$('#canvas').onpointercancel=()=>{const d=drag;drag=null;if(d)clearStudioDragPreview(d.id);};

$('#load-identity').onclick=()=>$('#identity-file').click();
$('#identity-file').onchange=async event=>{const file=event.target.files[0];if(!file)return;try{if(file.size>256*1024)throw Error('Identity exceeds 256 KB');const identity=validateIdentity(JSON.parse(await file.text()));const impacts=await identityImpact(project,identity);loadedIdentity=identity;identityImpactNotes=impacts;renderIdentity();}catch(error){status(error.message,true);}finally{event.target.value='';}};
$('#identity-direction').onchange=()=>{$('#identity-bindings').replaceChildren();renderIdentity();};
$('#reuse-identity').onclick=async()=>{try{if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before reusing identity');const direction=project.directions.find(d=>d.id===$('#identity-direction').value),identity=loadedIdentity;if(!direction||!identity)throw Error('Load an identity and choose a retained direction');const before=JSON.stringify(readStudioSnapshot()),bindings=[...document.querySelectorAll('#identity-bindings select')].filter(s=>s.value).map(s=>{const [element,field]=JSON.parse(s.dataset.binding);return {element,field,token:s.value};}),label=$('#identity-name').value,rationale=$('#identity-reason').value,next=await reuseIdentity(project,{source_direction:direction.id,expected_digest:direction.scene_digest,identity,bindings,id:'identity-'+crypto.randomUUID(),label,rationale}),impacts=await identityImpact(next,identity);if(busy||drag||loadedIdentity!==identity||JSON.stringify(readStudioSnapshot())!==before||$('#identity-name').value!==label||$('#identity-reason').value!==rationale)throw Error('Editor changed while reusing identity; your current work is retained');preflightStudioState({project:next});project=next;identityImpactNotes=impacts;save();render();}catch(error){status(error.message,true);}};

$('#merge-source').onclick=()=>{if(!busy)$('#merge-file').click();};
$('#merge-file').onchange=async event=>{const file=event.target.files[0];if(!file||busy)return;let accepted=false;const before=JSON.stringify(readStudioSnapshot());busy=true;let failure;try{
 if(drag||hasEditableDraft())throw Error('Apply or clear field edits before merging');
 if(file.size>20*1024*1024)throw Error('Source exceeds 20 MB');
 const local=clone({schema:'omega-studio-source-1',current:current(),history,feedback:comments,project,provenance,merge_sources:mergeRecords,...(briefChange?{brief_change:clone(briefChange)}:{})});const expected=await digest(local);
 const result=await mergeSources(local,JSON.parse(await file.text()));
 if(drag||JSON.stringify(readStudioSnapshot())!==before||await digest({schema:'omega-studio-source-1',current:current(),history,feedback:comments,project,provenance,merge_sources:mergeRecords,...(briefChange?{brief_change:clone(briefChange)}:{})})!==expected)throw Error('Canvas changed during merge; retry against the current source');
 if(result.status==='conflict')throw Error('Conflicting edits: '+result.conflicts.map(c=>c.element+' / '+c.field).join(', '));
 const snapshot=preflightStudioState({history:result.source.history,cursor:result.source.history.length-1,comments:result.source.feedback,mergeRecords:result.source.merge_sources});history=result.source.history;cursor=history.length-1;selected=snapshot.fields.selected;comments=result.source.feedback;mergeRecords=result.source.merge_sources;accepted=true;save();
 }catch(error){failure=error.message;}finally{busy=false;event.target.value='';if(accepted)render();if(failure)status(failure,true);}};

export async function insertStudioImage(image,{expectedSnapshot,isCurrent=()=>true}={}){
 if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before adding an image');
 const before=expectedSnapshot??JSON.stringify(readStudioSnapshot()),scene=clone(current().scene),expected=current().digest;
 const guard=()=>isCurrent()&&!drag&&!hasEditableDraft()&&JSON.stringify(readStudioSnapshot())===before;
 const id=newId(),change=await pickedImageInsertion(scene,image,{id,document,isCurrent:()=>!busy&&guard()});
 if(busy||!guard())throw Error('Editor changed while preparing image; your work is retained');
 if(!await commit([change],expected,{isCurrent:guard,selected:id}))throw Error('Image insertion was refused; your work is retained');
}
export function setStudioRecoverySourceRefReader(reader=()=>null){if(typeof reader!=='function')throw Error('Recovery source reference reader required');studioRecoverySourceRefReader=reader;}
export function setHostDraftCapability(value){hostDraftCapability=value===true;if(hostDraftCapability)$('#status').textContent=$('#status').textContent.replace(' · Draft save unavailable — Save to Hive or Export to keep this work.','');}
export function readStudioSnapshot(){return {schema:'omega-studio-draft-1',source:{...editableSource(),history:clone(history),maker_trace:clone(retainedMakerTrace(makerTrace,history))},fields:JSON.parse(editableDraftSnapshot())};}
export async function restoreStudioSnapshot(input,expectedSnapshot,{isCurrent=()=>true,sourceRef=studioRecoverySourceRefReader()}={}){
 const restored=await verifyStudioSnapshot(input);
 if(!isCurrent()||busy||drag||JSON.stringify(readStudioSnapshot())!==expectedSnapshot)throw Error('Editor changed while restoring; your current work is retained');
 const source=restored.source,fields=restored.fields;
 preflightStudioState({history:source.history,cursor:source.history.findIndex(r=>r.digest===source.current.digest&&r.revision===source.current.revision),project:source.project,selected:fields.selected,comments:source.feedback??[],provenance:source.provenance??null,mergeRecords:source.merge_sources??[],makerTrace:source.maker_trace??[],briefChange:source.brief_change??null},{fields,refreshProperties:false,sourceRef});
 closeMakerStream();history=clone(source.history);cursor=history.findIndex(r=>r.digest===source.current.digest&&r.revision===source.current.revision);project=clone(source.project);selected=fields.selected;comments=clone(source.feedback??[]);provenance=source.provenance??null;mergeRecords=clone(source.merge_sources??[]);makerTrace=clone(source.maker_trace??[]);briefChange=clone(source.brief_change??null);
 refreshBriefDraftFields();render();
 $('#note').value=fields.note;
 for(const [name,value] of fields.properties){const input=[...$('#properties').elements].find(x=>x.name===name);if(input)input.value=value;}
 ['purpose','audience','criteria','reason'].forEach((name,i)=>{$('#want-'+name).value=fields.brief[i];});
 save();return readStudioSnapshot();
}
export function selectStudioElement(id){if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before selecting another element');if(!current().scene.elements.some(e=>e.id===id))throw Error('Element is absent');preflightStudioState({selected:id});selected=id;render();}
export async function chooseStudioDirection(id,reason,{isCurrent=()=>true}={}){
 if(busy||drag||hasEditableDraft())throw Error('Apply or clear field edits before choosing a direction');
 const before=JSON.stringify(readStudioSnapshot()),next=await selectDirection(project,id,reason),direction=next.directions.find(d=>d.id===id),root=await initial(direction.scene);
 if(!isCurrent()||busy||drag||JSON.stringify(readStudioSnapshot())!==before)throw Error('Editor changed while selecting direction');
 preflightStudioState({project:next,history:[root],cursor:0,selected:root.scene.elements[0]?.id??'',makerTrace:[]});
 closeMakerStream();makerTrace=[];project=next;history=[root];cursor=0;selected=root.scene.elements[0]?.id??'';save();render();
}

export async function acceptStudioChange(input,reason,{expectedSnapshot,isCurrent=()=>true,sourceRef,canvasRef}={}){
 if(typeof reason!=='string'||!reason.trim()||reason.length>2000)throw Error('Explain why you accept this local suggestion');
 if(typeof expectedSnapshot!=='string'||!expectedSnapshot)throw Error('Exact full Studio snapshot required');
 const proposalReference=exactReference(sourceRef),original=current(),canvasBefore={scene_id:original.scene.id,revision:original.revision,digest:original.digest};
 if(!canvasRef||Object.keys(canvasRef).sort().join(',')!=='digest,revision,scene_id'||canonical(canvasRef)!==canonical(canvasBefore))throw Error('Exact proposal canvas reference differs');
 if(!isCurrent()||busy||drag||hasEditableDraft()||JSON.stringify(readStudioSnapshot())!==expectedSnapshot)throw Error('Finish or retain newer fields and canvas work before accepting a suggestion');
 const proposal=clone(input),change=checkedSuggestionChange(original.scene,proposal);
 busy=true;let accepted=false;
 try{
  const next=await apply(original,original.digest,[change]),changeDigest=await digest(proposal);
  if(!isCurrent()||drag||current()!==original||JSON.stringify(readStudioSnapshot())!==expectedSnapshot)throw Error('Editor or proposal access changed; your newer work is retained');
  const canvasAfter={scene_id:next.scene.id,revision:next.revision,digest:next.digest},decision={schema:'omega-local-suggestion-decision-1',proposal_reference:proposalReference,canvas_before:canvasBefore,canvas_after:canvasAfter,change_digest:changeDigest,decision:'accepted',reason:reason.trim(),issuer_authentication:'unverified',execution_admitted:false,adopted:false};
  const note={...feedback(next,change.element,'Accepted local suggestion: '+reason.trim()),suggestion_decision:clone(decision)};
  const nextHistory=[...history.slice(0,cursor+1),next],nextComments=[...comments,note],snapshot=preflightStudioState({history:nextHistory,cursor:nextHistory.length-1,comments:nextComments});
  pauseMakerStream();history=nextHistory;cursor=nextHistory.length-1;selected=snapshot.fields.selected;comments=nextComments;accepted=true;save();
  return clone(decision);
 }finally{busy=false;if(accepted)render();}
}

export function editableSource(){return {schema:'omega-studio-source-1',current:clone(current()),history:clone(history.slice(0,cursor+1)),feedback:clone(comments),project:clone(project),provenance,merge_sources:clone(mergeRecords),maker_trace:clone(retainedMakerTrace(makerTrace,history.slice(0,cursor+1))),derived_relations:sourceRelations(project,briefChange),...(briefChange?{brief_change:clone(briefChange)}:{})};}
export async function loadEditableSource(input,expectedSource=null,{protectDrafts=false,expectedDraft=null,isCurrent=()=>true,sourceRef=studioRecoverySourceRefReader()}={}){
 const sourceBefore=expectedSource??JSON.stringify(editableSource()),draftBefore=expectedDraft??editableDraftSnapshot();
 const source=await verifySource(input);if(!isCurrent())throw Error('Source request is no longer current');if(busy||drag)throw Error('Finish the current canvas edit before loading a source');const active=source.history.findIndex(r=>r.digest===source.current.digest&&r.revision===source.current.revision);
 if(JSON.stringify(editableSource())!==sourceBefore)throw Error('Canvas changed during requirement steering');
 if(editableDraftSnapshot()!==draftBefore)throw Error('Draft changed during requirement steering; retain your edits and retry');
 if(protectDrafts&&hasEditableDraft())throw Error('Unapplied field edits or feedback must be retained before loading another source');
 preflightStudioState({history:source.history,cursor:active,project:source.project,selected:source.current.scene.elements[0]?.id??'',comments:source.feedback??[],provenance:source.provenance??null,mergeRecords:source.merge_sources??[],makerTrace:source.maker_trace??[],briefChange:source.brief_change??null},{refreshBrief:true,sourceRef});
 closeMakerStream();history=clone(source.history);cursor=active;project=clone(source.project);selected=source.current.scene.elements[0]?.id??'';comments=clone(source.feedback??[]);provenance=source.provenance??null;mergeRecords=clone(source.merge_sources??[]);makerTrace=clone(source.maker_trace??[]);briefChange=clone(source.brief_change??null);refreshBriefDraftFields();save();render();return editableSource();
}

// Local entry points only. A host transport must authenticate the caller and bind
// the stream before invoking these; these functions confer no Hive authority.
let makerStream=null;
const makerListeners=new Set();
function notifyMakerState(){const state=makerStream?.state()??null;for(const listener of makerListeners)listener(state);return state;}
export function observeMakerState(listener){if(typeof listener!=='function')throw Error('State observer required');makerListeners.add(listener);listener(makerStream?.state()??null);return ()=>makerListeners.delete(listener);}
export function startMakerStream(streamId){
 if(busy||drag)throw Error('Finish the current canvas edit');
 if(makerStream?.state().streamId===streamId&&!makerStream.state().closed)return notifyMakerState();
 if(makerTrace.some(e=>e.receipt.stream_id===streamId))throw Error('Retained stream requires host reconciliation; use a new admitted stream');
 makerStream?.close();makerStream=liveEdits({streamId,sceneId:current().scene.id});
 return notifyMakerState();
}
export function pauseMakerStream(){makerStream?.pause();return notifyMakerState();}
export function resumeMakerStream(){makerStream?.resume();return notifyMakerState();}
export function closeMakerStream(){makerStream?.close();return notifyMakerState();}
export async function applyMakerEvent(event){
 if(!makerStream)throw Error('No bound maker stream');
 if(busy||drag||hasEditableDraft())throw Error('Canvas edit or pending fields in progress; retry the same event');
 const proposal=clone(event),stream=makerStream,before=JSON.stringify(readStudioSnapshot());busy=true;const original=current();let result,accepted=false;
 try{
  const eventDigest=await digest(proposal);
  if(makerStream!==stream||drag||JSON.stringify(readStudioSnapshot())!==before)throw Error('Editor changed while preparing maker edit; your current work is retained');
  result=await stream.receive(original,proposal,{commit:updated=>{
   if(makerStream!==stream||drag||current()!==original||JSON.stringify(readStudioSnapshot())!==before)return false;
   const reference=r=>({scene_id:r.scene.id,revision:r.revision,digest:r.digest}),receipt={schema:'omega-local-maker-edit-1',stream_id:proposal.stream_id,sequence:proposal.sequence,event_digest:eventDigest,before:reference(original),after:reference(updated),issuer_authentication:'unverified',adopted:false};
   const nextHistory=[...history.slice(0,cursor+1),updated],nextTrace=[...retainedMakerTrace(makerTrace,nextHistory),{event:proposal,receipt}],snapshot=preflightStudioState({history:nextHistory,cursor:nextHistory.length-1,makerTrace:nextTrace});
   history=nextHistory;cursor=nextHistory.length-1;selected=snapshot.fields.selected;makerTrace=nextTrace;accepted=true;return true;
  }});
  if(result.status==='applied')save();
  return {status:result.status,revision:current().revision,digest:current().digest,receipt:clone(result.receipt)};
 }finally{busy=false;if(accepted)render();}
}

function refreshBriefDraftFields(){$('#want-purpose').value=project.brief.purpose;$('#want-audience').value=project.brief.audience;$('#want-criteria').value=project.brief.criteria.join('\n');$('#want-reason').value='';}
$('#refresh-want').onclick=()=>{refreshBriefDraftFields();for(const listener of sourceObservers)listener(editableSource());};
$('#refresh-want').onclick();
$('#revise-want').onclick=async()=>{try{if(hasCanvasFieldDraft())throw Error('Apply artwork field edits and attach or clear feedback before revising requirements');const before=JSON.stringify(editableSource()),expectedDraft=editableDraftSnapshot();const brief=await briefFromFields(JSON.parse(before).project.brief,{purpose:$('#want-purpose').value,audience:$('#want-audience').value,criteria:$('#want-criteria').value});const next=await steerSource(JSON.parse(before),brief,$('#want-reason').value);await loadEditableSource(next,before,{expectedDraft});status('Requirements revised. Prior source retained; copy and design need reassessment.');}catch(error){status(error.message,true);}};
