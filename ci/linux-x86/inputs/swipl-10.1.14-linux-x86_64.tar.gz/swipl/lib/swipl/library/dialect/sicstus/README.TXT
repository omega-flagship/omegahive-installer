SISCtus compatibility library.
