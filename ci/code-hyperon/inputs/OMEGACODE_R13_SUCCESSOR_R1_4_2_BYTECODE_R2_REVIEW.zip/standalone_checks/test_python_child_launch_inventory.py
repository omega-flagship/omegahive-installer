"""Portable AST census and mutation controls; no product/toolchain execution."""
from __future__ import annotations

import ast
import copy
import json
from pathlib import Path
import unittest

import python_child_launch_inventory as inventory


class PythonChildLaunchInventoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sources = inventory.source_map()
        cls.registry = json.loads(inventory.REGISTRY.read_text())
        cls.scanned = inventory.scan_sources(cls.sources)

    def issues_for(self, sources):
        return inventory.check_inventory(inventory.scan_sources(sources), self.registry)

    def test_reviewed_inventory_contains_all_ten_owned_python_producers(self):
        self.assertEqual(inventory.check_inventory(self.scanned, self.registry), [])
        owned = [site for site, row in self.registry["argv_builders"].items() if row["kind"] == "owned_python"]
        self.assertEqual(len(owned), 10)
        self.assertEqual(len(self.scanned["process_sites"]), 26)
        dap = self.scanned["argv_builders"]["debugger.py:Dap.launch_python:argv#0"]
        self.assertTrue(dap["dap_python_field"])
        self.assertTrue(dap["explicit_bytecode_disabled"])

    def test_removing_b_at_each_owned_constructor_is_detected(self):
        for site, row in self.registry["argv_builders"].items():
            if row["kind"] != "owned_python":
                continue
            with self.subTest(site=site):
                filename = site.split(":", 1)[0]
                line = self.scanned["argv_builders"][site]["line"]
                tree = ast.parse(self.sources[filename])
                mutations = 0
                for node in ast.walk(tree):
                    if isinstance(node, (ast.List, ast.Tuple)) and node.lineno == line:
                        before = len(node.elts)
                        node.elts = [item for item in node.elts if not isinstance(item, ast.Constant) or item.value != "-B"]
                        mutations += before - len(node.elts)
                self.assertEqual(mutations, 1)
                changed = {**self.sources, filename: ast.unparse(tree)}
                issues = self.issues_for(changed)
                self.assertIn({"site": site, "reason": "explicit_b_required_before_target"}, issues)

    def test_b_after_module_target_is_not_an_interpreter_flag(self):
        filename = "service.py"
        site = "service.py:Service._spawn_run_executor:argv#0"
        tree = ast.parse(self.sources[filename])
        line = self.scanned["argv_builders"][site]["line"]
        for node in ast.walk(tree):
            if isinstance(node, ast.List) and node.lineno == line:
                flag = next(item for item in node.elts if isinstance(item, ast.Constant) and item.value == "-B")
                node.elts.remove(flag); node.elts.append(flag)
        self.assertIn({"site": site, "reason": "explicit_b_required_before_target"},
                      self.issues_for({**self.sources, filename: ast.unparse(tree)}))

    def test_b_after_option_terminator_is_not_an_interpreter_flag(self):
        source = "import subprocess, sys\ndef invented():\n subprocess.Popen([sys.executable, '--', '-B', '-m', 'invented'])\n"
        scanned = inventory.scan_text("invented_future.py", source)
        rows = list(scanned["argv_builders"].values())
        self.assertEqual(len(rows), 1)
        self.assertFalse(rows[0]["explicit_bytecode_disabled"])

    def test_new_aliased_process_launch_requires_review(self):
        changed = {**self.sources, "invented_future.py":
                   "import subprocess as launches\nimport sys\ndef future():\n launches.Popen([sys.executable, '-I', 'invented.py'])\n"}
        issues = self.issues_for(changed)
        self.assertTrue(any(row["site"].startswith("invented_future.py:") and
                            row["reason"] == "unreviewed_launch_or_builder" for row in issues))

    def test_new_imported_popen_alias_without_literal_argv_requires_review(self):
        changed = {**self.sources, "invented_future.py":
                   "from subprocess import Popen as launch\ndef future(argv):\n launch(argv)\n"}
        issues = self.issues_for(changed)
        self.assertTrue(any("subprocess.Popen" in row["site"] and row["reason"] == "unreviewed_launch_or_builder"
                            for row in issues))

    def test_new_python_builder_through_existing_generic_adapter_requires_review(self):
        text = self.sources["debug_session.py"] + "\ndef invented_future(root, interpreter):\n return Dap([interpreter, '-I', '-m', 'invented'], root)\n"
        issues = self.issues_for({**self.sources, "debug_session.py": text})
        self.assertTrue(any("invented_future:argv" in row["site"] and row["reason"] == "unreviewed_launch_or_builder"
                            for row in issues))

    def test_new_async_process_launch_requires_review(self):
        changed = {**self.sources, "invented_future.py":
                   "from asyncio import create_subprocess_exec as launch\nasync def future(argv):\n await launch(*argv)\n"}
        issues = self.issues_for(changed)
        self.assertTrue(any("asyncio.create_subprocess_exec" in row["site"] for row in issues))

    def test_changed_nonpython_or_dynamic_exemption_requires_review(self):
        filename = "context_selection.py"
        site = "context_selection.py:_select:argv#0"
        tree = ast.parse(self.sources[filename])
        line = self.scanned["argv_builders"][site]["line"]
        for node in ast.walk(tree):
            if isinstance(node, ast.List) and node.lineno == line:
                node.elts[0] = ast.Attribute(value=ast.Name(id="sys", ctx=ast.Load()), attr="executable", ctx=ast.Load())
        issues = self.issues_for({**self.sources, filename: ast.unparse(tree)})
        self.assertIn({"site": site, "reason": "reviewed_argv_changed"}, issues)

    def test_runner_keeps_m_import_path_without_adding_isolated_mode(self):
        row = self.scanned["argv_builders"]["service.py:Service._spawn_run_executor:argv#0"]
        node = ast.parse(row["argv"], mode="eval").body
        strings = [item.value for item in node.elts if isinstance(item, ast.Constant)]
        self.assertEqual(strings, ["-B", "-m", "omegacode.runner"])
        self.assertNotIn("-I", strings)
        self.assertIn('"PYTHONPATH": str(root / "executor")', self.sources["service.py"])

    def test_generic_user_and_tool_sinks_are_explicitly_classified(self):
        kinds = self.registry["process_sites"]
        self.assertEqual(kinds["runner.py:execute:subprocess.Popen#1"]["kind"], "approved_execution_argv")
        self.assertEqual(kinds["language.py:Stdio.__init__:subprocess.Popen#0"]["kind"], "registered_language_tool")
        self.assertEqual(kinds["debugger.py:Dap.__init__:subprocess.Popen#0"]["kind"], "generic_dap_transport")
        self.assertEqual(self.scanned["process_sites"]["runner.py:execute:subprocess.Popen#1"]["argv"], "spec['argv']")


if __name__ == "__main__":
    unittest.main()
