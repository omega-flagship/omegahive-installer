/*  Part of SWI-Prolog

    Author:        Jan Wielemaker
    E-mail:        J.Wielemaker@vu.nl
    WWW:           http://www.swi-prolog.org
    Copyright (c)  2019, VU University Amsterdam
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in
       the documentation and/or other materials provided with the
       distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
    FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
    COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
    LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
    ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
    POSSIBILITY OF SUCH DAMAGE.
*/

:- module(prolog_theme_auto, []).
:- use_module(library(ansi_term), [ansi_get_color/2]).

/** <module> Load a sensible theme based on the environment

This module examines the environment and   selects an appropriate theme.
THe current implementation is really basic.  Future versions should look
at more, partly OS specific, clues.
*/

:- multifile
    prolog:theme/1.

%!  theme(-Theme) is semidet.
%
%   Theme that suits the environment.  Fails   if  we cannot tell, which
%   leaves the default.  Note that the  default   is  a  light theme, so
%   failing here is the right thing on a light background.

theme(Theme) :-
    ansi_get_color(background, RGB),
    luminance(RGB, Y),
    (   Y < 0.5                         % darker than mid grey
    ->  Theme = dark
    ;   Theme = light
    ).

%!  luminance(+RGB, -Luminance) is det.
%
%   Perceived brightness of RGB as a  float   in  0.0..1.0.  This is the
%   luma of the sRGB encoded components  reported   by  the terminal, so
%   green weighs a lot more than blue and adding up the components would
%   call a saturated blue background light.

luminance(rgb(R,G,B), Y) :-
    Y is 0.299*R + 0.587*G + 0.114*B.

load_theme :-
    prolog:theme(_),                            % a theme has been loaded
    !.
load_theme :-
    theme(Theme),
    !,
    ensure_loaded(library(theme/Theme)).
load_theme.

:- initialization(load_theme, now).
