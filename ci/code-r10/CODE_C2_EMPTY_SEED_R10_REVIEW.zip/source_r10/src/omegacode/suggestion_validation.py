"""R20 pure validation/reconstruction kernel used by authenticated suggestion APIs.

The caller supplies a trusted saved-source scope and current CAS binding. No model
or browser may mint that scope. Accepted edits still need normal service authority.
"""
import hashlib
import json
from pathlib import PurePosixPath

MAX_BYTES = 2 * 1024 * 1024
sha = lambda b: hashlib.sha256(b).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def path_ok(path):
    return isinstance(path, str) and bool(path) and not PurePosixPath(path).is_absolute() and all(
        p not in ('', '.', '..') for p in path.split('/')) and '\\' not in path and '\0' not in path

def boundary(data, offset):
    return type(offset) is int and 0 <= offset <= len(data) and (
        offset == len(data) or data[offset] & 0xC0 != 0x80)

def prepare(binding, files, trusted_ranges, proposals, groups=None):
    """Retain normalized immutable proposal data from bounded untrusted hunks."""
    if not proposals or len(proposals) > 1000:
        raise ValueError('hunk count')
    hunks = []
    for item in proposals:
        if set(item) != {'path', 'start_byte', 'end_byte', 'replacement', 'before_digest'}:
            raise ValueError('hunk fields')
        path = item['path']
        if not path_ok(path) or path not in files or path not in trusted_ranges:
            raise ValueError('path scope')
        data = files[path]
        if type(data) is not bytes or len(data) > MAX_BYTES:
            raise ValueError('saved source')
        data.decode('utf-8', errors='strict')
        start, end = item['start_byte'], item['end_byte']
        if not boundary(data, start) or not boundary(data, end) or start > end:
            raise ValueError('UTF-8 range')
        # Closed boundaries are explicitly granted by the trusted range issuer.
        if not any(type(a) is int and type(b) is int and 0 <= a <= start <= end <= b <= len(data)
                   for a, b in trusted_ranges[path]):
            raise ValueError('range scope')
        if item['before_digest'] != sha(data[start:end]):
            raise ValueError('before digest')
        replacement = item['replacement']
        if type(replacement) is not str or len(replacement.encode()) > MAX_BYTES:
            raise ValueError('replacement size')
        hunk = {**item, 'expected_file_digest':sha(data)}
        hunk['id'] = sha(canonical({'binding':binding, 'hunk':hunk}))
        hunks.append(hunk)
    input_ids = [h['id'] for h in hunks]
    retained_groups = []
    if groups is not None:
        if type(groups) is not list or len(groups) > 500:
            raise ValueError('hunk groups count')
        seen = set()
        for group in groups:
            if type(group) is not list or not 2 <= len(group) <= len(proposals):
                raise ValueError('hunk groups need2 or more indexes')
            if any(type(i) is not int or not 0 <= i < len(input_ids) for i in group):
                raise ValueError('hunk group index')
            if len(set(group)) != len(group) or seen.intersection(group):
                raise ValueError('hunk groups must be disjoint')
            seen.update(group)
            retained_groups.append(sorted(input_ids[i] for i in group))
    hunks.sort(key=lambda h:(h['path'], h['start_byte'], h['end_byte']))
    for left, right in zip(hunks, hunks[1:]):
        if left['path'] == right['path'] and (
                right['start_byte'] < left['end_byte'] or right['start_byte'] == left['start_byte']
                or (right['start_byte'] == left['end_byte'] and (
                    left['start_byte'] == left['end_byte'] or right['start_byte'] == right['end_byte']))):
            raise ValueError('overlapping or ambiguous hunks')
    result = {'schema':'omegacode-scoped-suggestion-v1', 'binding':dict(binding),
              'scope':{p:[list(r) for r in trusted_ranges[p]] for p in sorted(trusted_ranges)}, 'hunks':hunks}
    if retained_groups:
        result['hunk_groups'] = sorted(retained_groups)
    result['digest'] = sha(canonical(result))
    # Caller mutation cannot alter retained data through aliasing.
    return json.loads(canonical(result))


def prepare_v2(binding, files, trusted_scope, scope_id, scope_digest, proposals, groups=None, author=None):
    """Normalize tagged text edits/creates against a retained v2 scope ceiling."""
    from .common import safe_path
    if type(proposals) is not list or not 1 <= len(proposals) <= 1000:
        raise ValueError('unit count')
    ranges = trusted_scope.get('ranges')
    create_files = trusted_scope.get('create_files')
    file_digests = trusted_scope.get('file_digests')
    if type(ranges) is not dict or type(create_files) is not dict or type(file_digests) is not dict:
        raise ValueError('v2 scope shape')
    edit_paths = set(ranges)
    create_paths = set(create_files)
    if edit_paths & create_paths or (edit_paths | create_paths) != set(file_digests) | create_paths:
        if edit_paths & create_paths or set(file_digests) != edit_paths:
            raise ValueError('v2 scope path union')
    if not create_paths and trusted_scope.get('max_total_create_bytes') != 0:
        raise ValueError('v2 scope byte ceiling')
    create_total = 0
    ids_by_index = {}
    edit_input = []
    edit_indexes = []
    create_seen = set()
    scope_map = {}
    for path in edit_paths:
        scope_map[path] = {'kind':'edit_text','ranges':ranges[path],'file_digest':file_digests[path]}
    for path, ceiling in create_files.items():
        if type(ceiling) is not dict or set(ceiling) != {'before','max_bytes'} or ceiling['before'] != {'kind':'absent'}:
            raise ValueError('v2 absent ceiling')
        if type(ceiling['max_bytes']) is not int or not 0 <= ceiling['max_bytes'] <= MAX_BYTES:
            raise ValueError('v2 per-file ceiling')
        scope_map[path] = {'kind':'create_text','before':{'kind':'absent'},'max_bytes':ceiling['max_bytes']}

    for index, item in enumerate(proposals):
        if type(item) is not dict or type(item.get('kind')) is not str:
            raise ValueError('v2 unit shape')
        kind = item['kind']
        if kind == 'edit_text':
            if set(item) != {'kind','path','start_byte','end_byte','replacement','before_digest'}:
                raise ValueError('v2 edit fields')
            path = item['path']
            if path not in edit_paths:
                raise ValueError('edit path scope')
            edit_indexes.append(index)
            edit_input.append({k:item[k] for k in ('path','start_byte','end_byte','replacement','before_digest')})
        elif kind == 'create_text':
            if set(item) != {'kind','path','content'}:
                raise ValueError('v2 create fields')
            path = item['path']
            if type(path) is not str or safe_path(path) != path or path not in create_paths:
                raise ValueError('create path scope')
            if path in create_seen:
                raise ValueError('create path appears more than once')
            create_seen.add(path)
            content = item['content']
            if type(content) is not str or '\0' in content:
                raise ValueError('create text content')
            try: data = content.encode('utf-8','strict')
            except UnicodeEncodeError: raise ValueError('create text UTF-8') from None
            ceiling = create_files[path]['max_bytes']
            if len(data) > MAX_BYTES or len(data) > ceiling:
                raise ValueError('create text byte ceiling')
            create_total += len(data)
            unit = {'kind':'create_text','path':path,'content':content,
                    'content_bytes':len(data),'content_digest':sha(data),
                    'before':{'kind':'absent'}}
            unit['id'] = sha(canonical({'binding':binding,'scope_id':scope_id,
                                        'scope_digest':scope_digest,'hunk':unit}))
            ids_by_index[index] = unit['id']
        else:
            raise ValueError('v2 unit kind')
    if create_total > trusted_scope.get('max_total_create_bytes',-1):
        raise ValueError('create total byte ceiling')

    if edit_input:
        if type(files) is not dict or any(path not in files for path in edit_paths):
            raise ValueError('missing edit source')
        normalized = prepare(binding,files,ranges,edit_input)
        by_key = {(row['path'],row['start_byte'],row['end_byte'],row['replacement'],row['before_digest']): row
                  for row in normalized['hunks']}
        for index, proposal in zip(edit_indexes,edit_input):
            key=(proposal['path'],proposal['start_byte'],proposal['end_byte'],proposal['replacement'],proposal['before_digest'])
            old=by_key.get(key)
            if old is None: raise ValueError('edit normalization mismatch')
            unit={k:old[k] for k in ('path','start_byte','end_byte','replacement','before_digest','expected_file_digest')}
            unit={'kind':'edit_text',**unit}
            unit['id']=sha(canonical({'binding':binding,'scope_id':scope_id,
                                      'scope_digest':scope_digest,'hunk':unit}))
            ids_by_index[index]=unit['id']
    units=[]
    if edit_input:
        for old in normalized['hunks']:
            unit={k:old[k] for k in ('path','start_byte','end_byte','replacement','before_digest','expected_file_digest')}
            unit={'kind':'edit_text',**unit}
            unit['id']=sha(canonical({'binding':binding,'scope_id':scope_id,
                                      'scope_digest':scope_digest,'hunk':unit}))
            units.append(unit)
    for index,item in enumerate(proposals):
        if item['kind']=='create_text':
            data=item['content'].encode('utf-8','strict')
            unit={'kind':'create_text','path':item['path'],'content':item['content'],
                  'content_bytes':len(data),'content_digest':sha(data),'before':{'kind':'absent'}}
            unit['id']=sha(canonical({'binding':binding,'scope_id':scope_id,
                                      'scope_digest':scope_digest,'hunk':unit}))
            units.append(unit)
    units.sort(key=lambda h:(h['path'],h['kind'],h.get('start_byte',-1),h.get('end_byte',-1),h['id']))
    result={'schema':'omegacode-scoped-suggestion-v2','binding':dict(binding),
            'scope_id':scope_id,'scope_digest':scope_digest,'scope':scope_map,
            'max_total_create_bytes':trusted_scope.get('max_total_create_bytes',0),
            'hunks':units,'author':author}
    if groups is not None:
        if type(groups) is not list or len(groups)>500:
            raise ValueError('unit groups count')
        seen=set(); retained_groups=[]
        for group in groups:
            if type(group) is not list or not 2<=len(group)<=len(proposals):
                raise ValueError('unit groups need at least two indexes')
            if any(type(i) is not int or not 0<=i<len(proposals) for i in group):
                raise ValueError('unit group index')
            if len(set(group))!=len(group) or seen.intersection(group):
                raise ValueError('unit groups must be disjoint')
            seen.update(group)
            retained_groups.append(sorted(ids_by_index[i] for i in group))
        if retained_groups: result['hunk_groups']=sorted(retained_groups)
    if len(canonical(result))>4*1024*1024:
        raise ValueError('serialized v2 proposal limit')
    return json.loads(canonical(result))


def reconstruct_v2(retained, expected_digest, current_binding, files, accepted_ids, existing_paths=()):
    """Rebuild selected v2 units as ordinary existing Service.edit descriptors."""
    if type(retained) is not dict or retained.get('schema')!='omegacode-scoped-suggestion-v2':
        raise ValueError('proposal schema')
    if sha(canonical(retained))!=expected_digest:
        raise ValueError('proposal digest')
    if retained.get('binding')!=current_binding:
        raise ValueError('stale or foreign binding')
    if type(accepted_ids) is not list or not accepted_ids or len(accepted_ids)!=len(set(accepted_ids)):
        raise ValueError('selection count')
    hunks=retained.get('hunks'); scope=retained.get('scope')
    if type(hunks) is not list or type(scope) is not dict:
        raise ValueError('proposal shape')
    known={h.get('id'):h for h in hunks if type(h) is dict and type(h.get('id')) is str}
    if len(known)!=len(hunks) or any(i not in known for i in accepted_ids):
        raise ValueError('unknown or duplicate hunk')
    decision_groups(retained,accepted_ids,[])
    selected=[known[i] for i in accepted_ids]
    edit_by_path={}; creates=[]; create_total=0; existing=set(existing_paths)
    for hunk in selected:
        kind=hunk.get('kind'); path=hunk.get('path')
        if not path_ok(path) or path not in scope:
            raise ValueError('hunk path scope')
        without_id={k:v for k,v in hunk.items() if k!='id'}
        expected_id=sha(canonical({'binding':retained['binding'],'scope_id':retained['scope_id'],
                                   'scope_digest':retained['scope_digest'],'hunk':without_id}))
        if hunk.get('id')!=expected_id:
            raise ValueError('hunk identity')
        if kind=='create_text':
            ceiling=scope[path]
            if (ceiling.get('kind')!='create_text' or ceiling.get('before')!={'kind':'absent'} or
                    hunk.get('before')!={'kind':'absent'} or path in existing):
                raise ValueError('create absence binding')
            try:data=hunk['content'].encode('utf-8','strict')
            except (KeyError,AttributeError,UnicodeError):raise ValueError('create text encoding') from None
            if (len(data)!=hunk.get('content_bytes') or sha(data)!=hunk.get('content_digest') or
                    len(data)>ceiling.get('max_bytes',-1) or len(data)>MAX_BYTES):
                raise ValueError('create text ceiling')
            create_total+=len(data)
            creates.append({'path':path,'expected_digest':None,'content':hunk['content']})
        elif kind=='edit_text':
            ceiling=scope[path]
            if ceiling.get('kind')!='edit_text' or path not in files:
                raise ValueError('edit scope')
            data=files[path]
            if type(data) is not bytes or sha(data)!=hunk.get('expected_file_digest') or ceiling.get('file_digest')!=sha(data):
                raise ValueError('stale edit source')
            start,end=hunk.get('start_byte'),hunk.get('end_byte')
            if not boundary(data,start) or not boundary(data,end) or start>end or sha(data[start:end])!=hunk.get('before_digest'):
                raise ValueError('edit byte range')
            if type(hunk.get('replacement')) is not str:
                raise ValueError('edit replacement')
            edit_by_path.setdefault(path,[]).append(hunk)
        else:
            raise ValueError('unit kind')
    if create_total>retained.get('max_total_create_bytes',-1):
        raise ValueError('create total ceiling')
    edits=[]
    for path, path_hunks in sorted(edit_by_path.items()):
        data=files[path]
        cursor=0;chunks=[]
        for hunk in sorted(path_hunks,key=lambda row:(row['start_byte'],row['end_byte'])):
            if hunk['start_byte']<cursor:
                raise ValueError('overlapping selected edit hunks')
            chunks.extend((data[cursor:hunk['start_byte']],hunk['replacement'].encode('utf-8')))
            cursor=hunk['end_byte']
        result=b''.join([*chunks,data[cursor:]])
        if len(result)>MAX_BYTES:
            raise ValueError('edit result size')
        try:text=result.decode('utf-8','strict')
        except UnicodeDecodeError:raise ValueError('edit result UTF-8') from None
        edits.append({'path':path,'expected_digest':sha(data),'content':text})
    return sorted([*edits,*creates],key=lambda item:item['path'])


def decision_groups(retained, accepted_ids, rejected_ids):
    """A dependent group is either untouched, wholly accepted, or wholly rejected."""
    accepted, rejected = set(accepted_ids), set(rejected_ids)
    for group in retained.get('hunk_groups', []):
        members = set(group)
        if members.intersection(accepted | rejected) and not (members <= accepted or members <= rejected):
            raise ValueError('dependent hunk group must be accepted or rejected together')

def reconstruct(retained, expected_digest, current_binding, files, accepted_ids):
    """Construct exact selected files; caller must commit these in one CAS edit."""
    body = {k:v for k,v in retained.items() if k != 'digest'}
    if retained.get('digest') != expected_digest or sha(canonical(body)) != expected_digest:
        raise ValueError('proposal digest')
    if retained['binding'] != current_binding:
        raise ValueError('stale or foreign binding')
    if not accepted_ids or len(accepted_ids) != len(set(accepted_ids)):
        raise ValueError('selection count')
    known = {h['id']:h for h in retained['hunks']}
    if any(i not in known for i in accepted_ids):
        raise ValueError('unknown hunk')
    decision_groups(retained, accepted_ids, [])
    selected = [known[i] for i in accepted_ids]
    result = []
    for path in sorted({h['path'] for h in selected}):
        data = files.get(path)
        if type(data) is not bytes:
            raise ValueError('missing source')
        grouped = sorted((h for h in selected if h['path']==path),key=lambda h:h['start_byte'])
        if any(sha(data) != h['expected_file_digest'] for h in grouped):
            raise ValueError('stale file')
        chunks, offset = [], 0
        for h in grouped:
            chunks += [data[offset:h['start_byte']], h['replacement'].encode()]
            offset = h['end_byte']
        content = b''.join([*chunks,data[offset:]])
        if len(content) > MAX_BYTES:
            raise ValueError('result size')
        result.append({'path':path,'expected_digest':sha(data),'content':content.decode('utf-8')})
    return result
