"""r3.5 successor: history-relative acknowledgement (draft revision pending) only. No settlement POST, ledger or authority."""
import datetime
import hashlib
import json
import re

class WireError(ValueError):
    pass

def require(condition):
    if not condition:
        raise WireError('inconsistent settlement readback')

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')

def digest(body):
    return 'sha256:' + hashlib.sha256(canonical(body)).hexdigest()

def fields(value, names):
    require(type(value) is dict and set(value) == set(names.split()))

def integer(value, low, high):
    require(type(value) is int and low <= value <= high)

def pattern(value, regex):
    require(type(value) is str and re.fullmatch(regex, value) is not None)

def timestamp(value, milliseconds=True):
    pattern(value, '\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}' + ('\\.\\d{3}' if milliseconds else '(?:\\.\\d{1,6})?') + 'Z')
    try:
        datetime.datetime.fromisoformat(value[:-1] + '+00:00')
    except ValueError:
        raise WireError('invalid timestamp') from None

def body_state(body):
    fields(body, 'outcome run_id runtime cleanup evidence receipt_digest')
    require(body['outcome'] in ('completed', 'failed', 'cancelled', 'withdrawn', 'not_started', 'unknown'))
    fields(body['runtime'], 'seconds provenance')
    runtime = body['runtime']
    require(runtime['provenance'] in ('executor_measured', 'wall_clock_bound', 'unknown'))
    if runtime['provenance'] == 'unknown':
        require(runtime['seconds'] is None)
    else:
        integer(runtime['seconds'], 0, 86400)
    fields(body['cleanup'], 'descendants_stopped observed_at')
    cleanup = body['cleanup']
    require(type(cleanup['descendants_stopped']) is bool)
    if cleanup['observed_at'] is not None:
        timestamp(cleanup['observed_at'], milliseconds=False)
    require(not cleanup['descendants_stopped'] or cleanup['observed_at'] is not None)
    fields(body['evidence'], 'launch_record_state launch_record_rev')
    require(body['evidence']['launch_record_state'] in ('never_spawning', 'spawning', 'running', 'ended'))
    integer(body['evidence']['launch_record_rev'], 1, 2 ** 63 - 1)
    if body['receipt_digest'] is not None:
        pattern(body['receipt_digest'], 'sha256:[0-9a-f]{64}')
    if body['run_id'] is not None:
        pattern(body['run_id'], 'run_[A-Za-z0-9_-]+')
        if runtime['seconds'] is not None:
            require(runtime['seconds'] >= 1)
    elif body['outcome'] not in ('not_started', 'unknown'):
        require(False)
    if body['outcome'] == 'not_started':
        require(body['run_id'] is None and body['evidence']['launch_record_state'] == 'never_spawning')
        return 'released'
    if body['outcome'] == 'unknown' or not cleanup['descendants_stopped']:
        return 'unknown'
    return 'settled'

def readback(envelope, *, test_id, hold_id, request_id, launch_key, argv_digest, runtime_seconds):
    fields(envelope, 'hold observations')
    observations = envelope['observations']
    require(type(observations) is list and len(observations) <= 16)
    hold = envelope['hold']
    if hold is None:
        require(not observations)
        return None
    fields(hold, 'hold_id test_id request_id launch_key argv_digest runtime_seconds_max state run_id cleanup accounting charged_seconds overrun_seconds observation_count created_at settled_at')
    pattern(hold['hold_id'], 'ph_[0-9a-f]{24}')
    pattern(hold['test_id'], 'pt_[0-9a-f]{24}')
    pattern(hold['request_id'], 'rq_[A-Za-z0-9_-]+')
    pattern(hold['argv_digest'], 'sha256:[0-9a-f]{64}')
    require(hold['hold_id'] == hold_id and hold['test_id'] == test_id and (hold['request_id'] == request_id) and (hold['launch_key'] == launch_key) and (hold['argv_digest'] == argv_digest))
    integer(hold['runtime_seconds_max'], 1, 600)
    require(type(runtime_seconds) is int and hold['runtime_seconds_max'] == runtime_seconds)
    integer(hold['charged_seconds'], 0, 86400)
    integer(hold['overrun_seconds'], 0, 86400)
    integer(hold['observation_count'], 0, 16)
    require(hold['observation_count'] == len(observations))
    timestamp(hold['created_at'])
    terminal = hold['state'] in ('settled', 'released')
    if terminal:
        timestamp(hold['settled_at'])
    else:
        require(hold['settled_at'] is None)
    state = 'dispatched'
    immutable_run = None
    seen = set()
    for (seq, observation) in enumerate(observations, 1):
        fields(observation, 'seq body_digest body state_before state_after received_at')
        integer(observation['seq'], 1, 16)
        require(observation['seq'] == seq and observation['state_before'] == state)
        timestamp(observation['received_at'])
        body = observation['body']
        next_state = body_state(body)
        require(state in ('dispatched', 'unknown') and next_state == observation['state_after'])
        require(state != 'unknown' or next_state in ('unknown', 'settled'))
        require(observation['body_digest'] == digest(body) and observation['body_digest'] not in seen)
        seen.add(observation['body_digest'])
        if immutable_run is not None:
            require(body['run_id'] == immutable_run)
        elif body['run_id'] is not None:
            immutable_run = body['run_id']
        state = next_state
    require(sum((o['state_after'] == 'unknown' for o in observations)) <= 15)
    require(state == hold['state'] and hold['run_id'] == immutable_run)
    maximum = hold['runtime_seconds_max']
    if state in ('dispatched', 'unknown'):
        expected = ('unobserved', 'reserved_max', maximum, 0)
    elif state == 'released':
        expected = ('observed', 'none', 0, 0)
    else:
        runtime = observations[-1]['body']['runtime']
        seconds = runtime['seconds']
        expected = ('observed', 'reserved_max', maximum, 0) if seconds is None else ('observed', runtime['provenance'], seconds, max(0, seconds - maximum))
    require((hold['cleanup'], hold['accounting'], hold['charged_seconds'], hold['overrun_seconds']) == expected)
    return json.loads(canonical(envelope))

def acknowledgement(validated, body):
    """An original observation can be acknowledged and later superseded."""
    if validated is None:
        return dict(acknowledged=False, superseded=False, host_settled=False)
    body_state(body)
    matches = [o for o in validated['observations'] if o['body_digest'] == digest(body) and canonical(o['body']) == canonical(body)]
    acknowledged = bool(matches) and (body['run_id'] is None or validated['hold']['run_id'] == body['run_id'])
    return dict(acknowledged=acknowledged, superseded=acknowledged and matches[0]['seq'] < len(validated['observations']), host_settled=acknowledged and validated['hold']['state'] in ('settled', 'released'))

class Reader:
    """Reuse the service-authenticated bounded HostClient; GET only."""

    def __init__(self, host):
        self.host = host

    def get(self, expected):
        pattern(expected['test_id'], 'pt_[0-9a-f]{24}')
        pattern(expected['hold_id'], 'ph_[0-9a-f]{24}')
        envelope = self.host._call('GET', '/api/services/proposal-tests/' + expected['test_id'] + '/holds/' + expected['hold_id'])
        return readback(envelope, **expected)
