import pytest
from fastapi.testclient import TestClient

pytest_plugins = ['test_service']

from omegacode.api import create_app
from omegacode.common import CodeError
from test_service import service, principal, workspace


def body(ws, **updates):
    value = {'schema':'omegacode-suggestion-scope-request-v2', 'operation_id':'create-scope-v2',
             'expected_generation':ws['generation'], 'expected_tree_digest':ws['tree_digest'],
             'ranges':{}, 'create_files':{'src/main.py':{'max_bytes':4096}},
             'max_total_create_bytes':4096}
    value.update(updates)
    return value


def test_scope_v2_http_roundtrip_preserves_absence_receipt_and_replay(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    client = TestClient(create_app(service))
    headers = {'Authorization':'Bearer '+grant['token']}
    url = f"/v1/workspaces/{ws['id']}/suggestion-scopes"
    payload = body(ws)
    try:
        first = client.post(url, headers=headers, json=payload)
        assert first.status_code == 200, first.text
        receipt = first.json()
        assert receipt['schema'] == 'omegacode-suggestion-scope-v2'
        assert receipt['create_files'] == {'src/main.py':{'before':{'kind':'absent'},'max_bytes':4096}}
        assert receipt['ranges'] == {} and receipt['file_digests'] == {}
        assert receipt['max_total_create_bytes'] == 4096
        assert receipt['context_policy_digest'] and receipt['edit_authority'] is False
        assert receipt['destination_evaluation']=={'generation':ws['generation'],'tree_digest':ws['tree_digest'],
            'context_policy_digest':receipt['context_policy_digest'],
            'results':{'src/main.py':{'allowed':True,'reason':None}}}
        scope_id = receipt['id']
        read_back = client.get(f"{url}/{scope_id}",headers=headers)
        assert read_back.status_code == 200, read_back.text
        assert {k:v for k,v in read_back.json().items() if k != 'currency'} == receipt
        assert read_back.json()['currency'] == 'current'
        again = client.post(url+'?include_binding=false', headers=headers, json=payload)
        assert again.status_code == 200 and again.json() == receipt
        assert len(service.store.list('suggestion_scope')) == 1
        assert 'issuer_claims' not in first.text and grant['token'] not in first.text
    finally:
        client.close()


def test_scope_v2_rejects_existing_empty_file_and_mixed_path_union(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    with pytest.raises(CodeError) as existing:
        service.create_suggestion_scope(p, ws['id'], {
            'schema':'omegacode-suggestion-scope-request-v2','operation_id':'scope-empty-existing',
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'ranges':{},'create_files':{'calculator.py':{'max_bytes':1}},'max_total_create_bytes':1})
    assert existing.value.code in ('draft_file_exists','context_excluded')

    with pytest.raises(CodeError) as overlap:
        service.create_suggestion_scope(p, ws['id'], {
            'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'scope-overlap',
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'ranges':{'calculator.py':[[0,1]]},'create_files':{'calculator.py':{'max_bytes':1}},
            'max_total_create_bytes':1})
    assert overlap.value.code == 'suggestion_scope'


def test_scope_v2_explicit_exclusion_refuses_absent_destination(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    service.repositories['synthetic']['context_excluded_paths'] = ['src']
    with pytest.raises(CodeError) as refused:
        service.create_suggestion_scope(p, ws['id'], {
            'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'scope-excluded',
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'ranges':{},'create_files':{'src/main.py':{'max_bytes':10}},'max_total_create_bytes':10})
    assert refused.value.code == 'context_excluded'


def test_scope_v2_conflicting_replay_does_not_issue_another_ceiling(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    client = TestClient(create_app(service))
    headers = {'Authorization':'Bearer '+grant['token']}
    url = f"/v1/workspaces/{ws['id']}/suggestion-scopes"
    first_body = body(ws)
    try:
        first = client.post(url, headers=headers, json=first_body)
        assert first.status_code == 200, first.text
        changed = body(ws, create_files={'src/other.py':{'max_bytes':4096}})
        conflict = client.post(url, headers=headers, json=changed)
        assert conflict.status_code == 409, conflict.text
        assert len(service.store.list('suggestion_scope')) == 1
    finally:
        client.close()


def test_scope_v2_applies_saved_gitignore_to_absent_destination(service):
    p, _ = principal(service)
    service.repositories['synthetic']['context_gitignore_enabled'] = True
    ws = workspace(service, p)
    changed = service.edit(p, ws['id'], {
        'operation_id':'add-ignore-rule','expected_generation':ws['generation'],
        'expected_tree_digest':ws['tree_digest'],
        'edits':[{'path':'.gitignore','expected_digest':None,'content':'build/'}]})
    ws = changed['workspace']
    with pytest.raises(CodeError) as refused:
        service.create_suggestion_scope(p, ws['id'], {
            'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'ignored-destination',
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'ranges':{},'create_files':{'build/new.py':{'max_bytes':20}},'max_total_create_bytes':20})
    assert refused.value.code == 'context_excluded'


@pytest.mark.parametrize('field,value', [
    ('max_total_create_bytes', True),
    ('create_files', {'src/main.py':{'max_bytes':True}}),
])
def test_scope_v2_rejects_non_strict_numeric_wire_fields(service, field, value):
    p, grant = principal(service)
    ws = workspace(service, p)
    client = TestClient(create_app(service))
    payload = body(ws)
    payload[field] = value
    try:
        response = client.post(f"/v1/workspaces/{ws['id']}/suggestion-scopes",
                               headers={'Authorization':'Bearer '+grant['token']},json=payload)
        assert response.status_code == 422, response.text
    finally:
        client.close()
