"""Uninstalled test-scoped original result/output reader, no generic read grant."""
import base64, json, os, stat, time
from omegacode.common import canonical, digest, CodeError, MAX_LOG
from omegacode.proposal_launch_custody import Custody, execution_binding
from omegacode.proposal_launch_result import observe
from .launch_admission import scope_binding
from .proposal_host_wire import key, launch_binding, fail

def view(service, authority, principal, launch_key, after=0, limit=16384):
    if type(after) is not int or not 0 <= after <= MAX_LOG or type(limit) is not int or (not 1 <= limit <= 65536):
        fail('purpose_result_cursor')
    key(launch_key)
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    p = g['proposal_test']
    tid = p['test_id']
    authority.require_route(principal, 'GET', '/v1/proposal-tests/' + tid)
    id_ = 'pl_' + digest(canonical([tid, launch_key]))
    row = Custody(service.store).get(id_)
    saved = service.store.get('proposal_preparation', tid)
    if saved['binding'] != scope_binding(g):
        fail('purpose_result_scope')
    expected = launch_binding(g)
    for (name, value) in expected.items():
        if name == 'fork' and p['stage'] == 'prepare':
            continue
        if name == 'fork' and p['stage'] == 'result' and (value['workspace_id'] is None):
            continue
        if row['binding'].get(name) != value:
            fail('purpose_result_scope')
    native = execution_binding(service.store, row)
    run = service.store.get('run', row['run_id'])
    original = service.store.db.execute('SELECT body FROM grants WHERE id=?', (native['grant_id'],)).fetchone()
    if original is None:
        fail('purpose_result_original')
    original = json.loads(original[0])
    if scope_binding(original) != scope_binding(g) or (p.get('origin_grant_id') if p['stage'] == 'result' else g.get('grant_id')) != original.get('grant_id'):
        fail('purpose_result_original')
    observation = observe(service, id_)
    current = service.store.get('run', run['id'])
    retained = Custody(service.store).get(id_)
    page = dict(available=False, reason='original_output_unconfirmed', after=after, cursor=after, eof=False, data='', encoding='base64')
    if current.get('output_digest'):
        raw = service.store.read_blob(current['output_digest'], native['workspace_id'])
        if len(raw) > MAX_LOG:
            fail('purpose_result_output')
        size = len(raw)
        data = raw[after:after + limit]
        source = 'retained-original-output'
        whole = current['output_digest']
    elif observation.get('process_observation'):
        root = service.store.root / 'runs' / run['id']
        path = root / 'output.log'
        if root.is_symlink():
            fail('purpose_result_output')
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            fd = None
        except OSError:
            fail('purpose_result_output')
        if fd is not None:
            try:
                meta = os.fstat(fd)
                if not stat.S_ISREG(meta.st_mode) or meta.st_size > MAX_LOG:
                    fail('purpose_result_output')
                size = meta.st_size
                os.lseek(fd, after, os.SEEK_SET)
                data = os.read(fd, min(limit, max(0, size - after)))
            except OSError:
                fail('purpose_result_output')
            finally:
                os.close(fd)
            source = 'original-running-output-snapshot'
            whole = None
        else:
            size = None
    else:
        size = None
    if size is not None:
        if after > size:
            fail('purpose_result_cursor')
        page = dict(available=True, after=after, cursor=after + len(data), eof=after + len(data) == size, size_bytes=size, data=base64.b64encode(data).decode(), encoding='base64', segment_digest=digest(data), output_digest=whole, source=source)
    authority.require_route(principal, 'GET', '/v1/proposal-tests/' + tid)
    service._check_owner(required=True)
    if canonical(g) != claims or g['exp'] <= time.time() or service.store.get('proposal_preparation', tid) != saved or (Custody(service.store).get(id_) != retained) or (execution_binding(service.store, retained) != native):
        fail('purpose_result_changed')
    now = service.store.get('run', run['id'])
    if any((now[k] != current[k] for k in ['id', 'nonce', 'workspace_id', 'generation', 'tree_digest', 'grant_id', 'author'])):
        fail('purpose_result_changed')
    return dict(test_id=tid, launch_id=id_, launch_key=launch_key, run_id=run['id'], nonce=row['nonce'], observation=observation, output=page, authority_renewed=False, host_settled=False, source_accepted=False)
