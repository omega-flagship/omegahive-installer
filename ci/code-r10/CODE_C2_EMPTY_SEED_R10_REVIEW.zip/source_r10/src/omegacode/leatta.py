"""Identity of an explicitly enabled, self-contained LeaTTa interpreter binary."""
import hashlib
import pathlib
import re


def runtime_identity(config):
    root=pathlib.Path(config['root']).resolve()
    executable=pathlib.Path(config['executable']).absolute()
    wanted=config.get('executable_digest')
    if (executable.is_symlink() or not executable.resolve().is_relative_to(root)
            or not executable.is_file() or not 0<executable.stat().st_size<=128*1024*1024
            or not isinstance(wanted,str) or not re.fullmatch('[a-f0-9]{64}',wanted)):
        raise ValueError('LeaTTa requires a bounded executable within its configured root and exact binary digest')
    if hashlib.sha256(executable.read_bytes()).hexdigest()!=wanted:
        raise ValueError('LeaTTa executable differs from the configured digest')
    return {'executable':str(executable),'executable_digest':wanted,
            'protocol':'omegacode-leatta-file-v1','sandboxed':False,
            'semantic_equivalence':'unqualified','implementation_correspondence_proved':False,
            'dependency_scope':'binary bytes pinned; OS libraries and host correspondence unqualified'}
