"""Frozen, exact source review plans; selected spans never use fuzzy patching.

These are current-to-base/checkpoint source restores, not Git index staging.
Text groups retain three lines of context and LF byte boundaries. Large or
binary files are one explicit whole-file selection, with mode handled explicitly.
"""
import difflib

from .common import CodeError, canonical, digest

MAX_LINE_HUNKS = 1000
MAX_HUNKS = 10000


def lines(data):
    pieces = data.split(b'\n')
    return [piece+b'\n' for piece in pieces[:-1]] + ([pieces[-1]] if pieces[-1] else [])


def binary(data):
    if b'\x00' in data: return True
    try: data.decode('utf-8')
    except UnicodeDecodeError: return True
    return False


def plan(review_id, before, after, read):
    hunks = []
    for path in sorted(set(before) | set(after)):
        old, new = before.get(path), after.get(path)
        if old == new: continue
        source = read(old['digest']) if old else b''
        target = read(new['digest']) if new else b''
        a, b = lines(source), lines(target)
        def add(kind, **extra):
            item = {'path':path, 'kind':kind, 'before':old, 'after':new, **extra}
            item['id'] = 'h_' + digest(canonical({'review_id':review_id, **item}))
            hunks.append(item)
            if len(hunks) > MAX_HUNKS:
                raise CodeError(413,'review_limit','source review exceeds 10000 hunks')
        if old is None or new is None or binary(source) or binary(target) or max(len(a),len(b)) > MAX_LINE_HUNKS:
            add('file', reason='create' if old is None else 'delete' if new is None else 'binary' if binary(source) or binary(target) else 'large-file',
                source_bytes=len(source), target_bytes=len(target))
            continue
        if old['digest'] != new['digest']:
            for group in difflib.SequenceMatcher(None,a,b,autojunk=True).get_grouped_opcodes(3):
                add('text', before_start=group[0][1], before_end=group[-1][2],
                    after_start=group[0][3], after_end=group[-1][4],
                    source_bytes=len(b''.join(a[group[0][1]:group[-1][2]])),
                    target_bytes=len(b''.join(b[group[0][3]:group[-1][4]])))
        if old['executable'] != new['executable']:
            add('mode', source_bytes=0,target_bytes=0)
    return hunks


def side_bytes(hunk, side, read):
    entry = hunk[side]
    if entry is None or hunk['kind']=='mode': return b''
    data = read(entry['digest'])
    if hunk['kind']=='text':
        data = b''.join(lines(data)[hunk[side+'_start']:hunk[side+'_end']])
    return data


def selected_files(hunks, selected, before, after, read, blob):
    """Return a new manifest for the frozen selection, preserving all other files."""
    if not selected or len(selected) != len(set(selected)):
        raise CodeError(400,'review_selection','select nonempty unique hunk IDs')
    index = {h['id']:h for h in hunks}
    if not set(selected) <= set(index):
        raise CodeError(403,'review_selection','selected hunk is not in this review')
    groups = {}
    for id_ in selected:
        hunk=index[id_]; groups.setdefault(hunk['path'], []).append(hunk)
    files = dict(before)
    for path, group in groups.items():
        if any(h['kind']=='file' for h in group):
            if len(group)!=1: raise CodeError(409,'review_corrupt','whole-file hunk overlaps another hunk')
            entry=after.get(path)
            if entry is None: files.pop(path,None)
            else:
                data=read(entry['digest'])
                if len(data)!=entry['size']: raise CodeError(409,'review_corrupt','source size does not match review')
                files[path]=dict(entry)
            continue
        entry=dict(before[path])
        text_hunks=sorted((h for h in group if h['kind']=='text'),key=lambda h:h['before_start'])
        for a,b in zip(text_hunks,text_hunks[1:]):
            if a['before_end'] > b['before_start']:
                raise CodeError(409,'review_corrupt','selected source spans overlap')
        if text_hunks:
            source=lines(read(entry['digest']))
            for h in reversed(text_hunks):
                source[h['before_start']:h['before_end']]=lines(side_bytes(h,'after',read))
            content=b''.join(source)
            entry.update(digest=blob(content),size=len(content))
        if any(h['kind']=='mode' for h in group): entry['executable']=after[path]['executable']
        files[path]=entry
    return files,sorted(groups)
