// A deterministic work plan. Completion must come from execution/review, never from text equality.
export function briefPlan(transition){
 const delta=transition.delta,contextChanged=delta.purpose_changed||delta.audience_changed;
 const tasks=[{id:'reassess-work',action:'Reassess retained artwork and copy against the revised purpose and audience',depends_on:[],state:'pending',retained_source:true}];
 for(const criterion of transition.after.brief.criteria){
  const retained=delta.retained_criteria.includes(criterion);
  tasks.push({id:'criterion:'+encodeURIComponent(criterion),action:'Check and refine: '+criterion,criterion,depends_on:['reassess-work'],state:'pending',obligation:retained?'retained':'added',prior_result_transfer:false,context_changed:contextChanged});
 }
 tasks.push({id:'review-revision',action:'Review the revised output against every current obligation',depends_on:tasks.map(t=>t.id),state:'pending'});
 tasks.push({id:'project-adoption',action:'Receiving project decides whether to adopt the reviewed revision',depends_on:['review-revision'],state:'pending',authority:'receiving-project'});
 return {schema:'omega-brief-work-plan-1',tasks,retired_obligations:[...delta.removed_criteria],completion:'unverified',adopted:false};
}
