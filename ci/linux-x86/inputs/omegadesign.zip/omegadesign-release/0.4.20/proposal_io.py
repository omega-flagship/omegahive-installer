"""Read-only proposal snapshot through existing exact artifact custody.

Artifact read permission is not goal execution or continuing stream authority.
"""
import json
import re
from .studio_actions import read_source


def view_proposals(ctx, focus):
    ref = json.loads(focus.removeprefix('studio-proposals:'))
    raw = read_source(ctx, ref)
    if len(raw) > 128*1024:
        raise ValueError('Proposal snapshot exceeds limit')
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('Duplicate proposal field')
            out[key] = value
        return out
    snapshot = json.loads(raw, object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Nonfinite proposal')))
    # V2 extends the same exact read path. It never grants execution.
    if isinstance(snapshot, dict) and snapshot.get('schema') == 'omega-maker-revision-2':
        if len(raw.encode('utf-8') if isinstance(raw, str) else raw) > 32768:
            raise ValueError('Proposal revision exceeds 32 KiB')
        if set(snapshot) != {'schema', 'goal_id', 'scene_id', 'base', 'items'}:
            raise ValueError('Exact V2 proposal revision required')
        for key in ['goal_id', 'scene_id']:
            if not isinstance(snapshot[key], str) or not 0 < len(snapshot[key]) <= 128:
                raise ValueError('Exact proposal binding required')
        base = snapshot['base']
        if (not isinstance(base, dict) or set(base) != {'scene_id', 'revision', 'digest'}
                or base['scene_id'] != snapshot['scene_id']
                or type(base['revision']) is not int or not 1 <= base['revision'] <= 9007199254740991
                or not isinstance(base['digest'], str)
                or not re.fullmatch(r'sha256:[0-9a-f]{64}', base['digest'])):
            raise ValueError('Exact observed local piece reference required')
        items = snapshot['items']
        if not isinstance(items, list) or not 1 <= len(items) <= 16:
            raise ValueError('Bounded V2 proposal items required')
        seen = set()
        for item in items:
            if (not isinstance(item, dict) or set(item) != {'op_id', 'op', 'args'}
                    or not isinstance(item['op_id'], str)
                    or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,80}', item['op_id'])
                    or item['op_id'] in seen or not isinstance(item['op'], str)
                    or not 0 < len(item['op']) <= 80 or not isinstance(item['args'], dict)):
                raise ValueError('Exact V2 operation identity required')
            seen.add(item['op_id'])
        return {'revision': ref['digest'], 'items': [{'id': 'maker-proposals', 'kind': 'status',
                'label': 'Retained maker proposals; execution not admitted',
                'data': {'snapshot': snapshot, 'reference': ref, 'execution_admitted': False,
                         'proposal_revision': snapshot, 'event_identity': ref}}],
                'links': [], 'focus': 'maker-proposals'}
    proposal_revision = None
    if isinstance(snapshot, dict) and snapshot.get('schema') == 'omega-maker-revision-1':
        if set(snapshot) != {'schema','goal_id','scene_id','changes'}:
            raise ValueError('Exact proposal revision required')
        for key in ['goal_id','scene_id']:
            if not isinstance(snapshot[key], str) or not 0 < len(snapshot[key]) <= 128:
                raise ValueError('Exact proposal binding required')
        if not isinstance(snapshot['changes'], list) or not 0 < len(snapshot['changes']) <= 20:
            raise ValueError('Bounded proposal changes required')
        proposal_revision = snapshot
        # Compatibility presentation only: n comes from the custody-checked
        # artifact reference, never a producer-supplied sequence.
        snapshot = {'schema':'omega-maker-proposals-1',
                    'stream_id':ref['artifact_id'],'scene_id':snapshot['scene_id'],
                    'goal_id':snapshot['goal_id'],
                    'events':[{'stream_id':ref['artifact_id'],
                               'scene_id':snapshot['scene_id'],
                               'sequence':ref['revision'],
                               'changes':snapshot['changes']}]}
    if not isinstance(snapshot, dict) or set(snapshot) != {'schema','stream_id','scene_id','goal_id','events'} or snapshot['schema'] != 'omega-maker-proposals-1':
        raise ValueError('Exact proposal snapshot required')
    for key in ['stream_id','scene_id','goal_id']:
        if not isinstance(snapshot[key], str) or not 0 < len(snapshot[key]) <= 128:
            raise ValueError('Exact proposal binding required')
    events = snapshot['events']
    if not isinstance(events, list) or not 0 < len(events) <= 20:
        raise ValueError('Bounded proposal events required')
    previous = None
    for event in events:
        if not isinstance(event, dict) or set(event) != {'stream_id','scene_id','sequence','changes'} or event['stream_id'] != snapshot['stream_id'] or event['scene_id'] != snapshot['scene_id']:
            raise ValueError('Proposal event binding differs')
        sequence = event['sequence']
        if type(sequence) is not int or not 1 <= sequence <= 1000 or previous is not None and sequence != previous+1:
            raise ValueError('Ordered proposal sequence required')
        if not isinstance(event['changes'], list) or not 0 < len(event['changes']) <= 20:
            raise ValueError('Bounded proposal changes required')
        previous = sequence
    return {'revision':ref['digest'],'items':[{'id':'maker-proposals','kind':'status',
            'label':'Retained maker proposals; execution not admitted',
            'data':{'snapshot':snapshot,'reference':ref,'execution_admitted':False,
                    **({'proposal_revision':proposal_revision,'event_identity':ref} if proposal_revision is not None else {})}}],
            'links':[],'focus':'maker-proposals'}
