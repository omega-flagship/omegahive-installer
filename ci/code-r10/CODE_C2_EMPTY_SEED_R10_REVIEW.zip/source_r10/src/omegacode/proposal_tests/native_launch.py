"""Uninstalled owned purpose batch launch via existing runner/monitor; no API."""
from omegacode.common import canonical, CodeError
from omegacode.proposal_launch_custody import Custody
from .launch_preflight import _inspect

def launch(service, authority, principal, host, launch_id):
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + g['proposal_test']['test_id'] + '/launches')
    watcher = service._watcher
    watchdog = service._proposal_watchdog
    pool = service._proposal_status_pool

    def ready():
        service._check_owner(required=True)
        if service._stop.is_set() or watcher is None or (not watcher.is_alive()) or (watchdog is None) or (pool is None) or (service._watcher is not watcher) or (service._proposal_watchdog is not watchdog) or (service._proposal_status_pool is not pool):
            raise CodeError(503, 'purpose_monitor_required', 'existing owned monitor must be running')
    ready()
    service.bind_proposal_watchdog(launch_id, g)
    service._proposal_watchdog_guard(launch_id)
    ready()

    def commit():
        ready()
        if canonical(g) != claims:
            raise CodeError(409, 'purpose_executor_claims', 'original claims changed')
        return service._start_purpose_executor(launch_id, g)
    return _inspect(service, authority, principal, host, launch_id, _commit=commit)
