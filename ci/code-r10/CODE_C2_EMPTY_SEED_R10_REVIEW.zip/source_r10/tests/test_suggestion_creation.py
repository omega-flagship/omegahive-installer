import pytest

from omegacode.common import CodeError, digest
from omegacode.context_selection import select_destinations
from omegacode.suggestion_creation import path_union, validate_create_scope
from omegacode import context_selection


def allowed(paths):
    return {p: {'allowed': True, 'reason': None} for p in paths}


def test_v2_scope_keeps_absence_separate_from_empty_file_and_unions_paths():
    result = validate_create_scope(
        {'edit.py': {'digest': 'a' * 64, 'size': 1}},
        {'edit.py': [[0, 1]]},
        {'new.py': {'max_bytes': 0}},
        0,
        allowed(['new.py']),
    )
    assert result['paths'] == ('edit.py', 'new.py')
    assert result['create_files'] == {'new.py': {'before': {'kind': 'absent'}, 'max_bytes': 0}}
    assert 'digest' not in result['create_files']['new.py']['before']


def test_zero_length_existing_file_is_still_existing_and_cannot_be_created():
    with pytest.raises(CodeError) as refused:
        validate_create_scope({'empty.txt': {'digest': digest(b''), 'size': 0}}, {},
                              {'empty.txt': {'max_bytes': 10}}, 10, allowed(['empty.txt']))
    assert refused.value.code == 'draft_file_exists'


@pytest.mark.parametrize('create,ceiling,code', [
    ({'a.py': {'max_bytes': True}}, 1, 'suggestion_scope'),
    ({'a.py': {'max_bytes': 1}}, True, 'suggestion_scope'),
    ({'a.py': {'max_bytes': 2}, 'b.py': {'max_bytes': 2}}, 3, 'suggestion_scope'),
    ({'a.py': {'max_bytes': 2}}, 1, 'suggestion_scope'),
])
def test_strict_create_byte_ceilings(create, ceiling, code):
    with pytest.raises(CodeError) as refused:
        validate_create_scope({}, {}, create, ceiling, allowed(create))
    assert refused.value.code == code


def test_scope_requires_ranges_or_created_names_and_rejects_double_use():
    with pytest.raises(CodeError):
        path_union({}, {})
    with pytest.raises(CodeError) as refused:
        path_union({'same.py': []}, {'same.py': {'max_bytes': 1}})
    assert refused.value.code == 'suggestion_scope'


def test_scope_path_union_allows_100_but_not_101_paths():
    paths = {f'new/file-{i:03}.txt': {'max_bytes': 1} for i in range(100)}
    result = validate_create_scope({}, {}, paths, 100, allowed(paths))
    assert len(result['paths']) == 100
    with pytest.raises(CodeError):
        path_union({}, {**paths, 'new/file-100.txt': {'max_bytes': 1}})


def test_create_path_utf8_byte_limits_accept_exact_boundary_and_reject_overflow():
    exact_path = '/'.join(('a' * 250, 'b' * 249, 'c' * 249, 'd' * 249))
    assert len(exact_path.encode('utf-8')) == 1000
    valid_component = 'a' * 255
    assert len(valid_component.encode('utf-8')) == 255
    accepted = validate_create_scope({}, {}, {exact_path: {'max_bytes': 0}}, 0,
                                     allowed([exact_path]))
    assert accepted['paths'] == (exact_path,)
    accepted = validate_create_scope({}, {}, {valid_component: {'max_bytes': 0}}, 0,
                                     allowed([valid_component]))
    assert accepted['paths'] == (valid_component,)

    for too_long in (exact_path + 'x', 'a' * 256):
        with pytest.raises(CodeError) as refused:
            validate_create_scope({}, {}, {too_long: {'max_bytes': 0}}, 0,
                                  allowed([too_long]))
        assert refused.value.code == 'draft_file_path_limit'


@pytest.mark.parametrize('path', ['.GITIGNORE', 'src/.GitIgnore'])
def test_portable_gitignore_alias_cannot_be_created(path):
    with pytest.raises(CodeError) as refused:
        validate_create_scope({}, {}, {path: {'max_bytes': 10}}, 10, allowed([path]))
    assert refused.value.code == 'draft_policy'


def test_malformed_saved_namespace_fails_closed():
    with pytest.raises(CodeError) as refused:
        validate_create_scope({'bad\\name': {'digest': 'a' * 64, 'size': 1}}, {},
                              {'new.py': {'max_bytes': 1}}, 1, allowed(['new.py']))
    assert refused.value.code == 'invalid_path'


def test_scope_requires_current_destination_context_for_every_creation():
    with pytest.raises(CodeError) as refused:
        validate_create_scope({}, {}, {'private/new.py': {'max_bytes': 10}}, 10,
                              {'private/new.py': {'allowed': False, 'reason': 'explicit_exclusion'}})
    assert refused.value.code == 'context_excluded'
    with pytest.raises(CodeError):
        validate_create_scope({}, {}, {'new.py': {'max_bytes': 1}}, 1, {})


def test_destination_gitignore_checks_nonexistent_names_without_materializing_them(tmp_path, monkeypatch):
    rules = b'generated/\n'
    saved = b'print("source")\n'
    files = {
        '.gitignore': {'digest': digest(rules), 'size': len(rules)},
        'src/main.py': {'digest': digest(saved), 'size': len(saved)},
    }
    blobs = {digest(rules): rules, digest(saved): saved}
    observations = []
    real_run = context_selection.subprocess.run

    def inspect_run(argv, **kwargs):
        if 'check-ignore' in argv:
            cwd = kwargs['cwd']
            observations.append((cwd / 'generated/new.py').exists())
        return real_run(argv, **kwargs)

    monkeypatch.setattr(context_selection.subprocess, 'run', inspect_run)
    results, context = select_destinations(
        files, {'context_gitignore_enabled': True}, blobs.__getitem__, tmp_path,
        ['generated/new.py', 'src/new.py'],
    )
    assert results['generated/new.py'] == {'allowed': False, 'reason': 'gitignore'}
    assert results['src/new.py'] == {'allowed': True, 'reason': None}
    assert context['active'] is True
    assert observations == [False]
    assert list(tmp_path.iterdir()) == []


def test_destination_gitignore_matches_portable_alias(tmp_path):
    rules=b'private/\n'
    files={'.gitignore':{'digest':digest(rules),'size':len(rules)}}
    results,_=select_destinations(files,{'context_gitignore_enabled':True},lambda _:rules,tmp_path,
                                  ['PRIVATE/new.py'])
    assert results['PRIVATE/new.py']=={'allowed':False,'reason':'gitignore'}


def test_destination_gitignore_refuses_ignored_new_file_under_existing_directory(tmp_path):
    rules=b'docs/private/*\n'; data=b'existing'
    files={'.gitignore':{'digest':digest(rules),'size':len(rules)},
           'docs/private/kept.txt':{'digest':digest(data),'size':len(data)}}
    blobs={digest(rules):rules,digest(data):data}
    results,_=select_destinations(files,{'context_gitignore_enabled':True},blobs.__getitem__,tmp_path,
                                  ['docs/private/new.txt'])
    assert results['docs/private/new.txt']=={'allowed':False,'reason':'gitignore'}


def test_destination_explicit_exclusions_are_prefix_and_portable_alias_aware(tmp_path):
    results, _ = select_destinations(
        {}, {'context_excluded_paths': ['Private/Area']}, lambda _: b'', tmp_path,
        ['private/area/new.py', 'public/new.py'],
    )
    assert results['private/area/new.py'] == {'allowed': False, 'reason': 'explicit_exclusion'}
    assert results['public/new.py'] == {'allowed': True, 'reason': None}


def test_destination_policy_refuses_when_rule_source_is_outside_read_scope(tmp_path):
    rules = b'private/\n'
    files = {'.gitignore': {'digest': digest(rules), 'size': len(rules)}}
    with pytest.raises(CodeError) as refused:
        select_destinations(files, {'context_gitignore_enabled': True}, lambda _: rules, tmp_path,
                            ['src/new.py'], allowed=['src'])
    assert refused.value.code == 'context_scope'


def test_destination_matcher_or_rule_read_failure_fails_closed(tmp_path, monkeypatch):
    rules = b'private/\n'
    files = {'.gitignore': {'digest': digest(rules), 'size': len(rules)}}
    monkeypatch.setattr(context_selection.shutil, 'which', lambda *_args, **_kwargs: None)
    with pytest.raises(CodeError) as unavailable:
        select_destinations(files, {'context_gitignore_enabled': True}, lambda _: rules, tmp_path,
                            ['new.py'])
    assert unavailable.value.code == 'context_unavailable'
    with pytest.raises(CodeError) as bad_rules:
        select_destinations(files, {'context_gitignore_enabled': True}, lambda _: b'changed', tmp_path,
                            ['new.py'])
    assert bad_rules.value.code == 'context_rules'
