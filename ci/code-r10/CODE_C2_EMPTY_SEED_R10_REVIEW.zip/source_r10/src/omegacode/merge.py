"""Three-way saved-source merge. No repository/index/branch mutation."""
from __future__ import annotations

import os
import pathlib
import shutil
import subprocess
import tempfile
import time

from .common import CodeError, MAX_FILE


def combine(base, ours, incoming, read, put, scratch_root):
    """Freeze a clean candidate plus explicit whole-file conflicts.

    Content and executable mode merge independently. Lifecycle/binary conflicts
    remain unresolved; conflicting text includes Git's diff3 suggestion for review
    only. Markers are never silently applied as a resolved file.
    """
    rows = []
    deadline = time.monotonic() + 20
    git = shutil.which('git', path=os.defpath)
    with tempfile.TemporaryDirectory(prefix='merge-preview-', dir=scratch_root) as temp:
        root = pathlib.Path(temp)
        (root / 'home').mkdir()
        for path in sorted(set(base) | set(ours) | set(incoming)):
            b, o, t = base.get(path), ours.get(path), incoming.get(path)
            if o == t or t == b:
                merged, conflict, reason = o, False, None
            elif o == b:
                merged, conflict, reason = t, False, None
            elif not all((b, o, t)):
                merged, conflict, reason = None, True, 'file-lifecycle'
            else:
                # A mode-only change does not conflict with a content-only change.
                mode = t['executable'] if o['executable'] == b['executable'] else o['executable']
                bd, od, td = (e['digest'] for e in (b, o, t))
                if od == td or td == bd:
                    merged, conflict, reason = {**o, 'executable': mode}, False, None
                elif od == bd:
                    merged, conflict, reason = {**t, 'executable': mode}, False, None
                else:
                    data = [read(e['digest']) for e in (o, b, t)]
                    binary = any(b'\0' in d for d in data)
                    try:
                        for d in data: d.decode('utf-8')
                    except UnicodeDecodeError:
                        binary = True
                    if binary or any(len(d) > 256 * 1024 for d in data):
                        merged, conflict, reason = None, True, 'binary' if binary else 'text-merge-limit'
                    else:
                        if not git:
                            raise CodeError(503, 'merge_tool_unavailable', 'Git merge-file is unavailable')
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise CodeError(504, 'merge_timeout', 'merge preview exceeded total deadline')
                        for name, d in zip(('ours', 'base', 'incoming'), data):
                            (root / name).write_bytes(d)
                        try:
                            result = subprocess.run([git, '-c', 'core.hooksPath=/dev/null', 'merge-file',
                                '--stdout', '--diff3', '-L', 'ours', '-L', 'base', '-L', 'incoming',
                                '--', 'ours', 'base', 'incoming'], cwd=root,
                                capture_output=True, timeout=min(5, remaining), stdin=subprocess.DEVNULL,
                                env={'PATH': os.defpath, 'LANG': 'C.UTF-8', 'HOME': str(root / 'home'),
                                     'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': os.devnull,
                                     'GIT_CONFIG_SYSTEM': os.devnull})
                        except (OSError, subprocess.TimeoutExpired):
                            raise CodeError(504, 'merge_timeout', 'Git merge-file did not complete') from None
                        if result.returncode < 0 or result.returncode > 127:
                            raise CodeError(502, 'merge_tool_failed', 'Git merge-file failed')
                        if len(result.stdout) > MAX_FILE:
                            raise CodeError(413, 'merge_limit', 'merged file exceeds source limit')
                        merged = {'digest': put(result.stdout), 'size': len(result.stdout), 'executable': mode}
                        conflict = result.returncode != 0
                        reason = 'text-overlap' if conflict else None
            if o != merged or conflict:
                rows.append({'path': path, 'base': b, 'ours': o, 'incoming': t,
                             'merged': merged, 'conflict': conflict, 'reason': reason})
            if time.monotonic() >= deadline:
                raise CodeError(504, 'merge_timeout', 'merge preview exceeded total deadline')
    candidate = dict(ours)
    for row in rows:
        if not row['conflict']:
            if row['merged']: candidate[row['path']] = row['merged']
            else: candidate.pop(row['path'], None)
    folded = {}
    for path in candidate: folded.setdefault(path.casefold(), []).append(path)
    collisions = set()
    for paths in folded.values():
        if len(paths) > 1: collisions.update(paths)
    for path in candidate:
        parts = pathlib.PurePosixPath(path).parts
        for i in range(1, len(parts)):
            parent = '/'.join(parts[:i]).casefold()
            if parent in folded:
                collisions.update(folded[parent]); collisions.add(path)
    indexed = {r['path']: r for r in rows}
    for path in collisions:
        if path not in indexed:
            row = {'path': path, 'base': base.get(path), 'ours': ours.get(path),
                   'incoming': incoming.get(path), 'merged': candidate[path]}
            rows.append(row); indexed[path] = row
        indexed[path].update(conflict=True, reason='path-collision')
    return sorted(rows, key=lambda r: r['path'])
