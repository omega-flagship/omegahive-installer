"""Pure, bounded inspection of a retained cooperative symbolic transcript.

Callers must obtain these bytes/records through the existing workspace custody
and read/events authorization. Matching hashes here does not grant access or
authenticate stdout: a program can print protocol-shaped JSON. This module does
not import a runtime, execute, restore, replay, or claim current admission.
"""
from __future__ import annotations

import base64
import hashlib
import json
import math
import re


MAX_LOG = 4 * 1024 * 1024
MAX_CONTROLS = 1024
MAX_INPUT = 65536
MAX_FRAMES = 4096
MAX_TRACES = 32
PROTOCOL = 'omegacode-symbolic-jsonl-v1'
STEP_PROTOCOL = 'omegacode-hyperon-runner-step-v1'
COVERAGE_MEANING = ('recent successful materialized step-next inspection batches; '
                    'not advances, reductions or delivered output')
STEP_OPS = ('step-start', 'step-next', 'step-status', 'step-clear')
OBS_KEYS = {'input_sequence', 'step_count', 'status', 'results_digest', 'rendered_atoms_digest'}


class TraceReadError(ValueError):
    """The supplied evidence cannot support this reader's bounded schema."""

    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def _fail(code, message):
    raise TraceReadError(code, message)


def _bytes_digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _encoded(value):
    try:
        return json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError):
        _fail('invalid_json_value', 'evidence contains a non-JSON value')


def _digest(value):
    return _bytes_digest(_encoded(value))


def _unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            _fail('duplicate_json_key', 'duplicate JSON object keys are refused')
        value[key] = item
    return value


def _float(text):
    value = float(text)
    if not math.isfinite(value):
        _fail('invalid_json_number', 'nonfinite JSON numbers are refused')
    return value


def _constant(_):
    _fail('invalid_json_number', 'nonfinite JSON constants are refused')


def _json(raw, limit):
    if type(raw) is not bytes or not 0 < len(raw) <= limit:
        _fail('json_size', 'JSON bytes are absent or exceed the reader bound')
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=_unique,
                          parse_float=_float, parse_constant=_constant)
    except TraceReadError:
        raise
    except (ValueError, UnicodeError, RecursionError):
        _fail('invalid_json', 'evidence is not bounded valid UTF-8 JSON')


def _int(value, low=0, high=MAX_FRAMES):
    return type(value) is int and low <= value <= high


def _text(value, limit=160):
    if type(value) is not str or not 0 < len(value) <= limit:
        return False
    try:
        return len(value.encode('utf-8')) <= limit
    except UnicodeError:
        return False


def _hex(value):
    return type(value) is str and re.fullmatch('[a-f0-9]{64}', value) is not None


def _keys(value, required, optional=()):
    if type(value) is not dict or not set(required) <= value.keys() or set(value) - set(required) - set(optional):
        _fail('frame_schema', 'transcript object has missing or unknown fields')


def _context(run):
    if type(run) is not dict or any(not _text(run.get(k), 256) for k in ('id', 'workspace_id', 'nonce')):
        _fail('run_binding', 'run identity is missing or malformed')
    if (not _int(run.get('generation'), 1, 2**63-1) or not _hex(run.get('tree_digest'))
            or run.get('terminal') is not True or not _hex(run.get('evaluator_digest'))):
        _fail('run_binding', 'run is not a saved symbolic terminal generation')
    if run.get('status') in ('prepared', 'starting', 'running', 'cancel_requested'):
        _fail('run_not_final', 'historical inspection requires a terminal run record')
    if not _text(run.get('status'), 64) or type(run.get('descendants_terminated')) is not bool:
        _fail('run_binding', 'run termination metadata is malformed')
    session = run.get('symbolic_session')
    if (type(session) is not dict or session.get('protocol') != PROTOCOL
            or not _text(session.get('runtime_id')) or not _hex(session.get('identity_digest'))
            or not _hex(session.get('helper_digest'))
            or session.get('all_inputs_require_run_authority') is not True
            or session.get('sandboxed') is not False):
        _fail('symbolic_binding', 'saved symbolic helper/runtime binding is malformed')
    return {'run_id': run['id'], 'generation': run['generation'], 'tree_digest': run['tree_digest'],
            'runtime_identity_digest': session['identity_digest'], 'runtime': 'hyperon'}


def _inputs(controls, run):
    """Reassemble submitted bytes; control sequence is NOT worker sequence."""
    if type(controls) not in (list, tuple) or len(controls) > MAX_CONTROLS:
        _fail('control_limit', 'at most 1024 ordered stored controls are supported')
    stream, segments, ids = bytearray(), [], set()
    for sequence, record in enumerate(controls, 1):
        if (type(record) is not dict or not {'id', 'run_id', 'workspace_id', 'sequence', 'actor',
                'payload', 'kind', 'input_bytes', 'input_digest'} <= record.keys()
                or not _text(record.get('id')) or record['id'] in ids
                or type(record.get('sequence')) is not int or record['sequence'] != sequence
                or record.get('run_id') != run['id'] or record.get('workspace_id') != run['workspace_id']
                or not _text(record.get('actor'), 256) or type(record.get('payload')) is not dict):
            _fail('control_binding', 'stored controls need unique identity and contiguous run-bound sequence')
        ids.add(record['id'])
        payload = record['payload']
        if payload.get('kind') != record.get('kind'):
            _fail('control_binding', 'stored control kind differs from its payload')
        if record['kind'] == 'resize':
            if (type(record.get('input_bytes')) is not int or record['input_bytes'] != 0
                    or record.get('input_digest') is not None
                    or 'data_base64' in payload or any(not _int(payload.get(k), 1, 500) for k in ('rows', 'cols'))):
                _fail('control_binding', 'resize control is malformed')
            continue
        if record['kind'] != 'input' or any(k in payload for k in ('rows', 'cols')):
            _fail('control_binding', 'unknown or mixed stored terminal control')
        try:
            if type(payload.get('data_base64')) is not str or len(payload['data_base64']) > 10924:
                raise ValueError()
            data = base64.b64decode(payload['data_base64'], validate=True)
        except (ValueError, TypeError):
            _fail('control_binding', 'stored input is not valid base64')
        if (not 1 <= len(data) <= 8192 or type(record.get('input_bytes')) is not int
                or record['input_bytes'] != len(data) or record.get('input_digest') != _bytes_digest(data)):
            _fail('control_binding', 'stored input length or digest differs from submitted bytes')
        if len(stream) + len(data) > MAX_INPUT:
            _fail('input_limit', 'submitted input stream exceeds 65536 bytes')
        segments.append((len(stream), len(stream) + len(data), sequence))
        stream.extend(data)
    requests, offset = {}, 0
    while b'\n' in stream[offset:]:
        end = stream.index(b'\n', offset) + 1
        raw = bytes(stream[offset:end])
        if len(raw) > 8192 or len(requests) >= MAX_FRAMES:
            _fail('input_alignment_unknown', 'input framing exceeds the supported worker bounds')
        request = _json(raw, 8192)
        if type(request) is not dict:
            _fail('input_alignment_unknown', 'non-object input prevents supported command correlation')
        touched = [sequence for start, stop, sequence in segments if start < end and stop > offset]
        requests[len(requests)+1] = {'request': request, 'frame_digest': _bytes_digest(raw),
            'controls': {'first': touched[0], 'last': touched[-1]}}
        offset = end
    if len(stream) - offset > 8192:
        _fail('input_alignment_unknown', 'unterminated submitted input exceeds a worker frame')
    return requests, offset != len(stream)


def _trace_catalog(requests, context):
    catalog = {}
    for sequence, item in requests.items():
        request = item['request']
        source, budget = request.get('source'), request.get('max_steps', 10000)
        if (request.get('op') != 'step-start' or not _text(request.get('id'))
                or set(request) - {'id', 'op', 'source', 'max_steps'}
                or not _text(source, 7000) or not _int(budget, 1, 10000)):
            continue
        source_digest = _bytes_digest(source.encode('utf-8'))
        trace_id = 'step_' + _digest([context, source_digest, sequence])
        catalog[trace_id] = {'start_sequence': sequence, 'source_digest': source_digest, 'max_steps': budget}
    return catalog


def _coverage(value, rows):
    _keys(value, {'total_observations', 'retained_observations', 'dropped_observations', 'truncated',
                 'first_retained_input_sequence', 'first_retained_step_count', 'window_limit', 'coverage'})
    total, retained, dropped = (value.get(k) for k in ('total_observations', 'retained_observations', 'dropped_observations'))
    if (not all(_int(n) for n in (total, retained, dropped)) or retained != len(rows)
            or retained != min(total, 100)
            or dropped != total-retained or type(value['truncated']) is not bool
            or value['truncated'] != (dropped > 0) or type(value['window_limit']) is not int
            or value['window_limit'] != 100 or value['coverage'] != COVERAGE_MEANING
            or value['first_retained_input_sequence'] != (rows[0]['input_sequence'] if rows else None)
            or value['first_retained_step_count'] != (rows[0]['step_count'] if rows else None)):
        _fail('coverage_invalid', 'declared observation coverage is inconsistent')
    # Equality alone would accept booleans in integer cursor fields.
    if rows and (type(value['first_retained_input_sequence']) is not int
                 or type(value['first_retained_step_count']) is not int):
        _fail('coverage_invalid', 'coverage cursors must be actual integers')
    return value.copy()


def _trace_result(result, request, sequence, context, catalog, traces, observations, requests, reasons):
    required = {'trace_id', 'source_digest', 'context', 'step_count', 'max_steps', 'status', 'results',
        'observations', 'results_currency', 'last_observed_step', 'engine_api', 'substitutions_available',
        'grounded_call_trace_available', 'persistence', 'effects_reversed'}
    coverage_keys = {'observation_coverage', 'observation_total', 'observation_window_limit',
        'observation_dropped_prefix', 'first_retained_input_sequence', 'first_retained_step'}
    _keys(result, required, coverage_keys)
    trace_id = result['trace_id']
    saved = catalog.get(trace_id) if type(trace_id) is str else None
    if (saved is None or result['source_digest'] != saved['source_digest'] or _encoded(result['context']) != _encoded(context)
            or result['max_steps'] != saved['max_steps'] or type(result['max_steps']) is not int
            or not _int(result['step_count'], 0, saved['max_steps'])
            or saved['start_sequence'] > sequence
            or (request['op'] == 'step-start' and saved['start_sequence'] != sequence)
            or (request['op'] != 'step-start' and request.get('trace_id') != trace_id)):
        _fail('trace_binding', 'reported trace differs from saved context or submitted source')
    if (result['status'] not in ('paused', 'complete', 'budget-exhausted', 'faulted')
            or result['engine_api'] != 'hyperon.runner.RunnerState.run_step'
            or result['substitutions_available'] is not False or result['grounded_call_trace_available'] is not False
            or result['effects_reversed'] is not False
            or result['persistence'] != 'resident process only; no automatic replay'):
        _fail('trace_schema', 'reported trace capability metadata is unsupported')
    groups = result['results']
    if (type(groups) is not list or any(type(group) is not list or any(type(atom) is not str for atom in group)
                                      for group in groups) or len(_encoded(groups)) > 262144):
        _fail('trace_schema', 'reported result groups are malformed or oversized')
    rows = result['observations']
    if type(rows) is not list or len(rows) > 100:
        _fail('observation_schema', 'reported recent window exceeds 100 observations')
    prior_sequence, prior_steps = 0, 0
    for row in rows:
        _keys(row, OBS_KEYS)
        row_sequence, steps = row['input_sequence'], row['step_count']
        submitted = requests.get(row_sequence, {}).get('request', {}) if type(row_sequence) is int else {}
        if (not _int(row_sequence, saved['start_sequence']+1, sequence) or row_sequence <= prior_sequence
                or not _int(steps, prior_steps, result['step_count'])
                or row['status'] not in ('paused', 'complete', 'budget-exhausted')
                or not _hex(row['results_digest']) or not _hex(row['rendered_atoms_digest'])
                or submitted.get('op') != 'step-next' or submitted.get('trace_id') != trace_id):
            _fail('observation_binding', 'observation is not ordered or correlated to a submitted step-next')
        key = (trace_id, row_sequence)
        if key in observations and observations[key] != row:
            _fail('observation_conflict', 'one trace/input sequence reports conflicting observations')
        observations[key] = row.copy()
        prior_sequence, prior_steps = row_sequence, steps
    if (type(result['last_observed_step']) is not int
            or result['last_observed_step'] != (rows[-1]['step_count'] if rows else 0)
            or result['results_currency'] != ('last successful step batch' if rows else 'not yet observed')):
        _fail('observation_schema', 'reported last-successful observation metadata disagrees')
    if request['op'] == 'step-next' and (result['status'] == 'faulted' or not rows
                                        or rows[-1]['input_sequence'] != sequence):
        _fail('observation_binding', 'successful step-next response lacks its inspection sample')
    if request['op'] == 'step-next' and rows[-1]['status'] != result['status']:
        _fail('observation_binding', 'successful step-next sample differs from the reported status')
    if result['status'] == 'budget-exhausted' and result['step_count'] != saved['max_steps']:
        _fail('trace_schema', 'budget-exhausted trace is below its budget')
    if result['status'] != 'faulted' and rows and rows[-1]['step_count'] != result['step_count']:
        _fail('observation_binding', 'successful trace state differs from the latest reported sample')
    if rows and _digest(groups) != rows[-1]['results_digest']:
        reasons.add('results_not_bound_to_last_observation')
    if result['status'] == 'faulted':
        reasons.add('reported_trace_fault')
    coverage = None
    r13_coverage_fields = {'observation_total', 'observation_window_limit',
        'observation_dropped_prefix', 'first_retained_input_sequence', 'first_retained_step'}
    if 'observation_coverage' not in result and r13_coverage_fields.intersection(result):
        _fail('coverage_invalid', 'partial R13 observation coverage metadata is inconsistent')
    if 'observation_coverage' in result:
        reported = result['observation_coverage']
        if type(reported) is dict:
            # Retain compatibility with the earlier structured coverage shape.
            if r13_coverage_fields.intersection(result):
                _fail('coverage_invalid', 'structured and R13 observation coverage metadata are mixed')
            coverage = _coverage(reported, rows)
        else:
            if (type(reported) is not str or reported not in ('complete-history', 'recent-tail')
                    or not r13_coverage_fields <= set(result)):
                _fail('coverage_invalid', 'declared R13 observation coverage is incomplete')
            total = result['observation_total']
            dropped = result['observation_dropped_prefix']
            first_sequence = result['first_retained_input_sequence']
            first_step = result['first_retained_step']
            if (not _int(total) or not _int(dropped) or dropped != total - len(rows)
                    or len(rows) > 100 or result['observation_window_limit'] != 100
                    or type(result['observation_window_limit']) is not int
                    or reported != ('recent-tail' if dropped else 'complete-history')
                    or first_sequence != (rows[0]['input_sequence'] if rows else None)
                    or first_step != (rows[0]['step_count'] if rows else None)
                    or (rows and (type(first_sequence) is not int or type(first_step) is not int))):
                _fail('coverage_invalid', 'declared R13 observation coverage is inconsistent')
            coverage = {'total_observations': total, 'retained_observations': len(rows),
                'dropped_observations': dropped, 'truncated': dropped > 0,
                'first_retained_input_sequence': first_sequence, 'first_retained_step_count': first_step,
                'window_limit': 100, 'coverage': COVERAGE_MEANING}
    previous = traces.get(trace_id)
    if previous and previous['cleared_reported']:
        _fail('trace_order', 'a cleared trace cannot report another successful response')
    if previous and result['step_count'] < previous['reported_step_count']:
        _fail('trace_order', 'reported step count went backwards')
    if previous and previous['reported_coverage'] is not None and coverage is not None:
        if coverage['total_observations'] < previous['reported_coverage']['total_observations']:
            _fail('coverage_invalid', 'reported materialization count went backwards')
    if coverage is not None:
        if coverage['total_observations'] < sum(key[0] == trace_id for key in observations):
            _fail('coverage_invalid', 'reported total understates unique observations already inspected')
        possible = sum(item['request'].get('op') == 'step-next'
                       and item['request'].get('trace_id') == trace_id for n, item in requests.items() if n <= sequence)
        if coverage['total_observations'] > possible:
            _fail('coverage_invalid', 'reported samples exceed submitted step-next commands')
    else:
        reasons.add('legacy_observation_coverage_unknown')
    if trace_id not in traces and len(traces) >= MAX_TRACES:
        _fail('trace_limit', 'historical report supports at most 32 traces')
    traces[trace_id] = {'trace_id': trace_id, 'source_digest': saved['source_digest'],
        'start_input_sequence': saved['start_sequence'], 'reported_step_count': result['step_count'],
        'max_steps': saved['max_steps'], 'reported_status': result['status'],
        'reported_coverage': coverage, 'coverage_known': coverage is not None,
        'cleared_reported': previous['cleared_reported'] if previous else False}


def inspect_trace(output: bytes, run: dict, controls, receipt_bytes: bytes, *, after=0, limit=100):
    """Inspect immutable supplied evidence; page unique *reported* observations.

    Raises TraceReadError on corrupt bindings/unsupported schemas. Incompleteness
    is explicit, and no result authenticates the author of stdout or native work.
    Caller remains responsible for obtaining all inputs under existing authority.
    """
    if not _int(after, 0, MAX_FRAMES) or not _int(limit, 1, 100):
        _fail('report_cursor', 'report needs an observation offset and limit 1..100')
    context = _context(run)
    if type(output) is not bytes or not len(output) <= MAX_LOG:
        _fail('output_limit', 'output bytes exceed the retained-log bound')
    if not _hex(run.get('output_digest')) or run['output_digest'] != _bytes_digest(output):
        _fail('output_binding', 'output differs from the saved artifact digest')
    if (not _hex(run.get('receipt_digest')) or type(receipt_bytes) is not bytes
            or run['receipt_digest'] != _bytes_digest(receipt_bytes)):
        _fail('receipt_binding', 'receipt differs from the saved artifact digest')
    receipt = _json(receipt_bytes, 512*1024)
    if (type(receipt) is not dict or receipt.get('nonce') != run['nonce'] or receipt.get('run_id') != run['id']
            or receipt.get('terminal') is not True or type(receipt.get('descendants_terminated')) is not bool
            or type(receipt.get('output_bytes')) is not int or receipt['output_bytes'] != len(output)
            or not _text(receipt.get('status'), 64)):
        _fail('receipt_binding', 'receipt is not bound to this saved terminal output')
    requests, partial_input = _inputs(controls, run)
    consumed = receipt.get('terminal_controls')
    if type(consumed) is not list or len(consumed) > len(controls):
        _fail('receipt_controls', 'receipt consumed controls are malformed')
    for actual, saved in zip(consumed, controls):
        if type(actual) is not dict or _encoded(actual) != _encoded({k: saved[k] for k in
                ('id', 'sequence', 'kind', 'input_bytes', 'input_digest', 'actor')}):
            _fail('receipt_controls', 'receipt consumed prefix differs from stored controls')
    reasons = set()
    if partial_input: reasons.add('submitted_partial_frame')
    if len(consumed) != len(controls): reasons.add('submitted_controls_not_reported_consumed')
    if receipt['status'] != 'completed' or run['status'] != 'completed': reasons.add('run_not_reported_completed')
    if receipt['status'] == 'output_limit' or run['status'] == 'output_limit': reasons.add('output_limit')
    if len(output) == MAX_LOG: reasons.add('output_at_capture_limit')
    if run['descendants_terminated'] is not True or receipt['descendants_terminated'] is not True:
        reasons.add('termination_unconfirmed')
    catalog = _trace_catalog(requests, context)
    traces, observations, responses = {}, {}, set()
    ready, last_sequence = False, 0
    if output.count(b'\n') > MAX_FRAMES:
        _fail('frame_limit', 'transcript exceeds 4096 complete frames')
    lines = output.split(b'\n')
    if lines[-1]: reasons.add('partial_output_frame')
    lines = lines[:-1]
    if len(lines) > MAX_FRAMES:
        _fail('frame_limit', 'transcript exceeds 4096 complete frames')
    for line in lines:
        frame = _json(line, 65536)
        if type(frame) is not dict:
            _fail('frame_schema', 'transcript frame is not an object')
        if frame.get('event') == 'ready':
            _keys(frame, {'event', 'protocol', 'runtime', 'persistence', 'atom_count', 'context',
                          'snapshot_representation', 'step_protocol', 'step_commands'})
            if (ready or responses or frame['protocol'] != PROTOCOL or frame['runtime'] != 'hyperon'
                    or _encoded(frame['context']) != _encoded(context) or frame['step_protocol'] != STEP_PROTOCOL
                    or frame['step_commands'] != list(STEP_OPS)
                    or type(frame['atom_count']) is not int or frame['atom_count'] != 0
                    or frame['snapshot_representation'] != 'rendered-atom-multiset-v1'
                    or frame['persistence'] != 'resident process only; no automatic replay'):
                _fail('ready_binding', 'ready frame differs from the saved run context/protocol')
            ready = True
            continue
        if not ready:
            _fail('ready_missing', 'a supported ready frame must precede observations')
        if frame.get('event') not in ('result', 'error'):
            _fail('frame_schema', 'unsupported transcript event')
        sequence = frame.get('input_sequence')
        if not _int(sequence, 1, len(requests)) or sequence <= last_sequence:
            _fail('response_order', 'response is not an ordered submitted-input correlation')
        request = requests[sequence]['request']
        expected_id = request.get('id')
        if type(expected_id) is not str or len(expected_id) > 160: expected_id = None
        if frame.get('id') != expected_id:
            _fail('response_binding', 'response id differs from parsed submitted input')
        responses.add(sequence)
        last_sequence = sequence
        if frame['event'] == 'error':
            _keys(frame, {'event', 'id', 'reason', 'input_sequence', 'state_may_have_changed'})
            if type(frame['reason']) is not str or len(frame['reason']) > 2000 or frame['state_may_have_changed'] is not True:
                _fail('error_schema', 'error frame is malformed')
            reasons.add('reported_input_error_state_uncertain')
            continue
        _keys(frame, {'event', 'id', 'op', 'result', 'atom_count', 'input_sequence'})
        if (not _text(request.get('id')) or frame['op'] != request.get('op') or not _text(frame['op'], 64)
                or not _int(frame['atom_count'], 0, 2**63-1)):
            _fail('response_binding', 'response operation/count differs from submitted command')
        if frame['op'] in STEP_OPS:
            allowed = {'step-start': {'id', 'op', 'source', 'max_steps'},
                'step-next': {'id', 'op', 'trace_id', 'count'},
                'step-status': {'id', 'op', 'trace_id'}, 'step-clear': {'id', 'op', 'trace_id'}}
            if (set(request) - allowed[frame['op']] or not _text(request.get('id'))
                    or (frame['op'] == 'step-next' and not _int(request.get('count', 1), 1, 1000))):
                _fail('response_binding', 'successful step response has an invalid submitted command schema')
        elif frame['op'] not in ('eval', 'add', 'remove', 'query', 'atoms', 'close', 'snapshot',
                                 'snapshots', 'snapshot-atoms', 'snapshot-bytes', 'diff'):
            _fail('response_binding', 'successful response has an unknown command')
        if frame['op'] in STEP_OPS[:3]:
            _trace_result(frame['result'], request, sequence, context, catalog, traces, observations, requests, reasons)
        elif frame['op'] == 'step-clear':
            result = frame['result']
            _keys(result, {'trace_id', 'cleared', 'effects_reversed'})
            if (not _text(result['trace_id']) or result['trace_id'] != request.get('trace_id')
                    or result['trace_id'] not in traces
                    or result['cleared'] is not True or result['effects_reversed'] is not False):
                _fail('clear_binding', 'clear response lacks a previously observed trace binding')
            traces[result['trace_id']]['cleared_reported'] = True
    if not ready:
        _fail('ready_missing', 'no supported ready frame was retained')
    missing = sorted(requests.keys() - responses)
    if missing: reasons.add('submitted_inputs_without_response')
    if not traces: reasons.add('trace_not_observed')
    ordered = sorted(observations.items(), key=lambda pair: (pair[1]['input_sequence'], pair[0][0]))
    if after > len(ordered):
        _fail('report_cursor', 'observation offset exceeds inspected unique rows')
    page = []
    for (trace_id, sequence), row in ordered[after:after+limit]:
        item = requests[sequence]
        page.append({'trace_id': trace_id, **row, 'submitted_frame_digest': item['frame_digest'],
                     'submitted_control_range': item['controls']})
    report = {'protocol': 'omegacode-symbolic-historical-readback-v1',
        'scope': 'cooperative retained transcript; supplied artifact bindings; historical inspection only',
        'run_id': run['id'], 'workspace_id': run['workspace_id'], 'context': context,
        'output_digest': run['output_digest'], 'receipt_digest': run['receipt_digest'],
        'evaluator_digest': run['evaluator_digest'], 'helper_digest': run['symbolic_session']['helper_digest'],
        'runtime_id': run['symbolic_session']['runtime_id'],
        'submitted_controls_binding_digest': _digest([{k: record[k] for k in
            ('id', 'sequence', 'kind', 'input_bytes', 'input_digest', 'actor')} for record in controls]),
        'evidence_origin': 'caller-provided run/control/receipt/output; provenance unattested by this pure reader',
        'record_origin_authenticated': False, 'workspace_custody_checked_here': False,
        'supplied_content_hashes_match': True, 'authorization_checked_here': False,
        'stdout_author_authenticated': False, 'native_integrity_verified': False,
        'reductions_verified': False, 'execution_effects_verified': False, 'history_complete': False,
        'current_engine_admission_verified': False, 'engine_invoked_by_reader': False,
        'replay_performed': False, 'submitted_inputs': len(requests),
        'reported_consumed_controls': len(consumed), 'control_consumption_is_execution': False,
        'correlated_response_frames': len(responses), 'missing_response_count': len(missing),
        'first_missing_input_sequences': missing[:16], 'incomplete_reasons': sorted(reasons),
        'traces': list(traces.values()), 'observations': page, 'after': after,
        'next': after+len(page), 'eof': after+len(page) == len(ordered),
        'unique_reported_observations': len(ordered),
        'observation_meaning': 'deduplicated reported samples keyed by trace and input sequence; not reductions or advances'}
    if len(_encoded(report)) > 65536:
        _fail('report_limit', 'typed readback exceeds the 65536-byte response bound')
    return report
