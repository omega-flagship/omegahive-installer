"""Exact Model delivery custody, shared by source view, recovery and findings.

These checks confer no access: every byte comes from the existing context's
revision-bound read_asset. Native Model/GLB verification remains in the tool.
"""
import hashlib
import json
import re
from .protocol import revision_ref

FILES = ('editable-model.json', 'model.glb', 'manifest.json')
MIMES = ('application/json', 'model/gltf-binary', 'application/json')
CAPS = (1024 * 1024, 20 * 1024 * 1024, 32 * 1024)
PRECISION = 'Editable JSON numbers retained; delivered mesh attributes use glTF float32.'
SHA = re.compile(r'[0-9a-f]{64}\Z')
DIGEST = re.compile(r'sha256:[0-9a-f]{64}\Z')
ID = re.compile(r'[A-Za-z][A-Za-z0-9_-]{0,79}\Z')


def exact_ref(value):
    revision_ref(value)
    if (set(value) != {'artifact_id', 'revision', 'digest'}
            or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value['artifact_id'])
            or value['revision'] > 2 ** 53 - 1):
        raise ValueError('Exact Model source reference required')
    return value


def file_record(raw, mime):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'mime': mime, 'bytes': len(raw)}


def validate_delivery(delivery, assets):
    keys = {'schema', 'model_id', 'model_digest', 'metadata_digest', 'units',
            'object_ids', 'source_digest', 'files', 'precision', 'generator',
            'editable', 'adopted', 'independent_review'}
    if (not isinstance(delivery, dict) or set(delivery) != keys
            or delivery['schema'] != 'omega-model-delivery-1'
            or delivery['units'] != 'metres' or delivery['editable'] is not True
            or delivery['adopted'] is not False or delivery['independent_review'] is not False
            or delivery['precision'] != PRECISION
            or delivery['generator'] != {'library': 'three', 'version': '0.186.1', 'revision': '186', 'exporter': 'GLTFExporter'}):
        raise ValueError('Exact native Model delivery required')
    if (not isinstance(delivery['model_id'], str) or not ID.fullmatch(delivery['model_id'])
            or any(not isinstance(delivery[name], str) or not DIGEST.fullmatch(delivery[name])
                   for name in ('model_digest', 'metadata_digest', 'source_digest'))):
        raise ValueError('Model delivery identity differs')
    ids = delivery['object_ids']
    if (not isinstance(ids, list) or len(ids) > 100 or any(not isinstance(v, str) or not ID.fullmatch(v) for v in ids)
            or len(set(ids)) != len(ids)):
        raise ValueError('Model delivery object identities differ')
    if not isinstance(assets, list) or len(assets) != 3:
        raise ValueError('Three Model delivery assets required')
    for asset, mime, cap in zip(assets, MIMES, CAPS):
        if (not isinstance(asset, dict) or set(asset) != {'sha256', 'mime', 'bytes'}
                or not isinstance(asset['sha256'], str) or not SHA.fullmatch(asset['sha256'])
                or asset['mime'] != mime or type(asset['bytes']) is not int or not 1 <= asset['bytes'] <= cap):
            raise ValueError('Bounded Model asset metadata differs')
    expected = {name: {'digest': 'sha256:' + asset['sha256'], 'bytes': asset['bytes'], 'mime': asset['mime']}
                for name, asset in zip(FILES[:2], assets[:2])}
    if delivery['files'] != expected or delivery['source_digest'] != 'sha256:' + assets[0]['sha256']:
        raise ValueError('Model delivery files differ')
    return delivery


def delivery_manifest(manifest):
    keys = {'schema', 'source', 'goal_id', 'operation', 'action_record', 'params_digest',
            'assets', 'originals', 'previews', 'delivery', 'adopted'}
    if (not isinstance(manifest, dict) or set(manifest) != keys
            or manifest['schema'] != 'omega-model-artifact-1'
            or manifest['operation'] != 'model-glb' or manifest['adopted'] is not False):
        raise ValueError('Model artifact manifest differs')
    exact_ref(manifest['source'])
    if any(not isinstance(manifest[name], str) or not 1 <= len(manifest[name]) <= 128
           for name in ('goal_id', 'action_record')):
        raise ValueError('Model artifact action binding missing')
    if not isinstance(manifest['params_digest'], str) or not DIGEST.fullmatch(manifest['params_digest']):
        raise ValueError('Model artifact parameters binding missing')
    assets = manifest['assets']
    validate_delivery(manifest['delivery'], assets)
    if manifest['originals'] != [assets[0], assets[2]] or manifest['previews'] != []:
        raise ValueError('Model original source custody differs')
    return assets


def read_delivery(ctx, manifest, ref):
    """Return all three verified native assets; never accept caller byte witnesses."""
    exact_ref(ref)
    assets = delivery_manifest(manifest)
    outputs = {}
    for name, asset in zip(FILES, assets):
        record = ctx.read_asset(asset['sha256'], ref['artifact_id'], ref['revision'])
        raw = record.get('data') if isinstance(record, dict) else None
        if (not isinstance(raw, bytes) or len(raw) != asset['bytes']
                or record.get('bytes') != asset['bytes'] or record.get('mime') != asset['mime']
                or hashlib.sha256(raw).hexdigest() != asset['sha256']):
            raise ValueError('Exact Model delivery asset custody differs')
        outputs[name] = raw
    if json.loads(outputs['manifest.json'].decode('utf-8')) != manifest['delivery']:
        raise ValueError('Stored Model delivery declaration differs')
    source = json.loads(outputs['editable-model.json'].decode('utf-8'))
    document = source.get('document') if isinstance(source, dict) else None
    delivery = manifest['delivery']
    if (not isinstance(source, dict) or set(source) != {'schema', 'document', 'digest'}
            or source['schema'] != 'omega-model-source-1' or not isinstance(document, dict)
            or document.get('id') != delivery['model_id'] or document.get('units') != delivery['units']
            or source['digest'] != delivery['model_digest']
            or not isinstance(document.get('objects'), list)
            or [v.get('id') for v in document['objects'] if isinstance(v, dict)] != delivery['object_ids']):
        raise ValueError('Model original source binding differs')
    return outputs
