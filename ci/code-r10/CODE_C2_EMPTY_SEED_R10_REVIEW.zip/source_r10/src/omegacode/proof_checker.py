"""Single-module Lean checking under authorized trusted-native run authority.

Lean elaboration can execute native code. This worker is not an OS sandbox or
an attestation boundary against hostile source/runtime mutation.
"""
import hashlib
try:
    import resource
except ImportError:
    resource = None
import json
import os
import re
from pathlib import Path
import subprocess
import sys
import tempfile
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def runtime_identity(config):
    root = Path(config['root']).resolve()
    executable = Path(config['executable']).absolute()
    if (executable != root / 'bin/lean' or executable.is_symlink() or not executable.is_file()
            or executable.resolve() != executable or (root / 'lib').is_symlink()):
        raise ValueError('Lean executable must be bin/lean in the operator runtime')
    hashes, total = {}, 0
    for path in sorted((root / 'lib').rglob('*')):
        if not ('.olean' in path.name or path.suffix in ('.ir', '.so', '.dylib')):
            continue
        if path.is_symlink() or not path.is_file() or path.resolve() != path:
            raise ValueError('Lean runtime library must be an ordinary file')
        total += path.stat().st_size
        if len(hashes) >= 20000 or total > 6 * 1024**3:
            raise ValueError('Lean runtime identity budget exceeded')
        hashes[str(path.relative_to(root))] = sha(path.read_bytes())
    if 'lib/lean/Init.olean' not in hashes or 'lib/lean/Lean.olean' not in hashes:
        raise ValueError('Lean standard library unavailable')
    return {'root': str(root), 'executable': str(executable), 'runtime': 'lean',
            'executable_digest': sha(executable.read_bytes()), 'library_digest': sha(encoded(hashes)),
            'library_files': len(hashes), 'library_bytes': total,
            'identity_scope': 'Lean executable and lib *.olean*/*.ir/*.so/*.dylib; native host dependencies external'}


AUDIT = '''import Lean.Elab
import Lean.Util.CollectAxioms
import Submitted
open Lean Elab Command
elab "#omega_proof_audit" : command => do
  let env ← getEnv
  let some submitted := env.getModuleIdx? `Submitted | throwError "submitted module missing"
  let allowed := ["propext", "Classical.choice", "Quot.sound"]
  let mut count := 0
  let mut refused := 0
  for (name, info) in env.constants.toList do
    if env.getModuleIdxFor? name == some submitted then
      if info.isTheorem then
        let axioms ← collectAxioms name
        let names := axioms.toList.map Name.toString
        let row := Json.mkObj [("theorem", toJson name.toString),
          ("type_expression", toJson (toString info.type)), ("axioms", toJson names)]
        logInfo m!"OMEGA_PROOF_ROW {row.compress}"
        count := count + 1
        if names.any (fun n => !allowed.contains n) then refused := refused + 1
      else
        let axioms ← collectAxioms name
        let names := axioms.toList.map Name.toString
        let row := Json.mkObj [("declaration", toJson name.toString), ("axioms", toJson names)]
        logInfo m!"OMEGA_PROOF_DEPENDENCY_ROW {row.compress}"
        if names.any (fun n => !allowed.contains n) then refused := refused + 1
        if info matches .axiomInfo _ then
          logInfo m!"OMEGA_PROOF_LOCAL_AXIOM {name}"
          refused := refused + 1
  logInfo m!"OMEGA_PROOF_TOTAL {count}"
  if count == 0 || refused != 0 then throwError "proof audit refused: {count} theorems, {refused} forbidden dependencies"
#omega_proof_audit
'''


RUNTIME_AUDIT = 'import Lean.Util.CollectAxioms\nimport Lean.Data.Json\n\nopen Lean\n\ninstance : MonadEnv (StateT Environment IO) where\n  getEnv := get\n  modifyEnv := modify\n\ndef auditSelected (modules : List Name) : StateT Environment IO UInt32 := do\n  let env ← getEnv\n  let selected ← modules.mapM fun name => do\n    match env.getModuleIdx? name with\n    | some index => pure index\n    | none => throw <| IO.userError s!"selected module missing: {name}"\n  let allowed := ["propext", "Classical.choice", "Quot.sound"]\n  let mut count := 0\n  let mut refused := 0\n  for (name, info) in env.constants.toList do\n    if (env.getModuleIdxFor? name).any selected.contains then\n      let axioms ← collectAxioms name\n      let names := axioms.toList.map Name.toString\n      if info.isTheorem then\n        let row := Json.mkObj [("theorem", toJson name.toString),\n          ("type_expression", toJson (toString info.type)), ("axioms", toJson names)]\n        IO.println s!"OMEGA_PROOF_ROW {row.compress}"\n        count := count + 1\n      else\n        let row := Json.mkObj [("declaration", toJson name.toString), ("axioms", toJson names)]\n        IO.println s!"OMEGA_PROOF_DEPENDENCY_ROW {row.compress}"\n        if info matches .axiomInfo _ then\n          IO.println s!"OMEGA_PROOF_LOCAL_AXIOM {name}"\n          refused := refused + 1\n      if names.any (fun n => !allowed.contains n) then refused := refused + 1\n  IO.println s!"OMEGA_PROOF_TOTAL {count}"\n  if count == 0 || refused != 0 then\n    IO.println s!"proof audit refused: {count} theorems, {refused} forbidden dependencies"\n    return 1\n  return 0\n\nunsafe def main (args : List String) : IO UInt32 := do\n  if args.length < 3 then throw <| IO.userError "runtime root, search path and selected modules required"\n  initSearchPath args[0]! [args[1]!]\n  -- Same initializer prerequisite used by Lean\'s frontend. This is trusted-native\n  -- tooling, not a source sandbox; imported proofs still use trust level zero.\n  enableInitializersExecution\n  let modules := (args.drop 2).map String.toName\n  let env ← importModules (loadExts := true) (level := .private)\n    (modules.toArray.map fun name => { module := name }) {} 0\n  (auditSelected modules).run\' env\n'

def execute(argv, scratch, env, name, timeout, observations=None):
    """Retain stage timing even on refusal; metadata never changes proof classification."""
    log = scratch / (name + '.log')
    started = time.monotonic()
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN) if resource else None
    process, outcome = None, 'start_failed'
    try:
        with log.open('wb') as stream:
            process = subprocess.Popen(argv, cwd=scratch, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
            deadline = time.monotonic() + timeout
            outcome = 'interrupted'
            try:
                while process.poll() is None:
                    output_bytes = log.stat().st_size
                    if output_bytes > 262144:
                        outcome = 'output_budget_exhausted'
                        raise ValueError(f'proof stage {name} output budget exhausted: {output_bytes} bytes exceeds262144')
                    if time.monotonic() > deadline:
                        outcome = 'time_budget_exhausted'
                        raise ValueError(f'proof stage {name} time budget exhausted: limit{timeout}s, output{output_bytes}bytes')
                    time.sleep(.02)
            finally:
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)
        if log.stat().st_size > 262144:
            outcome = 'output_budget_exhausted'
            raise ValueError(f'proof stage {name} output budget exhausted: {log.stat().st_size} bytes exceeds262144')
        outcome = 'completed'
        return process.returncode, log.read_text(errors='replace')
    finally:
        if observations is not None:
            usage_after = resource.getrusage(resource.RUSAGE_CHILDREN) if resource else None
            cpu = max(0.0, usage_after.ru_utime + usage_after.ru_stime - usage_before.ru_utime - usage_before.ru_stime) if resource else None
            observations.append({'stage': name, 'outcome': outcome,
                'budget_seconds': timeout, 'elapsed_seconds': max(0.0, time.monotonic()-started),
                'cpu_seconds': cpu, 'cpu_scope': 'waited-checker-child-processes' if resource else 'unavailable',
                'output_bytes': log.stat().st_size if log.exists() else 0,
                'exit_code': process.returncode if process is not None else None,
                'process_reaped': process is not None and process.returncode is not None})


def project_manifest(paths, files):
    if (type(paths) is not list or not 1 <= len(paths) <= 32
            or any(type(path) is not str or not 1 <= len(path) <= 1000 for path in paths)
            or len({path.casefold() for path in paths}) != len(paths)):
        raise ValueError('project needs 1..32 unique saved module paths, in dependency order')
    result, total = [], 0
    for path in paths:
        if not path.endswith('.lean'):
            raise ValueError('project source must end in .lean')
        parts = path[:-5].split('/')
        if (any(not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', part) for part in parts)
                or parts[0].casefold() in {'init', 'lean', 'std', 'lake', 'audit', 'submitted'}):
            raise ValueError('project needs ASCII module paths outside reserved standard/checker namespaces')
        entry = files.get(path)
        if (not entry or type(entry.get('size')) is not int or not 0 <= entry['size'] <= 1048576
                or not re.fullmatch('[a-f0-9]{64}', str(entry.get('digest', '')))):
            raise ValueError('project source unavailable or exceeds one MiB')
        total += entry['size']
        if total > 8 * 1048576: raise ValueError('project source exceeds eight MiB')
        result.append({'path': path, 'module': '.'.join(parts), 'digest': entry['digest']})
    return result


def check_project(spec, observations=None):
    runtime = spec['runtime']
    if runtime_identity(runtime) != runtime: raise ValueError('Lean runtime changed after approval')
    root = Path(spec['project_root'])
    rows = spec['project_files']
    if sha(encoded(rows)) != spec['project_digest']: raise ValueError('project identity changed')
    # Reject path/module metadata before touching any selected source bytes.
    selected = {row['path']: {'size': 0, 'digest': row['digest']} for row in rows}
    if project_manifest([row['path'] for row in rows], selected) != rows:
        raise ValueError('invalid project module identity')
    contents, files = {}, {}
    for row in rows:
        path = root / row['path']
        if path.is_symlink() or path.resolve() != path or not path.is_file() or path.stat().st_size > 1048576:
            raise ValueError('project frozen source unavailable')
        raw = path.read_bytes(); raw.decode('utf-8')
        if sha(raw) != row['digest']: raise ValueError('project frozen source changed after approval')
        contents[row['path']] = raw; files[row['path']] = {'size': len(raw), 'digest': sha(raw)}
    if project_manifest([row['path'] for row in rows], files) != rows:
        raise ValueError('invalid project module identity')
    if rows[-1]['path'] != spec['context']['source_path'] or rows[-1]['digest'] != spec['source_digest']:
        raise ValueError('project entry must be the last submitted module')
    modules = [row['module'] for row in rows]
    base = {'protocol': 'omegacode-lean-project-check-v1', 'context': spec['context'],
            'source_digest': spec['source_digest'], 'runtime_identity_digest': sha(encoded(runtime)),
            'project_files': rows, 'project_digest': spec['project_digest'],
            'scope': 'all selected modules in declared dependency order; runtime library imports only',
            'allowed_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
            'implementation_correspondence_proved': False, 'sandboxed': False,
            'integrity_profile': 'cooperative trusted-native source and process', 'theorems': [],
            'declaration_dependencies': [], 'compile_stages': []}
    env = {'PATH': os.defpath, 'LANG': 'C.UTF-8', 'HOME': os.environ['HOME'],
           'TMPDIR': os.environ['TMPDIR'], 'LEAN_NUM_THREADS': '2'}
    with tempfile.TemporaryDirectory(prefix='lean-project-', dir=os.environ['TMPDIR']) as directory:
        scratch = Path(directory); env['LEAN_PATH'] = str(scratch)
        for path, raw in contents.items():
            target = scratch / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        (scratch / 'Audit.lean').write_text(RUNTIME_AUDIT)
        compile_exit, outputs = 0, []
        for i, row in enumerate(rows):
            target = str(Path(row['path']).with_suffix('.olean'))
            compile_exit, output = execute([runtime['executable'], '-o', target, row['path']], scratch, env, 'compile-' + str(i), 30, observations)
            base['compile_stages'].append({'path': row['path'], 'module': row['module'], 'exit_code': compile_exit})
            outputs.append(output[:1024])
            if compile_exit: break
        base.update(compile_exit=compile_exit, compile_output='\n'.join(outputs))
        if compile_exit:
            base.update(status='compile-failed', audit_exit=None)
        else:
            audit_exit, output = execute([runtime['executable'], '--run', 'Audit.lean', runtime['root'], str(scratch), *modules], scratch, env, 'audit', 30, observations)
            theorems = [json.loads(line.split('OMEGA_PROOF_ROW ', 1)[1]) for line in output.splitlines() if 'OMEGA_PROOF_ROW ' in line]
            dependencies = [json.loads(line.split('OMEGA_PROOF_DEPENDENCY_ROW ', 1)[1]) for line in output.splitlines() if 'OMEGA_PROOF_DEPENDENCY_ROW ' in line]
            if len(theorems) + len(dependencies) > 1000: raise ValueError('project audit exceeds 1000 declarations')
            base.update(audit_exit=audit_exit, theorems=theorems, declaration_dependencies=dependencies,
                        audit_output=output, status='checked' if audit_exit == 0 and theorems else 'audit-refused')
    for path, raw in contents.items():
        if (root / path).read_bytes() != raw: raise ValueError('project frozen source changed during checking')
    if runtime_identity(runtime) != runtime: raise ValueError('Lean runtime changed during checking')
    return {**base, 'scratch_removed': not scratch.exists(), **({'stage_observations': observations} if observations is not None else {})}


def check(spec, observations=None):
    runtime = spec['runtime']
    if runtime_identity(runtime) != runtime:
        raise ValueError('Lean runtime changed after approval')
    source = Path(spec['source_path'])
    if source.is_symlink() or not source.is_file() or source.stat().st_size > 1024**2:
        raise ValueError('proof source unavailable or exceeds one MiB')
    raw = source.read_bytes()
    if sha(raw) != spec['source_digest']:
        raise ValueError('proof input changed after approval')
    raw.decode('utf-8')
    env = {'PATH': os.defpath, 'LANG': 'C.UTF-8', 'HOME': os.environ['HOME'],
           'TMPDIR': os.environ['TMPDIR'], 'LEAN_NUM_THREADS': '2'}
    base = {'protocol': 'omegacode-lean-check-v1', 'context': spec['context'],
            'source_digest': spec['source_digest'], 'runtime_identity_digest': sha(encoded(runtime)),
            'scope': 'single submitted module; standard-library imports only',
            'allowed_axioms': ['propext', 'Classical.choice', 'Quot.sound'],
            'implementation_correspondence_proved': False, 'sandboxed': False,
            'integrity_profile': 'cooperative trusted-native source and process', 'theorems': []}
    with tempfile.TemporaryDirectory(prefix='lean-proof-', dir=os.environ['TMPDIR']) as scratch:
        scratch = Path(scratch)
        (scratch / 'Submitted.lean').write_bytes(raw)
        (scratch / 'Audit.lean').write_text(RUNTIME_AUDIT)
        env['LEAN_PATH'] = str(scratch)
        compile_exit, compile_output = execute(
            [runtime['executable'], '-o', 'Submitted.olean', 'Submitted.lean'], scratch, env, 'compile', 90, observations)
        base.update(compile_exit=compile_exit, compile_output=compile_output[:32768])
        if compile_exit != 0:
            base.update(status='compile-failed', audit_exit=None)
        else:
            audit_exit, output = execute([runtime['executable'], '--run', 'Audit.lean', runtime['root'], str(scratch), 'Submitted'], scratch, env, 'audit', 30, observations)
            rows = [json.loads(line.split('OMEGA_PROOF_ROW ', 1)[1]) for line in output.splitlines()
                    if 'OMEGA_PROOF_ROW ' in line]
            dependencies = [json.loads(line.split('OMEGA_PROOF_DEPENDENCY_ROW ', 1)[1])
                            for line in output.splitlines() if 'OMEGA_PROOF_DEPENDENCY_ROW ' in line]
            if len(rows) + len(dependencies) > 1000:
                raise ValueError('proof audit exceeds 1000 theorem declarations')
            base.update(audit_exit=audit_exit, theorems=rows, declaration_dependencies=dependencies, audit_output=output,
                        status='checked' if audit_exit == 0 and rows else 'audit-refused')
    if sha(source.read_bytes()) != spec['source_digest'] or runtime_identity(runtime) != runtime:
        raise ValueError('proof source or runtime changed during checking')
    return {**base, 'scratch_removed': not scratch.exists(), **({'stage_observations': observations} if observations is not None else {})}


def main():
    protocol = 'omegacode-lean-check-v1'
    observations = []
    try:
        spec = json.loads(Path(sys.argv[1]).read_text())
        if 'project_files' in spec:
            protocol = 'omegacode-lean-project-check-v1'
            result = check_project(spec, observations)
        else:
            result = check(spec, observations)
        print(encoded(result).decode(), flush=True)
        return 0 if result['status'] == 'checked' else 1
    except Exception as error:
        print(encoded({'protocol': protocol, 'status': 'unconfirmed',
                       'reason': str(error)[:1024], 'implementation_correspondence_proved': False,
                       'stage_observations': observations}).decode(), flush=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
