// Native deck verification for person-authored save-source. No effect authority.
import fs from 'node:fs/promises';
import {validateSceneDeck} from './scene-deck.mjs';
import {digest} from './scene.mjs';
try{
 const [input,...extra]=process.argv.slice(2);
 if(!input||extra.length)throw Error('One deck input path required');
 if((await fs.stat(input)).size>20*1024*1024)throw Error('Deck source exceeds 20 MB');
 const deck=validateSceneDeck(JSON.parse(await fs.readFile(input,'utf8')));
 console.log(JSON.stringify({schema:'omega-scene-deck-inspection-1',source_digest:await digest(deck),slides:deck.slides.map(slide=>({id:slide.id,criteria:slide.criteria})),adopted:false}));
}catch(error){console.error(JSON.stringify({error:error.message}));process.exitCode=1;}
