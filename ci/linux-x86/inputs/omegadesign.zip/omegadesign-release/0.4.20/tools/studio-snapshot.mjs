import {verifySource} from './source.mjs';
const names=['x','y','width','height','text','fontSize','color','weight','fill','alt'];
export async function verifyStudioSnapshot(input){
 if(input?.schema!=='omega-studio-draft-1'||Object.keys(input).some(k=>!['schema','source','fields'].includes(k)))throw Error('Unsupported Studio draft');
 const source=await verifySource(input.source),fields=input.fields;
 if(!fields||typeof fields.selected!=='string'||typeof fields.note!=='string'||fields.note.length>16000||!Array.isArray(fields.properties)||fields.properties.length!==names.length||!Array.isArray(fields.brief)||fields.brief.length!==4||fields.brief.some(x=>typeof x!=='string'||x.length>32000))throw Error('Invalid retained draft fields');
 const seen=new Set();
 for(const entry of fields.properties){if(!Array.isArray(entry)||entry.length!==2||!names.includes(entry[0])||seen.has(entry[0])||typeof entry[1]!=='string'||entry[1].length>32000)throw Error('Invalid retained property field');seen.add(entry[0]);}
 if(fields.selected&&!source.current.scene.elements.some(e=>e.id===fields.selected))throw Error('Draft selection differs from source');
 return {schema:input.schema,source,fields:structuredClone(fields)};
}
