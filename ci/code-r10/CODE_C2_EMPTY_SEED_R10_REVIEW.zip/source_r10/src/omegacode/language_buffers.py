"""Inert unsaved language views over already authorized saved UTF-8 sources."""
import re
import unicodedata
from .common import CodeError,MAX_FILE,MAX_TREE,SECRET_NAMES,canonical,digest,safe_path


def portable_path_alias(value):
    return unicodedata.normalize('NFD', value).casefold()


def overlay(files,texts,buffers,revision):
    if buffers is None:
        if revision is not None:raise CodeError(400,'buffer_shape','buffer revision requires a nonempty buffer view')
        return dict(files),dict(texts),None,{}
    if (type(buffers) is not dict or not 1<=len(buffers)<=16 or type(revision) is not str
            or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}',revision)):
        raise CodeError(400,'buffer_shape','bounded buffers and exact draft revision required')
    result=dict(files);contents=dict(texts);writes={};sources={}
    for path,row in buffers.items():
        if type(path) is not str or safe_path(path)!=path or type(row) is not dict or set(row)!={'content','saved_source_digest'}:
            raise CodeError(400,'buffer_shape','exact existing source path/content/digest required')
        if path not in files:raise CodeError(403,'context_excluded','buffer is outside authorized context')
        if path not in texts:raise CodeError(415,'binary_file','buffer baseline must be UTF-8 source')
        if row['saved_source_digest']!=files[path]['digest']:
            raise CodeError(409,'buffer_source_changed','buffer base does not match saved source')
        if type(row['content']) is not str or '\0' in row['content']:
            raise CodeError(400,'buffer_content','buffer requires UTF-8 text without NUL')
        try:data=row['content'].encode('utf-8')
        except UnicodeEncodeError:raise CodeError(400,'buffer_content','invalid UTF-8 buffer') from None
        if len(data)>MAX_FILE:raise CodeError(413,'buffer_limit','buffer exceeds source byte bound')
        sources[path]={'saved_source_digest':files[path]['digest'],'analyzed_source_digest':digest(data),'size':len(data)}
        result[path]={**files[path],'digest':digest(data),'size':len(data)}
        contents[path]=row['content'];writes[path]=data
    if sum(v['size'] for v in result.values())>MAX_TREE:raise CodeError(413,'buffer_limit','analyzed snapshot exceeds byte bound')
    view={'revision':revision,'sources':sources,'persisted':False,'effect':'language analysis only'}
    view['digest']=digest(canonical(view))
    return result,contents,view,writes


def validate_new_path_namespace(manifest, candidate_paths, extra_existing=(), *, max_paths=100):
    """Validate exact prospective files against the complete portable namespace.

    This is a name-only check: it creates no files and does not treat a missing
    path as an empty preimage. Callers still need context, scope and CAS checks.
    """
    if type(manifest) is not dict or type(max_paths) is not int or not 1 <= max_paths <= 1000:
        raise CodeError(400, 'draft_file_shape', 'saved manifest and bounded path limit required')
    try:
        candidates = list(candidate_paths)
        occupied_extra = list(extra_existing)
    except TypeError:
        raise CodeError(400, 'draft_file_shape', 'candidate and occupied paths must be iterable') from None
    if not candidates or len(candidates) > max_paths or any(type(path) is not str for path in candidates):
        raise CodeError(400, 'draft_file_shape', 'bounded distinct destination paths required')
    if len(set(candidates)) != len(candidates) or any(type(path) is not str for path in occupied_extra):
        raise CodeError(400, 'draft_file_shape', 'bounded distinct destination paths required')
    alias = portable_path_alias
    protected = {alias(name) for name in SECRET_NAMES}
    saved = set(manifest)
    if any(type(path) is not str for path in saved | set(occupied_extra)):
        raise CodeError(400, 'draft_file_shape', 'saved and occupied namespace paths must be strings')
    for path in saved | set(occupied_extra):
        if safe_path(path) != path:
            raise CodeError(400, 'draft_file_shape', 'saved and occupied namespace paths must be canonical')
    occupied = saved | set(occupied_extra)
    all_names = list(occupied) + candidates
    existing_directories = {}
    for saved_path in occupied:
        parts = saved_path.split('/')
        for index in range(1, len(parts)):
            directory = '/'.join(parts[:index])
            directory_alias = alias(directory)
            prior = existing_directories.get(directory_alias)
            if prior is not None and prior != directory:
                raise CodeError(409, 'draft_directory_alias',
                                'saved directories have ambiguous portable spellings')
            existing_directories[directory_alias] = directory
    for path in candidates:
        if type(path) is not str or safe_path(path) != path:
            raise CodeError(400, 'draft_file_shape', 'exact new path required')
        if any(ord(char) < 0x20 or ord(char) > 0x7e for char in path):
            raise CodeError(400, 'draft_file_path_ascii',
                            'new file and folder names must use basic keyboard characters for now')
        if len(path.encode('utf-8')) > 1000 or any(len(part.encode('utf-8')) > 255 for part in path.split('/')):
            raise CodeError(413, 'draft_file_path_limit', 'new draft path exceeds source path bounds')
        parts = path.split('/')
        for index in range(1, len(parts) + 1):
            prefix = '/'.join(parts[:index])
            existing = existing_directories.get(alias(prefix))
            if existing is not None and existing != prefix:
                raise CodeError(409, 'draft_directory_case',
                                'a folder with that name already exists with different spelling')
        parts = alias(path).split('/')
        if any(part == '.git' or part in protected or part.startswith('.env.') for part in parts):
            raise CodeError(403, 'protected_path', 'new draft path aliases a protected source path')
        if parts[-1] == alias('.gitignore'):
            raise CodeError(403, 'draft_policy', 'new draft cannot replace saved context policy')
        if path in occupied:
            raise CodeError(409, 'draft_file_exists', 'new draft must not replace a saved or buffered path')
        candidate_alias = alias(path)
        for other in all_names:
            if other == path:
                continue
            other_alias = alias(other)
            aliased = (candidate_alias == other_alias or candidate_alias.startswith(other_alias + '/') or
                       other_alias.startswith(candidate_alias + '/'))
            literal_prefix = other.startswith(path + '/') or path.startswith(other + '/')
            if aliased or literal_prefix:
                if literal_prefix:
                    raise CodeError(409, 'draft_file_conflict', 'draft file/directory paths conflict')
                raise CodeError(409, 'draft_file_alias', 'new draft path aliases an existing file or directory')
    return tuple(candidates)


def new_files(manifest, draft_files, buffers, revision):
    """Caller-owned new text descriptors; selection/authority remains with service."""
    if draft_files is None:return {},{},{}
    if (type(draft_files) is not dict or not 1<=len(draft_files)<=16
            or type(revision) is not str or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,120}',revision)
            or (buffers is not None and type(buffers) is not dict)
            or len(draft_files)+(len(buffers) if buffers else 0)>16):
        raise CodeError(400,'draft_file_shape','bounded new drafts and exact revision required')
    descriptors={};texts={};writes={}
    for path,row in draft_files.items():
        if type(path) is not str or safe_path(path)!=path or type(row) is not dict or set(row)!={'content'}:
            raise CodeError(400,'draft_file_shape','exact new path/content required')
    validate_new_path_namespace(manifest, draft_files, buffers.keys() if buffers else (), max_paths=16)
    for path,row in draft_files.items():
        if type(row['content']) is not str or '\0' in row['content']:
            raise CodeError(400,'draft_file_content','new draft requires UTF-8 text without NUL')
        try:data=row['content'].encode('utf-8')
        except UnicodeEncodeError:raise CodeError(400,'draft_file_content','invalid UTF-8 draft') from None
        if len(data)>MAX_FILE:raise CodeError(413,'draft_file_limit','new draft exceeds source byte bound')
        descriptors[path]={'digest':digest(data),'size':len(data)};texts[path]=row['content'];writes[path]=data
    return descriptors,texts,writes


def new_view(files,texts,buffers,revision,new_texts,new_writes):
    result,contents,view,writes=overlay(files,texts,buffers,revision if buffers is not None or not new_texts else None)
    if sum(v['size'] for v in result.values())>MAX_TREE:raise CodeError(413,'buffer_limit','analyzed snapshot exceeds byte bound')
    if not new_texts:return result,contents,view,writes
    if not new_texts.keys()<=files.keys():raise CodeError(403,'context_excluded','new draft is outside selected context')
    contents.update(new_texts);writes.update(new_writes)
    sources=dict(view['sources']) if view else {}
    for path,data in new_writes.items():
        sources[path]={'saved_source_digest':None,'analyzed_source_digest':digest(data),'size':len(data),'origin':'new-draft'}
    view={'revision':revision,'sources':sources,'persisted':False,'effect':'language analysis only'}
    view['digest']=digest(canonical(view))
    return result,contents,view,writes
