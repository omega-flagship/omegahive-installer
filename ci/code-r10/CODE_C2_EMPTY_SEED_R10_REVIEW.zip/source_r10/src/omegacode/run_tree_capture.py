"""Bounded POSIX output-tree capture; caller supplies lifecycle and authority checks.

The caller owns the root and must prove the run has stopped before capture.
Two matching observations are not an atomic filesystem snapshot or containment.
No following symlinks, hard-linked files, special nodes or protected paths.
"""
import hashlib
import os
import stat
import time
from .common import MAX_FILE, MAX_FILES, MAX_TREE, CodeError, canonical, safe_path


def _identity(meta):
    return (meta.st_dev, meta.st_ino, meta.st_mode, meta.st_nlink,
            meta.st_size, meta.st_mtime_ns, meta.st_ctime_ns)


def _read_file(parent, name, observed):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    try:
        first = os.fstat(fd)
        if not stat.S_ISREG(first.st_mode) or first.st_nlink != 1:
            raise ValueError('regular singly-linked files required')
        if _identity(first) != _identity(observed) or first.st_size > MAX_FILE:
            raise ValueError('file changed or exceeds bound')
        chunks, size = [], 0
        while True:
            chunk = os.read(fd, min(65536, MAX_FILE + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > MAX_FILE:
                raise ValueError('file byte bound')
        if _identity(first) != _identity(os.fstat(fd)) or size != first.st_size:
            raise ValueError('file changed while reading')
        return b''.join(chunks)
    finally:
        os.close(fd)


def _observe(root, deadline):
    files, bodies, identities, folded = {}, {}, {}, set()
    nodes, total = 0, 0
    root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        root_identity = _identity(os.fstat(root_fd))

        def visit(fd, prefix, depth):
            nonlocal nodes, total
            if depth > 64 or time.monotonic() > deadline:
                raise ValueError('capture depth or deadline bound')
            initial = os.fstat(fd)
            names = []
            with os.scandir(fd) as entries:
                for entry in entries:
                    nodes += 1
                    if nodes > 4000:
                        raise ValueError('capture node bound')
                    names.append(entry.name)
            for name in sorted(names):
                if time.monotonic() > deadline:
                    raise ValueError('capture deadline bound')
                path = safe_path(prefix + name)
                if len(path.encode('utf-8')) > 4096 or path.casefold() in folded:
                    raise ValueError('path bound or case collision')
                folded.add(path.casefold())
                meta = os.stat(name, dir_fd=fd, follow_symlinks=False)
                identities[path] = _identity(meta)
                if stat.S_ISDIR(meta.st_mode):
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    try:
                        if _identity(os.fstat(child)) != _identity(meta):
                            raise ValueError('directory changed before opening')
                        visit(child, path + '/', depth + 1)
                    finally:
                        os.close(child)
                elif stat.S_ISREG(meta.st_mode):
                    if len(files) >= MAX_FILES or meta.st_size > MAX_FILE or total + meta.st_size > MAX_TREE:
                        raise ValueError('capture file or aggregate byte bound')
                    data = _read_file(fd, name, meta)
                    total += len(data)
                    files[path] = dict(digest=hashlib.sha256(data).hexdigest(), size=len(data),
                                       executable=bool(meta.st_mode & 0o111))
                    bodies[path] = data
                else:
                    raise ValueError('symlink or special node refused')
                if _identity(os.stat(name, dir_fd=fd, follow_symlinks=False)) != _identity(meta):
                    raise ValueError('entry changed during capture')
            if _identity(os.fstat(fd)) != _identity(initial):
                raise ValueError('directory changed during capture')

        visit(root_fd, '', 0)
        if _identity(os.stat(root, follow_symlinks=False)) != root_identity:
            raise ValueError('root binding changed')
        return files, bodies, identities, root_identity
    finally:
        os.close(root_fd)


def capture(root):
    """Return bytes and metadata only after two bounded matching observations."""
    deadline = time.monotonic() + 5
    first = _observe(root, deadline)
    second = _observe(root, deadline)
    if first[0] != second[0] or first[2:] != second[2:]:
        raise ValueError('tree changed between observations')
    files, bodies = first[:2]
    manifest = {'files': dict(sorted(files.items()))}
    return {'manifest': manifest, 'tree_digest': hashlib.sha256(canonical(manifest)).hexdigest(),
            'bodies': bodies, 'matching_observations': 2, 'atomic_snapshot': False,
            'effect_authority': False}


def changes(base, captured):
    """Compare trusted manifest metadata; no rename inference or mutation."""
    old, new = base['files'], captured['manifest']['files']
    return [{'path': path, 'kind': 'added' if path not in old else 'deleted' if path not in new else 'modified',
             'before': old.get(path), 'after': new.get(path)}
            for path in sorted(old.keys() | new.keys()) if old.get(path) != new.get(path)]
