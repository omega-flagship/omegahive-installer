import pytest
import json
from fastapi.testclient import TestClient

pytest_plugins = ['test_service']

from omegacode.api import create_app
from omegacode.common import CodeError, digest
from test_service import service, principal, workspace


def scope_request(ws, *, ranges=None, create_files=None, total=4096, operation='scope-v2'):
    return {'schema':'omegacode-suggestion-scope-request-v2','operation_id':operation,
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'ranges':ranges or {},'create_files':create_files or {'src/main.py':{'max_bytes':4096}},
            'max_total_create_bytes':total}


def test_http_v2_proposal_retains_exact_absent_file_without_writing_it(service):
    p, grant = principal(service)
    ws = workspace(service,p)
    client = TestClient(create_app(service))
    headers={'Authorization':'Bearer '+grant['token']}
    base=f"/v1/workspaces/{ws['id']}"
    try:
        issued=client.post(base+'/suggestion-scopes',headers=headers,json=scope_request(ws))
        assert issued.status_code==200,issued.text
        response=client.post(base+'/suggestions',headers=headers,json={
            'schema':'omegacode-suggestion-request-v2','operation_id':'proposal-v2',
            'scope_id':issued.json()['id'],'hunks':[{'kind':'create_text','path':'src/main.py','content':'print("hello")\n'}]})
        assert response.status_code==200,response.text
        record=response.json()
        retained=service.suggestion(p,ws['id'],record['id'])['content']
        unit=retained['hunks'][0]
        assert retained['schema']=='omegacode-scoped-suggestion-v2'
        assert unit['kind']=='create_text' and unit['before']=={'kind':'absent'}
        assert unit['content']=='print("hello")\n'
        assert unit['content_bytes']==len(unit['content'].encode())
        assert unit['content_digest']==digest(unit['content'].encode())
        assert retained['scope']['src/main.py']=={'kind':'create_text','before':{'kind':'absent'},'max_bytes':4096}
        assert retained['scope_digest']==issued.json()['digest']
        assert 'src/main.py' not in service.manifest(ws)['files']
        before=client.get(f"{base}/suggestions/{record['id']}/hunks/{unit['id']}/before",headers=headers)
        assert before.status_code==200,before.text
        assert before.json()['schema']=='omegacode-suggestion-before-v2'
        assert before.json()['before']=={'kind':'absent'} and before.json()['edit_authority'] is False
        schema=client.get('/openapi.json').json()
        response_schema=schema['paths']['/v1/workspaces/{id}/suggestions/{suggestion_id}/hunks/{hunk_id}/before']['get']['responses']['200']['content']['application/json']['schema']
        refs={item.get('$ref','').rsplit('/',1)[-1] for item in response_schema.get('anyOf',[])}
        assert refs=={'SuggestionBeforePage','SuggestionCreatedBefore'}
    finally:
        client.close()


def test_proposal_can_use_subset_of_exact_person_ceilings(service):
    p, grant=principal(service)
    ws=workspace(service,p)
    client=TestClient(create_app(service));headers={'Authorization':'Bearer '+grant['token']}
    base=f"/v1/workspaces/{ws['id']}"
    try:
        issued=client.post(base+'/suggestion-scopes',headers=headers,json=scope_request(
            ws,create_files={'src/main.py':{'max_bytes':100},'src/unused.py':{'max_bytes':100}},total=200))
        assert issued.status_code==200,issued.text
        response=client.post(base+'/suggestions',headers=headers,json={
            'schema':'omegacode-suggestion-request-v2','operation_id':'subset-proposal',
            'scope_id':issued.json()['id'],'hunks':[{'kind':'create_text','path':'src/main.py','content':'x'}]})
        assert response.status_code==200,response.text
        assert len(service.suggestion(p,ws['id'],response.json()['id'])['content']['hunks'])==1
    finally:
        client.close()


def test_mixed_edit_and_create_group_is_bound_to_exact_paths(service):
    p, grant=principal(service)
    ws=workspace(service,p)
    raw=service.read(p,ws['id'],'calculator.py')['content'].encode()
    position=raw.index(b'-')
    client=TestClient(create_app(service));headers={'Authorization':'Bearer '+grant['token']}
    base=f"/v1/workspaces/{ws['id']}"
    try:
        issued=client.post(base+'/suggestion-scopes',headers=headers,json=scope_request(
            ws,ranges={'calculator.py':[[0,len(raw)]]},
            create_files={'src/main.py':{'max_bytes':100}},total=100))
        assert issued.status_code==200,issued.text
        response=client.post(base+'/suggestions',headers=headers,json={
            'schema':'omegacode-suggestion-request-v2','operation_id':'mixed-proposal',
            'scope_id':issued.json()['id'],'hunks':[
                {'kind':'edit_text','path':'calculator.py','start_byte':position,'end_byte':position+1,
                 'replacement':'+','before_digest':digest(b'-')},
                {'kind':'create_text','path':'src/main.py','content':'app = True\n'}],
            'groups':[[0,1]]})
        assert response.status_code==200,response.text
        retained=service.suggestion(p,ws['id'],response.json()['id'])['content']
        assert {unit['kind'] for unit in retained['hunks']}=={'edit_text','create_text'}
        assert retained['hunk_groups']==[sorted(unit['id'] for unit in retained['hunks'])]
    finally:
        client.close()


@pytest.mark.parametrize('content,refused', [('too long',True), ('x',False)])
def test_create_proposal_enforces_per_file_byte_ceiling(service,content,refused):
    p,_=principal(service);ws=workspace(service,p)
    scope=service.create_suggestion_scope(p,ws['id'],{
        'schema_marker':'omegacode-suggestion-scope-request-v2','operation_id':'small-ceiling',
        'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
        'ranges':{},'create_files':{'src/main.py':{'max_bytes':1}},'max_total_create_bytes':1})
    payload={'schema_marker':'omegacode-suggestion-request-v2','operation_id':'small-proposal',
             'scope_id':scope['id'],'hunks':[{'kind':'create_text','path':'src/main.py','content':content}]}
    if refused:
        with pytest.raises(CodeError) as error:service.create_suggestion(p,ws['id'],payload)
        assert error.value.code=='suggestion_refused'
    else:
        created=service.create_suggestion(p,ws['id'],payload)
        retained=service.suggestion(p,ws['id'],created['id'])['content']
        assert retained['hunks'][0]['content_bytes']==1


def test_v2_text_encoding_refuses_nul_and_unpaired_surrogate_but_preserves_utf8(service):
    p,grant=principal(service);ws=workspace(service,p)
    client=TestClient(create_app(service));headers={'Authorization':'Bearer '+grant['token']}
    base=f"/v1/workspaces/{ws['id']}"
    try:
        issued=client.post(base+'/suggestion-scopes',headers=headers,json=scope_request(ws))
        assert issued.status_code==200,issued.text
        scope_id=issued.json()['id']
        for index,content in enumerate(('bad\0text','bad\ud800text')):
            payload={'schema':'omegacode-suggestion-request-v2','operation_id':f'invalid-text-{index}',
                'scope_id':scope_id,'hunks':[{'kind':'create_text','path':'src/main.py','content':content}]}
            response=client.post(base+'/suggestions',headers={**headers,'Content-Type':'application/json'},
                content=json.dumps(payload,ensure_ascii=True).encode('ascii'))
            assert response.status_code==(400 if index==0 else 422),response.text
        content='café 🐝\n'
        accepted=client.post(base+'/suggestions',headers=headers,json={
            'schema':'omegacode-suggestion-request-v2','operation_id':'valid-multibyte-text',
            'scope_id':scope_id,'hunks':[{'kind':'create_text','path':'src/main.py','content':content}]})
        assert accepted.status_code==200,accepted.text
        retained=service.suggestion(p,ws['id'],accepted.json()['id'])['content']['hunks'][0]
        assert retained['content']==content
        assert retained['content_bytes']==len(content.encode('utf-8'))
        assert retained['content_digest']==digest(content.encode('utf-8'))
    finally:
        client.close()


def test_v2_created_file_before_and_history_keep_absence_digest_and_currency(service):
    p,grant=principal(service);ws=workspace(service,p)
    client=TestClient(create_app(service));headers={'Authorization':'Bearer '+grant['token']}
    base=f"/v1/workspaces/{ws['id']}"
    try:
        issued=client.post(base+'/suggestion-scopes',headers=headers,json=scope_request(ws))
        proposal_response=client.post(base+'/suggestions',headers=headers,json={
            'schema':'omegacode-suggestion-request-v2','operation_id':'before-history-v2',
            'scope_id':issued.json()['id'],'hunks':[{'kind':'create_text','path':'src/main.py','content':'new file\n'}]})
        assert proposal_response.status_code==200,proposal_response.text
        proposal=proposal_response.json();record=service.store.get('suggestion',proposal['id'])
        hunk=service.suggestion(p,ws['id'],proposal['id'])['content']['hunks'][0]
        before_url=base+f"/suggestions/{proposal['id']}/hunks/{hunk['id']}/before"
        before=client.get(before_url,headers=headers)
        assert before.status_code==200,before.text
        assert before.json()['schema']=='omegacode-suggestion-before-v2'
        assert before.json()['before']=={'kind':'absent'} and before.json()['currency']=='current'
        assert before.json()['suggestion_digest']==record['digest'] and before.json()['edit_authority'] is False
        assert 'data' not in before.json() and 'before_digest' not in before.json()
        current=client.get(base+f"/suggestions/{proposal['id']}",headers=headers)
        assert current.status_code==200 and current.json()['currency']=='current'
        assert current.json()['record']['digest']==record['digest']

        source=service.read(p,ws['id'],'calculator.py')['content']
        source_digest=service.manifest(ws)['files']['calculator.py']['digest']
        service.edit(p,ws['id'],{'operation_id':'advance-after-proposal',
            'expected_generation':ws['generation'],'expected_tree_digest':ws['tree_digest'],
            'edits':[{'path':'calculator.py','expected_digest':source_digest,'content':source+'\n# later edit\n'}]})
        stale=client.get(base+f"/suggestions/{proposal['id']}",headers=headers)
        assert stale.status_code==200 and stale.json()['currency']=='stale'
        old_before=client.get(before_url,headers=headers)
        assert old_before.status_code==200 and old_before.json()['currency']=='stale'
        assert old_before.json()['suggestion_digest']==record['digest']
    finally:
        client.close()
