"""Explicit owner-only settlement attempt; default off, no automatic replay."""
from omegacode.common import CodeError, canonical, digest, stamp
from omegacode.proposal_launch_custody import Custody
from omegacode.proposal_tests.settlement_submission import KIND, identity, same_original
from omegacode.proposal_tests.reconciliation import reconcile
from omegacode.proposal_tests.proposal_host_wire import fail

def submit_once(service, host, submission_id, *, enabled=False):
    if type(enabled) is not bool:
        raise ValueError('explicit boolean enablement required')
    if not enabled:
        return dict(posted=False, enabled=False)
    service._check_owner(required=True)
    with service.store.lock:
        active = getattr(service, '_proposal_settlement_inflight', None)
        if active is None:
            active = service._proposal_settlement_inflight = set()
        if submission_id in active:
            fail('settlement_inflight')
        active.add(submission_id)
    try:
        before = reconcile(service, host, submission_id)
        if before['acknowledged']:
            return dict(before, posted=False, enabled=True)
        with service.store.transaction():
            service._check_owner(required=True)
            record = service.store.get(KIND, submission_id)
            current = record['host_readback']
            if current is None or current['hold']['state'] not in ('dispatched', 'unknown'):
                fail('settlement_host_binding')
            row = Custody(service.store).get(record['launch_id'])
            if record['id'] != 'ps_' + digest(canonical([row['id'], record['body_digest']])) or record['body_digest'] != digest(canonical(record['body'])) or (not same_original(record['identity'], identity(service, row))):
                fail('settlement_original')
            attempts = record.get('transport_attempts', 0)
            if type(attempts) is not int or not 0 <= attempts < 2 ** 31 - 1:
                fail('settlement_original')
            record.update(transport_attempts=attempts + 1, transport_last_attempt_at=stamp(), transport_outcome='unconfirmed')
            service.store.put(KIND, record)
            body = record['body']
            path = f"/api/services/proposal-tests/{record['test_id']}/holds/{record['hold_id']}/settle"
        error = None
        with service.store.lock:
            service._check_owner(required=True)
            if canonical(service.store.get(KIND, submission_id)) != canonical(record) or not same_original(record['identity'], identity(service, Custody(service.store).get(row['id']))):
                fail('settlement_original')
        try:
            host._call('POST', path, body, expected=200)
        except CodeError as exc:
            error = exc.code
        answer = reconcile(service, host, submission_id)
        return dict(answer, posted=True, enabled=True, transport_error=error)
    finally:
        with service.store.lock:
            active.discard(submission_id)
