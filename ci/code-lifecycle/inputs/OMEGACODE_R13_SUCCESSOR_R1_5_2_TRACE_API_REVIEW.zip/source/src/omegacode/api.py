"""Loopback HTTP boundary; caller identity comes exclusively from scoped grants."""
from contextlib import asynccontextmanager
from typing import Annotated, Literal
import asyncio
import json
from urllib.parse import urlsplit

from fastapi import FastAPI, Depends, Header, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.exceptions import RequestValidationError
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, ConfigDict, Field, StrictBool

from .common import CodeError
from .relay_auth import RelayChallengeStore
from .service import Service
from .registration import enrol


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CopyApply(Model):
    operation_id: str = Field(min_length=8, max_length=120, pattern=r'^[A-Za-z0-9_.:-]+$')
    request_id: str = Field(min_length=1, max_length=160)
    suggestion_id: str = Field(pattern=r'^suggestion_[a-f0-9]{32}$')
    suggestion_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    expected_generation: int = Field(strict=True, ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    scope_id: str = Field(min_length=1, max_length=160)
    scope_digest: str = Field(pattern=r'^sha256:[a-f0-9]{64}$')


class CopyUndo(Model):
    operation_id: str = Field(min_length=1, max_length=160)
    expected_generation: int = Field(strict=True, ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class Grant(Model):
    actor: str = Field(min_length=1, max_length=160)
    kind: str
    task_id: str = Field(min_length=1, max_length=160)
    swarm_id: str = Field(min_length=1, max_length=160)
    repository_id: str
    actions: list[str]
    paths: list[str] = Field(default_factory=list, max_length=2000)
    argv_prefixes: list[list[str]] = Field(default_factory=list, max_length=100)
    ttl_seconds: int = Field(default=3600, ge=1, le=86400)
    max_runs: int = Field(default=10, ge=0, le=100)
    max_runtime_seconds: int = Field(default=120, ge=1, le=3600)
    member_token: str | None = None


class Enrol(Model):
    enrol_token: str = Field(min_length=24, max_length=4000)


class RelayChallenge(Model):
    version: int = Field(strict=True, ge=1, le=1)
    service_id: str = Field(min_length=1, max_length=160)
    nonce: str = Field(pattern=r"^[0-9a-f]{64}$")
    method: str = Field(pattern=r"^[A-Z]{1,16}$")
    path: str = Field(min_length=1, max_length=4096)
    body_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")


class Operation(Model):
    operation_id: str = Field(min_length=1, max_length=160)
    approval_id: str | None = Field(default=None, max_length=160)


StrictSourceOffset = Annotated[int, Field(strict=True,ge=0,le=2*1024*1024)]


class FunctionScopePreview(Model):
    expected_generation: int = Field(strict=True,ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    path: str = Field(min_length=1,max_length=1000)
    source_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    caret_byte: StrictSourceOffset


class FunctionScopeCreate(FunctionScopePreview,Operation):
    selection_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class ProposalTestReceipt(Model):
    operation_id: str = Field(min_length=1,max_length=160)
    proposal_id: str = Field(min_length=1,max_length=160)
    proposal_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    fork_id: str = Field(min_length=1,max_length=160)
    run_id: str = Field(min_length=1,max_length=160)


class CaptureRunResult(Operation):
    expected_generation: int = Field(strict=True,ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class ImportRunResult(CaptureRunResult):
    result_id: str = Field(min_length=1,max_length=160)
    result_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    selected_paths: list[str] = Field(min_length=1,max_length=2000)


class SuggestionScope(Operation):
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    ranges: dict[str, list[tuple[StrictSourceOffset, StrictSourceOffset]]]


class SuggestionCreateCeiling(Model):
    max_bytes: int = Field(strict=True, ge=0, le=2*1024*1024)


class SuggestionScopeV2(Operation):
    schema_marker: Literal['omegacode-suggestion-scope-request-v2'] = Field(alias='schema')
    expected_generation: int = Field(strict=True, ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    ranges: dict[str, list[tuple[StrictSourceOffset, StrictSourceOffset]]]
    create_files: dict[str, SuggestionCreateCeiling]
    max_total_create_bytes: int = Field(strict=True, ge=0, le=2*1024*1024)


class SuggestionHunk(Model):
    path: str = Field(min_length=1,max_length=1000)
    start_byte: int = Field(ge=0,strict=True)
    end_byte: int = Field(ge=0,strict=True)
    replacement: str = Field(max_length=2*1024*1024)
    before_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


SuggestionGroup = Annotated[list[Annotated[int, Field(strict=True,ge=0,le=999)]], Field(min_length=2,max_length=1000)]


class SuggestionCreate(Operation):
    scope_id: str = Field(min_length=1,max_length=160)
    hunks: list[SuggestionHunk] = Field(min_length=1,max_length=1000)
    groups: list[SuggestionGroup] | None = Field(default=None,max_length=500)


class SuggestionEditTextV2(Model):
    kind: Literal['edit_text']
    path: str = Field(min_length=1,max_length=1000)
    start_byte: int = Field(strict=True,ge=0,le=2*1024*1024)
    end_byte: int = Field(strict=True,ge=0,le=2*1024*1024)
    replacement: str = Field(max_length=2*1024*1024)
    before_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class SuggestionCreateTextV2(Model):
    kind: Literal['create_text']
    path: str = Field(min_length=1,max_length=1000)
    content: str = Field(max_length=2*1024*1024)


SuggestionHunkV2 = Annotated[SuggestionEditTextV2 | SuggestionCreateTextV2,Field(discriminator='kind')]


class SuggestionCreateV2(Operation):
    schema_marker: Literal['omegacode-suggestion-request-v2'] = Field(alias='schema')
    scope_id: str = Field(min_length=1,max_length=160)
    hunks: list[SuggestionHunkV2] = Field(min_length=1,max_length=1000)
    groups: list[SuggestionGroup] | None = Field(default=None,max_length=500)


class SuggestionDecision(Operation):
    suggestion_id: str = Field(min_length=1,max_length=160)
    suggestion_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    accepted_hunk_ids: list[str] = Field(default_factory=list,max_length=1000)
    rejected_hunk_ids: list[str] = Field(default_factory=list,max_length=1000)


class WorkspaceHistoryResponse(Model):
    generation: int = Field(strict=True,ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    author: str
    change_id: str | None = None


class WorkspaceForkOrigin(Model):
    workspace_id: str
    generation: int = Field(strict=True,ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class WorkspaceResponse(Model):
    id: str
    repository_id: str
    task_id: str
    swarm_id: str
    base_commit: str
    base_ref: str
    generation: int = Field(strict=True,ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    base_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    created_by: str
    created_at: float
    profile: str
    environment: dict[str,str]
    history: list[WorkspaceHistoryResponse]
    fork_origin: WorkspaceForkOrigin | None = None


class ChangeSetResponse(Model):
    id: str
    workspace_id: str
    task_id: str
    author: str
    base_commit: str
    before_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    generation: int = Field(strict=True,ge=1)
    paths: list[str]
    created_at: float
    diff_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class SuggestionDecisionRecordResponse(Model):
    id: str
    suggestion_id: str
    suggestion_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    workspace_id: str
    actor: str
    accepted_hunk_ids: list[Annotated[str,Field(pattern=r'^[a-f0-9]{64}$')]]
    rejected_hunk_ids: list[Annotated[str,Field(pattern=r'^[a-f0-9]{64}$')]]
    change_id: str | None
    created_at: float


class SuggestionDecisionResponse(Model):
    workspace: WorkspaceResponse
    change: ChangeSetResponse | None = None
    decision: SuggestionDecisionRecordResponse


class SuggestionSourceBinding(Model):
    workspace_id: str = Field(min_length=1,max_length=160)
    task_id: str = Field(min_length=1,max_length=160)
    generation: int = Field(strict=True,ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class SuggestionScopeLegacy(Model):
    id: str
    workspace_id: str
    digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    author: str
    created_at: float


def scope_answer(result,include_binding):
    if result.get('schema') == 'omegacode-suggestion-scope-v2':
        return result
    return result if include_binding else {k:result[k] for k in ('id','workspace_id','digest','author','created_at')}


class SuggestionScopeReceipt(Model):
    id: str
    workspace_id: str
    digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    author: str
    created_at: float
    binding: SuggestionSourceBinding
    ranges: dict[str,list[tuple[StrictSourceOffset,StrictSourceOffset]]]
    file_digests: dict[str,Annotated[str,Field(pattern=r'^[a-f0-9]{64}$')]]
    edit_authority: Literal[False]


class AbsentFileBefore(Model):
    kind: Literal['absent']


class SuggestionScopeCreateReceipt(Model):
    before: AbsentFileBefore
    max_bytes: int = Field(strict=True, ge=0, le=2*1024*1024)


class SuggestionDestinationResult(Model):
    allowed: StrictBool
    reason: Literal['explicit_exclusion','gitignore'] | None


class SuggestionDestinationEvaluation(Model):
    generation: int = Field(strict=True,ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    context_policy_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    results: dict[str,SuggestionDestinationResult]


class SuggestionScopeReceiptV2(Model):
    schema_marker: Literal['omegacode-suggestion-scope-v2'] = Field(alias='schema')
    id: str
    workspace_id: str
    digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    author: str
    created_at: float
    binding: SuggestionSourceBinding
    ranges: dict[str,list[tuple[StrictSourceOffset,StrictSourceOffset]]]
    file_digests: dict[str,Annotated[str,Field(pattern=r'^[a-f0-9]{64}$')]]
    create_files: dict[str,SuggestionScopeCreateReceipt]
    max_total_create_bytes: int = Field(strict=True, ge=0, le=2*1024*1024)
    context_policy_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    destination_evaluation: SuggestionDestinationEvaluation | None = None
    edit_authority: Literal[False]


class SuggestionBeforePage(Model):
    schema_marker: Literal['omegacode-suggestion-before-v1'] = Field(alias='schema')
    workspace_id: str
    suggestion_id: str
    suggestion_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    hunk_id: str = Field(pattern=r'^[a-f0-9]{64}$')
    path: str = Field(min_length=1,max_length=1000)
    binding: SuggestionSourceBinding
    before_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    file_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    currency: Literal['current','stale']
    encoding: Literal['base64']
    data: str = Field(max_length=87384)
    offset: int = Field(strict=True,ge=0,le=2*1024*1024)
    total_bytes: int = Field(strict=True,ge=0,le=2*1024*1024)
    next_offset: Annotated[int, Field(strict=True,ge=0,le=2*1024*1024)] | None
    edit_authority: Literal[False]


class SuggestionCreatedBefore(Model):
    schema_marker: Literal['omegacode-suggestion-before-v2'] = Field(alias='schema')
    workspace_id: str
    suggestion_id: str
    suggestion_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    hunk_id: str = Field(pattern=r'^[a-f0-9]{64}$')
    path: str = Field(min_length=1,max_length=1000)
    binding: SuggestionSourceBinding
    before: AbsentFileBefore
    currency: Literal['current','stale']
    edit_authority: Literal[False]


class IterationLimits(Model):
    max_attempts: int = Field(strict=True,ge=1,le=100)
    max_seconds: float = Field(strict=True,gt=0,le=86400,allow_inf_nan=False)
    max_cost: float = Field(strict=True,gt=0,le=100000,allow_inf_nan=False)


class IterationObservations(Model):
    attempts: int = Field(strict=True,ge=0,le=100)
    elapsed_seconds: float | None = Field(default=None,strict=True,ge=0,allow_inf_nan=False)
    observed_cost: float | None = Field(default=None,strict=True,ge=0,allow_inf_nan=False)
    host_admitted: bool = Field(strict=True)
    cancelled: bool = Field(strict=True)


IterationArg = Annotated[str,Field(min_length=1,max_length=4096)]
IterationArgv = Annotated[list[IterationArg],Field(min_length=1,max_length=100)]
IterationVerificationId = Annotated[str,Field(min_length=1,max_length=160)]


class IterationCreate(Operation):
    expected_generation: int = Field(strict=True,ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    commands: list[IterationArgv] = Field(min_length=1,max_length=20)
    verification_ids: list[IterationVerificationId] = Field(max_length=20)
    limits: IterationLimits
    observations: IterationObservations


class WorkspaceCreate(Operation):
    repository_id: str
    task_id: str
    base_commit: str = Field(min_length=1, max_length=160)


class Search(Model):
    query: str = Field(min_length=1, max_length=4000)
    limit: int = Field(default=100, ge=1, le=500)


class RepositoryFactsQuery(Model):
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    changed_paths: list[str] | None = Field(default=None, max_length=512)
    base_generation: int | None = Field(default=None, strict=True, ge=1)
    base_tree_digest: str | None = Field(default=None, pattern=r'^[a-f0-9]{64}$')


class RepositoryRetrievalQuery(Model):
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')
    query: str = Field(min_length=1,max_length=4000)
    limit: int = Field(default=20,ge=1,le=100)
    path_prefix: str | None = Field(default=None,max_length=1000)
    fact_kind: str | None = Field(default=None,max_length=128)
    fact_target: str | None = Field(default=None,max_length=1000)
    corpus: Literal['python','metta','text'] = 'python'
    runtime_id: str | None = Field(default=None,min_length=1,max_length=160)


class Edit(Model):
    path: str = Field(min_length=1, max_length=1000)
    expected_digest: str | None
    content: str | None = Field(max_length=2 * 1024 * 1024)


class Patch(Operation):
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    edits: list[Edit] = Field(min_length=1, max_length=2000)


class LanguageQuery(Model):
    server_id: str = Field(min_length=1, max_length=160)
    feature: Literal["definition", "references", "completion", "hover", "rename", "diagnostics", "document_symbols", "signature_help"]
    path: str = Field(min_length=1, max_length=1000)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    line: int = Field(default=0, ge=0, le=2097152)
    character: int = Field(default=0, ge=0, le=2097152)
    new_name: str | None = Field(default=None, min_length=1, max_length=160)
    limit: int = Field(default=50, ge=1, le=100)

    buffers: dict[str, dict] | None = Field(default=None, min_length=1, max_length=16)
    draft_files: dict[str, dict] | None = Field(default=None, min_length=1, max_length=16)
    buffer_revision: str | None = Field(default=None, min_length=1, max_length=120)


class CompletionPreview(Model):
    profile: Literal["editor-snippet-template-v1"] | None = None
    selection_mode: Literal["insert", "replace"] | None = None
    query_id: str = Field(min_length=1, max_length=160)
    item_index: int = Field(ge=0, le=99)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class ApplyRename(Operation):
    preview_id: str = Field(min_length=1, max_length=160)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")


class GitExport(Operation):
    history_mode: Literal['snapshot', 'original'] = 'snapshot'
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    branch: str = Field(min_length=1, max_length=120)
    message: str = Field(min_length=1, max_length=4000)


class SourceReview(Model):
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    target: Literal["base", "checkpoint"] = "base"
    checkpoint_id: str | None = Field(default=None, min_length=1, max_length=160)


class ApplySourceReview(Operation):
    review_id: str = Field(min_length=1, max_length=160)
    hunk_ids: list[str] = Field(min_length=1, max_length=10000)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")


class MergePreview(Model):
    operation_id: str | None = Field(default=None,min_length=1,max_length=160)
    approval_id: str | None = Field(default=None,max_length=160)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    base_checkpoint_id: str = Field(min_length=1, max_length=160)
    incoming_checkpoint_id: str = Field(min_length=1, max_length=160)


class MergeResolution(Model):
    path: str = Field(min_length=1, max_length=1000)
    choice: Literal["ours", "incoming", "base", "manual", "delete"]
    content_base64: str | None = Field(default=None, max_length=2796204)
    executable: bool | None = None


class ApplyMerge(Operation):
    preview_id: str = Field(min_length=1, max_length=160)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    resolutions: list[MergeResolution] = Field(default_factory=list, max_length=2000)


class Run(Operation):
    proof_project_paths: list[str] | None = Field(default=None, min_length=1, max_length=32)
    proof_runtime_id: str | None = Field(default=None, min_length=1, max_length=160)
    leatta_runtime_id: str | None = Field(default=None, min_length=1, max_length=160)
    debugger_runtime_id: str | None = Field(default=None, min_length=1, max_length=160)
    symbolic_runtime_id: str | None = Field(default=None, min_length=1, max_length=160)
    terminal: bool = False
    rows: int = Field(default=24, ge=1, le=500)
    cols: int = Field(default=80, ge=1, le=500)
    workspace_id: str
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    argv: list[str] = Field(min_length=1, max_length=100)
    timeout_seconds: int = Field(default=30, ge=1, le=3600)


class TerminalSourcePrecondition(Model):
    workspace_id: str = Field(min_length=1, max_length=160)
    generation: int = Field(strict=True, ge=1)
    tree_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class TerminalControl(Operation):
    kind: Literal["input", "resize"]
    data_base64: str | None = Field(default=None, max_length=10924)
    source_precondition: TerminalSourcePrecondition | None = None
    rows: int | None = Field(default=None, ge=1, le=500)
    cols: int | None = Field(default=None, ge=1, le=500)


class Verify(Operation):
    run_id: str


class Checkpoint(Operation):
    expected_generation: int | None = Field(default=None, strict=True, ge=1)
    expected_tree_digest: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    label: str = Field(min_length=1, max_length=200)
    decision: str = Field(default="", max_length=10000)


class Restore(Operation):
    checkpoint_id: str = Field(min_length=1, max_length=160)
    expected_generation: int = Field(ge=1)
    expected_tree_digest: str = Field(pattern=r"^[a-f0-9]{64}$")


def create_app(service: Service, port=8724):
    @asynccontextmanager
    async def lifespan(app):
        service.start_monitor()
        yield
        service.close()

    app = FastAPI(title="OmegaCode", version="0.1.0", lifespan=lifespan)
    app.state.service = service
    app.state.relay_challenges = RelayChallengeStore(ttl_seconds=5.0, max_pending=1024)

    def relay_connection(scope):
        client, server = scope.get("client"), scope.get("server")
        if (not isinstance(client, (tuple, list)) or len(client) < 2
                or not isinstance(server, (tuple, list)) or len(server) < 2):
            return None
        return (str(client[0]), int(client[1]), str(server[0]), int(server[1]))

    def request_target(scope):
        try:
            raw_path = scope.get("raw_path") or str(scope.get("path", "")).encode("ascii", "strict")
            query = scope.get("query_string", b"")
            path = raw_path.decode("ascii")
            query_text = query.decode("ascii")
        except (UnicodeDecodeError, UnicodeEncodeError, AttributeError):
            return None
        return path + ("?" + query_text if query_text else "")

    @app.exception_handler(CodeError)
    async def code_error(request, exc):
        body = {"error": exc.code, "message": exc.message}
        if exc.details is not None:
            body["details"] = exc.details
        headers = {}
        if (exc.code == "registration_busy" and isinstance(exc.details, dict)
                and type(exc.details.get("retry_after_seconds")) is int
                and exc.details["retry_after_seconds"] > 0):
            headers["Retry-After"] = str(exc.details["retry_after_seconds"])
        return JSONResponse(status_code=exc.status, content=body, headers=headers)

    def contains_unpaired_surrogate(value):
        if isinstance(value,str):
            try:value.encode('utf-8','strict')
            except UnicodeEncodeError:return True
            return False
        if isinstance(value,dict):
            return any(contains_unpaired_surrogate(k) or contains_unpaired_surrogate(v) for k,v in value.items())
        if isinstance(value,(list,tuple)):
            return any(contains_unpaired_surrogate(item) for item in value)
        return False

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        errors=exc.errors()
        if any(contains_unpaired_surrogate(error.get('input')) for error in errors):
            # Starlette's default 422 renderer uses ensure_ascii=False; echoing
            # a JSON-escaped lone surrogate would itself raise UnicodeEncodeError.
            safe=[{key:value for key,value in error.items() if key not in ('input','ctx')} for error in errors]
            return JSONResponse(status_code=422,content={'detail':safe})
        return await request_validation_exception_handler(request,exc)

    # Content-Length is not sufficient: also bound actual request bodies before parsing.
    @app.middleware("http")
    async def bound_body(request: Request, call_next):
        try: service._check_owner()
        except CodeError as error:
            return JSONResponse(status_code=error.status, content={'error':error.code,'message':error.message})
        authorization = request.headers.get("authorization", "")
        relayed_host_capability = authorization.startswith("Bearer hc1.")
        if request.method in ("POST", "PUT", "PATCH") or relayed_host_capability:
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 34 * 1024 * 1024:
                    return JSONResponse(status_code=413, content={"error": "request_limit"})
            request._body = bytes(body)
        else:
            body = bytearray()
        if relayed_host_capability:
            challenge_id = request.headers.get("x-omegacode-relay-challenge", "")
            connection = relay_connection(request.scope)
            target = request_target(request.scope)
            if (connection is None or target is None
                    or not app.state.relay_challenges.consume(
                        connection, challenge_id, method=request.method, path=target, body=bytes(body))):
                return JSONResponse(status_code=403,
                                    content={"error": "relay_proof_failed",
                                             "message": "same-connection Hive relay proof is required"})
        try: service._check_owner()
        except CodeError as error:
            return JSONResponse(status_code=error.status, content={'error':error.code,'message':error.message})
        return await call_next(request)

    def principal(authorization: Annotated[str | None, Header()] = None,
                  x_hive_token: Annotated[str | None, Header()] = None):
        if not authorization or not authorization.startswith("Bearer "):
            raise CodeError(401, "authentication_required", "a scoped bearer capability is required")
        return service.authority.authenticate(authorization[7:], x_hive_token)

    P = Depends(principal)

    @app.post("/v1/relay-challenge")
    def relay_challenge(body: RelayChallenge, request: Request):
        service._check_owner()
        if request.headers.get("authorization") or request.headers.get("x-hive-token"):
            raise CodeError(400, "relay_challenge_bearer_forbidden", "relay challenge requests must not carry a bearer")
        registration = service.authority.registration or {}
        if body.service_id != registration.get("service_id"):
            raise CodeError(404, "not_found", "relay challenge is unavailable")
        connection = relay_connection(request.scope)
        try:
            registered = urlsplit(registration.get("address", ""))
            registered_listener = (registered.scheme, registered.hostname, registered.port)
        except (TypeError, ValueError):
            registered_listener = (None, None, None)
        if (connection is None or connection[0] != "127.0.0.1" or connection[2] != "127.0.0.1"
                or connection[3] != port or registered_listener != ("http", "127.0.0.1", port)):
            raise CodeError(403, "relay_connection_refused", "relay challenge requires the registered loopback listener")
        secret = registration.get("capability_secret")
        if not isinstance(secret, str) or len(secret) < 32:
            raise CodeError(503, "relay_proof_unavailable", "registered relay proof is unavailable")
        if body.path == "/v1/relay-challenge" or any(c in body.path for c in "\r\n#\x00"):
            raise CodeError(422, "relay_challenge_invalid", "relay target path is not canonical")
        try:
            challenge_id, proof = app.state.relay_challenges.issue(
                connection, secret=secret, service_id=body.service_id, nonce=body.nonce,
                method=body.method, path=body.path, body_sha256=body.body_sha256)
        except ValueError:
            raise CodeError(422, "relay_challenge_invalid", "relay challenge fields are invalid") from None
        return {"version": 1, "challenge_id": challenge_id, "proof": proof}

    def operator(p):
        service._check_owner()
        if not p.operator:
            raise CodeError(403, "operator_required", "operator registration authority is required")

    @app.get("/v1/capabilities")
    def capabilities(p=P):
        return {"service": "omegacode", "version": "0.1.0", "protocol": "0.1",
                "profiles": [{"id": "trusted-native", "os_sandbox": False, "disposable_only": True}],
                "features": ["source-tree", "python-repository-facts", "python-repository-retrieval", "context-exclusion-selection", "metta-delimiter-diagnostics", "search", "cas-edits", "frozen-runs", "changes", "verification", "events", "checkpoints", "checkpoint-restore", "run-log-stream", "run-history", "verification-history", "run-output-pages", "interactive-pty", "terminal-input", "terminal-resize", "language-server-queries", "rename-preview", "saved-completion-preview", "dependent-suggestion-groups", "retained-scope-echo", "retained-suggestion-before-bytes", "source-hunk-review", "selective-source-restore", "git-context", "git-review-export", "git-bundle", "binary-git-patch", "python-dap-session", "lean-single-module-check", "lean-project-check", "leatta-saved-file"],
                "unsupported": ["debugger-workbench", "remote-debug-attach", "expression-evaluation", "preview", "adapters", "promotion", "untrusted-execution"],
                "merge": {"kind": "manifest-three-way", "features": ["merge-preview", "explicit-conflict-resolution", "merge-review-packet", "workspace-symbolic-evidence-draft"],
                          "resolution_scope": "whole-file", "git_ancestry": False, "source_repository_mutation": False},
                "limits": {"file_bytes": 2097152, "workspace_bytes": 33554432, "files": 2000}}

    @app.post("/v1/operator/grants", status_code=201)
    def grants(body: Grant, p=P):
        operator(p)
        if body.repository_id not in service.repositories:
            raise CodeError(403, "repository_unregistered", "repository must be registered in operator configuration")
        return service.authority.issue(**body.model_dump())

    @app.post("/v1/operator/register", status_code=201)
    def register(body: Enrol, p=P):
        operator(p)
        return enrol(service.authority, service.store.root, body.enrol_token, port)

    @app.delete("/v1/operator/grants/{id}")
    def revoke(id: str, p=P):
        operator(p)
        return service.authority.revoke(id)

    @app.post("/v1/workspaces", status_code=201)
    def create(body: WorkspaceCreate, p=P):
        return service.create_workspace(p, body.model_dump())

    @app.get("/v1/workspaces/{id}")
    def workspace(id: str, p=P):
        ws = service.workspace(id)
        service._authorize(p, "read", ws, {})
        service.authority.gate(p, "read", {"workspace_id": id, "generation": ws["generation"]})
        return ws

    @app.post('/v1/workspaces/{id}/forks',status_code=201,response_model=WorkspaceResponse,response_model_exclude_unset=True)
    def workspace_fork(id: str, body: CaptureRunResult, p=P):
        return service.fork_workspace(p,id,body.model_dump())

    @app.get('/v1/tasks/{task_id}/workspaces')
    def task_workspaces(task_id: str, p=P):
        return service.task_workspaces(p, task_id)

    @app.get("/v1/workspaces/{id}/files")
    def read(id: str, path: str, expected_generation: int | None = None, p=P):
        return service.read(p, id, path, expected_generation)

    @app.get("/v1/workspaces/{id}/diagnostics")
    def diagnostics(id: str, path: str = Query(...), generation: int | None = None, p=P):
        return service.metta_diagnostics(p, id, path, generation)

    @app.get("/v1/workspaces/{id}/language/servers")
    def language_servers(id: str, p=P):
        return service.language_server_inventory(p, id)

    @app.post("/v1/workspaces/{id}/language/completion-previews")
    def completion_preview(id: str, body: CompletionPreview, p=P):
        return service.completion_preview(p, id, body.model_dump())

    @app.post("/v1/workspaces/{id}/language/completion-applies")
    def completion_apply(id: str, body: ApplyRename, p=P):
        return service.apply_completion_preview(p, id, body.model_dump())

    @app.post("/v1/workspaces/{id}/language/renames")
    def apply_rename(id: str, body: ApplyRename, p=P):
        return service.apply_language_rename(p, id, body.model_dump())

    @app.post("/v1/workspaces/{id}/language")
    def language(id: str, body: LanguageQuery, p=P):
        return service.language_query(p, id, body.model_dump())

    @app.get("/v1/workspaces/{id}/tree")
    def tree(id: str, expected_generation: int | None = None, p=P):
        return service.tree(p, id, expected_generation)

    @app.get("/v1/workspaces/{id}/toolchains")
    def toolchains(id: str, p=P):
        from .toolchains import inventory
        ws = service.workspace(id)
        service._authorize(p, "read", ws, {})
        service.authority.gate(p, "read", {"workspace_id": id, "resource": "toolchains"})
        return inventory(service.toolchains)

    @app.post('/v1/workspaces/{id}/repository-facts')
    def repository_facts(id: str, body: RepositoryFactsQuery, p=P):
        return service.repository_facts(p, id, **body.model_dump())

    @app.post('/v1/workspaces/{id}/repository-retrieval')
    def repository_retrieval(id: str, body: RepositoryRetrievalQuery, p=P):
        return service.repository_retrieval(p,id,**body.model_dump())

    @app.post("/v1/workspaces/{id}/search")
    def search(id: str, body: Search, p=P):
        return service.search(p, id, **body.model_dump())

    @app.post("/v1/workspaces/{id}/iterations",status_code=201)
    def iteration_create(id: str,body: IterationCreate,p=P):
        return service.retain_iteration(p,id,body.model_dump())

    @app.get("/v1/workspaces/{id}/iterations/{iteration_id}")
    def iteration_read(id: str,iteration_id: str,p=P):
        return service.iteration(p,id,iteration_id)

    @app.post("/v1/workspaces/{id}/function-scope-preview")
    def function_scope_preview(id: str,body: FunctionScopePreview,p=P):
        return service.function_scope_preview(p,id,body.model_dump())

    @app.post("/v1/workspaces/{id}/function-scopes",status_code=201,response_model=SuggestionScopeReceipt | SuggestionScopeLegacy)
    def function_scope_create(id: str,body: FunctionScopeCreate,include_binding: bool = Query(False),p=P):
        return scope_answer(service.create_function_scope(p,id,body.model_dump()),include_binding)

    @app.post("/v1/workspaces/{id}/suggestion-scopes",response_model=SuggestionScopeReceipt | SuggestionScopeLegacy | SuggestionScopeReceiptV2)
    def suggestion_scope(id: str, body: SuggestionScope | SuggestionScopeV2, include_binding: bool = Query(False), p=P):
        return scope_answer(service.create_suggestion_scope(p,id,body.model_dump()),include_binding)

    @app.get("/v1/workspaces/{id}/suggestion-scopes/{scope_id}")
    def suggestion_scope_read(id: str, scope_id: str, p=P):
        return service.suggestion_scope_read(p,id,scope_id)

    @app.post('/v1/workspaces/{id}/proposal-applications', status_code=201)
    def copy_apply(id: str, body: CopyApply, p=P):
        from .copy_application import CopyEngine
        engine = CopyEngine(service)
        return engine.application_receipt(engine.apply(p, id, body.model_dump()))

    @app.get('/v1/workspaces/{id}/proposal-applications/{application_id}')
    def copy_read(id: str, application_id: str, p=P):
        from .copy_application import CopyEngine
        return CopyEngine(service).read(p, id, application_id)

    @app.post('/v1/workspaces/{id}/proposal-applications/{application_id}/undo', status_code=201)
    def copy_undo(id: str, application_id: str, body: CopyUndo, p=P):
        from .copy_application import CopyEngine
        engine = CopyEngine(service)
        return engine.undo_receipt(engine.undo(p, id, application_id, body.model_dump()))

    @app.post("/v1/workspaces/{id}/suggestions")
    def suggestion_create(id: str, body: SuggestionCreate | SuggestionCreateV2, p=P):
        return service.create_suggestion(p,id,body.model_dump())

    @app.get("/v1/workspaces/{id}/suggestions")
    def suggestion_history(id: str, limit: int = Query(20, ge=1, le=20), cursor: str | None = Query(None, max_length=512), p=P):
        return service.suggestion_history(p,id,limit,cursor)

    @app.get("/v1/workspaces/{id}/suggestions/{suggestion_id}")
    def suggestion_read(id: str, suggestion_id: str, include_request_binding: bool = Query(False), p=P):
        return service.suggestion(p,id,suggestion_id,include_request_binding=include_request_binding)

    @app.get("/v1/workspaces/{id}/suggestions/{suggestion_id}/hunks/{hunk_id}/before",response_model=SuggestionBeforePage | SuggestionCreatedBefore)
    def suggestion_before(id: str, suggestion_id: str, hunk_id: str,
                          offset: int = Query(0,ge=0,le=2*1024*1024), limit: int = Query(65536,ge=1,le=65536), p=P):
        result=service.suggestion_hunk_before(p,id,suggestion_id,hunk_id,offset,limit)
        return result

    @app.post("/v1/workspaces/{id}/suggestion-decisions",response_model=SuggestionDecisionResponse,response_model_exclude_unset=True)
    def suggestion_decide(id: str, body: SuggestionDecision, p=P):
        return service.decide_suggestion(p,id,body.model_dump())

    @app.post("/v1/workspaces/{id}/patches")
    def patch(id: str, body: Patch, p=P):
        return service.edit(p, id, body.model_dump())

    @app.get("/v1/workspaces/{id}/git/context")
    def git_context(id: str, p=P):
        return service.git_context(p, id)

    @app.post("/v1/workspaces/{id}/git/exports", status_code=201)
    def git_export_create(id: str, body: GitExport, p=P):
        return service.create_git_export(p,id,body.model_dump(exclude={'history_mode'} - body.model_fields_set))

    @app.get("/v1/workspaces/{id}/git/exports/{export_id}")
    def git_export_get(id: str, export_id: str, p=P):
        return service.git_export(p,id,export_id)

    @app.get("/v1/workspaces/{id}/git/exports/{export_id}/patch")
    def git_export_patch(id: str, export_id: str, after: int = Query(default=0, ge=0), limit: int = Query(default=1024, ge=1, le=16384), p=P):
        return service.git_export_patch(p,id,export_id,after,limit)

    @app.post("/v1/workspaces/{id}/reviews", status_code=201)
    def create_review(id: str, body: SourceReview, p=P):
        return service.create_source_review(p, id, body.model_dump())

    @app.get("/v1/workspaces/{id}/reviews/{review_id}")
    def review(id: str, review_id: str, after: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100), p=P):
        return service.source_review(p, id, review_id, after, limit)

    @app.get("/v1/workspaces/{id}/reviews/{review_id}/hunks/{hunk_id}")
    def review_content(id: str, review_id: str, hunk_id: str, side: Literal["before", "after"],
                       after: int = Query(0, ge=0), limit: int = Query(1024, ge=1, le=16384), p=P):
        return service.source_review_content(p, id, review_id, hunk_id, side, after, limit)

    @app.post("/v1/workspaces/{id}/reviews/{review_id}/apply")
    def review_apply(id: str, review_id: str, body: ApplySourceReview, p=P):
        if review_id != body.review_id:
            raise CodeError(400, "review_identity", "route and body review IDs differ")
        return service.apply_source_review(p, id, body.model_dump())

    @app.get("/v1/workspaces/{id}/changes")
    def changes(id: str, p=P):
        return service.changes(p, id)

    @app.get("/v1/workspaces/{id}/merge-review/{change_id}")
    def merge_review(id: str, change_id: str, verification_id: list[str] = Query(default=[], max_length=100), p=P):
        return service.merge_review_packet(p, id, change_id, verification_id)

    @app.post("/v1/workspaces/{id}/merges", status_code=201)
    def merge_create(id: str, body: MergePreview, p=P):
        return service.create_merge_preview(p, id, body.model_dump(exclude_none=True))

    @app.get("/v1/workspaces/{id}/merges/{preview_id}")
    def merge_get(id: str, preview_id: str, after: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100), p=P):
        return service.merge_preview(p, id, preview_id, after, limit)

    @app.get("/v1/workspaces/{id}/merges/{preview_id}/content")
    def merge_content(id: str, preview_id: str, path: str, side: Literal["base", "ours", "incoming", "merged"],
                      after: int = Query(0, ge=0), limit: int = Query(1024, ge=1, le=16384), p=P):
        return service.merge_content(p, id, preview_id, path, side, after, limit)

    @app.post("/v1/workspaces/{id}/merges/{preview_id}/apply")
    def merge_apply(id: str, preview_id: str, body: ApplyMerge, p=P):
        if preview_id != body.preview_id:
            raise CodeError(400, "merge_identity", "route and body merge IDs differ")
        return service.apply_merge_preview(p, id, body.model_dump(exclude_none=True))

    @app.post("/v1/workspaces/{id}/checkpoints", status_code=201)
    def checkpoint(id: str, body: Checkpoint, p=P):
        return service.checkpoint(p, id, body.model_dump(exclude_none=True))

    @app.get("/v1/workspaces/{id}/checkpoints")
    def checkpoints(id: str, p=P):
        return service.checkpoints(p, id)

    @app.post("/v1/workspaces/{id}/restores")
    def restore(id: str, body: Restore, p=P):
        return service.restore_checkpoint(p, id, body.model_dump())

    @app.post("/v1/runs", status_code=201)
    def run(body: Run, p=P):
        if any(not arg or "\x00" in arg or len(arg) > 32000 for arg in body.argv):
            raise CodeError(400, "invalid_argv", "argv elements must be nonempty, bounded strings without NUL")
        return service.start_run(p, body.model_dump(exclude_none=True, exclude={"terminal", "rows", "cols"} - body.model_fields_set))

    @app.get("/v1/workspaces/{id}/runs")
    def run_history(id: str, limit: int = Query(50, ge=1, le=100), cursor: str | None = Query(None, max_length=512), p=P):
        return service.evidence_history(p, id, "run", limit, cursor)

    @app.get("/v1/workspaces/{id}/verifications")
    def verification_history(id: str, limit: int = Query(50, ge=1, le=100), cursor: str | None = Query(None, max_length=512), p=P):
        return service.evidence_history(p, id, "verification", limit, cursor)

    @app.post('/v1/workspaces/{id}/proposal-test-receipts', status_code=201)
    def retain_proposal_test_receipt(id: str, body: ProposalTestReceipt, p=P):
        return service.retain_proposal_test_receipt(p,id,body.model_dump())

    @app.get('/v1/workspaces/{id}/proposal-test-receipts/{receipt_id}')
    def get_proposal_test_receipt(id: str, receipt_id: str, p=P):
        return service.proposal_test_receipt(p,id,receipt_id)

    @app.get("/v1/runs/{id}")
    def get_run(id: str, p=P):
        return service.run(p, id)

    @app.get("/v1/runs/{id}/source")
    def run_source(id: str, source_path: str = Query(min_length=1, max_length=4096),
                   after: int = Query(0, ge=0, le=33554432), limit: int = Query(16384, ge=1, le=16384), p=P):
        return service.run_source(p, id, source_path, after, limit)

    @app.post('/v1/runs/{id}/results', status_code=201)
    def capture_run_result(id: str, body: CaptureRunResult, p=P):
        return service.capture_run_result(p, id, body.model_dump(exclude_none=True))

    @app.get('/v1/workspaces/{id}/run-results/{result_id}')
    def get_run_result(id: str, result_id: str, p=P):
        return service.run_result(p, id, result_id)

    @app.post('/v1/workspaces/{id}/run-results/{result_id}/import')
    def import_run_result(id: str, result_id: str, body: ImportRunResult, p=P):
        if body.result_id != result_id:
            raise CodeError(400,'result_identity','route and body result IDs differ')
        return service.import_run_result(p,id,body.model_dump(exclude_none=True))

    @app.get('/v1/workspaces/{id}/run-results/{result_id}/source')
    def get_run_result_source(id: str, result_id: str, path: str = Query(min_length=1,max_length=4096),
                              after: int = Query(0,ge=0,le=33554432),
                              limit: int = Query(16384,ge=1,le=16384), p=P):
        return service.run_result_source(p,id,result_id,path,after,limit)

    @app.get('/v1/runs/{id}/proof-result')
    def proof_result(id: str, p=P):
        return service.proof_result(p, id)

    @app.get('/v1/runs/{id}/symbolic-trace-result')
    def symbolic_trace_result(id: str, after: int = Query(0, ge=0, le=4096),
                              limit: int = Query(100, ge=1, le=100), p=P):
        return service.symbolic_trace_result(p, id, after, limit)

    @app.get("/v1/runs/{id}/output")
    def run_output(id: str, after: int = Query(0, ge=0, le=4194304), limit: int = Query(16384, ge=1, le=65536), p=P):
        return service.run_output(p, id, after, limit)

    @app.post("/v1/runs/{id}/terminal", status_code=202)
    def terminal_control(id: str, body: TerminalControl, p=P):
        return service.terminal_control(p, id, body.model_dump(exclude_none=True))

    @app.get("/v1/runs/{id}/terminal/{control_id}")
    def terminal_control_status(id: str, control_id: str, p=P):
        return service.terminal_control_status(p, id, control_id)

    @app.post("/v1/runs/{id}/cancel", status_code=202)
    def cancel(id: str, body: Operation, p=P):
        return service.cancel(p, id, body.model_dump())

    @app.post("/v1/verifications", status_code=201)
    def verify(body: Verify, p=P):
        return service.verify(p, body.model_dump())

    @app.get("/v1/verifications/{id}")
    def get_verification(id: str, p=P):
        return service.verification(p, id)

    @app.get("/v1/artifacts/{hash}")
    def artifact(hash: str, workspace_id: str, p=P):
        ws = service.workspace(workspace_id)
        service._authorize(p, "artifact", ws, {})
        if p.grant["paths"]:
            raise CodeError(403, "artifact_scope", "bulk artifacts require unrestricted file scope")
        service.authority.gate(p, "artifact", {"workspace_id": workspace_id, "digest": hash})
        return Response(service.store.read_blob(hash, workspace_id), media_type="application/octet-stream")

    @app.get("/v1/events")
    def events(workspace_id: str, after: int = Query(default=0, ge=0), p=P):
        ws = service.workspace(workspace_id)
        service._authorize(p, "events", ws, {})
        if p.grant["paths"]:
            raise CodeError(403, "event_scope", "workspace journal requires unrestricted file scope")
        service.authority.gate(p, "events", {"workspace_id": workspace_id, "after": after})
        return {"events": service.store.events(workspace_id, after)}

    @app.websocket("/v1/runs/{id}/stream")
    async def stream(socket: WebSocket, id: str):
        # Tokens never enter URLs. Browser hosts may use oc-cap.<token> as a subprotocol.
        protocols = socket.headers.get("sec-websocket-protocol", "").split(",")
        protocol = next((v.strip() for v in protocols if v.strip().startswith("oc-cap.")), None)
        token = socket.headers.get("authorization", "").removeprefix("Bearer ") or (protocol[7:] if protocol else "")
        if token.startswith("hc1."):
            challenge_id = socket.headers.get("x-omegacode-relay-challenge", "")
            connection = relay_connection(socket.scope)
            target = request_target(socket.scope)
            if (connection is None or target is None
                    or not app.state.relay_challenges.consume(
                        connection, challenge_id, method="GET", path=target, body=b"")):
                await socket.close(code=4403)
                return
        try:
            p = service.authority.authenticate(token, socket.headers.get("x-hive-token"))
            record = await asyncio.to_thread(service.run, p, id)
            ws = service.workspace(record["workspace_id"])
            service.authority.scope(p, "events", ws)
            if p.grant["paths"]:
                raise CodeError(403, "log_scope", "run output requires unrestricted file scope")
        except CodeError:
            await socket.close(code=1008)
            return
        await socket.accept(subprotocol=protocol)
        try:
            hello = await asyncio.wait_for(socket.receive_json(), timeout=10)
            cursor = hello.get("after", 0)
            if type(cursor) is not int or cursor < 0 or cursor > 4194304:
                await socket.close(code=1008)
                return
            while True:
                # Re-authenticate every tick, so an open socket does not survive revocation.
                p = service.authority.authenticate(token, socket.headers.get("x-hive-token"))
                record = await asyncio.to_thread(service.run, p, id)
                root = service.store.root / "runs" / id
                path = root / "output.log"
                if path.exists():
                    with path.open("rb") as log:
                        log.seek(cursor)
                        chunk = log.read(65536)
                    if chunk:
                        cursor += len(chunk)
                        import base64
                        await socket.send_json({"type": "output", "cursor": cursor, "encoding": "base64",
                                                "data": base64.b64encode(chunk).decode()})
                        continue
                if record["status"] not in ("prepared", "starting", "running", "cancel_requested"):
                    await socket.send_json({"type": "exit", "cursor": cursor, "exit_code": record["exit_code"],
                                            "signal": -record["exit_code"] if isinstance(record["exit_code"], int) and record["exit_code"] < 0 else None,
                                            "observed_at": record.get("observed_at"), "status": record["status"],
                                            "process_group": {"pgid": record.get("pgid"), "terminated": record["descendants_terminated"]}})
                    await socket.close()
                    return
                await asyncio.sleep(0.2)
        except WebSocketDisconnect:
            return
        except (CodeError, ValueError, asyncio.TimeoutError):
            await socket.close(code=1008)

    return app
