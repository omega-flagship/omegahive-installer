"""Draft r3.2 host wire binding; not installed, not an authority issuer or ledger.

Only service-authenticated host calls. The caller supplies already-verified hc1
claims and retained launch records. No token decoding, implicit retry, spawn,
settlement inference or production route is introduced.
"""
import copy, json, re
from urllib.parse import urlsplit
import httpx
from omegacode.common import CodeError, canonical, digest
LIMIT = 256 * 1024

def fail(code='proposal_host_shape'):
    raise CodeError(409, code, 'proposal-test host response refused')

def pattern(value, regex):
    if type(value) is not str or re.fullmatch(regex, value) is None:
        fail()
    return value

def integer(value, low=0, high=86400):
    if type(value) is not int or not low <= value <= high:
        fail()
    return value

def sha(value):
    return pattern(value, 'sha256:[0-9a-f]{64}')

def test_id(value):
    return pattern(value, 'pt_[0-9a-f]{24}')

def hold_id(value):
    return pattern(value, 'ph_[0-9a-f]{24}')

def key(value):
    return pattern(value, '[A-Za-z0-9_.:-]{8,120}')

def object_(value):
    if type(value) is not dict:
        fail()
    return value

def snapshot(value):
    try:
        return json.loads(json.dumps(value, allow_nan=False))
    except (ValueError, TypeError):
        fail()

def equal(left, right):
    return canonical(left) == canonical(right)

def launch_binding(verified_claims):
    p = object_(verified_claims.get('proposal_test'))
    names = ('request_id', 'lease_id', 'controller_id', 'execution_goal', 'origin_scope', 'proposal', 'parent', 'fork')
    if any((n not in p for n in names)):
        fail('proposal_host_binding')
    return snapshot({n: p[n] for n in names})

class HostClient:

    def __init__(self, url, service_token, transport=None):
        u = urlsplit(url)
        if u.scheme not in ('http', 'https') or not u.hostname or u.username or u.password or u.query or u.fragment or (u.path not in ('', '/')) or (u.scheme == 'http' and u.hostname not in ('127.0.0.1', 'localhost', '::1')):
            raise ValueError('exact HTTPS or local host origin required')
        if type(service_token) is not str or not service_token or any((c in service_token for c in '\r\n')):
            raise ValueError('service credential required')
        self._url = url.rstrip('/')
        self._token = service_token
        self._http = httpx.Client(timeout=3, follow_redirects=False, transport=transport, trust_env=False)

    def close(self):
        self._http.close()

    def _call(self, method, path, body=None, expected=200, params=None):
        try:
            with self._http.stream(method, self._url + path, json=body, params=params, headers={'Authorization': 'Bearer ' + self._token}) as response:
                if response.status_code != expected:
                    fail('proposal_host_refused')
                raw = bytearray()
                for chunk in response.iter_bytes():
                    raw.extend(chunk)
                    if len(raw) > LIMIT:
                        fail('proposal_host_oversize')

                def unique(pairs):
                    out = {}
                    for (k, v) in pairs:
                        if k in out:
                            fail()
                        out[k] = v
                    return out
                value = json.loads(raw, object_pairs_hook=unique, parse_constant=lambda _: fail())
                return object_(value)
        except (httpx.HTTPError, ValueError, UnicodeError):
            fail('proposal_host_unavailable')

    def status(self, verified_claims):
        claims = snapshot(verified_claims)
        p = object_(claims.get('proposal_test'))
        cap = pattern(claims.get('id'), 'cap_[A-Za-z0-9_-]+')
        tid = test_id(p.get('test_id'))
        stage = p.get('stage')
        if stage not in ('prepare', 'run', 'result') or claims.get('actions') != ['proposal-test'] or 'delegated' in claims or (p.get('controller_id') != claims.get('actor')):
            fail()
        if stage == 'result' and ('grant_id' not in claims or claims['grant_id'] is not None):
            fail()
        result = self._call('GET', '/api/services/capabilities/' + cap)
        if result.get('id') != cap or result.get('active') is not True or result.get('reason') is not None or (result.get('stage') != stage) or (not equal(result.get('claims'), claims)):
            fail('proposal_host_inactive')
        lease = object_(result.get('lease'))
        test = object_(result.get('test'))
        origin = object_(result.get('origin'))
        if lease.get('lease_id') != p.get('lease_id') or lease.get('state') not in ('active', 'expired', 'revoked', 'replaced') or test.get('test_id') != tid or (test.get('state') not in ('open', 'ended')) or (origin.get('grant') not in ('active', 'withdrawn')) or (origin.get('task') not in ('open', 'closed')) or (origin.get('request') not in ('open', 'closed')):
            fail()
        if stage != 'result' and (lease['state'] != 'active' or test['state'] != 'open' or origin != dict(grant='active', task='open', request='open')):
            fail('proposal_host_inactive')
        fork = object_(p.get('fork'))
        if 'bound_fork' not in test or 'fork_workspace_id' in test:
            fail('proposal_host_shape')
        bound = test['bound_fork']
        if bound is not None:
            if type(bound) is not dict or set(bound) != {'workspace_id', 'preparation_digest'}:
                fail()
            pattern(bound['workspace_id'], 'ws_[0-9a-f]{32}')
            sha(bound['preparation_digest'])
        if stage == 'prepare':
            if fork != dict(workspace_id=None, preparation_digest=None):
                fail('proposal_host_binding')
        elif stage == 'run':
            if fork.get('workspace_id') is None or not equal(fork, bound):
                fail('proposal_host_binding')
        elif fork.get('workspace_id') is not None and (not equal(fork, bound)):
            fail('proposal_host_binding')
        if stage == 'run' and test.get('admission_closed') is not None:
            fail('proposal_host_inactive')
        return snapshot(result)

    def admit(self, tid, capability_id, launch_key, argv, runtime_seconds):
        tid = test_id(tid)
        cap = pattern(capability_id, 'cap_[A-Za-z0-9_-]+')
        launch_key = key(launch_key)
        if type(argv) is not list or not argv or any((type(a) is not str or '\x00' in a for a in argv)):
            fail()
        seconds = integer(runtime_seconds, 1, 600)
        body = dict(capability_id=cap, launch_key=launch_key, argv_digest='sha256:' + digest(canonical(argv)), runtime_seconds=seconds)
        r = self._call('POST', f'/api/services/proposal-tests/{tid}/holds', body, expected=201)
        hold_id(r.get('hold_id'))
        if r.get('launch_key') != launch_key or r.get('state') != 'dispatched' or type(r.get('runtime_seconds')) is not int or (r['runtime_seconds'] != seconds):
            fail('proposal_host_binding')
        object_(r.get('allowance'))
        return snapshot(r)

    def lookup(self, tid, launch_key):
        tid = test_id(tid)
        launch_key = key(launch_key)
        r = self._call('GET', f'/api/services/proposal-tests/{tid}/holds', params={'launch_key': launch_key})
        if set(r) != {'hold'}:
            fail()
        if r['hold'] is None:
            return None
        return self._row(r['hold'], tid, launch_key)

    def hold(self, tid, hid, launch_key):
        tid = test_id(tid)
        hid = hold_id(hid)
        launch_key = key(launch_key)
        r = self._call('GET', f'/api/services/proposal-tests/{tid}/holds/{hid}')
        row = self._row(r, tid, launch_key)
        if row['id'] != hid:
            fail('proposal_host_binding')
        return row

    def _row(self, r, tid, launch_key):
        r = object_(r)
        hold_id(r.get('id'))
        if r.get('test_id') != tid or r.get('launch_key') != launch_key or r.get('state') not in ('dispatched', 'settled', 'released', 'unknown'):
            fail('proposal_host_binding')
        sha(r.get('argv_digest'))
        integer(r.get('runtime_seconds_max'), 1, 600)
        return snapshot(r)

    def projection(self, row, launch):
        """Normalize the current retained host row for existing Custody.attach_hold."""
        row = self._row(row, launch['test_id'], launch['launch_key'])
        if row['argv_digest'] != 'sha256:' + digest(canonical(launch['argv'])) or row['runtime_seconds_max'] != launch['runtime_seconds']:
            fail('proposal_host_binding')
        return dict(hold_id=row['id'], test_id=row['test_id'], launch_key=row['launch_key'], argv_digest=row['argv_digest'][7:], runtime_seconds=row['runtime_seconds_max'], state=row['state'])

    def dispatch_gate(self, verified_claims, launch):
        """Fresh status + current hold for the existing custody pre-spawn CAS.

        No positive is cached. Caller still must perform Custody.claim_dispatch.
        A result claim can recover/cancel, never reach this gate.
        """
        if verified_claims.get('proposal_test', {}).get('stage') != 'run':
            fail('proposal_host_inactive')
        tid = verified_claims['proposal_test']['test_id']
        if launch['test_id'] != tid or not equal(launch.get('binding'), launch_binding(verified_claims)):
            fail('proposal_host_binding')
        self.status(verified_claims)
        row = self.hold(tid, launch['hold_id'], launch['launch_key'])
        self.projection(row, launch)
        return row['state'] == 'dispatched'
