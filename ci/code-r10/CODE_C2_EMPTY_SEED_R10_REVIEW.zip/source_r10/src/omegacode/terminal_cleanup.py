"""Observe original/PTY groups AND all jobs in this exact helper-owned session."""
import os,signal,subprocess,time
from .runner import group_members


def capture(master,proc,original_pgid):
    session=os.getsid(0);groups={original_pgid}
    if session != os.getpid():
        raise RuntimeError('terminal helper must own its private session')
    if master is not None:
        try:groups.add(os.tcgetpgrp(master))
        except OSError:pass
    if proc is not None and proc.poll() is None:
        try:groups.add(os.getpgid(proc.pid))
        except ProcessLookupError:pass
    return {'session_id':session,'process_groups':sorted(g for g in groups if g>1),
            'scope':'all non-zombie jobs in exact helper-owned session plus captured group checks; no detached-session claim'}


def session_members(session):
    inspector=subprocess.Popen(['/bin/ps','-axo','pid=,stat='],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:out,_=inspector.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        inspector.kill();inspector.communicate();raise RuntimeError('session observation timed out')
    if inspector.returncode:raise RuntimeError('session observation failed')
    found=[]
    for line in out.splitlines():
        p=line.split()
        if len(p)!=2 or p[1].startswith('Z'):continue
        pid=int(p[0])
        if pid in (os.getpid(),inspector.pid):continue
        try:
            if os.getsid(pid)==session:found.append(pid)
        except ProcessLookupError:pass
    return found


def clean(context):
    me=os.getpid();session=context['session_id'];groups=context['process_groups']
    if session!=os.getsid(0) or session!=me:
        return {**context,'observed_stopped':False,'refusal':'not_owning_helper_session'}
    def members():
        found=set(session_members(session))
        for group in groups:
            for pid in group_members(group):
                if pid==me:continue
                try:
                    if os.getsid(pid)!=session:raise RuntimeError('foreign session: refuse cleanup')
                except ProcessLookupError:continue
                found.add(pid)
        return sorted(found)
    try:
        for sig,seconds in [(signal.SIGTERM,1),(signal.SIGKILL,2)]:
            for pid in members():
                try:
                    if os.getsid(pid)!=session:raise RuntimeError('session changed: refuse cleanup')
                    os.kill(pid,sig)
                except ProcessLookupError:pass
            until=time.monotonic()+seconds
            while time.monotonic()<until:
                if not members():return {**context,'observed_stopped':True}
                time.sleep(.03)
        return {**context,'observed_stopped':not members()}
    except (OSError,RuntimeError):return {**context,'observed_stopped':False}
