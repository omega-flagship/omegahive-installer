"""Read-only custody check; host supplies action context and authorized reads."""
import hashlib,json
from .studio_actions import read_source
from .protocol import revision_ref
from .source_io import decode_source_input


def reconcile_output(ctx, output):
    command=getattr(ctx,'command',None) or {}
    actor=getattr(ctx,'actor',None) or {}
    if not actor.get('id') or (actor.get('kind')=='person' and not actor.get('principal')) or not command.get('record_id') or not isinstance(command.get('params'),dict):
        raise ValueError('Host action context required')
    params=command['params'];operation=command.get('action')
    if operation not in {'init','revise','direction','reuse-identity','select','merge','svg','ui','react','save-source','motion'}:
        raise ValueError('Supported output action required')
    revision_ref(output)
    record=ctx.read_revision(output['artifact_id'],output['revision'])
    raw=record['body'].encode()
    if len(raw)>256*1024 or record['digest']!=output['digest'] or 'sha256:'+hashlib.sha256(raw).hexdigest()!=output['digest']:
        raise ValueError('Exact output revision differs')
    manifest=json.loads(raw)
    expected_schema='omega-motion-artifact-1' if operation=='motion' else 'omega-studio-export-1' if operation in {'svg','ui','react'} else 'omega-studio-source-pointer-1'
    if manifest.get('schema')!=expected_schema or manifest.get('action_record')!=command['record_id'] or manifest.get('operation')!=operation or manifest.get('goal_id')!=params.get('goal_id') or manifest.get('source')!=params.get('source') or manifest.get('incoming_source')!=params.get('incoming_source') or manifest.get('adopted') is not False:
        raise ValueError('Output action binding differs')
    if operation=='motion':
        source=read_source(ctx,params['source']);assets=manifest.get('assets');delivery=manifest.get('delivery')
        if not isinstance(assets,list) or len(assets)!=3 or not isinstance(delivery,dict) or delivery.get('schema')!='omega-motion-delivery-1' or delivery.get('adopted') is not False or delivery.get('independent_review') is not False:
            raise ValueError('Motion output manifest differs')
        names=['editable-motion.json','animated-motion.svg','manifest.json'];mimes=['application/json','image/svg+xml','application/json'];total=0;blobs=[]
        for name,mime,asset in zip(names,mimes,assets):
            if not isinstance(asset,dict) or set(asset)!={'sha256','mime','bytes'} or asset['mime']!=mime or type(asset['bytes']) is not int or not 0<asset['bytes']<=30*1024*1024:raise ValueError('Bounded motion asset required')
            total+=asset['bytes']
            if total>30*1024*1024:raise ValueError('Motion assets exceed limit')
            stored=ctx.read_asset(asset['sha256'],output['artifact_id'],output['revision']);data=stored['data']
            if not isinstance(data,bytes) or len(data)!=asset['bytes'] or stored['bytes']!=asset['bytes'] or stored['mime']!=mime or hashlib.sha256(data).hexdigest()!=asset['sha256']:raise ValueError('Exact motion asset differs')
            if name!='manifest.json' and delivery.get('files',{}).get(name)!={'digest':'sha256:'+asset['sha256'],'bytes':asset['bytes'],'mime':mime}:raise ValueError('Motion delivery binding differs')
            blobs.append(data)
        if blobs[0]!=source or json.loads(blobs[2])!=delivery:raise ValueError('Motion source or delivery bytes differ')
        return {'schema':'omega-output-custody-reconciliation-1','output':dict(output),'action_record':command['record_id'],'custody':'verified-accessible-output','action_completion':'unconfirmed','replay_allowed':False,'adopted':False}
    if operation=='save-source':
        if actor.get('kind')!='person':raise ValueError('Person save reconciliation requires person context')
        if params.get('source') is not None:read_source(ctx,params['source'])
    else:read_source(ctx,params['source'])
    if operation=='merge':read_source(ctx,params['incoming_source'])
    asset=manifest['asset'];stored=ctx.read_asset(asset['sha256'],output['artifact_id'],output['revision'])
    data=stored['data']
    if not isinstance(data,bytes) or len(data)!=asset['bytes'] or stored['bytes']!=asset['bytes'] or stored['mime']!=asset['mime'] or hashlib.sha256(data).hexdigest()!=asset['sha256']:
        raise ValueError('Exact output asset differs')
    if operation=='save-source':
        submitted=json.dumps(decode_source_input(params),sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if hashlib.sha256(submitted).hexdigest()!=asset['sha256']:raise ValueError('Person editable source differs')
    return {'schema':'omega-output-custody-reconciliation-1','output':dict(output),
            'action_record':command['record_id'],'custody':'verified-accessible-output',
            'action_completion':'unconfirmed','replay_allowed':False,'adopted':False}
