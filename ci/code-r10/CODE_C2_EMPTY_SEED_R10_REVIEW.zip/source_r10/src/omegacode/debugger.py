"""Bounded trusted-native DAP driver. Internal adapter, not an authenticated service API.

The future run bridge must freeze source/provider identity and require execution
approval for the whole session, including inspection (Python repr can execute).
No arbitrary attach/evaluate/setVariable/terminal reverse request is supported.
"""
import json
import os
import pathlib
import selectors
import signal
import subprocess
import time

from .common import CodeError, canonical, safe_path
from .runner import group_members

MAX_MESSAGE = 1024 * 1024
MAX_TOTAL = 4 * 1024 * 1024
COMMANDS = {'initialize', 'launch', 'setBreakpoints', 'configurationDone', 'threads',
            'stackTrace', 'scopes', 'variables', 'next', 'stepIn', 'stepOut', 'continue', 'pause', 'disconnect'}


class Dap:
    def __init__(self, argv, root, lifetime=60):
        if not 1 <= lifetime <= 120: raise ValueError('debugger lifetime must be 1 to 120 seconds')
        self.root = pathlib.Path(root).resolve()
        self.deadline = time.monotonic() + lifetime
        self.seq, self.frames, self.received = 0, 0, 0
        self.buffer, self.events, self.responses, self.pending = bytearray(), [], {}, {}
        self.closed = False
        self.targets, self.launch_requested = set(), False
        for name in ('home', 'tmp'): (self.root / name).mkdir(exist_ok=True)
        self.proc = subprocess.Popen(argv, cwd=self.root/'tree', stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, start_new_session=True,
            env={'PATH': os.defpath, 'LANG': 'C.UTF-8', 'HOME': str(self.root/'home'),
                 'TMPDIR': str(self.root/'tmp'), 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1'})
        for stream in (self.proc.stdin, self.proc.stdout): os.set_blocking(stream.fileno(), False)
        self.selector = selectors.DefaultSelector(); self.selector.register(self.proc.stdout, selectors.EVENT_READ)

    def _send(self, message):
        if self.closed: raise CodeError(409, 'debugger_closed', 'debugger is closed')
        self.seq += 1
        raw = canonical({'seq': self.seq, **message})
        if len(raw) > MAX_MESSAGE: raise CodeError(413, 'debugger_limit', 'DAP request is too large')
        packet = f'Content-Length: {len(raw)}\r\n\r\n'.encode() + raw
        offset = 0
        end = min(self.deadline, time.monotonic() + 5)
        with selectors.DefaultSelector() as writable:
            writable.register(self.proc.stdin, selectors.EVENT_WRITE)
            while offset < len(packet):
                if time.monotonic() >= end: raise CodeError(504, 'debugger_timeout', 'DAP send deadline exceeded')
                if writable.select(.02):
                    try: offset += os.write(self.proc.stdin.fileno(), packet[offset:])
                    except BlockingIOError: pass
                    except BrokenPipeError: raise CodeError(502, 'debugger_exit', 'DAP adapter ended') from None
        return self.seq

    def begin(self, command, arguments=None):
        if command not in COMMANDS: raise CodeError(400, 'debugger_command', 'unsupported DAP operation')
        if len(self.pending) >= 16: raise CodeError(429, 'debugger_limit', 'too many pending DAP requests')
        if command == 'launch': self.launch_requested = True
        id_ = self._send({'type': 'request', 'command': command, 'arguments': arguments or {}})
        self.pending[id_] = command
        return id_

    def _receive(self, end):
        while time.monotonic() < end:
            boundary = self.buffer.find(b'\r\n\r\n')
            if boundary > 8192 or boundary < 0 and len(self.buffer) > 8192:
                raise CodeError(502, 'debugger_protocol', 'oversized DAP header')
            if boundary >= 0:
                try:
                    pairs = [line.split(b':', 1) for line in self.buffer[:boundary].split(b'\r\n')]
                    lengths = [int(v.strip()) for k,v in pairs if k.lower() == b'content-length']
                    if len(lengths) != 1 or not 0 < lengths[0] <= MAX_MESSAGE: raise ValueError()
                except (ValueError, TypeError): raise CodeError(502, 'debugger_protocol', 'invalid DAP header') from None
                limit = boundary+4+lengths[0]
                if len(self.buffer) >= limit:
                    try: message = json.loads(self.buffer[boundary+4:limit])
                    except (ValueError, UnicodeDecodeError): raise CodeError(502, 'debugger_protocol', 'invalid DAP JSON') from None
                    del self.buffer[:limit]; self.frames += 1
                    if (self.frames > 2048 or not isinstance(message, dict) or type(message.get('seq')) is not int
                            or message['seq'] < 1 or message.get('type') not in ('response', 'event', 'request')):
                        raise CodeError(502, 'debugger_protocol', 'invalid DAP message')
                    return message
            if self.selector.select(.02):
                chunk = os.read(self.proc.stdout.fileno(), 65536)
                if not chunk: raise CodeError(502, 'debugger_exit', 'DAP adapter ended before responding')
                self.received += len(chunk)
                if self.received > MAX_TOTAL: raise CodeError(413, 'debugger_limit', 'DAP output budget exceeded')
                self.buffer.extend(chunk)
        raise CodeError(504, 'debugger_timeout', 'DAP receive deadline exceeded')

    def _pump(self, end):
        message = self._receive(end)
        kind = message['type']
        if kind == 'request':
            # Never honor runInTerminal/startDebugging or any adapter-initiated effect.
            self._send({'type': 'response', 'request_seq': message['seq'], 'command': message.get('command', ''),
                        'success': False, 'message': 'Reverse requests are unsupported'})
        elif kind == 'response':
            id_ = message.get('request_seq')
            if type(id_) is not int or self.pending.get(id_) != message.get('command') or id_ in self.responses:
                raise CodeError(502, 'debugger_protocol', 'unmatched DAP response')
            if type(message.get('success')) is not bool:
                raise CodeError(502, 'debugger_protocol', 'DAP response has no success flag')
            self.responses[id_] = message
        else:
            if not isinstance(message.get('event'), str): raise CodeError(502, 'debugger_protocol', 'invalid DAP event')
            if message['event'] == 'process':
                pid = message.get('body', {}).get('systemProcessId')
                if type(pid) is not int or pid <= 1:
                    raise CodeError(502, 'debugger_protocol', 'invalid local debug target process identity')
                self.targets.add(pid)
            self.events.append(message)
            if len(self.events) > 256: raise CodeError(413, 'debugger_limit', 'DAP event retention budget exceeded')

    def response(self, id_, timeout=10):
        if id_ not in self.pending: raise CodeError(400, 'debugger_request', 'unknown pending DAP request')
        end = min(self.deadline, time.monotonic()+timeout)
        while id_ not in self.responses: self._pump(end)
        message = self.responses.pop(id_); self.pending.pop(id_)
        if not message['success']: raise CodeError(422, 'debugger_refused', 'DAP adapter refused operation', {'command':message['command']})
        return message.get('body', {})

    def request(self, command, arguments=None, timeout=10):
        return self.response(self.begin(command, arguments), timeout)

    def event(self, name, timeout=10):
        end = min(self.deadline, time.monotonic()+timeout)
        while True:
            for i, message in enumerate(self.events):
                if message['event'] == name: return self.events.pop(i).get('body', {})
            self._pump(end)

    def launch_python(self, executable, program, lines=()):
        name = safe_path(program)
        path = (self.root/'tree'/name).resolve()
        if not path.is_relative_to(self.root/'tree') or not path.is_file():
            raise CodeError(403, 'debugger_source', 'debug target must be a saved file inside the execution tree')
        if len(lines) > 100 or any(type(n) is not int or not 1 <= n <= 100000 for n in lines) or len(set(lines)) != len(lines):
            raise CodeError(400, 'debugger_breakpoints', 'use at most 100 unique positive line numbers')
        capabilities = self.request('initialize', {'adapterID':'python', 'clientID':'omegacode', 'pathFormat':'path',
            'linesStartAt1':True, 'columnsStartAt1':True, 'supportsRunInTerminalRequest':False})
        if capabilities.get('supportsConfigurationDoneRequest') is not True:
            raise CodeError(422, 'debugger_capability', 'adapter does not support configuration completion')
        launching = self.begin('launch', {'program':str(path), 'python':[str(executable)], 'cwd':str(self.root/'tree'),
            'console':'internalConsole', 'redirectOutput':True, 'justMyCode':True, 'subProcess':False, 'stopOnEntry':False})
        self.event('initialized')
        points = self.request('setBreakpoints', {'source':{'path':str(path)}, 'breakpoints':[{'line':n} for n in lines]})
        self.request('configurationDone'); self.response(launching)
        return points

    def close(self):
        if self.closed: return
        # Stop authority has its own cleanup deadline after execution expires.
        self.deadline = time.monotonic()+3
        try:
            self.request('disconnect', {'terminateDebuggee': True}, timeout=1)
        except (CodeError, OSError): pass
        observed = False
        try:
            # Keep the owned adapter unreaped through group cleanup, preventing PID reuse.
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try: os.killpg(self.proc.pid, sig)
                except (ProcessLookupError, PermissionError): pass
                end = time.monotonic()+1
                while time.monotonic() < end:
                    try: observed = not group_members(self.proc.pid)
                    except (OSError, RuntimeError, subprocess.SubprocessError): observed = False
                    if observed: break
                    time.sleep(.02)
                if observed: break
        finally:
            self.closed = True; self.selector.close()
            try: self.proc.wait(timeout=1)
            except subprocess.TimeoutExpired: observed = False
            for stream in (self.proc.stdin, self.proc.stdout): stream.close()
        targets_stopped = not self.launch_requested or bool(self.targets)
        end = time.monotonic()+2
        while self.targets and time.monotonic() < end:
            try: targets_stopped = all(not group_members(pid) for pid in self.targets)
            except (OSError, RuntimeError, subprocess.SubprocessError): targets_stopped = False
            if targets_stopped: break
            time.sleep(.02)
        if not observed or not targets_stopped:
            raise CodeError(503, 'debugger_cleanup_unknown', 'DAP adapter/observed target process-group stop could not be confirmed')
