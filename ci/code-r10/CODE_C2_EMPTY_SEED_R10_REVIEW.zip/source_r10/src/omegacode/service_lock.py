"""Validated lifetime ownership of the existing daemon service.lock primitive."""
import fcntl,os,stat
from pathlib import Path

class LockError(RuntimeError):pass

class ServiceLock:
    def __init__(self,root):
        self.root=Path(root).resolve(strict=True);self.pid=os.getpid();self.fd=None;self.directory=None
        try:
            self.directory=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            self.root_identity=self._identity(os.fstat(self.directory))
            self.fd=os.open('service.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.directory)
            meta=os.fstat(self.fd)
            if not stat.S_ISREG(meta.st_mode) or meta.st_nlink!=1 or meta.st_uid!=os.getuid() or meta.st_mode&0o077:
                raise LockError('invalid daemon lock file')
            self.lock_identity=self._identity(meta)
            fcntl.flock(self.fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            self.check()
        except BaseException:
            self.close();raise

    @staticmethod
    def _identity(meta):return meta.st_dev,meta.st_ino

    def check(self):
        try:
            if self.fd is None or self.directory is None or os.getpid()!=self.pid:
                raise LockError('daemon ownership is unavailable in this process')
            root=os.stat(self.root,follow_symlinks=False)
            lock=os.stat('service.lock',dir_fd=self.directory,follow_symlinks=False)
            held=os.fstat(self.fd)
            if (self._identity(root)!=self.root_identity or not stat.S_ISDIR(root.st_mode)
                    or self._identity(lock)!=self.lock_identity or self._identity(held)!=self.lock_identity
                    or not stat.S_ISREG(lock.st_mode) or lock.st_nlink!=1 or lock.st_mode&0o077):
                raise LockError('daemon ownership path changed')
        except OSError as error:raise LockError('daemon ownership cannot be observed') from error
        return self

    def close(self):
        # A forked child must not explicitly unlock the parent's shared open-file
        # description. Closing its copy leaves the parent's descriptor locked.
        if self.fd is not None:
            fd,self.fd=self.fd,None
            try:
                if os.getpid()==self.pid:fcntl.flock(fd,fcntl.LOCK_UN)
            finally:os.close(fd)
        if self.directory is not None:
            fd,self.directory=self.directory,None;os.close(fd)

    def __enter__(self):return self.check()
    def __exit__(self,*_):self.close()
