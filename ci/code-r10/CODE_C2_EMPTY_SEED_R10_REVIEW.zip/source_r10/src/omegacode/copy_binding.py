"""Exact Platform copy_apply seam validator. Does not authenticate a token,
change Authority, or grant general edit. status_reader is the server's existing
authenticated capability-status client, not input from the browser.
"""
import re
import time
import math

from omegacode.common import CodeError, digest


def validate_binding(principal, workspace, payload, *, audience, status_reader, now=None):
    g = principal.grant
    now = time.time() if now is None else now
    try:
        if (principal.operator or g['iss'] != 'hive' or g['aud'] != audience or g['kind'] != 'agent'
                or g['actor'] != principal.actor or g['actions'] != ['proposal-apply']
                or 'delegated' in g or 'proposal_test' in g or g['argv_prefixes'] != []
                or type(g['max_runs']) is not int or g['max_runs'] != 0
                or type(g['max_runtime_seconds']) is not int or g['max_runtime_seconds'] != 0
                or not principal.hive_token or g['member_hash'] != digest(principal.hive_token.encode())
                or any(type(g[k]) not in (int, float) or not math.isfinite(g[k]) for k in ('iat', 'exp'))
                or not 0 < g['exp'] - g['iat'] <= 300
                or not now < g['exp'] <= now + 300):
            raise ValueError('capability ceiling')
        c = g['copy_apply']
        if set(c) != {'purpose', 'operation_id', 'request_id', 'lease_id', 'controller_id',
                      'execution_goal', 'issuer', 'origin_grant_id', 'origin', 'proposal', 'expected'}:
            raise ValueError('closed purpose claims')
        if (c['purpose'] != 'workspace-copy-apply' or c['controller_id'] != principal.actor
                or c['origin_grant_id'] != g['grant_id'] or not g['grant_id']
                or not c['lease_id'] or not c['execution_goal'] or not c['issuer'].startswith('user:')
                or c['issuer'] == 'user:operator'
                or not re.fullmatch(r'[A-Za-z0-9_.:-]{8,120}', c['operation_id'])
                or c['operation_id'] != payload['operation_id'] or c['request_id'] != payload['request_id']):
            raise ValueError('request binding')
        origin = c['origin']
        if (set(origin) != {'task_id', 'repository_id', 'workspace_id', 'scope_id', 'scope_digest'}
                or any(g[k] != workspace[k] for k in ('task_id', 'swarm_id', 'repository_id'))
                or any(origin[k] != workspace[k] for k in ('task_id', 'repository_id'))
                or origin['workspace_id'] != workspace['id']
                or origin['scope_id'] != payload['scope_id'] or origin['scope_digest'] != payload['scope_digest']
                or not re.fullmatch(r'ws_[0-9a-f]{32}', origin['workspace_id'])
                or not re.fullmatch(r'sha256:[0-9a-f]{64}', origin['scope_digest'])):
            raise ValueError('origin binding')
        if (c['proposal'] != {k: payload[k] for k in ('suggestion_id', 'suggestion_digest')}
                or c['expected'] != {'generation': payload['expected_generation'],
                                     'tree_digest': payload['expected_tree_digest']}
                or type(c['expected']['generation']) is not int or c['expected']['generation'] < 1
                or not re.fullmatch(r'suggestion_[0-9a-f]{32}', payload['suggestion_id'])
                or not re.fullmatch(r'[0-9a-f]{64}', payload['suggestion_digest'])
                or not re.fullmatch(r'[0-9a-f]{64}', payload['expected_tree_digest'])):
            raise ValueError('proposal binding')
    except (ValueError, KeyError, TypeError, AttributeError):
        raise CodeError(403, 'copy_apply_binding_invalid', 'purpose claims do not match this exact application') from None
    if status_reader is None:
        raise CodeError(503, 'copy_apply_status_unavailable', 'live capability status is required')
    status = status_reader(g['id'])
    if (not isinstance(status, dict) or status.get('active') is not True or status.get('claims') != g):
        raise CodeError(403, 'host_capability_inactive', 'host capability is inactive or mismatched')
    return True
