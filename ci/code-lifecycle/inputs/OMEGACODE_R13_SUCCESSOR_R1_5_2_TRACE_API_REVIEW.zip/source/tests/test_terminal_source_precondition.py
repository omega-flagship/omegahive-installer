import base64
import sys
import time
import uuid

import pytest
from pydantic import ValidationError
from omegacode.api import TerminalControl
from omegacode.common import CodeError
from test_service import repo, service, principal, workspace, edit


def active_run(service, p, ws):
    run_id = 'run_' + uuid.uuid4().hex
    run = {
        'id': run_id, 'workspace_id': ws['id'], 'terminal': True, 'status': 'running',
        'argv': [sys.executable], 'timeout_seconds': 60, 'generation': ws['generation'],
        'tree_digest': ws['tree_digest'], 'nonce': 'launch_' + uuid.uuid4().hex,
        'grant_id': p.grant['id'], 'created_at': time.time(), 'actor': p.actor,
    }
    service.store.put('run', run)
    return run


def input_payload(precondition, operation_id='step-input'):
    return {
        'operation_id': operation_id,
        'kind': 'input',
        'data_base64': base64.b64encode(b'{"op":"step-next"}\n').decode(),
        'source_precondition': precondition,
    }


def test_terminal_input_precondition_is_checked_atomically_and_exact_retry_replays(service, monkeypatch):
    monkeypatch.setattr(service, "reconcile", lambda: None)
    p, _ = principal(service)
    ws = workspace(service, p)
    run = active_run(service, p, ws)
    precondition = {'workspace_id': ws['id'], 'generation': ws['generation'], 'tree_digest': ws['tree_digest']}

    accepted = service.terminal_control(p, run['id'], input_payload(precondition))
    assert accepted['status'] == 'queued'
    assert service.terminal_control(p, run['id'], input_payload(precondition)) == accepted
    assert len([x for x in service.store.list('terminal_control') if x['run_id'] == run['id']]) == 1


def test_changed_workspace_refuses_retry_that_was_never_previously_received(service, monkeypatch):
    monkeypatch.setattr(service, "reconcile", lambda: None)
    p, _ = principal(service)
    ws = workspace(service, p)
    run = active_run(service, p, ws)
    old = {'workspace_id': ws['id'], 'generation': ws['generation'], 'tree_digest': ws['tree_digest']}
    # The UI has retained operation_id and body, but the first POST never reached the service.
    edit(service, p, ws, 'print("changed")\n', op='source-changed')

    with pytest.raises(CodeError) as refused:
        service.terminal_control(p, run['id'], input_payload(old, 'retry-after-source-change'))
    assert refused.value.code == 'source_changed'
    assert not [x for x in service.store.list('terminal_control') if x['run_id'] == run['id']]



def test_source_precondition_is_rechecked_after_initial_read_before_atomic_apply(service, monkeypatch):
    monkeypatch.setattr(service, "reconcile", lambda: None)
    p, _ = principal(service)
    ws = workspace(service, p)
    run = active_run(service, p, ws)
    old = {"workspace_id": ws["id"], "generation": ws["generation"], "tree_digest": ws["tree_digest"]}
    original_operation = service._operation

    def interleave(principal, action, selected_ws, payload, apply, validate_result=None):
        if action == "run" and payload.get("source_precondition"):
            # This is the gap between terminal_control's first workspace read and its locked apply.
            edit(service, p, ws, 'print("concurrent change")\n', op="interleaved-head-change")
        return original_operation(principal, action, selected_ws, payload, apply, validate_result)

    monkeypatch.setattr(service, "_operation", interleave)
    with pytest.raises(CodeError) as refused:
        service.terminal_control(p, run["id"], input_payload(old, "interleaved-step-input"))
    assert refused.value.code == "source_changed"
    assert not [x for x in service.store.list("terminal_control") if x["run_id"] == run["id"]]

def test_source_precondition_is_input_only_and_strict(service, monkeypatch):
    monkeypatch.setattr(service, "reconcile", lambda: None)
    p, _ = principal(service)
    ws = workspace(service, p)
    run = active_run(service, p, ws)
    precondition = {"workspace_id": ws["id"], "generation": ws["generation"], "tree_digest": ws["tree_digest"]}
    with pytest.raises(CodeError) as refused:
        service.terminal_control(p, run["id"], {
            "operation_id": "resize-with-pre", "kind": "resize", "rows": 24, "cols": 80,
            "source_precondition": precondition,
        })
    assert refused.value.code == "invalid_source_precondition"
    with pytest.raises(ValidationError):
        TerminalControl.model_validate({
            "operation_id": "bool-generation", "kind": "input", "data_base64": "eA==",
            "source_precondition": {**precondition, "generation": True},
        })
