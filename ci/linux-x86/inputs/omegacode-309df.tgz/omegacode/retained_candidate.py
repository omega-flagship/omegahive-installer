"""Additive read-only retained-V2 candidate envelope SOURCE CANDIDATE.

Original validators are invoked against saved CAS source, never an effect route.
The original-release identity below is lineage, NOT loaded-service attestation.
"""
import json
import math
import sqlite3
from typing import Any, Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .common import CodeError, MAX_FILE, MAX_FILES, MAX_TREE, canonical, digest, safe_path
from .suggestion_creation import validate_create_scope
from .suggestion_validation import prepare_v2, reconstruct_v2

BODY_CAP = 4 * 1024 * 1024
# Outside content, shared workspace/task/scope strings occur at most3/2/1
# additional times. Each is already in the capped body: total<=4*BODY_CAP+fixed.
ENVELOPE_CAP = 4 * BODY_CAP + 16384
SOURCE_CAP = 8 * 1024 * 1024
BASE_RELEASE = "c63d17cb8886a119fd35358108b4fd5daeb16074cdf74de0a108f218a070d319"
SHA = Annotated[str, Field(strict=True, pattern=r"^[a-f0-9]{64}$")]
PREFIX_SHA = Annotated[str, Field(strict=True, pattern=r"^sha256:[a-f0-9]{64}$")]
ID = Annotated[str, Field(strict=True, min_length=1, max_length=BODY_CAP)]
UINT = Annotated[int, Field(strict=True, ge=0, le=2**53)]


def require(condition):
    if condition is not True:
        raise ValueError("candidate_invalid")


def strict_json(value, cap=BODY_CAP):
    """Exact builtin JSON with an aggregate escaped-byte budget before encoding."""
    active, nodes, amount = set(), 0, 0

    def charge(size):
        nonlocal amount
        amount += size
        require(amount <= cap)

    def visit(item, depth):
        nonlocal nodes
        nodes += 1
        require(depth <= 48 and nodes <= 1000000)
        kind = type(item)
        if kind in (dict, list):
            require(id(item) not in active)
            active.add(id(item))
            charge(2 + max(0, len(item)-1) + (len(item) if kind is dict else 0))
            if kind is dict:
                require(all(type(k) is str for k in item))
                for k, v in item.items():
                    visit(k, depth+1); visit(v, depth+1)
            else:
                for v in item: visit(v, depth+1)
            active.remove(id(item))
        elif kind is str:
            require(len(item) <= cap)
            raw = item.encode("utf-8", "strict")
            require(len(raw) <= cap)
            charge(len(json.dumps(item, ensure_ascii=False).encode("utf-8")))
        elif kind is int:
            require(abs(item) <= 2**53); charge(len(str(item)))
        elif kind is float:
            require(math.isfinite(item)); charge(len(json.dumps(item, allow_nan=False)))
        else:
            require(item is None or kind is bool)
            charge(4 if item is None or item is True else 5)

    visit(value, 0)
    raw = canonical(value)
    require(len(raw) <= cap)
    return raw


def decode(raw, cap=BODY_CAP, *, canonical_required=False):
    require(type(raw) is bytes and len(raw) <= cap)

    def pairs(items):
        out = {}
        for key, value in items:
            require(type(key) is str and key not in out)
            out[key] = value
        return out

    def bad(_value):
        raise ValueError("candidate_invalid")

    value = json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs, parse_constant=bad)
    encoded = strict_json(value, cap)
    require(not canonical_required or encoded == raw)
    return value


def fields(value, keys):
    require(type(value) is dict and set(value) == set(keys))


def uint(value, ceiling=2**53):
    require(type(value) is int and 0 <= value <= ceiling)


def text(value):
    require(type(value) is str and 0 < len(value) <= BODY_CAP)
    require(len(value.encode("utf-8", "strict")) <= BODY_CAP)


def hex64(value):
    require(type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value))


def path(value):
    require(type(value) is str)
    try:
        require(safe_path(value) == value)
    except CodeError:
        raise ValueError("candidate_invalid") from None


def binding_shape(value):
    fields(value, ("workspace_id", "task_id", "generation", "tree_digest"))
    text(value["workspace_id"]); text(value["task_id"])
    uint(value["generation"]); require(value["generation"] >= 1); hex64(value["tree_digest"])


def scope_rows(scope):
    require(type(scope) is dict and 1 <= len(scope) <= 100)
    for name, row in scope.items():
        path(name); require(type(row) is dict)
        if row.get("kind") == "edit_text":
            fields(row, ("kind", "ranges", "file_digest")); hex64(row["file_digest"])
            require(type(row["ranges"]) is list and 1 <= len(row["ranges"]) <= 100)
            for pair in row["ranges"]:
                require(type(pair) is list and len(pair) == 2)
                uint(pair[0], MAX_FILE); uint(pair[1], MAX_FILE); require(pair[0] <= pair[1])
        elif row.get("kind") == "create_text":
            fields(row, ("kind", "before", "max_bytes"))
            fields(row["before"], ("kind",)); require(row["before"]["kind"] == "absent")
            uint(row["max_bytes"], MAX_FILE)
        else:
            raise ValueError("candidate_invalid")


def body_shape(body):
    strict_json(body)
    required = {"schema", "binding", "scope_id", "scope_digest", "scope", "max_total_create_bytes", "hunks", "author"}
    require(type(body) is dict and required <= set(body) <= required | {"hunk_groups"})
    require(body["schema"] == "omegacode-scoped-suggestion-v2")
    binding_shape(body["binding"]); text(body["scope_id"]); hex64(body["scope_digest"]); text(body["author"])
    uint(body["max_total_create_bytes"], MAX_FILE); scope_rows(body["scope"])
    require(type(body["hunks"]) is list and 1 <= len(body["hunks"]) <= 1000)
    ids = set()
    for unit in body["hunks"]:
        require(type(unit) is dict)
        kind = unit.get("kind")
        if kind == "edit_text":
            fields(unit, ("kind", "path", "start_byte", "end_byte", "replacement", "before_digest", "expected_file_digest", "id"))
            uint(unit["start_byte"], MAX_FILE); uint(unit["end_byte"], MAX_FILE)
            require(unit["start_byte"] <= unit["end_byte"])
            require(type(unit["replacement"]) is str and len(unit["replacement"].encode("utf-8")) <= MAX_FILE)
            hex64(unit["before_digest"]); hex64(unit["expected_file_digest"])
        elif kind == "create_text":
            fields(unit, ("kind", "path", "content", "content_bytes", "content_digest", "before", "id"))
            require(type(unit["content"]) is str and "\0" not in unit["content"])
            raw = unit["content"].encode("utf-8", "strict")
            uint(unit["content_bytes"], MAX_FILE); hex64(unit["content_digest"])
            require(len(raw) == unit["content_bytes"] and digest(raw) == unit["content_digest"])
            fields(unit["before"], ("kind",)); require(unit["before"]["kind"] == "absent")
        else:
            raise ValueError("candidate_invalid")
        path(unit["path"]); hex64(unit["id"])
        require(unit["id"] not in ids and unit["path"] in body["scope"] and body["scope"][unit["path"]]["kind"] == kind)
        ids.add(unit["id"])
    if "hunk_groups" in body:
        groups = body["hunk_groups"]
        require(type(groups) is list and 1 <= len(groups) <= 500)
        seen = set()
        for group in groups:
            require(type(group) is list and 2 <= len(group) <= len(ids))
            require(all(type(i) is str and i in ids for i in group) and len(set(group)) == len(group))
            require(group == sorted(group) and not seen.intersection(group)); seen.update(group)
        require(groups == sorted(groups))


def validator_identity():
    """Original immutable primitive lineage; current loaded identity is external."""
    return {"profile": "omegacode-retained-v2-consistency/1", "original_release": BASE_RELEASE,
            "normalizer_module": "omegacode.suggestion_validation", "normalizer_function": "prepare_v2",
            "reconstructor_function": "reconstruct_v2",
            "normalizer_source_sha256": "686a899b59421aadae46d4b92ac9373df470d54fd48412d65b3ce16d1bd8e5f0",
            "scope_module": "omegacode.suggestion_creation", "scope_function": "validate_create_scope",
            "scope_source_sha256": "a3912020a8cad3340b21a09b76f229fce3270f646fead928e442110f95165704",
            "loaded_attestation": "external_selection_required"}


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True, revalidate_instances="always")


class CandidateBinding(StrictModel):
    workspace_id: ID
    task_id: ID
    generation: Annotated[int, Field(strict=True, ge=1, le=2**53)]
    tree_digest: SHA


class CandidateValidation(StrictModel):
    schema_marker: Literal["omegacode-retained-v2-validation/1"] = Field(alias="schema")
    status: Literal["retained_consistent"]
    candidate_digest: PREFIX_SHA
    binding: CandidateBinding
    scope_id: ID
    scope_digest: SHA
    validator: dict[str, str]


class RetainedCandidateResponse(StrictModel):
    schema_marker: Literal["omegacode-retained-candidate-envelope/1"] = Field(alias="schema")
    suggestion_id: Annotated[str, Field(strict=True, pattern=r"^suggestion_[a-f0-9]{32}$")]
    workspace_id: ID
    binding: CandidateBinding
    candidate_digest: PREFIX_SHA
    content: dict[str, Any]
    currency: Literal["current", "stale"]
    validation: CandidateValidation

    @model_validator(mode="before")
    @classmethod
    def native_and_bound(cls, value):
        strict_json(value, ENVELOPE_CAP)
        fields(value, ("schema", "suggestion_id", "workspace_id", "binding", "candidate_digest", "content", "currency", "validation"))
        body = value["content"]; body_shape(body)
        validation = value["validation"]
        fields(validation, ("schema", "status", "candidate_digest", "binding", "scope_id", "scope_digest", "validator"))
        candidate = "sha256:" + digest(canonical(body))
        require(value["candidate_digest"] == candidate == validation["candidate_digest"])
        require(value["workspace_id"] == body["binding"]["workspace_id"])
        require(canonical(value["binding"]) == canonical(body["binding"]) == canonical(validation["binding"]))
        require(validation["scope_id"] == body["scope_id"] and validation["scope_digest"] == body["scope_digest"])
        require(canonical(validation["validator"]) == canonical(validator_identity()))
        return value


def parse_candidate_response(raw, *, suggestion_id, workspace_id):
    """Strict wire parser returning immutable canonical bytes, not authentication."""
    text(suggestion_id); text(workspace_id)
    value = decode(raw, ENVELOPE_CAP)
    model = RetainedCandidateResponse.model_validate(value)
    require(model.suggestion_id == suggestion_id and model.workspace_id == workspace_id)
    return strict_json(model.model_dump(by_alias=True), ENVELOPE_CAP)


def scope_shape(ceiling):
    strict_json(ceiling)
    fields(ceiling, ("schema", "workspace_id", "task_id", "generation", "tree_digest", "ranges", "file_digests", "create_files", "destination_evaluation", "max_total_create_bytes", "context_selection", "author"))
    require(ceiling["schema"] == "omegacode-suggestion-scope-v2")
    binding_shape({k: ceiling[k] for k in ("workspace_id", "task_id", "generation", "tree_digest")}); text(ceiling["author"])
    ranges, creates, hashes = ceiling["ranges"], ceiling["create_files"], ceiling["file_digests"]
    require(type(ranges) is dict and type(creates) is dict and type(hashes) is dict and set(ranges) == set(hashes) and not set(ranges).intersection(creates))
    expected = {p: {"kind": "edit_text", "ranges": r, "file_digest": hashes[p]} for p, r in ranges.items()}
    for p, row in creates.items():
        fields(row, ("before", "max_bytes")); expected[p] = {"kind": "create_text", **row}
    scope_rows(expected); uint(ceiling["max_total_create_bytes"], MAX_FILE)
    context = ceiling["context_selection"]
    fields(context, ("policy_digest", "active", "excluded_count", "profile", "authority")); hex64(context["policy_digest"])
    require(type(context["active"]) is bool); uint(context["excluded_count"], MAX_FILES)
    require(context["profile"] == "saved-gitignore-and-explicit-paths-v1" and context["authority"] == "does not widen grants or change direct file/execution authority")
    evaluation = ceiling["destination_evaluation"]
    fields(evaluation, ("generation", "tree_digest", "context_policy_digest", "results"))
    uint(evaluation["generation"]); hex64(evaluation["tree_digest"]); hex64(evaluation["context_policy_digest"])
    require(evaluation["generation"] == ceiling["generation"] and evaluation["tree_digest"] == ceiling["tree_digest"] and evaluation["context_policy_digest"] == context["policy_digest"])
    try:
        issued = validate_create_scope({}, ranges, {p: {"max_bytes": r["max_bytes"]} for p, r in creates.items()}, ceiling["max_total_create_bytes"], evaluation["results"])
    except CodeError:
        raise ValueError("candidate_invalid") from None
    require(canonical(issued["create_files"]) == canonical(creates))
    return expected


def manifest_shape(manifest):
    strict_json(manifest, MAX_TREE)
    fields(manifest, ("files",)); metas = manifest["files"]
    require(type(metas) is dict and len(metas) <= MAX_FILES)
    total = 0
    for name, row in metas.items():
        path(name); fields(row, ("digest", "size", "executable")); hex64(row["digest"])
        uint(row["size"], MAX_FILE); require(type(row["executable"]) is bool); total += row["size"]
    require(total <= MAX_TREE)
    return metas, total


def revalidate(body, ceiling, manifest, files, candidate_digest):
    """Use the original production normalizer/reconstructor and scope validator."""
    body_shape(body); expected_scope = scope_shape(ceiling)
    require(canonical(body["scope"]) == canonical(expected_scope))
    binding = {k: ceiling[k] for k in ("workspace_id", "task_id", "generation", "tree_digest")}
    require(canonical(binding) == canonical(body["binding"]))
    require(body["max_total_create_bytes"] == ceiling["max_total_create_bytes"])
    metas, _total = manifest_shape(manifest)
    require(set(files) == set(ceiling["file_digests"]))
    for name, raw in files.items():
        require(type(raw) is bytes and name in metas and len(raw) == metas[name]["size"] and digest(raw) == metas[name]["digest"] == ceiling["file_digests"][name])
    require(sum(map(len, files.values())) <= SOURCE_CAP)
    requested = {p: {"max_bytes": r["max_bytes"]} for p, r in ceiling["create_files"].items()}
    try:
        issued = validate_create_scope(metas, ceiling["ranges"], requested, ceiling["max_total_create_bytes"], ceiling["destination_evaluation"]["results"])
        require(canonical(issued["create_files"]) == canonical(ceiling["create_files"]))
        proposals = []
        for unit in body["hunks"]:
            keys = ("kind", "path", "start_byte", "end_byte", "replacement", "before_digest") if unit["kind"] == "edit_text" else ("kind", "path", "content")
            proposals.append({k: unit[k] for k in keys})
        by_id = {unit["id"]: i for i, unit in enumerate(body["hunks"])}
        groups = [[by_id[i] for i in group] for group in body["hunk_groups"]] if "hunk_groups" in body else None
        normalized = prepare_v2(binding, files, ceiling, body["scope_id"], body["scope_digest"], proposals, groups, body["author"])
        require(canonical(normalized) == canonical(body))
        reconstruct_v2(body, candidate_digest, binding, files, [unit["id"] for unit in body["hunks"]], existing_paths=metas.keys())
    except CodeError:
        raise ValueError("candidate_invalid") from None


def record_shape(record, *, scope=False):
    strict_json(record)
    keys = ("id", "workspace_id", "digest", "author", "created_at", "issuer_claims") if scope else ("id", "workspace_id", "scope_id", "digest", "author", "created_at")
    fields(record, keys)
    for key in ("id", "workspace_id", "author"): text(record[key])
    if not scope: text(record["scope_id"])
    hex64(record["digest"])
    require(type(record["created_at"]) in (int, float) and math.isfinite(record["created_at"]) and record["created_at"] >= 0)
    if scope: require(type(record["issuer_claims"]) is dict)


def read_candidate(service, principal, workspace_id, suggestion_id):
    """Original authorized read + saved-source consistency, no Store writes."""
    service._check_owner()
    with service.store.lock:
        try:
            text(workspace_id); text(suggestion_id)
            # Preserve the ORIGINAL production read authorization/gate/final-live
            # path. Malformed retained JSON still becomes a finite refusal here.
            projection = service.suggestion(principal, workspace_id, suggestion_id)
            record = projection["record"]; record_shape(record)
            require(record["id"] == suggestion_id and record["workspace_id"] == workspace_id)
            body_raw = service.store.read_blob(record["digest"], workspace_id)
            body = decode(body_raw, canonical_required=True)
            require(canonical(projection["content"]) == body_raw)
            if type(body) is dict and body.get("schema") == "omegacode-scoped-suggestion-v1":
                raise CodeError(409, "candidate_version_unavailable", "retained V2 candidate required")
            body_shape(body)
            current = service.workspace(workspace_id)
            current_raw = strict_json(current)
            binding_shape({"workspace_id": current["id"], "task_id": current["task_id"],
                           "generation": current["generation"], "tree_digest": current["tree_digest"]})
            require(current["id"] == workspace_id)
            require(body["binding"]["workspace_id"] == workspace_id and body["binding"]["task_id"] == current["task_id"])
            scope_record = service.store.get("suggestion_scope", record["scope_id"]); record_shape(scope_record, scope=True)
            require(scope_record["id"] == record["scope_id"] == body["scope_id"] and scope_record["workspace_id"] == workspace_id)
            require(scope_record["digest"] == body["scope_digest"] and record["author"] == body["author"])
            scope_raw = service.store.read_blob(scope_record["digest"], workspace_id)
            ceiling = decode(scope_raw, canonical_required=True)
            if (type(ceiling) is dict and ceiling.get("schema") == "omegacode-suggestion-scope-v2"
                    and ceiling.get("destination_evaluation") is None):
                raise CodeError(409, "candidate_validation_unavailable", "retained validation metadata unavailable")
            scope_shape(ceiling)
            require(scope_record["author"] == ceiling["author"])
            require(canonical({k: ceiling[k] for k in ("workspace_id", "task_id", "generation", "tree_digest")}) == canonical(body["binding"]))
            # Existing issuer/delegated/principal read checks, WITHOUT asserting
            # fresh/current source or invoking a Git/context subprocess.
            bound_scope = service._bound_suggestion_scope(principal, current, record["scope_id"], fresh=False)
            require(canonical(bound_scope) == scope_raw)
            manifest_raw = service.store.read_blob(body["binding"]["tree_digest"], workspace_id)
            manifest = decode(manifest_raw, MAX_TREE, canonical_required=True)
            metas, _total = manifest_shape(manifest)
            files = {}; total = 0
            for name, expected in ceiling["file_digests"].items():
                require(name in metas and metas[name]["digest"] == expected)
                total += metas[name]["size"]; require(total <= SOURCE_CAP)
                files[name] = service.store.read_blob(expected, workspace_id)
            revalidate(body, ceiling, manifest, files, record["digest"])
            candidate = "sha256:" + digest(canonical(body)); require(candidate == "sha256:" + record["digest"])
            result = {"schema": "omegacode-retained-candidate-envelope/1", "suggestion_id": suggestion_id,
                      "workspace_id": workspace_id, "binding": body["binding"], "candidate_digest": candidate,
                      "content": body, "currency": "current" if body["binding"]["generation"] == current["generation"] and body["binding"]["tree_digest"] == current["tree_digest"] else "stale",
                      "validation": {"schema": "omegacode-retained-v2-validation/1", "status": "retained_consistent",
                                     "candidate_digest": candidate, "binding": body["binding"], "scope_id": body["scope_id"],
                                     "scope_digest": body["scope_digest"], "validator": validator_identity()}}
            accepted = RetainedCandidateResponse.model_validate(result).model_dump(by_alias=True)
            record_snapshot = canonical(record); scope_snapshot = canonical(scope_record)
            paths = sorted(body["scope"])
            service._check_owner()
            final_scope = service._bound_suggestion_scope(principal, current, record["scope_id"], fresh=False)
            require(canonical(final_scope) == scope_raw)
            service._authorize(principal, "read", current, {"paths": paths})
            service.authority.gate(principal, "read", {"workspace_id": workspace_id, "resource": "suggestion", "suggestion_id": suggestion_id})
            service._live(principal)
            # Catch gate/host-callback source drift before returning the result.
            require(strict_json(service.workspace(workspace_id)) == current_raw)
            require(canonical(service.store.get("suggestion", suggestion_id)) == record_snapshot)
            require(canonical(service.store.get("suggestion_scope", record["scope_id"])) == scope_snapshot)
            require(service.store.read_blob(record["digest"], workspace_id) == body_raw)
            require(service.store.read_blob(scope_record["digest"], workspace_id) == scope_raw)
            require(service.store.read_blob(body["binding"]["tree_digest"], workspace_id) == manifest_raw)
            for name, expected in ceiling["file_digests"].items():
                require(service.store.read_blob(expected, workspace_id) == files[name])
            # Actual original liveness after the final CAS reads as well. The
            # three bounded metadata reads then reject source drift performed
            # inside that final host callback; no more callbacks follow them.
            service._live(principal)
            require(strict_json(service.workspace(workspace_id)) == current_raw)
            require(canonical(service.store.get("suggestion", suggestion_id)) == record_snapshot)
            require(canonical(service.store.get("suggestion_scope", record["scope_id"])) == scope_snapshot)
            return accepted
        except CodeError:
            raise
        except (ValueError, TypeError, KeyError, IndexError, UnicodeError, OverflowError, RecursionError):
            raise CodeError(409, "candidate_invalid", "retained candidate consistency unavailable") from None
        except (OSError, sqlite3.Error):
            raise CodeError(503, "candidate_unavailable", "retained candidate temporarily unavailable") from None
