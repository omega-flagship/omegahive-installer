export async function verifiedPickedImage(msg,selected){
 if(!(msg.bytes instanceof ArrayBuffer)||!selected||msg.handle!==selected.handle||msg.mime!==selected.mime||msg.size!==selected.size||msg.bytes.byteLength!==selected.size||selected.size<1||selected.size>8*1024*1024||!['image/png','image/jpeg','image/webp','image/gif'].includes(selected.mime))throw Error('Picked image binding differs');
 const bytes=new Uint8Array(msg.bytes),signature=[...bytes.slice(0,12)];
 const valid=msg.mime==='image/png'?signature.slice(0,8).join(',')==='137,80,78,71,13,10,26,10':msg.mime==='image/jpeg'?signature[0]===255&&signature[1]===216&&signature[2]===255:msg.mime==='image/gif'?String.fromCharCode(...signature.slice(0,6)).match(/^GIF8[79]a$/):String.fromCharCode(...signature.slice(0,4))==='RIFF'&&String.fromCharCode(...signature.slice(8,12))==='WEBP';
 if(!valid)throw Error('Picked image signature differs');
 const sha=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
 if(sha!==selected.handle)throw Error('Picked image digest differs');
 return {bytes,mime:msg.mime,sha256:sha,name:selected.name};
}
export function mountStudioAssets(container,{post,insert,notice,readSnapshot}){
 const doc=container.ownerDocument,section=doc.createElement('section');section.className='hive-source-panel';
 const title=doc.createElement('h2');title.textContent='Assets';const button=doc.createElement('button');button.type='button';button.textContent='Add image from Hive…';button.disabled=true;
 const hint=doc.createElement('p');hint.textContent='PNG, JPEG, WebP or GIF · embedded editable image · up to 8 MB';section.append(title,button,hint);container.append(section);
 let available=false,pending=null,selection=null,before=null,epoch=0,disposed=false;
 button.onclick=()=>{if(!available||pending||disposed)return;before=JSON.stringify(readSnapshot());pending=crypto.randomUUID();epoch++;post({type:'pick',id:pending,accept:['asset'],kinds:['image/png','image/jpeg','image/webp','image/gif']});button.disabled=true;};
 return {
  context(msg){available=msg.capabilities?.picker===true;if(!available){epoch++;pending=null;selection=null;}button.disabled=!available||!!pending;},
  async receive(msg){
   if(disposed||!pending||msg.id!==pending||!['picked','asset','asset-refused'].includes(msg.type))return false;
   const currentEpoch=epoch,isCurrent=()=>!disposed&&available&&currentEpoch===epoch;
   if(msg.type==='picked'&&!msg.cancelled&&msg.asset){selection=msg.asset;pending=crypto.randomUUID();post({type:'asset-bytes',id:pending,handle:selection.handle});return true;}
   try{if(msg.type==='asset'){const image=await verifiedPickedImage(msg,selection);if(!isCurrent()||JSON.stringify(readSnapshot())!==before)throw Error('Editor changed while reading image; choose it again');await insert(image,{expectedSnapshot:before,isCurrent});if(isCurrent())notice('Image added; save the editable source to keep it.');}else if(isCurrent())notice(msg.reason?'Image unavailable: '+msg.reason:'Image selection cancelled');}
   catch(error){if(isCurrent())notice(error.message);}
   finally{if(isCurrent()){pending=null;selection=null;button.disabled=!available;}}
   return true;
  },dispose(){disposed=true;epoch++;pending=null;section.remove();}
 };
}
