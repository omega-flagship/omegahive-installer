"""Native Mind client: member identity and exact approvals remain owned by Hive."""
import json
import base64
from urllib.parse import quote

import httpx


class NativeClient:
    def __init__(self, hive_url, member_token, code_url="http://127.0.0.1:8724", transport=None):
        self.hive_url, self.code_url = hive_url.rstrip("/"), code_url.rstrip("/")
        self.member_token = member_token
        self.http = httpx.Client(timeout=20, transport=transport, follow_redirects=False)

    def close(self):
        self.http.close()

    def call(self, action, task_id, repository_id, payload):
        """Return structured success/refusal; never return a capability or member token."""
        if not isinstance(payload, dict):
            raise ValueError("payload must be a JSON object")
        ws = quote(str(payload.get("workspace_id", "")), safe="")
        run = quote(str(payload.get("run_id", "")), safe="")
        control = quote(str(payload.get("control_id", "")), safe="")
        export = quote(str(payload.get("export_id", "")), safe="")
        review = quote(str(payload.get("review_id", "")), safe="")
        merge = quote(str(payload.get("preview_id", "")), safe="")
        result_id = quote(str(payload.get('result_id','')), safe='')
        hunk = quote(str(payload.get("hunk_id", "")), safe="")
        digest = quote(str(payload.get("digest", "")), safe="")
        iteration = quote(str(payload.get("iteration_id", "")), safe="")
        suggestion = quote(str(payload.get("suggestion_id", "")), safe="")
        methods = {"function-scope-preview": ("POST", f"/v1/workspaces/{ws}/function-scope-preview"),"iteration-create": ("POST", f"/v1/workspaces/{ws}/iterations"),
                   "iteration-read": ("GET", f"/v1/workspaces/{ws}/iterations/{iteration}"),"workspace": ("POST", "/v1/workspaces"), "workspace-fork": ("POST", f"/v1/workspaces/{ws}/forks"), "read": ("GET", f"/v1/workspaces/{ws}/files"),
                   "suggestion-create": ("POST", f"/v1/workspaces/{ws}/suggestions"),
                   "suggestion-history": ("GET", f"/v1/workspaces/{ws}/suggestions"),
                   "suggestion-read": ("GET", f"/v1/workspaces/{ws}/suggestions/{suggestion}"),
                   "suggestion-before": ("GET", f"/v1/workspaces/{ws}/suggestions/{suggestion}/hunks/{hunk}/before"),
                   "suggestion-decide": ("POST", f"/v1/workspaces/{ws}/suggestion-decisions"),
                   "workspace-list": ("GET", f"/v1/tasks/{quote(str(task_id), safe='')}/workspaces"),
                   "edit": ("POST", f"/v1/workspaces/{ws}/patches"), "run": ("POST", "/v1/runs"),
                   "search": ("POST", f"/v1/workspaces/{ws}/search"),
                   "repository-facts": ("POST", f"/v1/workspaces/{ws}/repository-facts"),
                   "repository-retrieval": ("POST", f"/v1/workspaces/{ws}/repository-retrieval"),
                   "checkpoint": ("POST", f"/v1/workspaces/{ws}/checkpoints"),
                   "run-history": ("GET", f"/v1/workspaces/{ws}/runs"),
                   "verification-history": ("GET", f"/v1/workspaces/{ws}/verifications"),
                   "checkpoint-list": ("GET", f"/v1/workspaces/{ws}/checkpoints"),
                   "restore": ("POST", f"/v1/workspaces/{ws}/restores"),
                   "toolchains": ("GET", f"/v1/workspaces/{ws}/toolchains"),
                   "language-servers": ("GET", f"/v1/workspaces/{ws}/language/servers"),
                   "language-rename-apply": ("POST", f"/v1/workspaces/{ws}/language/renames"),
                   "language-query": ("POST", f"/v1/workspaces/{ws}/language"),
                   "completion-preview": ("POST", f"/v1/workspaces/{ws}/language/completion-previews"),
                   "completion-apply": ("POST", f"/v1/workspaces/{ws}/language/completion-applies"),
                   "diagnostics": ("GET", f"/v1/workspaces/{ws}/diagnostics"),
                   "tree": ("GET", f"/v1/workspaces/{ws}/tree"),
                   "workspace-state": ("GET", f"/v1/workspaces/{ws}"),
                   "git-export": ("POST", f"/v1/workspaces/{ws}/git/exports"),
                   "git-export-state": ("GET", f"/v1/workspaces/{ws}/git/exports/{export}"),
                   "git-export-patch": ("GET", f"/v1/workspaces/{ws}/git/exports/{export}/patch"),
                   "git-context": ("GET", f"/v1/workspaces/{ws}/git/context"),
                   "review-create": ("POST", f"/v1/workspaces/{ws}/reviews"),
                   "review-state": ("GET", f"/v1/workspaces/{ws}/reviews/{review}"),
                   "review-content": ("GET", f"/v1/workspaces/{ws}/reviews/{review}/hunks/{hunk}"),
                   "review-apply": ("POST", f"/v1/workspaces/{ws}/reviews/{review}/apply"),
                   "merge-create": ("POST", f"/v1/workspaces/{ws}/merges"),
                   "merge-state": ("GET", f"/v1/workspaces/{ws}/merges/{merge}"),
                   "merge-content": ("GET", f"/v1/workspaces/{ws}/merges/{merge}/content"),
                   "merge-apply": ("POST", f"/v1/workspaces/{ws}/merges/{merge}/apply"),
                   "changes": ("GET", f"/v1/workspaces/{ws}/changes"),
                   "run-source": ("GET", f"/v1/runs/{run}/source"),
                   "run-result-capture": ('POST', f'/v1/runs/{run}/results'),
                   "run-result-read": ('GET', f'/v1/workspaces/{ws}/run-results/{result_id}'),
                   "run-result-source": ('GET', f'/v1/workspaces/{ws}/run-results/{result_id}/source'),
                   "run-result-import": ('POST', f'/v1/workspaces/{ws}/run-results/{result_id}/import'),
                   "proof-result": ("GET", f"/v1/runs/{run}/proof-result"),
                   "symbolic-trace-result": ("GET", f"/v1/runs/{run}/symbolic-trace-result"),
                   "run-output": ("GET", f"/v1/runs/{run}/output"),
                   "run-status": ("GET", f"/v1/runs/{run}"),
                   "terminal-control": ("POST", f"/v1/runs/{run}/terminal"),
                   "terminal-control-status": ("GET", f"/v1/runs/{run}/terminal/{control}"),
                   "cancel": ("POST", f"/v1/runs/{run}/cancel"),
                   "verify": ("POST", "/v1/verifications"),
                   "artifact": ("GET", f"/v1/artifacts/{digest}"),
                   "events": ("GET", "/v1/events")}
        if action not in methods:
            raise ValueError("unsupported native client operation")
        scoped_action = "run" if action == "terminal-control" else "read" if action == "terminal-control-status" else "edit" if action in ("restore", "completion-apply", "language-rename-apply", "review-apply", "git-export") else "read" if action in ("git-export-state", "git-export-patch", "git-context", "review-create", "review-state", "review-content", "language-servers", "language-query", "completion-preview", "run-history", "verification-history", "diagnostics", "toolchains", "tree", "workspace-state", "changes", "run-status", "run-source", "checkpoint-list") else action
        request = dict(task_id=task_id, repository_id=repository_id, actions=["read", "events"] if action in ("run-output", "proof-result", "symbolic-trace-result") else [scoped_action], ttl_seconds=300)
        if action == 'workspace-fork':
            request['actions'] = ['read','workspace']
        if action == 'function-scope-preview':
            request['actions'] = ['read']
        if action == 'iteration-create':
            request['actions'] = ['checkpoint','read']
        if action == 'run-result-capture':
            request['actions'] = ['checkpoint','read']
        if action in ('run-result-read','run-result-source'):
            request['actions'] = ['read']
        if action == 'run-result-import':
            request['actions'] = ['read','edit']
        if action == 'iteration-read':
            request['actions'] = ['read']
        if action in ('suggestion-create','suggestion-read','suggestion-history','suggestion-before'):
            request['actions'] = ['read']
        if action == 'suggestion-decide':
            request['actions'] = ['read','edit']
        if action in ('workspace-list', 'repository-facts', 'repository-retrieval'):
            request['actions'] = ['read']
        if action == "git-export":
            request["actions"] = ["read", "edit"]
        if action == "merge-create":
            request["actions"] = ["read", "checkpoint"]
        if action in ("merge-state", "merge-content"):
            request["actions"] = ["read"]
        if action == "merge-apply":
            request["actions"] = ["read", "edit"]
        if action in ("run", "terminal-control"):
            request["argv_prefixes"] = [payload["argv"]]
        cap = self.http.post(self.hive_url+"/api/agent/code/capability", json=request,
                             headers={"Authorization":"Bearer "+self.member_token})
        if cap.status_code != 200:
            return {"ok":False,"phase":"capability","http_status":cap.status_code,"result":cap.json()}
        token = cap.json()["token"]
        method, path = methods[action]
        body = dict(payload)
        if action in ('run-result-read','run-result-source'):
            body.pop('result_id',None)
        if action == 'run-result-source':
            body.setdefault('limit',1024)
        if action == 'run-result-capture':
            body.pop('run_id',None)
        if action == "workspace":
            body.update(task_id=task_id, repository_id=repository_id)
        elif action not in ("run", "events", "artifact"):
            body.pop("workspace_id", None)
        if action in ("git-export-state", "git-export-patch"):
            body.pop("export_id", None)
        if action == "iteration-read":
            body.pop("iteration_id",None)
        if action in ('suggestion-read','suggestion-before'):
            body.pop("suggestion_id",None)
        if action == 'suggestion-before':
            body.pop('hunk_id',None)
            body.setdefault('limit',65536)
        if action == "git-export-patch":
            body.setdefault("limit", 1024)
        if action in ("review-state", "review-content"):
            body.pop("review_id", None)
            body.pop("hunk_id", None)
        if action == "review-state":
            body.setdefault("limit", 5)
        if action in ("merge-state", "merge-content"):
            body.pop("preview_id", None)
            body.setdefault("limit", 5 if action == "merge-state" else 1024)
        if action == "review-content":
            body.setdefault("limit", 1024)
        if action in ("run-output", "run-source"):
            body.setdefault("limit", 1024)
        if action == "terminal-control":
            for key in ("argv", "timeout_seconds", "run_generation", "run_tree_digest"):
                body.pop(key, None)
        if action == "terminal-control-status":
            body.pop("control_id", None)
        if action in ("cancel", "run-status", "run-output", "run-source", "proof-result", "symbolic-trace-result", "terminal-control", "terminal-control-status"):
            body.pop("run_id", None)
        if action == "artifact":
            body.pop("digest", None)
        if action == "symbolic-trace-result":
            body = {"after": payload.get("after", 0), "limit": payload.get("limit", 100)}
        response = self.http.request(method, self.code_url+path, params=body if method=="GET" else None,
                                     json=body if method!="GET" else None,
                                     headers={"Authorization":"Bearer "+token,"X-Hive-Token":self.member_token})
        if action == "artifact" and response.is_success:
            result = {"digest": payload["digest"], "size_bytes": len(response.content),
                      "content_base64": base64.b64encode(response.content).decode("ascii")}
            try:
                result["content"] = response.content.decode("utf-8")
            except UnicodeDecodeError:
                pass
        else:
            result = response.json()
        if action in ("git-export", "git-export-state") and response.is_success:
            result["affected_paths_count"] = len(result.pop("paths", []))
            result.pop("message", None)  # Full commit/source metadata stays in service custody.
        if action == "language-query" and payload.get("feature") == "rename" and response.is_success:
            # The full reviewed edit is retained by digest in service custody.
            # Native result windows carry its exact ID and scope, not whole files.
            result.get("result", {}).pop("edits", None)
        if action == 'completion-preview' and response.is_success:
            result.pop('edits', None)  # Full patch stays scoped by exact edit_digest.
            for key in ('replacement', 'replaced_text'):
                value = result.get(key)
                if isinstance(value, str):
                    result[key] = value[:600]
                    result[key + '_truncated'] = len(value) > 600
            if isinstance(result.get('label'), str): result['label'] = result['label'][:160]
            result['preview_text_complete'] = False
        return {"ok":response.is_success,"phase":"operation","http_status":response.status_code,"result":result}


def code_call(action, task_id, repository_id, payload_json):
    """MeTTa membrane entry point. No separate harness loop or goal scheduler."""
    import os
    hive = os.environ.get("HIVE_API_URL")
    member = os.environ.get("HIVE_WS_TOKEN")
    if not hive or not member:
        return json.dumps({"ok":False,"error":"hive_member_not_configured"})
    client = NativeClient(hive, member)
    try:
        return json.dumps(client.call(action, task_id, repository_id, json.loads(payload_json)), sort_keys=True)
    except (httpx.HTTPError, ValueError, KeyError, TypeError):
        return json.dumps({"ok":False,"error":"native_code_request_failed"})
    finally:
        client.close()
