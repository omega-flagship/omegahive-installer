"""Bounded display-only LSP signature help; labels use UTF-16, never file edits."""
from .common import CodeError, canonical


def refuse():
    raise CodeError(502, 'signature_protocol', 'invalid bounded signature help')


def text(value, maximum=8192):
    if type(value) is not str:
        refuse()
    try:
        if len(value.encode('utf-8')) > maximum:
            refuse()
    except UnicodeEncodeError:
        refuse()
    return value


def documentation(value):
    if value is None:
        return None
    if type(value) is dict:
        if value.get('kind') not in ('plaintext', 'markdown'):
            refuse()
        value = value.get('value')
    # Markdown is returned as literal display text, never executable markup.
    return text(value)


def index(value, size):
    if value is None:
        return 0 if size else None
    if type(value) is not int or value < 0:
        refuse()
    return value if value < size else 0 if size else None


def normalize(raw, limit):
    if type(limit) is not int or not 1 <= limit <= 100:
        refuse()
    if raw is None:
        return {'signatures': [], 'active_signature': None, 'active_signature_visible': False,
                'truncated': False, 'rendering': 'plain-text'}
    if type(raw) is not dict or type(raw.get('signatures')) is not list:
        refuse()
    try:
        if len(canonical(raw)) > 262144:
            raise CodeError(413, 'signature_limit', 'signature help exceeds256KiB')
    except (TypeError, ValueError, UnicodeEncodeError):
        refuse()
    signatures = raw['signatures']
    if len(signatures) > 256:
        raise CodeError(413, 'signature_limit', 'too many signatures')
    active = index(raw.get('activeSignature'), len(signatures))
    result = []
    for i, signature in enumerate(signatures):
        if type(signature) is not dict:
            refuse()
        label = text(signature.get('label'))
        encoded = label.encode('utf-16-le')
        parameters = signature.get('parameters', [])
        if type(parameters) is not list or len(parameters) > 64:
            refuse()
        normalized = []
        for parameter in parameters:
            if type(parameter) is not dict:
                refuse()
            value = parameter.get('label')
            span = None
            if type(value) is list:
                if (len(value) != 2 or any(type(n) is not int or n < 0 for n in value) or
                        value[0] > value[1] or value[1]*2 > len(encoded)):
                    refuse()
                try:
                    # Check both endpoints, including zero-length mid-surrogate ranges.
                    encoded[:value[0]*2].decode('utf-16-le')
                    encoded[:value[1]*2].decode('utf-16-le')
                    value_text = encoded[value[0]*2:value[1]*2].decode('utf-16-le')
                except UnicodeDecodeError:
                    refuse()
                span = list(value)
            else:
                value_text = text(value)
                if value_text not in label:
                    refuse()
            normalized.append({'label': value_text, 'label_range': span,
                               'documentation': documentation(parameter.get('documentation'))})
        parameter_index = index(signature.get('activeParameter', raw.get('activeParameter') if i == active else None), len(parameters))
        result.append({'index': i, 'label': label, 'documentation': documentation(signature.get('documentation')),
                       'parameters': normalized, 'active_parameter': parameter_index})
    return {'signatures': result[:limit], 'active_signature': active,
            'active_signature_visible': active is not None and active < limit,
            'truncated': len(result) > limit, 'rendering': 'plain-text'}
