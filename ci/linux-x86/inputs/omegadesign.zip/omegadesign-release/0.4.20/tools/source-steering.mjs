import {verifySource} from './source.mjs';
import {changeBrief} from './brief-change.mjs';
import {initial,clone,digest} from './scene.mjs';
export async function steerSource(input,brief,reason){
 const before=await verifySource(input),transition=await changeBrief(before.project,brief,reason);
 const current=await initial({...clone(before.current.scene),criteria:clone(brief.criteria)});
 return await verifySource({schema:'omega-studio-source-1',current,history:[current],project:transition.after,feedback:[],merge_sources:[],maker_trace:[],
  brief_change:{transition,source:before,source_digest:await digest(before)},adopted:false});
}
