"""NEXT mind Model actions using existing goal/source/sandbox/custody authority.

Source preparation requires Root's genuine locked native exporter before GLB
execution. No provider, automatic adoption, retry ledger or new identity layer.
"""
import asyncio
import contextlib
import hashlib
import json
import math
import re
from .protocol import canonical, digest, validate_brief
from .studio_actions import held, read_source
from .model_delivery import (FILES, MIMES, CAPS, exact_ref, file_record,
                             validate_delivery, read_delivery)

OPERATIONS = ('model-init', 'model-inspect', 'model-revise', 'model-glb')
SOURCE_CAP = 1024 * 1024
PARAMS_CAP = 64 * 1024
INSPECTION_CAP = 64 * 1024
IDENTIFIER = re.compile(r'[A-Za-z0-9_-]{1,128}\Z')
DIGEST = re.compile(r'sha256:[0-9a-f]{64}\Z')


def load_json(raw):
    if not isinstance(raw, bytes):
        raise ValueError('Native bytes required')
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('Duplicate native JSON field')
            out[key] = value
        return out
    def number(value):
        parsed = float(value)
        if not math.isfinite(parsed):
            raise ValueError('Finite native JSON required')
        return parsed
    def invalid(value):
        raise ValueError('Finite native JSON required')
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                      parse_float=number, parse_constant=invalid)


def encoded(value, cap):
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False,
                     sort_keys=True, separators=(',', ':')).encode('utf-8')
    if len(raw) > cap:
        raise ValueError('Model structured input exceeds bound')
    return raw


def model_source(raw):
    if not isinstance(raw, bytes) or not raw or len(raw) > SOURCE_CAP:
        raise ValueError('Bounded host-resolved Model source required')
    source = load_json(raw)
    if (not isinstance(source, dict) or set(source) != {'schema', 'document', 'digest'}
            or source['schema'] != 'omega-model-source-1' or not isinstance(source['document'], dict)
            or not isinstance(source['digest'], str) or not DIGEST.fullmatch(source['digest'])):
        raise ValueError('Exact parametric Model source required')
    return source


def init_arguments(raw, ref):
    request = load_json(raw)
    if (not isinstance(request, dict) or set(request) != {'schema', 'brief', 'document'}
            or request['schema'] != 'omega-model-init-request-1'
            or not isinstance(request['document'], dict)
            or not isinstance(request['document'].get('metadata'), dict)
            or 'creative_work' in request['document']['metadata']):
        raise ValueError('Retained Model init request required')
    brief = validate_brief(request['brief'])
    if brief['mode'] != 'create':
        raise ValueError('Model init creates; refine an existing exact source separately')
    record = {'schema': 'omega-model-creative-work-1', 'brief_json': canonical(brief),
              'brief_digest': digest(brief), 'request_source': dict(exact_ref(ref))}
    # Preserve Python's CreativeWork canonical text/digest domain across JS numeric JSON.
    # This record is immutable provenance/criteria, never effect authority.
    metadata = {**request['document']['metadata'], 'creative_work': record}
    encoded(metadata, 32000)
    return {'creative_work': record}


def source_creative_record(source):
    document = source['document']
    metadata = document.get('metadata')
    if not isinstance(metadata, dict):
        raise ValueError('Model metadata required')
    record = metadata.get('creative_work')
    if record is None:
        return None  # Ordinary person/Flow-originated Model work is still supported.
    if (not isinstance(record, dict) or set(record) != {'schema', 'brief_json', 'brief_digest', 'request_source'}
            or record['schema'] != 'omega-model-creative-work-1' or not isinstance(record['brief_json'], str)):
        raise ValueError('Retained Model creative brief differs')
    brief = validate_brief(load_json(record['brief_json'].encode('utf-8')))
    exact_ref(record['request_source'])
    if record['brief_json'] != canonical(brief) or record['brief_digest'] != digest(brief):
        raise ValueError('Retained Model criteria digest differs')
    return record


def action_arguments(operation, arguments):
    if not isinstance(arguments, dict):
        raise ValueError('Model operation arguments required')
    encoded(arguments, PARAMS_CAP)
    if operation in {'model-init', 'model-glb'} and arguments:
        raise ValueError('This Model action takes no inline source/options')
    if operation == 'model-inspect':
        if set(arguments) - {'offset', 'limit'}:
            raise ValueError('Model inspection paging only')
        if (type(arguments.get('offset', 0)) is not int or not 0 <= arguments.get('offset', 0) <= 100
                or type(arguments.get('limit', 20)) is not int or not 1 <= arguments.get('limit', 20) <= 20):
            raise ValueError('Bounded Model inspection page required')
    if operation == 'model-revise':
        if (set(arguments) != {'expected_digest', 'changes'}
                or not isinstance(arguments['expected_digest'], str) or not DIGEST.fullmatch(arguments['expected_digest'])
                or not isinstance(arguments['changes'], list) or not 1 <= len(arguments['changes']) <= 100):
            raise ValueError('Exact Model change batch required')
    return arguments


def checked_inspection(inspection, source, arguments):
    """Bind bounded native object paging in normal and retained-done paths.

    The codec admits fixed parametric box/sphere/cylinder records, not arbitrary
    mesh arrays. Metadata is represented by its native digest, never echoed.
    """
    names = {'schema', 'model_id', 'model_digest', 'metadata_digest', 'units',
             'title', 'background', 'object_count', 'offset', 'limit', 'objects',
             'creative_brief_digest', 'adopted'}
    document = source['document']
    objects = document.get('objects')
    offset, limit = arguments.get('offset', 0), arguments.get('limit', 20)
    creative = source_creative_record(source)
    if (not isinstance(inspection, dict) or set(inspection) != names
            or inspection['schema'] != 'omega-model-action-inspection-1'
            or inspection['adopted'] is not False
            or inspection['model_id'] != document.get('id')
            or inspection['model_digest'] != source['digest']
            or inspection['units'] != document.get('units') or inspection['units'] != 'metres'
            or inspection['title'] != document.get('title')
            or inspection['background'] != document.get('background')
            or not isinstance(inspection['metadata_digest'], str)
            or not DIGEST.fullmatch(inspection['metadata_digest'])
            or type(inspection['offset']) is not int or inspection['offset'] != offset
            or type(inspection['limit']) is not int or inspection['limit'] != limit
            or not isinstance(objects, list)
            or type(inspection['object_count']) is not int or inspection['object_count'] != len(objects)
            or inspection['objects'] != objects[offset:offset + limit]
            or inspection['creative_brief_digest'] != (creative['brief_digest'] if creative else None)):
        raise ValueError('Model inspection binding differs')
    encoded(inspection, INSPECTION_CAP)
    return inspection


async def execute_model(ctx, operation, raw, arguments, ref):
    if operation not in OPERATIONS or not isinstance(raw, bytes) or not raw or len(raw) > SOURCE_CAP:
        raise ValueError('Bounded native Model action required')
    arguments = action_arguments(operation, arguments)
    native_arguments = init_arguments(raw, ref) if operation == 'model-init' else arguments
    if operation != 'model-init':
        source_creative_record(model_source(raw))
    names = ['inspection.json'] if operation == 'model-inspect' else list(FILES) if operation == 'model-glb' else ['editable-model.json']
    runner = getattr(ctx, 'sandbox_run', None)
    if not callable(runner):
        raise ValueError('Host sandbox capability unavailable')
    result = await runner('model-sandbox-cli.mjs', args=[operation],
                          inputs={'source.json': raw, 'params.json': encoded(native_arguments, PARAMS_CAP)},
                          outputs=names, runtime='node', bundle='tools',
                          cpu_seconds=10, file_bytes=30 * 1024 * 1024, timeout=30)
    if (not isinstance(result, dict) or type(result.get('exit')) is not int or result['exit'] != 0
            or result.get('stdout_truncated') or result.get('missing_outputs')):
        raise ValueError('Native Model execution did not produce complete output')
    outputs = result.get('outputs')
    if (not isinstance(outputs, dict) or set(outputs) != set(names)
            or any(not isinstance(v, bytes) or not v for v in outputs.values())
            or sum(map(len, outputs.values())) > 30 * 1024 * 1024):
        raise ValueError('Exact bounded native Model outputs required')
    if operation == 'model-inspect':
        data = outputs['inspection.json']
        if len(data) > INSPECTION_CAP:
            raise ValueError('Model inspection exceeds bound')
        inspection = checked_inspection(load_json(data), model_source(raw), arguments)
        return {'inspection': inspection, 'adopted': False}
    if len(outputs['editable-model.json']) > SOURCE_CAP:
        raise ValueError('Model source output exceeds bound')
    source = model_source(outputs['editable-model.json'])
    if operation == 'model-init':
        request = load_json(raw)
        expected_document = {**request['document'], 'metadata': {**request['document']['metadata'], 'creative_work': native_arguments['creative_work']}}
        if (source['document'] != expected_document
                or source_creative_record(source) != native_arguments['creative_work']):
            raise ValueError('Constructed Model brief/identity binding differs')
    else:
        prior = model_source(raw)
        if (source['document'].get('id') != prior['document'].get('id')
                or source['document'].get('units') != prior['document'].get('units')
                or source['document'].get('metadata') != prior['document'].get('metadata')):
            raise ValueError('Model identity/units/criteria changed')
    if operation == 'model-glb':
        if outputs['editable-model.json'] != raw or len(outputs['model.glb']) > CAPS[1] or len(outputs['manifest.json']) > CAPS[2]:
            raise ValueError('Model export originals/output bound differs')
        delivery = load_json(outputs['manifest.json'])
        assets = [file_record(outputs[name], mime) for name, mime in zip(FILES, MIMES)]
        validate_delivery(delivery, assets)
        if (delivery['model_id'] != source['document'].get('id') or delivery['model_digest'] != source['digest']
                or delivery['object_ids'] != [v.get('id') for v in source['document'].get('objects', [])]):
            raise ValueError('Native Model delivery binding differs')
        return {'outputs': outputs, 'delivery': delivery, 'assets': assets, 'adopted': False}
    # Native CLI validates the complete source before writing; summary is bounded bytes.
    stdout = result.get('stdout')
    if not isinstance(stdout, bytes) or len(stdout) > 4096:
        raise ValueError('Bounded native Model summary missing')
    summary = load_json(stdout)
    if (summary.get('operation') != operation or summary.get('adopted') is not False
            or summary.get('model_id') != source['document'].get('id') or summary.get('model_digest') != source['digest']
            or not isinstance(summary.get('metadata_digest'), str) or not DIGEST.fullmatch(summary['metadata_digest'])):
        raise ValueError('Native Model summary differs')
    return {'source': outputs['editable-model.json'], 'summary': summary, 'adopted': False}


async def act_model(ctx, operation, params):
    command = getattr(ctx, 'command', None) or {}
    if (operation not in OPERATIONS or not isinstance(params, dict)
            or not {'goal_id', 'source'} <= set(params) or set(params) - {'goal_id', 'source', 'params', 'base_revision'}
            or params.get('base_revision') is not None
            or any(not isinstance(command.get(name), str) or not command[name] for name in ('record_id', 'idempotency_key'))):
        raise ValueError('Bound native Model action identity required')
    goal, ref = params['goal_id'], dict(exact_ref(params['source']))
    if not isinstance(goal, str) or not IDENTIFIER.fullmatch(goal):
        raise ValueError('Bounded held Model goal required')
    arguments = action_arguments(operation, load_json(encoded(params.get('params', {}), PARAMS_CAP)))
    binding = digest(arguments)
    def admit():
        held(ctx, goal)
        raw = read_source(ctx, ref)
        if len(raw) > SOURCE_CAP:
            raise ValueError('Model source exceeds native bound')
        return raw
    raw = admit()
    if (getattr(ctx, 'actor', None) or {}).get('recovery'):
        recorded = command.get('recorded_result')
        if not isinstance(recorded, dict) or recorded.get('status') != 'done':
            raise ValueError('Unknown Model effects require native custody reconciliation; no replay')
        if operation == 'model-inspect':
            data = recorded.get('data')
            inspection = data.get('inspection') if isinstance(data, dict) else None
            if not isinstance(data, dict) or set(data) != {'inspection', 'adopted'} or data['adopted'] is not False:
                raise ValueError('Recorded Model inspection differs')
            checked_inspection(inspection, model_source(raw), arguments)
        else:
            data = recorded['data']; out = exact_ref(data['output'])
            revision = ctx.read_revision(out['artifact_id'], out['revision']); body = revision['body'].encode('utf-8')
            if revision['digest'] != out['digest'] or 'sha256:' + hashlib.sha256(body).hexdigest() != out['digest']:
                raise ValueError('Recorded Model output reference differs')
            manifest = load_json(body)
            if (manifest.get('source') != ref or manifest.get('goal_id') != goal or manifest.get('operation') != operation
                    or manifest.get('action_record') != command['record_id'] or manifest.get('params_digest') != binding
                    or manifest.get('adopted') is not False or data.get('adopted') is not False):
                raise ValueError('Recorded Model output binding differs')
            if operation == 'model-glb':
                delivered = read_delivery(ctx, manifest, out)
                if delivered['editable-model.json'] != raw or data.get('assets') != manifest['assets']:
                    raise ValueError('Recorded Model delivery assets differ')
            else:
                if manifest.get('schema') != 'omega-studio-source-pointer-1' or data.get('assets') != [manifest['asset']]:
                    raise ValueError('Recorded Model source pointer differs')
                output_source = model_source(read_source(ctx, out))
                summary = manifest.get('model')
                if (not isinstance(summary, dict) or set(summary) != {'model_id', 'model_digest', 'metadata_digest'}
                        or summary['model_id'] != output_source['document'].get('id')
                        or summary['model_digest'] != output_source['digest']
                        or not isinstance(summary['metadata_digest'], str) or not DIGEST.fullmatch(summary['metadata_digest'])):
                    raise ValueError('Recorded Model source identity differs')
                if operation == 'model-init':
                    creative = init_arguments(raw, ref)['creative_work']
                    request = load_json(raw)
                    expected_document = {**request['document'], 'metadata': {**request['document']['metadata'], 'creative_work': creative}}
                    if output_source['document'] != expected_document or source_creative_record(output_source) != creative:
                        raise ValueError('Recorded Model creative criteria differ')
                else:
                    prior = model_source(raw)['document']
                    if any(output_source['document'].get(name) != prior.get(name) for name in ('id', 'units', 'metadata')):
                        raise ValueError('Recorded Model identity/units/metadata differs')
        admit(); return recorded
    task = asyncio.create_task(execute_model(ctx, operation, raw, arguments, ref))
    try:
        while not task.done():
            admit(); await asyncio.wait({task}, timeout=.1)
        result = await task; admit()
        if operation == 'model-inspect':
            return {'status': 'done', 'data': result}
        if operation == 'model-glb':
            assets = result['assets']
            manifest = {'schema': 'omega-model-artifact-1', 'source': ref, 'goal_id': goal,
                        'operation': operation, 'action_record': command['record_id'], 'params_digest': binding,
                        'assets': assets, 'originals': [assets[0], assets[2]], 'previews': [],
                        'delivery': result['delivery'], 'adopted': False}
            supplied = [{'data': result['outputs'][name], 'mime': mime, 'name': name} for name, mime in zip(FILES, MIMES)]
            kind, title = 'model-export', 'Editable parametric Model and GLB'
        else:
            asset = file_record(result['source'], 'application/json')
            manifest = {'schema': 'omega-studio-source-pointer-1', 'asset': asset, 'originals': [asset],
                        'source': ref, 'goal_id': goal, 'operation': operation,
                        'action_record': command['record_id'], 'params_digest': binding,
                        'model': {k: result['summary'][k] for k in ('model_id', 'model_digest', 'metadata_digest')}, 'adopted': False}
            assets = [asset]; supplied = [{'data': result['source'], 'mime': 'application/json', 'name': 'editable-model.json'}]
            kind, title = 'studio-source', 'Studio ' + operation
        body = encoded(manifest, 256 * 1024).decode('utf-8')
        admit()  # Final authority/source check; no new owner action can interleave with synchronous publish.
        published = ctx.publish(kind, title, body, assets=supplied)
        # Never turn an already-published effect into a refusal after later withdrawal.
        return {'status': 'done', 'data': {'output': {k: published[k] for k in ('artifact_id', 'revision', 'digest')},
                                         'assets': published['assets'], 'adopted': False}}
    finally:
        if not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
