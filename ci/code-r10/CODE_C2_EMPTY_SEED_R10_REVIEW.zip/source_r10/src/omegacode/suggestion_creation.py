"""Pure create-file scope validation for the Code-for-members v2 successor.

This prepares an absence ceiling only. It neither writes files nor creates service
authority; callers must bind the result to the existing human scope operation.
"""
from .common import CodeError, MAX_FILE, safe_path
from .language_buffers import validate_new_path_namespace

MAX_CREATE_TOTAL_BYTES = 2 * 1024 * 1024
MAX_SCOPE_PATHS = 100


def path_union(ranges, create_files):
    if type(ranges) is not dict or type(create_files) is not dict:
        raise CodeError(400, 'suggestion_scope', 'ranges and create_files must be objects')
    if any(type(path) is not str for path in (*ranges.keys(), *create_files.keys())):
        raise CodeError(400, 'suggestion_scope', 'scope paths must be strings')
    if set(ranges).intersection(create_files):
        raise CodeError(400, 'suggestion_scope', 'a path cannot be both edited and created')
    paths = set(ranges) | set(create_files)
    if not paths or len(paths) > MAX_SCOPE_PATHS:
        raise CodeError(400, 'suggestion_scope', 'scope needs 1 to 100 distinct paths')
    for path in ranges:
        safe_path(path)
    for path in create_files:
        safe_path(path)
    return tuple(sorted(paths))


def validate_create_scope(manifest, ranges, create_files, max_total_create_bytes, destination_results):
    """Return canonical absence ceilings after full-manifest and context checks."""
    paths = path_union(ranges, create_files)
    if type(max_total_create_bytes) is not int or not 0 <= max_total_create_bytes <= MAX_CREATE_TOTAL_BYTES:
        raise CodeError(400, 'suggestion_scope', 'max_total_create_bytes must be a strict integer from 0 to 2097152')
    for path, ranges_for_path in ranges.items():
        if type(ranges_for_path) is not list or len(ranges_for_path) > 100:
            raise CodeError(400, 'suggestion_scope', 'bounded ranges are required for each edited path')
    if not create_files:
        if max_total_create_bytes != 0:
            raise CodeError(400, 'suggestion_scope', 'a zero-create scope must have a zero byte ceiling')
        if destination_results != {}:
            raise CodeError(403,'context_excluded','zero-create scope has unexpected destination classifications')
        return {'schema':'omegacode-suggestion-scope-v2','paths':paths,'create_files':{},
                'max_total_create_bytes':0,'destination_results':{}}
    ceilings = {}
    for path, entry in create_files.items():
        if type(path) is not str or type(entry) is not dict or set(entry) != {'max_bytes'}:
            raise CodeError(400, 'suggestion_scope', 'each create file needs exactly max_bytes')
        amount = entry['max_bytes']
        if type(amount) is not int or not 0 <= amount <= MAX_FILE:
            raise CodeError(400, 'suggestion_scope', 'each max_bytes must be a strict integer from 0 to 2097152')
        ceilings[path] = amount
    if sum(ceilings.values()) > max_total_create_bytes:
        raise CodeError(413, 'suggestion_scope', 'per-file creation ceilings exceed max_total_create_bytes')
    if type(destination_results) is not dict:
        raise CodeError(403, 'context_excluded', 'destination context selection is unavailable')
    validate_new_path_namespace(manifest, tuple(ceilings), max_paths=MAX_SCOPE_PATHS)
    if set(destination_results) != set(ceilings):
        raise CodeError(403,'context_excluded','destination classifications do not match the exact creation scope')
    retained_results={}
    for path in sorted(ceilings):
        result = destination_results.get(path)
        if (type(result) is not dict or set(result)!={'allowed','reason'} or
                type(result.get('allowed')) is not bool or
                result.get('reason') not in (None,'explicit_exclusion','gitignore')):
            raise CodeError(403,'context_excluded','destination classification is malformed')
        if result['allowed'] is not True:
            raise CodeError(403, 'context_excluded', 'destination is excluded or unavailable under saved context policy')
        retained_results[path]={'allowed':True,'reason':None}
    return {
        'schema':'omegacode-suggestion-scope-v2',
        'paths':paths,
        'create_files':{path:{'before':{'kind':'absent'},'max_bytes':ceilings[path]} for path in sorted(ceilings)},
        'max_total_create_bytes':max_total_create_bytes,'destination_results':retained_results,
    }
