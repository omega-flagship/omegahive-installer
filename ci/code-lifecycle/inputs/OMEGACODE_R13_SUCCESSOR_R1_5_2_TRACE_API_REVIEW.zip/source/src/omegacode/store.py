"""A SQLite journal and content-addressed files, with task-scoped artifact custody."""

from __future__ import annotations

import contextlib
import json
import os
import pathlib
import re
import sqlite3
import stat
import threading

from .common import CodeError, atomic_write, canonical, digest, stamp


class Store:
    def __init__(self, root: pathlib.Path, effect_guard=None):
        self.effect_guard = effect_guard or (lambda: None)
        self.effect_guard()
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(self.root / "index.sqlite3", check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.lock = threading.RLock()
        self.transaction_local = threading.local()
        self.db.executescript("""
          CREATE TABLE IF NOT EXISTS records(kind TEXT, id TEXT, body TEXT NOT NULL, PRIMARY KEY(kind,id));
          CREATE TABLE IF NOT EXISTS operations(actor TEXT, id TEXT, fingerprint TEXT NOT NULL,
            result TEXT NOT NULL, PRIMARY KEY(actor,id));
          CREATE TABLE IF NOT EXISTS artifact_refs(digest TEXT, workspace TEXT, kind TEXT,
            PRIMARY KEY(digest,workspace,kind));
          CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, workspace TEXT NOT NULL,
            task TEXT NOT NULL, kind TEXT NOT NULL, at REAL NOT NULL, body TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS grants(id TEXT PRIMARY KEY, body TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
        """)

    @contextlib.contextmanager
    def transaction(self):
        with self.lock:
            self.effect_guard()
            self.db.execute("BEGIN IMMEDIATE")
            self.transaction_local.active = True
            try:
                self.effect_guard()
                yield
                self.effect_guard()
                self.db.execute("COMMIT")
            except BaseException:
                self.db.execute("ROLLBACK")
                raise
            finally:
                self.transaction_local.active = False

    def get(self, kind: str, id_: str):
        with self.lock:
            row = self.db.execute("SELECT body FROM records WHERE kind=? AND id=?", (kind, id_)).fetchone()
        if row is None:
            raise CodeError(404, "not_found", f"{kind} record not found")
        return json.loads(row[0])

    def put(self, kind: str, value: dict):
        self.db.execute("INSERT INTO records VALUES(?,?,?) ON CONFLICT(kind,id) DO UPDATE SET body=excluded.body",
                        (kind, value["id"], canonical(value).decode()))

    def list(self, kind: str):
        with self.lock:
            return [json.loads(r[0]) for r in self.db.execute("SELECT body FROM records WHERE kind=? ORDER BY rowid", (kind,))]

    def cached(self, actor: str, operation_id: str, payload: dict):
        if not operation_id or len(operation_id) > 160:
            raise CodeError(400, "operation_id_required", "write operations need a bounded operation_id")
        row = self.db.execute("SELECT fingerprint,result FROM operations WHERE actor=? AND id=?", (actor, operation_id)).fetchone()
        if not row:
            return None
        if row[0] != digest(canonical(payload)):
            raise CodeError(409, "operation_conflict", "operation_id was already used with another payload")
        return json.loads(row[1])

    def remember(self, actor, operation_id, payload, result):
        self.db.execute("INSERT INTO operations VALUES(?,?,?,?)",
                        (actor, operation_id, digest(canonical(payload)), canonical(result).decode()))

    def blob_path(self, hash_: str):
        if not re.fullmatch(r"[a-f0-9]{64}", hash_):
            raise CodeError(400, "invalid_digest", "expected a SHA256 digest")
        return self.root / "artifacts" / hash_[:2] / hash_[2:]

    def blob(self, content: bytes, workspace: str, kind: str) -> str:
        hash_ = digest(content)
        path = self.blob_path(hash_)
        if not path.exists():
            atomic_write(path, content)
        self.db.execute("INSERT OR IGNORE INTO artifact_refs VALUES(?,?,?)", (hash_, workspace, kind))
        return hash_

    def read_blob(self, hash_: str, workspace: str, *, max_bytes: int | None = None) -> bytes:
        if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
            raise CodeError(400, "invalid_artifact_limit", "artifact byte limit must be a nonnegative integer")
        with self.lock:
            allowed = self.db.execute("SELECT 1 FROM artifact_refs WHERE digest=? AND workspace=?", (hash_, workspace)).fetchone()
        if not allowed:
            raise CodeError(403, "artifact_forbidden", "artifact is not referenced by this workspace")
        path = self.blob_path(hash_)
        try:
            with path.open("rb") as stream:
                before = os.fstat(stream.fileno())
                if not stat.S_ISREG(before.st_mode):
                    raise CodeError(409, "artifact_corrupt", "referenced artifact is not a regular file")
                if max_bytes is not None and before.st_size > max_bytes:
                    raise CodeError(409, "artifact_too_large", "referenced artifact exceeds the read bound")
                data = stream.read() if max_bytes is None else stream.read(max_bytes + 1)
                after = os.fstat(stream.fileno())
                if max_bytes is not None and (len(data) > max_bytes or len(data) != before.st_size
                                              or before.st_size != after.st_size):
                    raise CodeError(409, "artifact_too_large", "referenced artifact exceeds the read bound")
        except FileNotFoundError:
            raise CodeError(409, "artifact_missing", "referenced artifact is missing")
        if digest(data) != hash_:
            raise CodeError(409, "artifact_corrupt", "artifact content no longer matches its digest")
        return data

    def emit(self, workspace: dict, kind: str, payload: dict):
        self.db.execute("INSERT INTO events(workspace,task,kind,at,body) VALUES(?,?,?,?,?)",
                        (workspace["id"], workspace["task_id"], kind, stamp(), canonical(payload).decode()))

    def events(self, workspace: str, after=0, limit=200):
        with self.lock:
            rows = self.db.execute("SELECT * FROM events WHERE workspace=? AND seq>? ORDER BY seq LIMIT ?",
                                   (workspace, after, min(max(limit, 1), 1000))).fetchall()
        return [{**dict(r), "body": json.loads(r["body"])} for r in rows]

    def close(self):
        self.db.close()

