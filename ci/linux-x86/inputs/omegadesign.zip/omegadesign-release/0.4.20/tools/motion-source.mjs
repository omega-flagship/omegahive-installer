import {sampleMotion} from './motion.mjs';
export async function readMotionSource(text){
 if(typeof text!=='string'||new TextEncoder().encode(text).length>20*1024*1024)throw Error('Motion source exceeds 20 MiB limit');
 const value=JSON.parse(text);
 if(!value||Object.keys(value).sort().join(',')!=='adopted,scene,schema,timeline'||value.schema!=='omega-editable-motion-export-1'||value.adopted!==false)throw Error('Editable unadopted motion source required');
 await sampleMotion(value.scene,value.timeline,0);
 return value;
}
