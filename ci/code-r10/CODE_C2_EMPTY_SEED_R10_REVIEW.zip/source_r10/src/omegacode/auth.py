"""Explicit grants and exact-request Hive policy checks. Unknown capabilities fail closed."""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import math
import re
import time
from dataclasses import dataclass

import httpx

from .common import CodeError, canonical, digest, ident, safe_path

ACTIONS = {"workspace", "read", "search", "edit", "run", "cancel", "verify", "events", "artifact", "checkpoint"}
SKILLS = {"workspace": "code-workspace", "read": "code-read", "search": "code-search", "edit": "code-edit",
          "run": "code-run", "cancel": "code-cancel", "verify": "code-verify", "events": "code-events",
          "artifact": "code-artifact", "checkpoint": "code-checkpoint"}


@dataclass(frozen=True)
class Principal:
    actor: str
    grant: dict
    hive_token: str | None = None
    operator: bool = False


class Authority:
    def __init__(self, store, operator_token: str, hive_url: str | None = None, transport=None,
                 service_token: str | None = None):
        if len(operator_token) < 24:
            raise ValueError("operator token must contain at least 24 characters")
        self.store, self.operator_token = store, operator_token
        self.hive_url = hive_url.rstrip("/") if hive_url else None
        self.service_token = service_token
        self.registration = None
        self.client = httpx.Client(timeout=10, transport=transport, follow_redirects=False)

    def issue(self, *, actor: str, kind: str, task_id: str, swarm_id: str, repository_id: str,
              actions: list[str], paths: list[str] | None = None, argv_prefixes: list[list[str]] | None = None,
              ttl_seconds: int = 3600, max_runs: int = 10, max_runtime_seconds: int = 120,
              member_token: str | None = None):
        if kind not in ("human", "agent") or not actor or not task_id or not swarm_id:
            raise CodeError(400, "invalid_grant", "kind, actor, task and swarm are required")
        if not actions or not set(actions) <= ACTIONS or not 1 <= ttl_seconds <= 86400:
            raise CodeError(400, "invalid_grant", "invalid actions or grant lifetime")
        if kind == "agent" and (not member_token or not self.hive_url):
            raise CodeError(400, "hive_required", "agent grants bind a member token and a configured Hive")
        if not 0 <= max_runs <= 100 or not 1 <= max_runtime_seconds <= 3600:
            raise CodeError(400, "invalid_grant", "run limits are out of range")
        paths = paths or []
        for path in paths:
            safe_path(path)
        if any(not p or any(not isinstance(a, str) or not a or "\x00" in a for a in p) for p in argv_prefixes or []):
            raise CodeError(400, "invalid_grant", "command prefixes must be nonempty argv arrays")
        claims = {"id": ident("cap"), "actor": actor, "kind": kind, "task_id": task_id, "swarm_id": swarm_id,
                  "repository_id": repository_id, "actions": sorted(set(actions)), "paths": paths,
                  "argv_prefixes": argv_prefixes or [], "exp": time.time() + ttl_seconds,
                  "max_runs": max_runs, "max_runtime_seconds": max_runtime_seconds,
                  "member_hash": digest(member_token.encode()) if member_token else None}
        with self.store.transaction():
            self.store.db.execute("INSERT INTO grants(id,body) VALUES(?,?)", (claims["id"], canonical(claims).decode()))
        payload = base64.urlsafe_b64encode(canonical(claims)).decode().rstrip("=")
        signature = hmac.new(self.operator_token.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return {"token": f"oc1.{payload}.{signature}", "grant": claims}

    def revoke(self, id_: str):
        with self.store.transaction():
            n = self.store.db.execute("UPDATE grants SET revoked=1 WHERE id=?", (id_,)).rowcount
        if not n:
            raise CodeError(404, "not_found", "grant not found")
        return {"revoked": True, "id": id_}

    def authenticate(self, token: str, hive_token=None) -> Principal:
        if token and hmac.compare_digest(token, self.operator_token):
            return Principal("operator", {}, operator=True)
        try:
            if len(token) > 32768:
                raise ValueError()
            prefix, payload, signature = token.split(".")
            secret = self.operator_token if prefix == "oc1" else (self.registration or {}).get("capability_secret") if prefix == "hc1" else None
            if not secret:
                raise ValueError()
            expected = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature, expected):
                raise ValueError()
            claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            if not isinstance(claims, dict) or claims["exp"] <= time.time():
                raise ValueError()
            if prefix == "hc1":
                self._validate_host_claims(claims, hive_token)
                self.host_live(claims)
                # Persist only validated public claims for budgets and recovery, never member tokens.
                with self.store.transaction():
                    old = self.store.db.execute("SELECT body,revoked FROM grants WHERE id=?", (claims["id"],)).fetchone()
                    if old and (old[1] or json.loads(old[0]) != claims):
                        raise ValueError()
                    self.store.db.execute("INSERT OR IGNORE INTO grants(id,body) VALUES(?,?)", (claims["id"], canonical(claims).decode()))
            else:
                if any(k in claims for k in ('delegated', 'copy_apply')):
                    raise ValueError()
                with self.store.lock:
                    row = self.store.db.execute("SELECT body,revoked FROM grants WHERE id=?", (claims["id"],)).fetchone()
                if not row or row[1] or claims != json.loads(row[0]):
                    raise ValueError()
        except (ValueError, KeyError, TypeError, binascii.Error):
            raise CodeError(401, "invalid_capability", "capability is invalid, expired or revoked")
        if claims["kind"] == "agent" and (not hive_token or not hmac.compare_digest(digest(hive_token.encode()), claims["member_hash"])):
            raise CodeError(401, "member_token_mismatch", "agent capability requires its bound Hive member token")
        return Principal(claims["actor"], claims, hive_token)

    def _validate_host_claims(self, g, hive_token=None):
        if g.get("iss") != "hive" or g.get("aud") != self.registration["service_id"] or g.get("kind") not in ("human", "agent"):
            raise ValueError()
        for key in ("id", "actor", "task_id", "swarm_id", "repository_id"):
            if not isinstance(g.get(key), str) or not g[key] or any(c.isspace() or c in '()"\\/' for c in g[key]):
                raise ValueError()
        if 'copy_apply' in g:
            self._copy_binding(Principal(g['actor'], g, hive_token))
            for path in g['paths']:
                safe_path(path)
            return
        allowed = {'read', 'search', 'suggest'} if 'delegated' in g else ACTIONS
        if not isinstance(g.get("actions"), list) or not g["actions"] or not set(g["actions"]) <= allowed:
            raise ValueError()
        if not isinstance(g.get("paths"), list) or not isinstance(g.get("argv_prefixes"), list):
            raise ValueError()
        for path in g["paths"]:
            safe_path(path)
        if any(not isinstance(p, list) or not p or any(not isinstance(a, str) or not a or "\x00" in a for a in p) for p in g["argv_prefixes"]):
            raise ValueError()
        if type(g.get("max_runs")) is not int or not 0 <= g["max_runs"] <= 100 or type(g.get("max_runtime_seconds")) is not int or not 1 <= g["max_runtime_seconds"] <= 3600:
            raise ValueError()
        if g["kind"] == "agent" and not isinstance(g.get("member_hash"), str):
            raise ValueError()
        if g["kind"] == "human" and not g.get("grant_id") and g["actor"] != "user:operator":
            raise ValueError()
        if 'delegated' in g:
            self._validate_delegated(g)

    def _copy_binding(self, principal, workspace=None, payload=None):
        from .copy_binding import validate_binding
        g = principal.grant
        try:
            c = g['copy_apply']
            ws = workspace or self.store.get('workspace', c['origin']['workspace_id'])
            expected = {'operation_id': c['operation_id'], 'request_id': c['request_id'],
                        **c['proposal'], 'expected_generation': c['expected']['generation'],
                        'expected_tree_digest': c['expected']['tree_digest'],
                        'scope_id': c['origin']['scope_id'], 'scope_digest': c['origin']['scope_digest']}
            if payload is not None and any(payload.get(k) != value for k, value in expected.items()):
                raise CodeError(403, 'capability_mismatch', 'body differs from the active application capability binding')
            body = expected if payload is None else payload
            if not isinstance(g.get('paths'), list) or any(not isinstance(p, str) for p in g['paths']):
                raise ValueError()
            return validate_binding(principal, ws, body, audience=self.registration['service_id'],
                status_reader=lambda id_: self._call(self.service_token, 'GET', f'/api/services/capabilities/{id_}'))
        except (ValueError, KeyError, TypeError):
            raise CodeError(403, 'copy_apply_binding_invalid', 'invalid application capability') from None

    def _validate_delegated(self, g):
        """Separate host-issued proposal authority; never a local grant upgrade."""
        d = g.get('delegated')
        if g.get('iss') != 'hive' or g.get('kind') != 'agent' or not isinstance(d, dict) or set(d) != {'request_id','controller_id','execution_goal','issuer','origin_scope'}:
            raise ValueError()
        for key in ('request_id','controller_id','execution_goal','issuer'):
            v = d[key]
            if not isinstance(v,str) or not v or any(c.isspace() or c in '()"\\/' for c in v):
                raise ValueError()
        if not d['issuer'].startswith('user:') or d['issuer'] == 'user:operator':
            raise ValueError()
        scope = d['origin_scope']
        if not isinstance(scope,dict) or set(scope) != {'scope_id','scope_digest','generation'}:
            raise ValueError()
        if not isinstance(scope['scope_id'],str) or not scope['scope_id'] or any(c.isspace() or c in '()"\\/' for c in scope['scope_id']):
            raise ValueError()
        if not isinstance(scope['scope_digest'],str) or not re.fullmatch(r'sha256:[a-f0-9]{64}',scope['scope_digest']) or type(scope['generation']) is not int or scope['generation']<1:
            raise ValueError()
        if not isinstance(g.get('actions'),list) or not g['actions'] or not set(g['actions']) <= {'read','search','suggest'}:
            raise ValueError()
        if any(type(g.get(k)) not in (int,float) or not math.isfinite(g[k]) for k in ('iat','exp')) or not 0 < g['exp']-g['iat'] <= 900:
            raise ValueError()

    def host_live(self, claims):
        if claims.get("iss") != "hive":
            return
        if not self.hive_url or not self.service_token or claims["exp"] <= time.time():
            raise CodeError(403, "host_capability_inactive", "registered Hive authority is unavailable or expired")
        status = self._call(self.service_token, "GET", f'/api/services/capabilities/{claims["id"]}')
        if status.get("active") is not True or status.get("claims") != claims:
            raise CodeError(403, "host_capability_inactive", "Hive capability is inactive or mismatched")

    def scope(self, principal: Principal, action: str, workspace: dict | None = None, payload=None):
        if principal.operator:
            raise CodeError(403, "coding_capability_required", "operator registration authority is not a coding grant")
        g = principal.grant
        self.host_live(g)
        if 'copy_apply' in g:
            if (action != 'proposal-apply' or not workspace or not payload
                    or payload.get('mutation') not in ('proposal-copy-application-r1', 'proposal-copy-read-r3')):
                raise CodeError(403, 'action_forbidden', 'copy capability is restricted to application and own recovery read')
            self._copy_binding(principal, workspace, payload)
        if action not in g["actions"]:
            raise CodeError(403, "action_forbidden", "action is outside this capability")
        if 'delegated' in g and (payload or {}).get('mutation') == 'suggestion-preview' and 'suggest' not in g['actions']:
            raise CodeError(403, 'action_forbidden', 'retained proposals require delegated suggest authority')
        if workspace and any(workspace[key] != g[key] for key in ("task_id", "swarm_id", "repository_id")):
            raise CodeError(403, "workspace_forbidden", "workspace is outside this task/swarm/repository capability")
        if g.get("iss") == "hive" and g["kind"] == "human" and g.get("grant_id"):
            grants = self._call(self.service_token, "GET", f'/api/goals/{g["task_id"]}/grants', list_result=True)
            grant = next((x for x in grants if isinstance(x, dict) and x.get("id") == g["grant_id"]), None)
            if not grant or grant.get("active") is not True or grant.get("principal") != principal.actor or grant.get("goal_id") != g["task_id"]:
                raise CodeError(403, "collaborator_inactive", "human collaborator grant is inactive or mismatched")
            if grant.get("workspace_id") and (not workspace or grant["workspace_id"] != workspace["id"]):
                raise CodeError(403, "workspace_forbidden", "collaborator grant is bound to another workspace")
            if action not in ("read", "search", "events", "artifact") and grant.get("scope") != "edit":
                raise CodeError(403, "action_forbidden", "collaborator grant is read-only")
        for path in (payload or {}).get("paths", []):
            path = safe_path(path)
            if g["paths"] and not any(path == p or path.startswith(p.rstrip("/") + "/") for p in g["paths"]):
                raise CodeError(403, "path_forbidden", "file is outside the capability's paths")
        if action == "run":
            if g["paths"]:
                raise CodeError(403, "run_scope", "native execution needs full workspace scope; path grants cannot contain a program")
            argv = (payload or {}).get("argv", [])
            if not any(argv[:len(p)] == p for p in g["argv_prefixes"]):
                raise CodeError(403, "command_forbidden", "argv is outside the explicitly granted command prefixes")
            if (payload or {}).get("timeout_seconds", 0) > g["max_runtime_seconds"]:
                raise CodeError(403, "runtime_limit", "run exceeds the capability runtime limit")

    def _call(self, token, method, path, body=None, *, list_result=False):
        try:
            response = self.client.request(method, self.hive_url + path, json=body,
                                           headers={"Authorization": f"Bearer {token}"})
        except httpx.HTTPError:
            raise CodeError(503, "hive_unavailable", "Hive could not validate authority")
        if response.status_code != 200:
            raise CodeError(403, "hive_refused", "Hive refused member/task authority")
        try:
            result = response.json()
            if not isinstance(result, list if list_result else dict):
                raise ValueError()
            return result
        except ValueError:
            raise CodeError(503, "hive_invalid_response", "Hive returned an invalid authority response")

    def check_claim(self, principal: Principal, *, cancelling=False, historical=False):
        if principal.grant["kind"] != "agent":
            return
        g = principal.grant
        if 'copy_apply' in g:
            self._copy_binding(principal)
            return
        if 'delegated' in g:
            try:
                self._validate_delegated(g)
            except (ValueError,KeyError,TypeError):
                raise CodeError(403,'delegation_invalid','delegated capability is not a valid host-issued proposal grant') from None
            self.host_live(g)
            return
        goal = self._call(principal.hive_token, "GET", f"/api/agent/goals/{g['task_id']}")
        if goal.get("swarm_id") != g["swarm_id"] or goal.get("claimed_by") != g["actor"]:
            raise CodeError(403, "goal_not_owned", "the agent does not hold this goal")
        from datetime import datetime, timezone
        def valid_time(value):
            try:
                return datetime.fromisoformat(value.replace("Z", "+00:00")) > datetime.now(timezone.utc)
            except (ValueError, AttributeError, TypeError):
                return False
        if not cancelling and not historical and (goal.get("status") != "claimed" or not valid_time(goal.get("lease_until"))
                               or goal.get("deadline_at") and not valid_time(goal["deadline_at"])):
            raise CodeError(409, "goal_inactive", "goal is not actively claimed or its lease/deadline expired")
        return goal

    def gate(self, principal: Principal, action: str, payload: dict):
        if principal.grant["kind"] != "agent":
            return
        if 'copy_apply' in principal.grant:
            if action != 'proposal-apply':
                raise CodeError(403, 'action_forbidden', 'purpose capability cannot redeem ordinary policy')
            self._copy_binding(principal, payload=payload)
            return
        operation = {k: v for k, v in payload.items() if k != "approval_id"}
        hash_ = "sha256:" + digest(canonical(operation))
        binding = {"task_id": principal.grant["task_id"], "swarm_id": principal.grant["swarm_id"],
                   "workspace_id": operation.get("workspace_id"), "operation_id": operation.get("operation_id"),
                   "expected_generation": operation.get("expected_generation"), "payload_digest": hash_}
        # No-default-allow boundary: mutating agent operations require a bound approved receipt.
        if action in ("workspace", "edit", "run", "verify", "checkpoint"):
            approval_id = payload.get("approval_id")
            if approval_id:
                if not self.service_token:
                    raise CodeError(503, "registration_required", "exact approval redemption requires registered service authority")
                approval = self._call(self.service_token, "GET", f"/api/agent/approvals/{approval_id}")
                if approval.get("status") != "approved" or approval.get("agent_id") != principal.actor or approval.get("skill") != SKILLS[action] or approval.get("binding") != binding:
                    raise CodeError(403, "approval_mismatch", "approval is not bound to this exact actor/task/operation")
                self._call(self.service_token, "POST", f"/api/agent/approvals/{approval_id}/redeem", {"binding": binding})
                return
            command = (f'({SKILLS[action]} task={binding["task_id"]} swarm={binding["swarm_id"]} '
                       f'workspace={binding["workspace_id"] or "none"} op={binding["operation_id"] or "none"} '
                       f'generation={binding["expected_generation"] or 0} digest={hash_})')
            # Values are bounded trusted grant/resource identifiers; reject parser metacharacters.
            values = [str(v) for k,v in binding.items() if k != "payload_digest" and v is not None]
            if any(any(c.isspace() or c in '()"\\' for c in value) for value in values):
                raise CodeError(400, "invalid_binding", "operation binding identifiers contain policy syntax")
            decision = self._call(principal.hive_token, "POST", "/api/agent/authorize", {"command": command})
            if decision.get("decision") == "deny":
                raise CodeError(403, "policy_refused", "Hive denied this coding operation")
            raise CodeError(403, "approval_required", "exact operation approval required",
                            {"approval_id": decision.get("approval_id"), "binding": binding, "skill": SKILLS[action]})
        command = f'({SKILLS[action]} "{hash_}")'
        decision = self._call(principal.hive_token, "POST", "/api/agent/authorize", {"command": command})
        if decision.get("decision") != "allow":
            raise CodeError(403, "policy_refused", f"Hive policy did not authorize exact operation: {decision.get('approval_id', '')}")
