"""Retained human-issued source ranges and approval-bound suggested changes.

Scope describes an edit ceiling, never new edit/model/execution authority.
"""
import json
import base64
import math
from .auth import Principal
from .common import CodeError, ident, canonical, digest, stamp
from .suggestion_validation import prepare, prepare_v2, reconstruct, reconstruct_v2, boundary, decision_groups


def _scope_paths(body):
    return sorted(set(body.get('ranges', {})) | set(body.get('create_files', {})))


class Suggestions:
    def suggestion_history(self, principal, ws_id, limit=20, cursor=None):
        """Bounded retained proposal metadata for reconnect; never grants edit authority."""
        if type(limit) is not int or not 1 <= limit <= 20:
            raise CodeError(400, 'suggestion_history', 'limit must be from1 to20')
        ws = self.workspace(ws_id)
        self._authorize(principal, 'read', ws, {})
        if principal.grant['paths']:
            raise CodeError(403, 'suggestion_history_scope', 'proposal history requires full workspace scope')
        self.authority.gate(principal, 'read', {'workspace_id': ws_id, 'resource': 'suggestion-history'})
        after = None
        if cursor is not None:
            try:
                if not isinstance(cursor, str) or not 1 <= len(cursor) <= 512:
                    raise ValueError()
                after = json.loads(base64.b64decode(cursor + '=' * (-len(cursor) % 4), altchars=b'-_', validate=True))
                if (not isinstance(after, dict) or set(after) != {'workspace_id','kind','at','id'} or
                    after['workspace_id'] != ws_id or after['kind'] != 'suggestion' or
                    type(after['at']) not in (int,float) or not math.isfinite(after['at']) or
                    not isinstance(after['id'], str) or not 1 <= len(after['id']) <= 100):
                    raise ValueError()
            except (ValueError, KeyError, TypeError, OverflowError):
                raise CodeError(400, 'invalid_cursor', 'proposal cursor is invalid for this workspace and kind') from None
        query = "SELECT body FROM records WHERE kind='suggestion' AND json_extract(body,'$.workspace_id')=?"
        params = [ws_id]
        if after:
            query += " AND (json_extract(body,'$.created_at') < ? OR (json_extract(body,'$.created_at') = ? AND id < ?))"
            params.extend([after['at'],after['at'],after['id']])
        query += " ORDER BY json_extract(body,'$.created_at') DESC,id DESC LIMIT ?"
        params.append(limit+1)
        with self.store.lock:
            ws = self.workspace(ws_id)
            rows = [json.loads(row[0]) for row in self.store.db.execute(query, params)]
            more, rows = len(rows) > limit, rows[:limit]
            items = []
            for record in rows:
                saved = self.suggestion(principal, ws_id, record['id'])
                body = saved['content']
                accepted = {i for d in saved['decisions'] for i in d['accepted_hunk_ids']}
                rejected = {i for d in saved['decisions'] for i in d['rejected_hunk_ids']}
                items.append({**record, 'generation':body['binding']['generation'],
                              'tree_digest':body['binding']['tree_digest'], 'currency':saved['currency'],
                              'hunk_count':len(body['hunks']), 'accepted_count':len(accepted),
                              'rejected_count':len(rejected)})
            self._authorize(principal, 'read', ws, {})
            self._live(principal)
            next_cursor = None
            if more:
                last = rows[-1]
                next_cursor = base64.urlsafe_b64encode(canonical({'workspace_id':ws_id,'kind':'suggestion',
                    'at':last['created_at'],'id':last['id']})).decode().rstrip('=')
            return {'workspace_id':ws_id,'generation':ws['generation'],'tree_digest':ws['tree_digest'],
                    'items':items,'next_cursor':next_cursor}

    def _suggestion_source(self, principal, ws, paths, context):
        manifest = self.manifest(ws)['files']
        allowed, current_context = self._context_files(principal, ws)
        self._context_current(ws, context)
        files, total = {}, 0
        for path in paths:
            if path not in manifest or path not in allowed:
                raise CodeError(403, 'suggestion_path', 'path is absent or context-excluded')
            data = self.store.read_blob(manifest[path]['digest'], ws['id'])
            total += len(data)
            if total > 8*1024*1024:
                raise CodeError(413,'suggestion_size','suggestion source exceeds8MiB')
            try: data.decode('utf-8')
            except UnicodeDecodeError:
                raise CodeError(415,'suggestion_binary','suggestions require UTF-8 text')
            files[path] = data
        return files

    def function_scope_preview(self,principal,ws_id,payload):
        from .function_scope_process import select
        import subprocess
        ws=self.workspace(ws_id)
        self._live(principal)
        self._authorize(principal,'read',ws,{'paths':[payload['path']]})
        self._fresh(ws,payload['expected_generation'],payload['expected_tree_digest'])
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'function-scope-preview',
                                             'generation':ws['generation'],'path':payload['path']})
        if not payload['path'].endswith(('.py','.pyi')):
            raise CodeError(415,'function_language','exact function selection currently supports saved Python')
        _,context=self._context_files(principal,ws)
        files=self._suggestion_source(principal,ws,[payload['path']],context)
        if digest(files[payload['path']])!=payload['source_digest']:
            raise CodeError(409,'function_scope_stale','saved file digest changed')
        if not self._function_scope_slots.acquire(blocking=False):
            raise CodeError(429,'function_scope_busy','function parser capacity exhausted')
        try:
            try:result=select(files[payload['path']],payload['caret_byte'],payload['source_digest'],self.store.root)
            except (ValueError,OSError,RuntimeError,subprocess.TimeoutExpired):
                raise CodeError(422,'function_scope_refused','bounded saved function selection refused') from None
        finally:self._function_scope_slots.release()
        self._live(principal)
        self._authorize(principal,'read',ws,{'paths':[payload['path']]})
        current=self.workspace(ws_id)
        self._fresh(current,payload['expected_generation'],payload['expected_tree_digest'])
        self._context_current(current,context)
        selection={**result,'workspace_id':ws_id,'task_id':ws['task_id'],'generation':ws['generation'],
                   'tree_digest':ws['tree_digest'],'path':payload['path'],'caret_byte':payload['caret_byte'],
                   'context_selection':context}
        return {'selection':selection,'selection_digest':digest(canonical(selection)),'scope_issued':False}

    def create_function_scope(self,principal,ws_id,payload):
        if principal.grant.get('kind')!='human':
            raise CodeError(403,'human_scope_required','a person must issue function scope')
        ws=self.workspace(ws_id)
        request={**payload,'mutation':'function-scope-request'}
        operation={'action':'read','workspace_id':ws_id,
                   **{k:v for k,v in request.items() if k!='approval_id'}}
        with self.store.lock:
            self._authorize(principal,'read',ws,{'paths':[payload['path']]})
            self._live(principal)
            cached=self.store.cached(principal.actor,payload['operation_id'],operation)
            if cached is not None:return self._scope_echo(principal,ws_id,cached)
        preview=self.function_scope_preview(principal,ws_id,payload)
        if preview['selection_digest']!=payload['selection_digest']:
            raise CodeError(409,'function_scope_stale','function preview identity changed')
        selection=preview['selection']
        scoped={k:v for k,v in payload.items() if k in ('operation_id','approval_id','expected_generation','expected_tree_digest')}
        scoped['ranges']={payload['path']:[[selection['start_byte'],selection['end_byte']]]}
        return self.create_suggestion_scope(principal,ws_id,scoped,
                                            _function_selection=selection,_operation_payload=request)

    def create_suggestion_scope(self, principal, ws_id, payload, *, _function_selection=None, _operation_payload=None):
        if principal.grant.get('kind') != 'human':
            raise CodeError(403,'human_scope_required','a person must issue the edit scope')
        if payload.get('schema_marker',payload.get('schema')) == 'omegacode-suggestion-scope-request-v2':
            return self._create_suggestion_scope_v2(principal, ws_id, payload)
        ws = self.workspace(ws_id)
        paths = sorted(payload['ranges'])
        if not paths or len(paths)>100:
            raise CodeError(400,'suggestion_scope','scope needs1–100 paths')
        operation = {**payload,'paths':paths,'mutation':'suggestion-scope'}
        if _function_selection is not None:
            operation['function_selection']=_function_selection
        if _operation_payload is not None:
            operation=_operation_payload
        def apply():
            current=self.workspace(ws_id)
            if sum(r['workspace_id']==ws_id for r in self.store.list('suggestion_scope'))>=128:
                raise CodeError(429,'suggestion_budget','workspace scope budget exhausted')
            self._fresh(current,payload['expected_generation'],payload['expected_tree_digest'])
            _,context=self._context_files(principal,current)
            files=self._suggestion_source(principal,current,paths,context)
            normalized={}
            for path,ranges in payload['ranges'].items():
                if not ranges or len(ranges)>100:
                    raise CodeError(400,'suggestion_scope','bounded ranges required')
                normalized[path]=[]
                for start,end in ranges:
                    if not boundary(files[path],start) or not boundary(files[path],end) or start>end:
                        raise CodeError(400,'suggestion_scope','invalid UTF-8 range')
                    normalized[path].append([start,end])
            body={'workspace_id':ws_id,'task_id':current['task_id'],
                  'generation':current['generation'],'tree_digest':current['tree_digest'],
                  'ranges':normalized,'file_digests':{p:digest(b) for p,b in files.items()},
                  'context_selection':context,'author':principal.actor}
            if _function_selection is not None:
                if _function_selection['source_digest']!=body['file_digests'][_function_selection['path']]:
                    raise CodeError(409,'function_scope_stale','function source changed')
                body['function_selection']=_function_selection
            blob=self.store.blob(canonical(body),ws_id,'suggestion-scope')
            record={'id':ident('scope'),'workspace_id':ws_id,'digest':blob,'author':principal.actor,
                    'issuer_claims':principal.grant,'created_at':stamp()}
            self._context_current(current,context)
            self.store.put('suggestion_scope',record)
            result={k:v for k,v in record.items() if k!='issuer_claims'}
            self.store.emit(current,'suggestion.scope-created',result)
            return result
        result = self._operation(principal,'read',ws,operation,apply)
        return self._scope_echo(principal,ws_id,result)

    def _create_suggestion_scope_v2(self, principal, ws_id, payload):
        """Retain an explicit absent-path ceiling through the existing person scope."""
        from .suggestion_creation import path_union, validate_create_scope
        from .context_selection import select_destinations
        ws = self.workspace(ws_id)
        ranges = payload['ranges']
        create_files = {path: row for path, row in payload['create_files'].items()}
        paths = path_union(ranges, create_files)
        operation = {**payload, 'paths':paths, 'mutation':'suggestion-scope-v2'}

        def apply():
            current = self.workspace(ws_id)
            if sum(r['workspace_id']==ws_id for r in self.store.list('suggestion_scope')) >= 128:
                raise CodeError(429,'suggestion_budget','workspace scope budget exhausted')
            self._fresh(current,payload['expected_generation'],payload['expected_tree_digest'])
            manifest = self.manifest(current)['files']
            config = self.repositories[current['repository_id']]
            destination_results, context = select_destinations(
                manifest, config,
                lambda value:self.store.read_blob(value,current['id']), self.store.root,
                list(create_files), principal.grant['paths'])
            issued = validate_create_scope(manifest, ranges, create_files,
                                           payload['max_total_create_bytes'],destination_results)
            range_paths = sorted(ranges)
            files = self._suggestion_source(principal,current,range_paths,context) if range_paths else {}
            normalized = {}
            for path, byte_ranges in ranges.items():
                if not byte_ranges or len(byte_ranges)>100:
                    raise CodeError(400,'suggestion_scope','bounded ranges required')
                normalized[path] = []
                for start, end in byte_ranges:
                    if not boundary(files[path],start) or not boundary(files[path],end) or start>end:
                        raise CodeError(400,'suggestion_scope','invalid UTF-8 range')
                    normalized[path].append([start,end])
            body = {'schema':'omegacode-suggestion-scope-v2','workspace_id':ws_id,
                    'task_id':current['task_id'],'generation':current['generation'],
                    'tree_digest':current['tree_digest'],'ranges':normalized,
                    'file_digests':{p:digest(data) for p,data in files.items()},
                    'create_files':issued['create_files'],
                    'destination_evaluation':{'generation':current['generation'],
                        'tree_digest':current['tree_digest'],
                        'context_policy_digest':context['policy_digest'],
                        'results':issued['destination_results']},
                    'max_total_create_bytes':issued['max_total_create_bytes'],
                    'context_selection':context,'author':principal.actor}
            blob = self.store.blob(canonical(body),ws_id,'suggestion-scope')
            record = {'id':ident('scope'),'workspace_id':ws_id,'digest':blob,
                      'author':principal.actor,'issuer_claims':principal.grant,'created_at':stamp()}
            self._context_current(current,context)
            self.store.put('suggestion_scope',record)
            public = {k:v for k,v in record.items() if k!='issuer_claims'}
            self.store.emit(current,'suggestion.scope-created',public)
            return public

        result = self._operation(principal,'read',ws,operation,apply)
        return self._scope_echo(principal,ws_id,result)

    def suggestion_scope_read(self, principal, ws_id, scope_id):
        """Read the existing admitted scope; never create or renew a proposal ceiling."""
        current=self.workspace(ws_id)
        self._authorize(principal,'read',current,{})
        self._live(principal)
        self._bound_suggestion_scope(principal,current,scope_id)
        record=self.store.get('suggestion_scope',scope_id)
        public={k:record[k] for k in ('id','workspace_id','digest','author','created_at')}
        result=self._scope_echo(principal,ws_id,public)
        current=self.workspace(ws_id)
        self._fresh(current,result['binding']['generation'],result['binding']['tree_digest'])
        self._live(principal)
        return {**result,'currency':'current'}

    def _scope_echo(self,principal,ws_id,result):
        # Enrich old cached receipts from custody; never renew their source binding.
        current=self.workspace(ws_id)
        body=self._bound_suggestion_scope(principal,current,result['id'],fresh=False)
        self._context_current(current,body['context_selection'])
        paths = _scope_paths(body)
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'suggestion-scope-echo',
                                             'scope_id':result['id'],'paths':paths})
        current=self.workspace(ws_id)
        body=self._bound_suggestion_scope(principal,current,result['id'],fresh=False)
        self._live(principal)
        self._context_current(self.workspace(ws_id),body['context_selection'])
        receipt = {**result,'binding':{k:body[k] for k in ('workspace_id','task_id','generation','tree_digest')},
                   'ranges':body['ranges'],'file_digests':body['file_digests'],'edit_authority':False}
        if body.get('schema') == 'omegacode-suggestion-scope-v2':
            receipt.update(schema=body['schema'],create_files=body['create_files'],
                           max_total_create_bytes=body['max_total_create_bytes'],
                           context_policy_digest=body['context_selection']['policy_digest'])
            if body.get('destination_evaluation') is not None:
                receipt['destination_evaluation']=body['destination_evaluation']
        return receipt

    def _bound_suggestion_scope(self, principal, ws, scope_id, *, fresh=True):
        record=self.store.get('suggestion_scope',scope_id)
        if record['workspace_id']!=ws['id']:
            raise CodeError(403,'suggestion_scope','scope belongs to another workspace')
        body=json.loads(self.store.read_blob(record['digest'],ws['id']))
        if body.get('schema') == 'omegacode-suggestion-scope-v2' and body.get('destination_evaluation') is not None:
            evaluation=body['destination_evaluation']
            expected_paths=set(body.get('create_files',{}))
            results=evaluation.get('results') if type(evaluation) is dict else None
            if (type(evaluation) is not dict or
                    set(evaluation)!={'generation','tree_digest','context_policy_digest','results'} or
                    evaluation['generation']!=body.get('generation') or
                    evaluation['tree_digest']!=body.get('tree_digest') or
                    evaluation['context_policy_digest']!=body.get('context_selection',{}).get('policy_digest') or
                    type(results) is not dict or set(results)!=expected_paths or
                    any(row!={'allowed':True,'reason':None} for row in results.values())):
                raise CodeError(409,'suggestion_scope','retained destination evaluation differs from its source or policy binding')
        delegated=principal.grant.get('delegated')
        if delegated is not None:
            ceiling=delegated['origin_scope']
            if (scope_id!=ceiling['scope_id'] or 'sha256:'+record['digest']!=ceiling['scope_digest'] or
                body['generation']!=ceiling['generation'] or record['author']!=delegated['issuer']):
                raise CodeError(403,'delegated_scope_forbidden','scope is outside the request-bound person-issued proposal ceiling')
        issuer=Principal(record['author'],record['issuer_claims'])
        self._live(issuer)
        paths = _scope_paths(body)
        self._authorize(issuer,'read',ws,{'paths':paths})
        self._authorize(principal,'read',ws,{'paths':paths})
        if fresh:
            self._fresh(ws,body['generation'],body['tree_digest'])
            self._context_current(ws,body['context_selection'])
        return body

    def create_suggestion(self, principal, ws_id, payload):
        if payload.get('schema_marker',payload.get('schema')) == 'omegacode-suggestion-request-v2':
            return self._create_suggestion_v2(principal,ws_id,payload)
        # Preserve operation fingerprints for old clients and retained replay receipts.
        if payload.get('groups') is None:
            payload = {k:v for k,v in payload.items() if k != 'groups'}
        ws=self.workspace(ws_id)
        scope=self._bound_suggestion_scope(principal,ws,payload['scope_id'])
        operation={**payload,'paths':list(scope['ranges']),'mutation':'suggestion-preview'}
        request_binding=json.loads(canonical(principal.grant['delegated'])) if 'delegated' in principal.grant else None
        if request_binding is not None:
            operation['request_binding']=request_binding
        def apply():
            current=self.workspace(ws_id)
            if sum(r['workspace_id']==ws_id for r in self.store.list('suggestion'))>=128:
                raise CodeError(429,'suggestion_budget','workspace proposal budget exhausted')
            if len(canonical(payload['hunks']))>4*1024*1024:
                raise CodeError(413,'suggestion_size','proposal exceeds4MiB')
            scope=self._bound_suggestion_scope(principal,current,payload['scope_id'])
            files=self._suggestion_source(principal,current,list(scope['ranges']),scope['context_selection'])
            binding={k:scope[k] for k in ('workspace_id','task_id','generation','tree_digest')}
            try: normalized=prepare(binding,files,scope['ranges'],payload['hunks'],payload.get('groups'))
            except (ValueError,TypeError,KeyError) as exc:
                raise CodeError(400,'suggestion_refused',str(exc))
            body={**normalized,'scope_id':payload['scope_id'],'author':principal.actor}
            blob=self.store.blob(canonical(body),ws_id,'suggestion')
            record={'id':ident('suggestion'),'workspace_id':ws_id,'scope_id':payload['scope_id'],
                    'digest':blob,'author':principal.actor,'created_at':stamp()}
            self._context_current(current,scope['context_selection'])
            self.store.put('suggestion',record)
            if request_binding is not None:
                provenance={'schema':'omegacode-request-proposal-v1','workspace_id':ws_id,
                            'proposal_id':record['id'],'proposal_digest':record['digest'],
                            'author':principal.actor,'origin_task_id':current['task_id'],
                            'origin_swarm_id':current['swarm_id'],'repository_id':current['repository_id'],
                            'delegated':request_binding}
                provenance_digest=self.store.blob(canonical(provenance),ws_id,'suggestion-provenance')
                self.store.put('suggestion_provenance',{'id':record['id'],'workspace_id':ws_id,'digest':provenance_digest})

            self.store.emit(current,'suggestion.created',record)
            return record
        return self._operation(principal,'read',ws,operation,apply)

    def _create_suggestion_v2(self, principal, ws_id, payload):
        from .context_selection import select_destinations
        from .language_buffers import validate_new_path_namespace
        ws = self.workspace(ws_id)
        scope = self._bound_suggestion_scope(principal,ws,payload['scope_id'])
        if scope.get('schema') != 'omegacode-suggestion-scope-v2':
            raise CodeError(409,'suggestion_scope_version','v2 proposal requires a retained v2 person scope')
        scope_paths = _scope_paths(scope)
        operation = {**payload,'paths':scope_paths,'mutation':'suggestion-preview-v2',
                     'scope_digest':self.store.get('suggestion_scope',payload['scope_id'])['digest']}
        request_binding=json.loads(canonical(principal.grant['delegated'])) if 'delegated' in principal.grant else None
        if request_binding is not None:
            operation['request_binding']=request_binding

        def apply():
            current=self.workspace(ws_id)
            if sum(r['workspace_id']==ws_id for r in self.store.list('suggestion'))>=128:
                raise CodeError(429,'suggestion_budget','workspace proposal budget exhausted')
            scope=self._bound_suggestion_scope(principal,current,payload['scope_id'])
            if scope.get('schema') != 'omegacode-suggestion-scope-v2':
                raise CodeError(409,'suggestion_scope_version','v2 proposal requires a retained v2 person scope')
            scope_record=self.store.get('suggestion_scope',payload['scope_id'])
            self._fresh(current,scope['generation'],scope['tree_digest'])
            manifest=self.manifest(current)['files']
            create_paths=sorted(scope['create_files'])
            validate_new_path_namespace(manifest,create_paths,max_paths=100) if create_paths else None
            destinations,context=select_destinations(
                manifest,self.repositories[current['repository_id']],
                lambda value:self.store.read_blob(value,current['id']),self.store.root,
                create_paths,principal.grant['paths'])
            for path in create_paths:
                if destinations.get(path,{}).get('allowed') is not True:
                    raise CodeError(403,'context_excluded','destination is excluded or unavailable under saved context policy')
            edit_paths=sorted(scope['ranges'])
            files=self._suggestion_source(principal,current,edit_paths,context) if edit_paths else {}
            binding={k:scope[k] for k in ('workspace_id','task_id','generation','tree_digest')}
            try:
                normalized=prepare_v2(binding,files,scope,payload['scope_id'],scope_record['digest'],
                                      payload['hunks'],payload.get('groups'),principal.actor)
                body_size=len(canonical(normalized))
            except CodeError:
                raise
            except (ValueError,TypeError,KeyError,UnicodeError) as exc:
                raise CodeError(400,'suggestion_refused',str(exc)) from None
            if body_size>4*1024*1024:
                raise CodeError(413,'suggestion_size','proposal exceeds4MiB')
            blob=self.store.blob(canonical(normalized),ws_id,'suggestion')
            record={'id':ident('suggestion'),'workspace_id':ws_id,'scope_id':payload['scope_id'],
                    'digest':blob,'author':principal.actor,'created_at':stamp()}
            self._context_current(current,context)
            self.store.put('suggestion',record)
            if request_binding is not None:
                provenance={'schema':'omegacode-request-proposal-v1','workspace_id':ws_id,
                            'proposal_id':record['id'],'proposal_digest':record['digest'],
                            'author':principal.actor,'origin_task_id':current['task_id'],
                            'origin_swarm_id':current['swarm_id'],'repository_id':current['repository_id'],
                            'delegated':request_binding}
                provenance_digest=self.store.blob(canonical(provenance),ws_id,'suggestion-provenance')
                self.store.put('suggestion_provenance',{'id':record['id'],'workspace_id':ws_id,'digest':provenance_digest})
            self.store.emit(current,'suggestion.created',record)
            return record
        return self._operation(principal,'read',ws,operation,apply)

    def suggestion(self, principal, ws_id, suggestion_id, *, include_request_binding=False):
        ws=self.workspace(ws_id)
        record=self.store.get('suggestion',suggestion_id)
        if record['workspace_id']!=ws_id:
            raise CodeError(403,'suggestion_scope','proposal belongs to another workspace')
        body=json.loads(self.store.read_blob(record['digest'],ws_id))
        self._authorize(principal,'read',ws,{'paths':list(body['scope'])})
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'suggestion','suggestion_id':suggestion_id})
        decisions=[r for r in self.store.list('suggestion_decision') if r['suggestion_id']==suggestion_id]
        self._live(principal)
        result={'record':record,'content':body,'decisions':decisions,
                'currency':'current' if body['binding']['generation']==ws['generation'] and body['binding']['tree_digest']==ws['tree_digest'] else 'stale'}
        if include_request_binding:
            saved=next((r for r in self.store.list('suggestion_provenance') if r['id']==suggestion_id),None)
            result['request_binding']=None
            if saved is not None:
                if saved['workspace_id']!=ws_id:
                    raise CodeError(403,'provenance_scope','request provenance belongs to another workspace')
                provenance=json.loads(self.store.read_blob(saved['digest'],ws_id))
                if (provenance['proposal_id']!=record['id'] or provenance['proposal_digest']!=record['digest'] or
                    provenance['author']!=record['author'] or provenance['workspace_id']!=ws_id):
                    raise CodeError(409,'provenance_mismatch','request provenance is not bound to this proposal')
                delegated=principal.grant.get('delegated')
                if delegated is not None and provenance['delegated']!=delegated:
                    raise CodeError(403,'provenance_scope','request provenance is outside this delegated request')
                result['request_binding']={'digest':saved['digest'],'content':provenance}
            self._live(principal)
        return result

    def decide_suggestion(self, principal, ws_id, payload):
        ws=self.workspace(ws_id)
        record=self.store.get('suggestion',payload['suggestion_id'])
        if record['workspace_id']!=ws_id or record['digest']!=payload['suggestion_digest']:
            raise CodeError(403,'suggestion_scope','proposal identity mismatch')
        body=json.loads(self.store.read_blob(record['digest'],ws_id))
        if (payload['expected_generation']!=body['binding']['generation'] or
                payload['expected_tree_digest']!=body['binding']['tree_digest']):
            raise CodeError(409,'suggestion_stale','decision must bind the retained proposal source')
        v2=body.get('schema')=='omegacode-scoped-suggestion-v2'
        # A retained v2 decision is the person's explicit apply/reject action.
        # Check before scope access, policy receipts, or idempotency replay.
        if v2 and principal.grant.get('kind') != 'human':
            raise CodeError(403,'person_required','v2 proposal decisions require person authority')
        scope=self._bound_suggestion_scope(principal,ws,record['scope_id'],fresh=False)
        if v2:
            scope_record=self.store.get('suggestion_scope',record['scope_id'])
            if (body.get('scope_id')!=record['scope_id'] or body.get('scope_digest')!=scope_record['digest'] or
                    body.get('author')!=record['author'] or scope.get('schema')!='omegacode-suggestion-scope-v2'):
                raise CodeError(409,'suggestion_scope','v2 proposal identity differs from its retained person scope')
        accepted,rejected=payload['accepted_hunk_ids'],payload['rejected_hunk_ids']
        ids=accepted+rejected;known={h['id'] for h in body['hunks']}
        if not ids or len(ids)!=len(set(ids)) or not set(ids)<=known:
            raise CodeError(400,'suggestion_decision','unknown/duplicate/empty hunk decisions')
        try: decision_groups(body, accepted, rejected)
        except ValueError as exc:
            raise CodeError(409,'suggestion_group_split',str(exc))
        files={p:self.store.read_blob(h,ws_id) for p,h in scope['file_digests'].items()}
        current={'workspace_id':ws_id,'task_id':ws['task_id'],'generation':payload['expected_generation'],
                 'tree_digest':payload['expected_tree_digest']}
        try:
            if v2:
                edits=reconstruct_v2(body,record['digest'],current,files,accepted,
                                     self.manifest(ws,payload['expected_tree_digest'])['files'].keys()) if accepted else []
            else:
                edits=reconstruct({k:v for k,v in body.items() if k not in ('scope_id','author')},body['digest'],current,files,accepted) if accepted else []
        except (ValueError,KeyError,TypeError) as exc:
            raise CodeError(409,'suggestion_stale',str(exc))
        operation={**payload,'paths':_scope_paths(scope),'mutation':'suggestion-decision',
                   'context_policy_digest':scope['context_selection']['policy_digest']}
        def retain(result):
            # Runs inside the edit operation's transaction, before final live checks.
            for prior in self.store.list('suggestion_decision'):
                if prior['suggestion_id']==record['id'] and set(ids)&set(prior['accepted_hunk_ids']+prior['rejected_hunk_ids']):
                    raise CodeError(409,'suggestion_decided','hunk already decided')
            issuer=Principal(scope['author'],self.store.get('suggestion_scope',record['scope_id'])['issuer_claims'])
            self._live(issuer)
            self._authorize(issuer,'read',self.workspace(ws_id),{'paths':_scope_paths(scope)})
            decision={'id':ident('decision'),'suggestion_id':record['id'],'suggestion_digest':record['digest'],
                      'workspace_id':ws_id,'actor':principal.actor,'accepted_hunk_ids':accepted,
                      'rejected_hunk_ids':rejected,'change_id':result.get('change',{}).get('id'),
                      'created_at':stamp()}
            self.store.put('suggestion_decision',decision)
            self.store.emit(self.workspace(ws_id),'suggestion.decided',decision)
            return {**result,'decision':decision}
        if accepted:
            create_paths=[edit['path'] for edit in edits if edit.get('expected_digest') is None and edit.get('content') is not None] if v2 else []
            return self.edit(principal,ws_id,{**operation,'edits':edits},_after_edit=retain,
                             _create_paths=create_paths,_authorization_paths=_scope_paths(scope) if v2 else None)
        def reject():
            self._fresh(self.workspace(ws_id),payload['expected_generation'],payload['expected_tree_digest'])
            self._context_current(self.workspace(ws_id),scope['context_selection'])
            return retain({'workspace':self.workspace(ws_id)})
        return self._operation(principal,'edit',ws,operation,reject)

    def suggestion_hunk_before(self, principal, ws_id, suggestion_id, hunk_id, offset=0, limit=65536):
        """Page retained original bytes; history never supplies a fresh edit binding."""
        if type(offset) is not int or not 0 <= offset <= 2*1024*1024 or type(limit) is not int or not 1 <= limit <= 65536:
            raise CodeError(400,'suggestion_before_range','bounded byte offset/limit required')
        ws = self.workspace(ws_id)
        self._authorize(principal,'read',ws,{})
        self._live(principal)
        record = self.store.get('suggestion',suggestion_id)
        if record['workspace_id'] != ws_id:
            raise CodeError(403,'suggestion_scope','proposal belongs to another workspace')
        body = json.loads(self.store.read_blob(record['digest'],ws_id))
        hunk = next((h for h in body['hunks'] if h['id'] == hunk_id),None)
        if hunk is None:
            raise CodeError(404,'suggestion_hunk','hunk is not in the retained proposal')
        scope = self._bound_suggestion_scope(principal,ws,record['scope_id'],fresh=False)
        self._context_current(ws,scope['context_selection'])
        self.authority.gate(principal,'read',{'workspace_id':ws_id,'resource':'suggestion-hunk-before',
                                             'suggestion_id':suggestion_id,'hunk_id':hunk_id,'paths':[hunk['path']]})
        if body.get('schema') == 'omegacode-scoped-suggestion-v2' and hunk.get('kind') == 'create_text':
            ceiling=scope.get('create_files',{}).get(hunk['path'])
            if (ceiling is None or ceiling.get('before') != {'kind':'absent'} or
                    hunk.get('before') != {'kind':'absent'} or hunk['path'] in scope['file_digests']):
                raise CodeError(409,'suggestion_before_integrity','retained absent-file binding mismatch')
            try:content_bytes=hunk['content'].encode('utf-8','strict')
            except (KeyError,AttributeError,UnicodeError):
                raise CodeError(409,'suggestion_before_integrity','retained create-text content is invalid') from None
            if (len(content_bytes)!=hunk.get('content_bytes') or digest(content_bytes)!=hunk.get('content_digest') or
                    len(content_bytes)>ceiling['max_bytes']):
                raise CodeError(409,'suggestion_before_integrity','retained create-text content digest mismatch')
            if offset != 0:
                raise CodeError(400,'suggestion_before_range','an absent file has no source byte range')
            current=self.workspace(ws_id)
            self._bound_suggestion_scope(principal,current,record['scope_id'],fresh=False)
            self._live(principal)
            self._context_current(self.workspace(ws_id),scope['context_selection'])
            return {'schema':'omegacode-suggestion-before-v2','workspace_id':ws_id,
                    'suggestion_id':suggestion_id,'suggestion_digest':record['digest'],'hunk_id':hunk_id,
                    'path':hunk['path'],'binding':body['binding'],'before':{'kind':'absent'},
                    'currency':'current' if body['binding']['generation']==current['generation'] and
                    body['binding']['tree_digest']==current['tree_digest'] else 'stale','edit_authority':False}
        file_digest = scope['file_digests'].get(hunk['path'])
        if file_digest != hunk['expected_file_digest']:
            raise CodeError(409,'suggestion_before_integrity','retained source binding mismatch')
        source = self.store.read_blob(file_digest,ws_id)
        start,end = hunk['start_byte'],hunk['end_byte']
        if len(source) > 2*1024*1024 or not boundary(source,start) or not boundary(source,end) or start > end:
            raise CodeError(409,'suggestion_before_integrity','retained source range mismatch')
        before = source[start:end]
        if digest(before) != hunk['before_digest']:
            raise CodeError(409,'suggestion_before_integrity','retained original bytes mismatch')
        if offset > len(before):
            raise CodeError(400,'suggestion_before_range','offset exceeds retained hunk bytes')
        page = before[offset:offset+limit]
        current = self.workspace(ws_id)
        self._bound_suggestion_scope(principal,current,record['scope_id'],fresh=False)
        self._live(principal)
        current = self.workspace(ws_id)
        self._context_current(current,scope['context_selection'])
        return {'schema':'omegacode-suggestion-before-v1','workspace_id':ws_id,
                'suggestion_id':suggestion_id,'suggestion_digest':record['digest'],'hunk_id':hunk_id,
                'path':hunk['path'],'binding':body['binding'],'before_digest':hunk['before_digest'],
                'file_digest':file_digest,'currency':'current' if body['binding']['generation']==current['generation'] and body['binding']['tree_digest']==current['tree_digest'] else 'stale',
                'encoding':'base64','data':base64.b64encode(page).decode(),'offset':offset,
                'total_bytes':len(before),'next_offset':offset+len(page) if offset+len(page)<len(before) else None,
                'edit_authority':False}
