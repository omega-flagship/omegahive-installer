"""Bounded trusted parser helper; no user code execution or OS sandbox claim."""
from pathlib import Path
import tempfile,subprocess,sys,os,signal,json,base64,hashlib
from .runner import group_members

def select(data,caret,expected_digest,scratch_root):
    if type(data) is not bytes or len(data)>1024*1024:raise ValueError('bounded saved bytes required')
    if type(caret) is not int or not 0<=caret<len(data):raise ValueError('byte caret required')
    if hashlib.sha256(data).hexdigest()!=expected_digest:raise ValueError('source digest mismatch')
    interpreter_digest=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()
    helper=Path(__file__).with_name('function_scope_helper.py').read_bytes()
    request=json.dumps(dict(data=base64.b64encode(data).decode(),caret=caret,expected_digest=expected_digest)).encode()
    with tempfile.TemporaryDirectory(prefix='function-parser-',dir=scratch_root) as tmp:
        root=Path(tmp);frozen=root/'helper.py';frozen.write_bytes(helper);frozen.chmod(0o400)
        with tempfile.TemporaryFile(dir=root) as out,tempfile.TemporaryFile(dir=root) as err:
            process=subprocess.Popen([sys.executable,'-I',str(frozen)],stdin=subprocess.PIPE,stdout=out,stderr=err,
                                     cwd=root,start_new_session=True,env={'PATH':os.defpath,'LANG':'C.UTF-8','TMPDIR':str(root)})
            timed_out=False
            try:process.communicate(request,timeout=3)
            except subprocess.TimeoutExpired:
                timed_out=True
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                process.communicate(timeout=2)
            if group_members(process.pid):raise ValueError('parser cleanup unconfirmed')
            if timed_out:raise ValueError('parser deadline exceeded')
            if out.tell()>8192 or err.tell()>8192:raise ValueError('parser output bound exceeded')
            out.seek(0);raw=out.read(8193)
            if process.returncode!=0:raise ValueError('parser selection refused')
    try:reply=json.loads(raw);result=reply['result']
    except (ValueError,KeyError,TypeError):raise ValueError('parser protocol refused') from None
    if reply.get('ok') is not True or result['source_digest']!=expected_digest:
        raise ValueError('parser source binding refused')
    if result.get('parser_executable_digest')!=interpreter_digest or hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()!=interpreter_digest:
        raise ValueError('parser executable identity changed')
    start,end=result['start_byte'],result['end_byte']
    if type(start) is not int or type(end) is not int or not 0<=start<=caret<end<=len(data):
        raise ValueError('parser range refused')
    if hashlib.sha256(data[start:end]).hexdigest()!=result['range_digest']:
        raise ValueError('parser range digest refused')
    result['helper_digest']=hashlib.sha256(helper).hexdigest()
    result['cleanup_observed']=True
    return result
