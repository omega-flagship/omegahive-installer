"""Uninstalled owner-only purpose batch preparation; automatic launch stays off."""
import copy, pathlib
from omegacode.common import canonical, CodeError
from omegacode.confinement import identity
from omegacode.proposal_launch_custody import Custody
from .launch_admission import candidate
from .proposal_host_wire import fail

def prepare(service, authority, principal, host, launch_id):
    service._check_owner(required=True)
    g = principal.grant
    claims = canonical(g)
    p = g['proposal_test']
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + p['test_id'] + '/launches')
    row = Custody(service.store).get(launch_id)
    projection = service.store.get('proposal_dispatch_binding', launch_id)
    (saved, bound, fork) = candidate(service, authority, principal)
    expected = dict(workspace_id=fork['id'], generation=fork['generation'], tree_digest=fork['tree_digest'], grant_id=g['id'], actor=principal.actor)
    if row['state'] != 'spawning' or row['ever_spawning'] is not True or row['test_id'] != p['test_id'] or (projection['execution_binding'] != expected) or (projection['host_binding'] != row['binding']) or (projection['run_id'] != row['run_id']) or (projection['nonce'] != row['nonce']) or (row['spawn_marker'] != str(service.store.root / 'runs' / row['run_id'])) or (not any((row['argv'][:len(prefix)] == prefix for prefix in g['argv_prefixes']))) or (row['runtime_seconds'] > min(g['max_runtime_seconds'], p['allowance']['per_launch_max_runtime_seconds'])):
        fail('purpose_native_binding')
    config = service.repositories[fork['repository_id']]
    conf = copy.deepcopy(config.get('execution_confinement'))
    try:
        pinned = identity(conf)
        if str(pathlib.Path(row['argv'][0]).resolve(strict=True)) != pinned['python']:
            raise ValueError('only pinned batch Python')
    except (OSError, ValueError, TypeError, KeyError):
        fail('purpose_native_profile')
    if not host.dispatch_gate(g, row):
        fail('purpose_native_admission')
    payload = dict(operation_id=row['launch_key'], workspace_id=fork['id'], expected_generation=fork['generation'], expected_tree_digest=fork['tree_digest'], argv=row['argv'], timeout_seconds=row['runtime_seconds'], terminal=False)
    with service.store.transaction():
        service._check_owner(required=True)
        if canonical(g) != claims or Custody(service.store).get(launch_id) != row or service.store.get('proposal_dispatch_binding', launch_id) != projection or (service.workspace(fork['id']) != fork):
            fail('purpose_native_binding')
        if any((r['id'] == row['run_id'] for r in service.store.list('run'))):
            fail('purpose_native_prepared')
        root = service.store.root / 'runs' / row['run_id']
        if root.exists() or root.is_symlink():
            fail('purpose_native_root_retained')
        runs = [r for r in service.store.list('run') if r['task_id'] == fork['task_id'] and r['swarm_id'] == fork['swarm_id']]
        if len(runs) >= config.get('max_task_runs', 20) or sum((r['timeout_seconds'] for r in runs)) + row['runtime_seconds'] > config.get('task_runtime_budget_seconds', 600):
            raise CodeError(429, 'task_budget', 'aggregate task run/runtime budget exhausted')
        run = service._prepare_run_snapshot(principal, payload, fork, fork, row, confinement_config=conf, purpose_id=row['test_id'])
        fresh = candidate(service, authority, principal)
        try:
            current_pin = identity(service.repositories[fork['repository_id']].get('execution_confinement'))
        except (OSError, ValueError, TypeError, KeyError):
            fail('purpose_native_profile')
        if fresh != (saved, bound, fork) or canonical(g) != claims or current_pin != pinned or (Custody(service.store).get(launch_id) != row) or (service.store.get('proposal_dispatch_binding', launch_id) != projection):
            fail('purpose_native_binding')
        service._check_owner(required=True)
    return run
