"""AST-only inventory of reviewed process sinks and interpreter argv builders.

No product/toolchain import or execution. New launch calls, aliases, Python
argv builders, or changed reviewed dynamic/non-Python argv require review.
This is a bounded source regression, not whole-program taint verification.
"""
from __future__ import annotations

import ast
from collections import defaultdict
import json
from pathlib import Path
import re


SOURCE = Path(__file__).resolve().parents[1]
REGISTRY = Path(__file__).with_name("PYTHON_CHILD_LAUNCH_CENSUS.json")
SUBPROCESS = {"Popen", "run", "call", "check_call", "check_output", "getoutput", "getstatusoutput"}


def dotted(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = dotted(node.value)
        return prefix + "." + node.attr if prefix else node.attr
    return ""


def scan_text(filename, text):
    tree = ast.parse(text)
    parents = {child: node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for item in node.names:
                aliases[item.asname or item.name.split(".")[0]] = item.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for item in node.names:
                aliases[item.asname or item.name] = node.module + "." + item.name

    def target(node):
        name = dotted(node)
        first, separator, suffix = name.partition(".")
        return aliases.get(first, first) + (separator + suffix if separator else "")

    def dap_python(node):
        parent = parents.get(node)
        return isinstance(parent, ast.Dict) and any(
            value is node and isinstance(key, ast.Constant) and key.value == "python"
            for key, value in zip(parent.keys, parent.values))

    def candidate(node):
        if not node.elts:
            return False
        if dap_python(node):
            return True
        first = node.elts[0]
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            if first.value.startswith("-"):
                return False
            if re.fullmatch(r"python(?:[0-9]+(?:\.[0-9]+)*)?", Path(first.value).name):
                return True
        if target(first) == "sys.executable":
            return True
        flags = {item.value for item in node.elts[1:] if isinstance(item, ast.Constant) and isinstance(item.value, str)}
        return bool(flags.intersection({"-I", "-m", "-c", "-u"}))

    records = {"process_sites": {}, "argv_builders": {}}

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.scope = []
            self.process_counts = defaultdict(int)
            self.builder_counts = defaultdict(int)

        def visit_FunctionDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_ClassDef(self, node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()

        def visit_Call(self, node):
            name = target(node.func)
            module, _, method = name.rpartition(".")
            sink = ((module == "subprocess" and method in SUBPROCESS)
                    or method in {"create_subprocess_exec", "create_subprocess_shell"}
                    or (module == "os" and (method.startswith(("exec", "spawn")) or method in {"system", "popen", "posix_spawn", "posix_spawnp"}))
                    or name == "pty.spawn")
            if sink:
                scope = ".".join(self.scope) or "<module>"
                count_key = (scope, name)
                number = self.process_counts[count_key]; self.process_counts[count_key] += 1
                key = f"{filename}:{scope}:{name}#{number}"
                argv = node.args[0] if node.args else next((item.value for item in node.keywords if item.arg in {"args", "argv"}), None)
                records["process_sites"][key] = {"argv": ast.unparse(argv) if argv is not None else "<unknown>", "line": node.lineno}
            self.generic_visit(node)

        def visit_List(self, node):
            if candidate(node):
                scope = ".".join(self.scope) or "<module>"
                number = self.builder_counts[scope]; self.builder_counts[scope] += 1
                key = f"{filename}:{scope}:argv#{number}"
                items = node.elts
                bytecode = [i for i, item in enumerate(items) if isinstance(item, ast.Constant) and item.value == "-B"]
                first_target = len(items)
                for i, item in enumerate(items[1:], 1):
                    if not isinstance(item, ast.Constant) or not isinstance(item.value, str) or not item.value.startswith("-") or item.value in {"-c", "-m", "--"}:
                        first_target = i
                        break
                records["argv_builders"][key] = {"argv": ast.unparse(node), "line": node.lineno,
                    "explicit_bytecode_disabled": len(bytecode) == 1 and 0 < bytecode[0] < first_target,
                    "dap_python_field": dap_python(node)}
            self.generic_visit(node)
        visit_Tuple = visit_List

    Visitor().visit(tree)
    return records


def scan_sources(sources):
    combined = {"process_sites": {}, "argv_builders": {}}
    for name, text in sorted(sources.items()):
        records = scan_text(name, text)
        for category in combined:
            combined[category].update(records[category])
    return combined


def source_map(root=SOURCE):
    package = root / "src/omegacode"
    return {path.relative_to(package).as_posix(): path.read_text() for path in package.rglob("*.py") if "__pycache__" not in path.parts}


def check_inventory(scanned, registry):
    issues = []
    for category in ("process_sites", "argv_builders"):
        actual, expected = scanned[category], registry[category]
        for site in sorted(set(actual) - set(expected)):
            issues.append({"site": site, "reason": "unreviewed_launch_or_builder"})
        for site in sorted(set(expected) - set(actual)):
            issues.append({"site": site, "reason": "reviewed_site_missing"})
        for site in sorted(set(actual) & set(expected)):
            if actual[site]["argv"] != expected[site]["argv"]:
                issues.append({"site": site, "reason": "reviewed_argv_changed"})
            if category == "argv_builders" and expected[site]["kind"] == "owned_python" and not actual[site]["explicit_bytecode_disabled"]:
                issues.append({"site": site, "reason": "explicit_b_required_before_target"})
    owned = [value for value in registry["argv_builders"].values() if value["kind"] == "owned_python"]
    if len(owned) != 10:
        issues.append({"site": "registry", "reason": "expected_ten_owned_python_launches"})
    return issues


def main():
    scanned = scan_sources(source_map())
    registry = json.loads(REGISTRY.read_text())
    issues = check_inventory(scanned, registry)
    result = {"ok": not issues, "process_launch_sites": len(scanned["process_sites"]),
              "candidate_argv_builders": len(scanned["argv_builders"]), "owned_python_launches": 10,
              "scope": "ast_reviewed_launch_inventory_only", "issues": issues}
    print(json.dumps(result, sort_keys=True))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
