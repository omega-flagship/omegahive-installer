"""Uninstalled run/result own-cancel; no generic principal or hold settlement."""
import time, json
from omegacode.common import canonical, digest, atomic_write, stamp, CodeError
from omegacode.proposal_launch_custody import Custody, execution_binding
from omegacode.proposal_watchdog import Watchdog
from .proposal_host_wire import key, launch_binding, fail
from .launch_admission import scope_binding

def cancel(service, authority, principal, launch_key, operation_id):
    service._check_owner(required=True)
    key(launch_key)
    key(operation_id)
    g = principal.grant
    claims = canonical(g)
    p = g['proposal_test']
    tid = p['test_id']
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + tid + '/launches/' + launch_key + '/cancel')
    id_ = 'pl_' + digest(canonical([tid, launch_key]))
    custody = Custody(service.store)
    row = custody.get(id_)
    saved = service.store.get('proposal_preparation', tid)
    if row['test_id'] != tid or saved['binding'] != scope_binding(g):
        fail('purpose_cancel_binding')
    expected = launch_binding(g)
    for (name, value) in expected.items():
        if name == 'fork' and p['stage'] == 'result' and (value['workspace_id'] is None):
            continue
        if row['binding'].get(name) != value:
            fail('purpose_cancel_binding')
    payload = dict(action='proposal-own-cancel', test_id=tid, launch_id=id_, binding=scope_binding(g))
    authority.require_route(principal, 'POST', '/v1/proposal-tests/' + tid + '/launches/' + launch_key + '/cancel')
    with service.store.lock:
        service._check_owner(required=True)
        if canonical(g) != claims or custody.get(id_) != row or service.store.get('proposal_preparation', tid) != saved:
            fail('purpose_cancel_binding')
        if g['exp'] <= time.time():
            fail('purpose_cancel_authority')
        native = execution_binding(service.store, row)
        run = service.store.get('run', row['run_id'])
        if run['nonce'] != row['nonce'] or run.get('launch_custody_id') != id_ or run['argv'] != row['argv'] or (run['timeout_seconds'] != row['runtime_seconds']) or any((run[k] != native[n] for (k, n) in [('workspace_id', 'workspace_id'), ('generation', 'generation'), ('tree_digest', 'tree_digest'), ('grant_id', 'grant_id'), ('author', 'actor')])):
            fail('purpose_cancel_original')
        original = service.store.db.execute('SELECT body FROM grants WHERE id=?', (native['grant_id'],)).fetchone()
        if original is None:
            fail('purpose_cancel_original')
        execution_claims = json.loads(original[0])
        if execution_claims.get('id') != native['grant_id'] or scope_binding(execution_claims) != scope_binding(g) or (p.get('origin_grant_id') if p['stage'] == 'result' else g.get('grant_id')) != execution_claims.get('grant_id'):
            fail('purpose_cancel_origin_grant')
        cached = service.store.cached(principal.actor, operation_id, payload)
        if cached is not None:
            return cached
        root = service.store.root / 'runs' / row['run_id']
        if row['spawn_marker'] != str(root) or root.is_symlink():
            fail('purpose_cancel_original')
        Watchdog(service, None, time.monotonic)._cancel_original(row)
        if run['status'] in ('prepared', 'unknown'):
            with service.store.transaction():
                service._check_owner(required=True)
                current = service.store.get('run', run['id'])
                if current != run or custody.get(id_) != row:
                    fail('purpose_cancel_original')
                atomic_write(root / 'cancel.request', b'proposal own cancel')
                current.update(status='unknown', descendants_terminated=False)
                service.store.put('run', current)
                row.update(state='unknown', reason='own_cancel_unconfirmed')
                custody._put(row)
        result = dict(test_id=tid, launch_id=id_, run_id=run['id'], nonce=run['nonce'], cancel_requested=True, descendants_stopped=False, settled=False, at=stamp())
        with service.store.transaction():
            service._check_owner(required=True)
            service.store.remember(principal.actor, operation_id, payload, result)
        return result
