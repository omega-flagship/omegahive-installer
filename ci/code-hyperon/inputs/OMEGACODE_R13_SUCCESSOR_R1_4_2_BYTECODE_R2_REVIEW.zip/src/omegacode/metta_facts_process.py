"""Operator-enabled native syntax search with exact runtime/source custody pins."""
import base64,hashlib,json,os,signal,subprocess,tempfile
from pathlib import Path
from .symbolic import runtime_identity
from .runner import group_members

def search(sources,kind,symbol,config,scratch_root):
    if config.get('kind')!='hyperon' or config.get('source_search_enabled') is not True:
        raise ValueError('MeTTa source search requires explicit operator enablement')
    if type(sources) is not dict or len(sources)>128 or any(type(p) is not str or type(v) is not bytes or len(v)>1024*1024 for p,v in sources.items()) or sum(map(len,sources.values()))>8*1024*1024:
        raise ValueError('bounded named source bytes required')
    if kind not in ('expression_head','equation_subject','type_declared_subject') or type(symbol) is not str or not symbol or len(symbol.encode())>256:
        raise ValueError('closed symbolic query required')
    identity=runtime_identity(config)
    helpers={name:Path(__file__).with_name(name).read_bytes() for name in ('metta_facts_helper.py','metta_source_facts.py')}
    encoded=lambda v:json.dumps(v,sort_keys=True,separators=(',',':')).encode()
    request=encoded({'sources':{p:base64.b64encode(v).decode() for p,v in sources.items()},'kind':kind,'symbol':symbol,'runtime':identity})
    if len(request)>12*1024*1024:raise ValueError('encoded request bound')
    with tempfile.TemporaryDirectory(prefix='metta-facts-',dir=scratch_root) as tmp:
        root=Path(tmp)
        for name,raw in helpers.items():
            target=root/name;target.write_bytes(raw);target.chmod(0o400)
        with tempfile.TemporaryFile(dir=root) as out,tempfile.TemporaryFile(dir=root) as err:
            process=subprocess.Popen([identity['executable'],'-I','-B',str(root/'metta_facts_helper.py')],stdin=subprocess.PIPE,stdout=out,stderr=err,cwd=root,start_new_session=True,env={'PATH':os.defpath,'LANG':'C.UTF-8','TMPDIR':str(root)})
            timed_out=False
            try:process.communicate(request,timeout=10)
            except subprocess.TimeoutExpired:
                timed_out=True
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                process.communicate(timeout=2)
            if group_members(process.pid):raise ValueError('MeTTa parser cleanup unconfirmed')
            if timed_out:raise ValueError('MeTTa parser deadline exceeded')
            if process.returncode!=0 or out.tell()>4*1024*1024 or err.tell()>4*1024*1024:raise ValueError('MeTTa parser refused or exceeded output bound')
            out.seek(0);result=json.loads(out.read(4*1024*1024+1))
    expected_sources={p:hashlib.sha256(v).hexdigest() for p,v in sources.items()}
    if runtime_identity(config)!=identity or result.get('runtime_identity_digest')!=hashlib.sha256(encoded(identity)).hexdigest():
        raise ValueError('MeTTa runtime changed')
    if result.get('sources')!=expected_sources or result.get('kind')!=kind or result.get('symbol')!=symbol:
        raise ValueError('MeTTa source/query binding mismatch')
    for row in result['matches']:
        raw=sources.get(row['path']);start,end=row['start_byte'],row['end_byte']
        if raw is None or type(start) is not int or type(end) is not int or not 0<=start<end<=len(raw) or row['source_digest']!=expected_sources[row['path']] or hashlib.sha256(raw[start:end]).hexdigest()!=row['range_digest'] or raw[start:end].decode('utf-8')!=symbol:
            raise ValueError('MeTTa result range mismatch')
    result['helper_digests']={name:hashlib.sha256(raw).hexdigest() for name,raw in helpers.items()}
    result['cleanup_observed']=True
    return result
