"""Bounded top-level Python navigation. Host owns source authorization and edits."""
import ast,hashlib
from pathlib import PurePosixPath


def digest(data):return 'sha256:'+hashlib.sha256(data).hexdigest()


def index_sources(sources):
    if not isinstance(sources,dict) or not 0<len(sources)<=100:raise ValueError('Explicit bounded source map required')
    if any(not isinstance(data,bytes) for data in sources.values()) or sum(map(len,sources.values()))>2*1024*1024:raise ValueError('Source bytes exceed limit')
    result={'schema':'omega-python-navigation-1','files':{},'definitions':{},'imports':{},'shadowed':{},'diagnostics':[],'scope':'Top-level definitions and absolute from-import aliases; no runtime resolution','authority':'none'}
    for name,data in sources.items():
        path=PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or path.suffix!='.py' or str(path)!=name:raise ValueError('Relative Python source paths required')
        result['files'][name]=digest(data)
        try:tree=ast.parse(data,filename=name)
        except (SyntaxError,UnicodeError) as error:
            result['diagnostics'].append({'file':name,'source_digest':digest(data),'line':getattr(error,'lineno',None),'column':getattr(error,'offset',None),'message':str(error),'kind':'syntax'});continue
        definitions={};imports={};shadowed=set()
        for node in tree.body:
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                definitions.setdefault(node.name,[]).append({'file':name,'source_digest':digest(data),'line':node.lineno,'column':node.col_offset+1,'symbol':node.name,'kind':type(node).__name__})
            elif isinstance(node,ast.ImportFrom) and node.level==0 and node.module:
                for alias in node.names:
                    if alias.name=='*':shadowed.add('*')
                    else:imports.setdefault(alias.asname or alias.name,[]).append({'module':node.module,'symbol':alias.name})
            else:
                for child in ast.walk(node):
                    if isinstance(child,ast.Name) and isinstance(child.ctx,(ast.Store,ast.Del)):shadowed.add(child.id)
                    if isinstance(child,ast.Import):shadowed.update(alias.asname or alias.name.split('.')[0] for alias in child.names)
                    if isinstance(child,ast.ImportFrom):shadowed.update(alias.asname or alias.name for alias in child.names)
                    if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):shadowed.add(child.name)
        result['definitions'][name]=definitions;result['imports'][name]=imports
        result['shadowed'][name]=sorted(shadowed)
    return result


def resolve_symbol(index,sources,file,symbol):
    current=index_sources(sources)
    if index.get('schema')!='omega-python-navigation-1' or index.get('files')!=current['files']:raise ValueError('Stale source index; reindex exact bytes')
    if file not in current['files']:raise ValueError('Source not indexed')
    if '*' in current['shadowed'].get(file,[]) or symbol in current['shadowed'].get(file,[]):raise ValueError('Symbol has unsupported reassignment or import')
    definitions=current['definitions'].get(file,{})
    local=definitions.get(symbol,[])
    imports=current['imports'].get(file,{}).get(symbol,[])
    if local and imports or len(local)>1 or len(imports)>1:raise ValueError('Ambiguous symbol binding')
    if len(local)==1:return {'definition':local[0],'via':[],'authority':'none'}
    if len(imports)!=1:raise ValueError('Symbol not resolved in supported scope')
    imported=imports[0];module=imported['module'].replace('.','/')
    candidates=[p for p in [module+'.py',module+'/__init__.py'] if p in current['files']]
    if len(candidates)!=1:raise ValueError('Imported module unavailable or ambiguous')
    if '*' in current['shadowed'].get(candidates[0],[]) or imported['symbol'] in current['shadowed'].get(candidates[0],[]):raise ValueError('Imported definition has unsupported reassignment or import')
    targets=current['definitions'].get(candidates[0],{}).get(imported['symbol'],[])
    if len(targets)!=1:raise ValueError('Imported definition unavailable or ambiguous')
    return {'definition':targets[0],'via':[{'file':file,'alias':symbol,**imported}],'authority':'none'}
