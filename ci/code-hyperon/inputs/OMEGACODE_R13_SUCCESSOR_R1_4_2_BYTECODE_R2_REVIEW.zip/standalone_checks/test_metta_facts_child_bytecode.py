"""Portable launch regression with invented Python imports, never Hyperon.

Only the subprocess launch is real: a test-owned helper imports one invented
module in a writable temporary fixture tree. Parser helpers/runtime identity
and process census are substituted. The fixture child additionally uses -S to
exclude machine sitecustomize hooks; its module path is supplied explicitly.
This does not qualify a native parser.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock


SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE / "src"))
from omegacode import metta_facts_process as parser_process


def inventory(root):
    return sorted((path.relative_to(root).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest())
                  for path in root.rglob("*") if path.is_file())


class ParserChildBytecodeTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(Path(parser_process.__file__).resolve().is_relative_to(SOURCE / "src"))
        self.directory = tempfile.TemporaryDirectory(prefix="invented-parser-bytecode-")
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name).resolve()
        self.site = self.root / "invented-installed-tree"
        self.site.mkdir()
        (self.site / "invented_worker_module.py").write_text("VALUE = 'invented portable fixture'\n")
        self.scratch = self.root / "scratch"
        self.scratch.mkdir(mode=0o700)
        self.identity = {"executable": str(Path(sys.executable).absolute()), "root": str(self.site),
                         "executable_digest": "0" * 64, "files": {}}
        self.helper = ("import base64, hashlib, json, os, sys\n"
                       "sys.path.insert(0, " + repr(str(self.site)) + ")\n"
                       "import invented_worker_module\n"
                       "request = json.loads(sys.stdin.buffer.read())\n"
                       "encoded = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode()\n"
                       "result = {'sources': {path: hashlib.sha256(base64.b64decode(raw)).hexdigest() "
                       "for path, raw in request['sources'].items()}, 'kind': request['kind'], 'symbol': request['symbol'], "
                       "'matches': [], 'runtime_identity_digest': hashlib.sha256(encoded(request['runtime'])).hexdigest(), "
                       "'synthetic_bytecode_disabled': sys.dont_write_bytecode, "
                       "'synthetic_isolated': sys.flags.isolated, 'synthetic_ignore_environment': sys.flags.ignore_environment, "
                       "'synthetic_env_flag': os.environ.get('PYTHONDONTWRITEBYTECODE')}\n"
                       "sys.stdout.write(json.dumps(result))\n").encode()

    def run_fixture(self, *, remove_bytecode_flag=False, environment_only=False):
        original_read = Path.read_bytes
        original_popen = parser_process.subprocess.Popen
        helper_root = Path(parser_process.__file__).parent
        calls = []

        def read_bytes(path):
            if path == helper_root / "metta_facts_helper.py":
                return self.helper
            if path == helper_root / "metta_source_facts.py":
                return b"# invented companion; never imported\n"
            return original_read(path)

        def launch(argv, **kwargs):
            actual = list(argv)
            if remove_bytecode_flag:
                actual = [item for item in actual if item != "-B"]
            if environment_only:
                kwargs["env"] = {**kwargs["env"], "PYTHONDONTWRITEBYTECODE": "1"}
            calls.append((actual, dict(kwargs["env"]), kwargs["start_new_session"]))
            # Keep the actual producer argv above observable, while the
            # invented child excludes machine-specific sitecustomize policy.
            # No Hyperon/site-packages import is needed by this fixture.
            fixture_argv = [actual[0], "-S", *actual[1:]]
            return original_popen(fixture_argv, **kwargs)

        with mock.patch.object(Path, "read_bytes", read_bytes), \
             mock.patch.object(parser_process, "runtime_identity", return_value=self.identity), \
             mock.patch.object(parser_process, "group_members", return_value=[]), \
             mock.patch.object(parser_process.subprocess, "Popen", side_effect=launch):
            result = parser_process.search({"invented.metta": b"(invented)"}, "expression_head", "invented",
                        {"kind": "hyperon", "source_search_enabled": True}, self.scratch)
        self.assertEqual(list(self.scratch.iterdir()), [])
        self.assertTrue(result["cleanup_observed"])
        self.assertEqual(len(calls), 1)
        return result, calls[0]

    def test_explicit_b_preserves_writable_installed_fixture_tree(self):
        before = inventory(self.site)
        result, (argv, environment, new_session) = self.run_fixture()
        self.assertEqual(argv[:3], [self.identity["executable"], "-I", "-B"])
        self.assertEqual(argv.count("-B"), 1)
        self.assertEqual(Path(argv[3]).name, "metta_facts_helper.py")
        self.assertEqual(set(environment), {"PATH", "LANG", "TMPDIR"})
        self.assertTrue(new_session)
        self.assertTrue(result["synthetic_bytecode_disabled"])
        self.assertEqual(result["synthetic_isolated"], 1)
        self.assertEqual(result["synthetic_ignore_environment"], 1)
        self.assertEqual(inventory(self.site), before)
        self.assertFalse((self.site / "__pycache__").exists())

    def test_prior_argv_control_writes_only_invented_fixture_bytecode(self):
        before = inventory(self.site)
        result, _ = self.run_fixture(remove_bytecode_flag=True)
        self.assertFalse(result["synthetic_bytecode_disabled"])
        self.assertNotEqual(inventory(self.site), before)
        self.assertEqual(len(list((self.site / "__pycache__").glob("invented_worker_module.*.pyc"))), 1)

    def test_environment_only_cannot_replace_b_under_isolated_mode(self):
        result, (_, environment, _) = self.run_fixture(remove_bytecode_flag=True, environment_only=True)
        self.assertEqual(environment["PYTHONDONTWRITEBYTECODE"], "1")
        self.assertEqual(result["synthetic_env_flag"], "1")
        self.assertEqual(result["synthetic_ignore_environment"], 1)
        self.assertFalse(result["synthetic_bytecode_disabled"])
        self.assertTrue((self.site / "__pycache__").exists())


if __name__ == "__main__":
    unittest.main()
