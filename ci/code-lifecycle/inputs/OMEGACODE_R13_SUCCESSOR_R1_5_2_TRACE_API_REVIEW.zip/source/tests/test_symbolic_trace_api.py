"""Actual in-process ASGI and NativeClient plumbing; synthetic retained evidence only."""
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from omegacode.api import create_app
from omegacode.client import NativeClient
from omegacode.common import canonical
from service_fixture import Fixture, OPERATOR


@pytest.fixture
def case(tmp_path):
    fixture = Fixture(tmp_path / 'state')
    # Do not enter TestClient's lifespan: the real monitor/listener is outside this scope.
    api = TestClient(create_app(fixture.service))
    try:
        yield fixture, api
    finally:
        api.close()
        fixture.service.close()


def capability(fixture, **changes):
    config = {'actor': 'person:synthetic', 'kind': 'human', 'task_id': 'task-synthetic',
              'swarm_id': 'swarm-synthetic', 'repository_id': 'repo-synthetic', 'actions': ['read', 'events']}
    config.update(changes)
    return fixture.service.authority.issue(**config)['token']


def headers(token):
    return {'Authorization': 'Bearer ' + token}


def url(fixture):
    return '/v1/runs/' + fixture.run['id'] + '/symbolic-trace-result'


def assert_private_report(response, fixture, *tokens):
    assert response.status_code == 200
    result = response.json()
    assert result['status'] == 'inspected'
    assert result['custody']['workspace_artifact_references_checked'] is True
    report = result['result']
    for key in ('authorization_checked_here', 'record_origin_authenticated', 'workspace_custody_checked_here',
                'stdout_author_authenticated', 'native_integrity_verified', 'execution_effects_verified',
                'history_complete', 'current_engine_admission_verified', 'engine_invoked_by_reader', 'replay_performed'):
        assert report[key] is False
    for value in (OPERATOR, *tokens, '!(+ 1 1)', fixture.controls[0]['payload']['data_base64']):
        assert value not in response.text
    assert 'payload' not in report and 'controls' not in report
    return result


def test_actual_asgi_preserves_private_custody_and_current_then_historical(case):
    fixture, api = case
    token = capability(fixture)
    current = assert_private_report(api.get(url(fixture), headers=headers(token)), fixture, token)
    assert current['currency'] == 'current' and current['generation'] == 1
    fixture.edit_source()  # Actual local Service edit; no process or provider.
    historical = assert_private_report(api.get(url(fixture), headers=headers(token)), fixture, token)
    assert historical['currency'] == 'historical' and historical['generation'] == 1
    assert historical['tree_digest'] == current['tree_digest']


def test_asgi_pages_observations_without_raw_command_dump(case):
    fixture, api = case
    token = capability(fixture)
    response = api.get(url(fixture), params={'after': 1, 'limit': 1}, headers=headers(token))
    result = assert_private_report(response, fixture, token)['result']
    assert result['after'] == 1 and result['observations'] == [] and result['eof'] is True
    assert result['unique_reported_observations'] == 1
    assert result['traces'][0]['reported_coverage']['total_observations'] == 1


def test_current_r13_coverage_string_is_validated_and_normalized(case):
    fixture, api = case
    token = capability(fixture)
    response = api.get(url(fixture), headers=headers(token))
    report = response.json()['result']
    assert report['traces'][0]['coverage_known'] is True
    assert report['traces'][0]['reported_coverage']['coverage']
    fixture.output = fixture.output.replace(b'"observation_total":1', b'"observation_total":2')
    fixture.retain()
    refused = api.get(url(fixture), headers=headers(token))
    assert refused.status_code == 409 and refused.json()['details']['reader_code'] == 'coverage_invalid'


def test_partial_r13_coverage_metadata_is_not_misclassified_as_legacy(case):
    fixture, api = case
    token = capability(fixture)
    original = fixture.output
    fixture.output = original.replace(b'"observation_coverage":"complete-history",', b'')
    assert fixture.output != original
    fixture.receipt['output_bytes'] = len(fixture.output)
    fixture.retain()
    refused = api.get(url(fixture), headers=headers(token))
    assert refused.status_code == 409 and refused.json()['details']['reader_code'] == 'coverage_invalid'


def test_mixed_structured_and_r13_coverage_is_refused(case):
    fixture, api = case
    token = capability(fixture)
    original = fixture.output
    fixture.output = original.replace(
        b'\"observation_coverage\":\"complete-history\"',
        b'\"observation_coverage\":{}',
        1,
    )
    assert fixture.output != original
    fixture.receipt['output_bytes'] = len(fixture.output)
    fixture.retain()
    refused = api.get(url(fixture), headers=headers(token))
    assert refused.status_code == 409
    assert refused.json()['details']['reader_code'] == 'coverage_invalid'


@pytest.mark.parametrize('shape', ['observation_total_only', 'marker_without_counters'])
def test_incomplete_r13_coverage_shapes_are_refused(case, shape):
    fixture, api = case
    token = capability(fixture)
    frames = [json.loads(line) for line in fixture.output.splitlines()]
    start = next(frame for frame in frames if frame.get('event') == 'result' and frame.get('op') == 'step-start')
    result = start['result']
    fields = ('observation_total', 'observation_window_limit', 'observation_dropped_prefix',
              'first_retained_input_sequence', 'first_retained_step')
    if shape == 'observation_total_only':
        result.pop('observation_coverage', None)
        for field in fields:
            if field != 'observation_total':
                result.pop(field, None)
    else:
        for field in fields:
            result.pop(field, None)
    fixture.output = b''.join(canonical(frame) + b'\n' for frame in frames)
    fixture.receipt['output_bytes'] = len(fixture.output)
    fixture.retain()
    refused = api.get(url(fixture), headers=headers(token))
    assert refused.status_code == 409
    assert refused.json()['details']['reader_code'] == 'coverage_invalid'


def test_oversized_trace_artifact_is_refused_before_reader(monkeypatch, case):
    import omegacode.service as service_module
    fixture, api = case
    monkeypatch.setattr(service_module, 'MAX_LOG', 1)
    response = api.get(url(fixture), headers=headers(capability(fixture)))
    assert response.status_code == 409 and response.json()['error'] == 'artifact_too_large'


def test_api_does_not_authenticate_operator_or_missing_bearer_as_reader(case):
    fixture, api = case
    assert api.get(url(fixture)).status_code == 401
    response = api.get(url(fixture), headers=headers(OPERATOR))
    assert response.status_code == 403 and response.json()['error'] == 'coding_capability_required'


@pytest.mark.parametrize('changes,code', [({'actions': ['read']}, 'action_forbidden'),
    ({'actions': ['events']}, 'action_forbidden'), ({'task_id': 'foreign-task'}, 'workspace_forbidden'),
    ({'paths': ['private_fixture.py']}, 'symbolic_trace_scope')])
def test_actual_asgi_reuses_existing_scope_refusals(case, changes, code):
    fixture, api = case
    response = api.get(url(fixture), headers=headers(capability(fixture, **changes)))
    assert response.status_code == 403 and response.json()['error'] == code


def test_actual_asgi_preserves_service_error_details_and_termination_hold(case):
    fixture, api = case
    token = capability(fixture)
    response = api.get(url(fixture), params={'after': 2}, headers=headers(token))
    assert response.status_code == 409
    assert response.json()['error'] == 'symbolic_trace_invalid'
    assert response.json()['details'] == {'reader_code': 'report_cursor'}
    fixture.mutate_run(descendants_terminated=False)
    response = api.get(url(fixture), headers=headers(token))
    assert response.status_code == 409 and response.json()['error'] == 'symbolic_trace_unconfirmed'


def test_actual_asgi_retains_artifact_custody_and_hash_refusal(case):
    fixture, api = case
    fixture.service.store.blob_path(fixture.run['receipt_digest']).write_bytes(b'synthetic corruption')
    response = api.get(url(fixture), headers=headers(capability(fixture)))
    assert response.status_code == 409 and response.json()['error'] == 'artifact_corrupt'


@pytest.mark.parametrize('params', [{'after': -1}, {'after': 4097}, {'after': 'true'},
    {'after': '1.5'}, {'limit': 0}, {'limit': 101}, {'limit': 'false'}])
def test_standard_query_validation_is_422_before_artifact_reads(case, monkeypatch, params):
    fixture, api = case
    token = capability(fixture)
    def no_read(*args, **kwargs):
        raise AssertionError('invalid query reached artifact read')
    monkeypatch.setattr(fixture.service.store, 'read_blob', no_read)
    response = api.get(url(fixture), params=params, headers=headers(token))
    assert response.status_code == 422 and 'detail' in response.json()


def test_only_get_is_exposed(case):
    fixture, api = case
    response = api.post(url(fixture), headers=headers(capability(fixture)), json={})
    assert response.status_code == 405


def native_bridge(fixture, api, token, *, capability_status=200):
    requests = []
    def transport(request):
        requests.append(request)
        if request.url.host == 'synthetic-hive.invalid':
            assert request.method == 'POST' and request.url.path == '/api/agent/code/capability'
            if capability_status != 200:
                return httpx.Response(capability_status, json={'error': 'action_forbidden',
                    'message': 'synthetic delegated member lacks events authority'})
            return httpx.Response(200, json={'token': token})
        assert request.url.host == 'synthetic-code.invalid'
        response = api.request(request.method, request.url.raw_path.decode('ascii'), headers=dict(request.headers))
        return httpx.Response(response.status_code, json=response.json())
    client = NativeClient('https://synthetic-hive.invalid', 'synthetic-member-secret',
        code_url='https://synthetic-code.invalid', transport=httpx.MockTransport(transport))
    return client, requests


def test_native_client_exact_capability_and_query_shape_preserves_actual_asgi_result(case):
    fixture, api = case
    token = capability(fixture)
    client, requests = native_bridge(fixture, api, token)
    try:
        result = client.call('symbolic-trace-result', 'task-synthetic', 'repo-synthetic',
            {'run_id': fixture.run['id'], 'after': 1, 'limit': 7,
             'workspace_id': fixture.workspace['id'], 'actions': ['run'],
             'data_base64': 'DO_NOT_FORWARD', 'instruction': 'DO_NOT_FORWARD'})
    finally:
        client.close()
    assert result['ok'] is True and result['phase'] == 'operation' and result['http_status'] == 200
    assert result['result']['currency'] == 'current'
    assert result['result']['result']['after'] == 1
    assert result['result']['custody']['workspace_artifact_references_checked'] is True
    assert result['result']['result']['native_integrity_verified'] is False
    cap, operation = requests
    assert json.loads(cap.content) == {'task_id': 'task-synthetic', 'repository_id': 'repo-synthetic',
                                     'actions': ['read', 'events'], 'ttl_seconds': 300}
    assert operation.method == 'GET' and operation.url.path == url(fixture)
    assert dict(operation.url.params) == {'after': '1', 'limit': '7'}
    assert 'run_id' not in operation.url.params
    encoded = json.dumps(result)
    assert all(value not in encoded for value in (token, 'synthetic-member-secret', 'DO_NOT_FORWARD'))


def test_native_client_default_query_is_observation_page_not_output_byte_page(case):
    fixture, api = case
    client, requests = native_bridge(fixture, api, capability(fixture))
    try:
        response = client.call('symbolic-trace-result', 'task-synthetic', 'repo-synthetic', {'run_id': fixture.run['id']})
    finally:
        client.close()
    assert response['ok'] is True
    assert dict(requests[1].url.params) == {'after': '0', 'limit': '100'}


def test_native_client_capability_refusal_does_not_upgrade_or_reach_code(case):
    fixture, api = case
    client, requests = native_bridge(fixture, api, 'unused', capability_status=403)
    try:
        result = client.call('symbolic-trace-result', 'task-synthetic', 'repo-synthetic',
                             {'run_id': fixture.run['id'], 'delegated': True, 'actions': ['run', 'events']})
    finally:
        client.close()
    assert result == {'ok': False, 'phase': 'capability', 'http_status': 403,
                      'result': {'error': 'action_forbidden',
                                 'message': 'synthetic delegated member lacks events authority'}}
    assert len(requests) == 1
    assert json.loads(requests[0].content)['actions'] == ['read', 'events']
    assert 'delegated' not in json.loads(requests[0].content)


def test_native_client_operation_refusal_keeps_service_envelope(case):
    fixture, api = case
    fixture.mutate_run(descendants_terminated=False)
    client, requests = native_bridge(fixture, api, capability(fixture))
    try:
        result = client.call('symbolic-trace-result', 'task-synthetic', 'repo-synthetic', {'run_id': fixture.run['id']})
    finally:
        client.close()
    assert result['ok'] is False and result['phase'] == 'operation' and result['http_status'] == 409
    assert result['result']['error'] == 'symbolic_trace_unconfirmed'
    assert len(requests) == 2
