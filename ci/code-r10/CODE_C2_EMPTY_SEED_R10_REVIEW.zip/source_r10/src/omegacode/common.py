"""Bounded formats shared by the service and its disposable run helpers."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import tempfile
import time
import uuid

MAX_FILE = 2 * 1024 * 1024
MAX_TREE = 32 * 1024 * 1024
MAX_FILES = 2000
MAX_LOG = 4 * 1024 * 1024
SECRET_NAMES = {".env", ".netrc", ".npmrc", "credentials", "token", "id_rsa", "id_ed25519"}


class CodeError(Exception):
    def __init__(self, status: int, code: str, message: str, details=None):
        self.status, self.code, self.message = status, code, message
        self.details = details
        super().__init__(message)


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ident(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def stamp() -> float:
    return time.time()


def safe_path(value: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value:
        raise CodeError(400, "invalid_path", "expected a relative POSIX file path")
    path = pathlib.PurePosixPath(value)
    if path.is_absolute() or any(p in (".", "..", "") for p in value.split("/")):
        raise CodeError(403, "path_outside_workspace", "path must remain inside this workspace")
    if any(p == ".git" or p in SECRET_NAMES or p.startswith(".env.") for p in path.parts):
        raise CodeError(403, "protected_path", "repository metadata and credential paths are not coding artifacts")
    return str(path)


def atomic_write(path: pathlib.Path, data: bytes, mode: int = 0o600):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, name = tempfile.mkstemp(prefix=".pending-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(name, mode)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)
