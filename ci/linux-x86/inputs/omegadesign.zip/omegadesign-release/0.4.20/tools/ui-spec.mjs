// Editable onboarding UI schema and fixed safe renderer; no submission or adoption.
import {clone} from './scene.mjs';
const text=(v,max=2000)=>typeof v==='string'&&v.trim()&&v.length<=max;
const color=v=>typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v);
export function validateUI(input){
 if(input?.schema!=='omega-onboarding-ui-1'||!text(input.id,80)||!text(input.title,150)||!text(input.introduction)||!Array.isArray(input.criteria)||!input.criteria.length||input.criteria.some(c=>!text(c)))throw Error('UI needs identity, purpose copy and criteria');
 if(!input.identity||!['paper','ink','accent'].every(k=>color(input.identity[k])))throw Error('UI needs valid palette');
 const form=input.form;
 if(!form||!text(form.name_label,100)||!text(form.availability_label,100)||!text(form.button,100)||!text(form.success)||!text(form.name_error)||!text(form.availability_error)||!Array.isArray(form.options)||form.options.length<2||form.options.length>8||form.options.some(o=>!text(o,100))||new Set(form.options).size!==form.options.length)throw Error('UI needs labelled inputs, unique options and validation copy');
 return clone(input);
}
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function renderUI(input){
 const ui=validateUI(input),f=ui.form;
 return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(ui.title)}</title>
<style>*{box-sizing:border-box}body{margin:0;padding:clamp(18px,5vw,72px);background:${ui.identity.paper};color:${ui.identity.ink};font:18px/1.5 system-ui}main{max-width:1080px;margin:auto;display:grid;grid-template-columns:1fr 1fr;gap:clamp(24px,5vw,72px)}h1{font-size:clamp(38px,5vw,64px);line-height:1.1;letter-spacing:-.03em}form{background:white;padding:32px;border-radius:18px;box-shadow:0 8px 32px #00000010}label,legend{font-weight:600}input[type=text]{display:block;width:100%;margin:10px 0;padding:12px;border:2px solid ${ui.identity.ink};border-radius:8px;font:inherit}fieldset{border:0;padding:0;margin:28px 0}fieldset label{display:flex;gap:12px;align-items:center;margin:12px 0;font-weight:400}input[type=checkbox]{width:22px;height:22px}button{background:${ui.identity.accent};color:white;border:0;padding:14px 24px;border-radius:8px;font:inherit;cursor:pointer}:focus-visible{outline:3px solid ${ui.identity.ink};outline-offset:4px}.error{color:#A32020;font-weight:600}.hint{font-size:14px}#result{margin-top:20px}@media(max-width:720px){main{grid-template-columns:1fr}form{padding:22px}}</style>
<main><section><p>Neighbourhood garden · proposal</p><h1>${esc(ui.title)}</h1><p>${esc(ui.introduction)}</p><p class="hint">A local preview. Your details stay in this page.</p></section><form id="join" novalidate><label for="name">${esc(f.name_label)}</label><input id="name" name="name" type="text" maxlength="120" autocomplete="off" required aria-describedby="name-error"><p id="name-error" class="error" hidden></p><fieldset aria-describedby="availability-error"><legend>${esc(f.availability_label)}</legend>${f.options.map((o,i)=>`<label for="option-${i}"><input id="option-${i}" name="availability" type="checkbox" value="${i}">${esc(o)}</label>`).join('')}<p id="availability-error" class="error" hidden></p></fieldset><button type="submit">${esc(f.button)}</button><div id="result" role="status" aria-live="polite"></div></form></main>
<script>const form=document.getElementById('join'),nameField=document.getElementById('name'),nameError=document.getElementById('name-error'),availabilityError=document.getElementById('availability-error'),result=document.getElementById('result');const copy=${JSON.stringify({name_error:f.name_error,availability_error:f.availability_error,success:f.success,options:f.options}).replace(/</g,'\\u003c')};form.addEventListener('submit',event=>{event.preventDefault();const nameOK=!!nameField.value.trim(),availabilityOK=!!form.querySelector('input[name="availability"]:checked');nameError.textContent=nameOK?'':copy.name_error;nameError.hidden=nameOK;availabilityError.textContent=availabilityOK?'':copy.availability_error;availabilityError.hidden=availabilityOK;nameField.setAttribute('aria-invalid',String(!nameOK));for(const input of form.querySelectorAll('input[name="availability"]'))input.setAttribute('aria-invalid',String(!availabilityOK));result.textContent=nameOK&&availabilityOK?copy.success:'Please check the highlighted fields.';if(nameOK&&availabilityOK){const summary=document.createElement('ul');const name=document.createElement('li');name.textContent=nameField.value.trim();summary.append(name);for(const input of form.querySelectorAll('input[name="availability"]:checked')){const item=document.createElement('li');item.textContent=copy.options[Number(input.value)];summary.append(item);}result.append(summary);}if(!nameOK)nameField.focus();else if(!availabilityOK)form.querySelector('input[name="availability"]').focus();});</script></html>`;
}

export function verifyUICopyRevision(before,after){
 validateUI(before);validateUI(after);
 const original=clone(before),revised=clone(after),changes=[];
 for(const field of ['title','introduction']){if(original[field]!==revised[field])changes.push(field);delete original[field];delete revised[field];}
 if(original.form.button!==revised.form.button)changes.push('form.button');delete original.form.button;delete revised.form.button;
 const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
 if(canonical(original)!==canonical(revised))throw Error('Copy revision changed retained obligations or behavior');
 if(!changes.length)throw Error('Copy revision contains no change');
 return {changes,retained_requirements:true,retained_form_behavior:true,assessment:'scope-verified-quality-unverified'};
}
