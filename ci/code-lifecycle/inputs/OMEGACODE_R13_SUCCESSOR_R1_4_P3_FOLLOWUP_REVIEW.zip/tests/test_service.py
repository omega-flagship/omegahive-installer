"""Actual disposable git inputs and native processes; no model or live Hive claims."""
import json
import os
import pathlib
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import httpx
import pytest
from fastapi.testclient import TestClient

from omegacode.api import create_app
from omegacode.auth import ACTIONS
from omegacode.common import CodeError, canonical, digest
from omegacode.registration import _registration_lock, enrol
from omegacode.runner import group_members
from omegacode.service import Service


OPERATOR = "synthetic-test-operator-token-123456789"


@pytest.fixture
def repo(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "calculator.py").write_text("def add(a, b):\n    return a - b\n")
    (repo / "test_calculator.py").write_text("from calculator import add\nassert add(2, 3) == 5\n")
    for argv in (["git", "init", "-q", str(repo)], ["git", "-C", str(repo), "add", "."],
                 ["git", "-C", str(repo), "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-qm", "synthetic"]):
        subprocess.run(argv, check=True, capture_output=True)
    return repo


@pytest.fixture
def service(tmp_path, repo):
    service = Service(tmp_path / "state", OPERATOR, {"synthetic": {"path": str(repo), "max_task_runs": 50,
                                                                 "task_runtime_budget_seconds": 1000}})
    yield service
    for run in service.store.list("run"):
        if run.get("pgid") and run["status"] in ("starting", "running", "cancel_requested"):
            (service.store.root / "runs" / run["id"] / "cancel.request").write_text("test cleanup")
    end = time.monotonic() + 8
    while time.monotonic() < end:
        service.reconcile()
        if not any(r["status"] in ("running", "cancel_requested") for r in service.store.list("run")):
            break
        time.sleep(.05)
    service.close()


def principal(service, **updates):
    config = dict(actor="user:test", kind="human", task_id="goal-test", swarm_id="swarm-test",
                  repository_id="synthetic", actions=sorted(ACTIONS), argv_prefixes=[[sys.executable]], max_runs=50)
    config.update(updates)
    grant = service.authority.issue(**config)
    return service.authority.authenticate(grant["token"], config.get("member_token")), grant


def workspace(service, p):
    return service.create_workspace(p, {"operation_id": "create", "task_id": "goal-test",
                                        "repository_id": "synthetic", "base_commit": "HEAD"})


def edit(service, p, ws, content, op="edit", path="calculator.py"):
    old = service.manifest(ws)["files"].get(path)
    return service.edit(p, ws["id"], {"operation_id": op, "expected_generation": ws["generation"],
                                     "expected_tree_digest": ws["tree_digest"], "edits": [
                                         {"path": path, "expected_digest": old["digest"] if old else None,
                                          "content": content}]})


def run(service, p, ws, argv=None, timeout=10, op="run"):
    return service.start_run(p, {"operation_id": op, "workspace_id": ws["id"],
                                 "expected_generation": ws["generation"], "expected_tree_digest": ws["tree_digest"],
                                 "argv": argv or [sys.executable, "test_calculator.py"], "timeout_seconds": timeout})


def finish(service, id, seconds=12):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        service.reconcile()
        r = service.store.get("run", id)
        if r["status"] not in ("prepared", "starting", "running", "cancel_requested"):
            return r
        time.sleep(.05)
    pytest.fail("native run did not reach an observed terminal state")


def test_failure_repair_stale_verification_and_restart(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    baseline = finish(service, run(service, p, ws)["id"])
    assert baseline["status"] == "failed"
    failed = service.verify(p, {"operation_id": "verify-fail", "run_id": baseline["id"]})
    assert failed["status"] == "failed"
    repaired = edit(service, p, ws, "def add(a, b):\n    return a + b\n")["workspace"]
    passed_run = finish(service, run(service, p, repaired, op="run-fixed")["id"])
    assert passed_run["descendants_terminated"] and passed_run["exit_code"] == 0
    vr = service.verify(p, {"operation_id": "verify-fixed", "run_id": passed_run["id"]})
    assert vr["status"] == "passed" and vr["currency"] == "current"
    assert vr["independent_rsi_evaluation"] is False
    edit(service, p, repaired, "def add(a, b):\n    return a + b + 1\n", "edit-later")
    assert service.verification(p, vr["id"])["currency"] == "stale"
    cp = service.checkpoint(p, ws["id"], {"operation_id": "checkpoint", "label": "review", "decision": "keep evaluator separate"})
    other = Service(service.store.root, OPERATOR, service.repositories)
    try:
        restored = other.authority.authenticate(grant["token"])
        assert other.verification(restored, vr["id"])["currency"] == "stale"
        assert other.store.get("checkpoint", cp["id"])["decision"] == "keep evaluator separate"
        assert len(other.store.events(ws["id"])) >= 10
    finally:
        other.close()


def test_atomic_stale_and_idempotence(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    payload = {"operation_id": "save", "expected_generation": ws["generation"], "expected_tree_digest": ws["tree_digest"],
               "edits": [{"path": "calculator.py", "expected_digest": service.read(p, ws["id"], "calculator.py")["digest"], "content": "new\n"}]}
    first = service.edit(p, ws["id"], payload)
    assert service.edit(p, ws["id"], payload) == first
    with pytest.raises(CodeError, match="already used"):
        service.edit(p, ws["id"], dict(payload, edits=[dict(payload["edits"][0], content="different")]))
    with pytest.raises(CodeError, match="workspace changed"):
        edit(service, p, ws, "worker stale", "other")
    current = service.workspace(ws["id"])
    with pytest.raises(CodeError, match="digest differs"):
        service.edit(p, ws["id"], {"operation_id": "atomic-fail", "expected_generation": current["generation"],
                                   "expected_tree_digest": current["tree_digest"], "edits": [
                                       {"path": "new.py", "expected_digest": None, "content": "must roll back"},
                                       {"path": "calculator.py", "expected_digest": None, "content": "bad"}]})
    assert "new.py" not in service.manifest(service.workspace(ws["id"]))["files"]


def test_expired_authority_cannot_commit_after_workspace_preparation(service, monkeypatch):
    p, _ = principal(service, ttl_seconds=1)
    original = service._repository_files
    def delayed(*args):
        result = original(*args)
        time.sleep(1.1)
        return result
    monkeypatch.setattr(service, "_repository_files", delayed)
    with pytest.raises(CodeError, match="expired"):
        workspace(service, p)
    assert not service.store.list("workspace")
    assert not service.store.db.execute("SELECT 1 FROM operations").fetchone()


@pytest.mark.parametrize("path", ["../outside", "/absolute", ".git/config", ".env", "a/.env.local", "a\\b", "a//b"])
def test_path_boundary(service, path):
    p, _ = principal(service)
    ws = workspace(service, p)
    with pytest.raises(CodeError):
        edit(service, p, ws, "bad", path=path)


def test_frozen_run_ignores_concurrent_edit(service):
    p, _ = principal(service)
    ws = workspace(service, p)
    ws = edit(service, p, ws, "def add(a,b):\n    return a + b\n")["workspace"]
    r = run(service, p, ws, [sys.executable, "-c", "import time; time.sleep(.3); exec(open('test_calculator.py').read())"])
    edit(service, p, ws, "def add(a,b):\n    return 0\n", "concurrent")
    r = finish(service, r["id"])
    assert r["status"] == "completed" and not r["input_mutations"]
    vr = service.verify(p, {"operation_id": "frozen-verification", "run_id": r["id"]})
    assert vr["status"] == "passed" and vr["currency"] == "stale"


def test_human_run_reconciles_from_another_service_without_relaunch(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    r = run(service, p, ws, [sys.executable, "-c", "import time;time.sleep(.5);print('persisted-run')"])
    reopened = Service(service.store.root, OPERATOR, service.repositories)
    try:
        p2 = reopened.authority.authenticate(grant["token"])
        restored = finish(reopened, r["id"])
        assert restored["status"] == "completed" and restored["pid"] == r["pid"]
        assert b"persisted-run" in reopened.store.read_blob(restored["output_digest"], ws["id"])
        assert len(reopened.store.list("run")) == 1
        assert reopened.run(p2, r["id"])["descendants_terminated"]
    finally:
        reopened.close()


def test_stream_resume_and_artifact_task_scope(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    r = finish(service, run(service, p, ws, [sys.executable, "-c", "print('stream-data')"])["id"])
    client = TestClient(create_app(service))
    headers = {"Authorization": "Bearer " + grant["token"]}
    import base64
    with client.websocket_connect(f"/v1/runs/{r['id']}/stream", headers=headers) as socket:
        socket.send_json({"after": 7})
        chunk = socket.receive_json()
        assert base64.b64decode(chunk["data"]) == b"data\n"
        terminal = socket.receive_json()
        assert terminal["type"] == "exit" and terminal["process_group"]["terminated"]
    other, other_grant = principal(service, task_id="other")
    refused = client.get(f"/v1/artifacts/{r['output_digest']}", params={"workspace_id": ws["id"]},
                         headers={"Authorization": "Bearer " + other_grant["token"]})
    assert refused.status_code == 403
    assert client.get(f"/v1/artifacts/{r['output_digest']}", params={"workspace_id": ws["id"]}, headers=headers).content == b"stream-data\n"


def test_symlink_repository_input_is_refused(service, repo):
    (repo / "link.py").symlink_to("calculator.py")
    subprocess.run(["git", "-C", str(repo), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(repo), "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-qm", "symlink"], check=True, capture_output=True)
    p, _ = principal(service)
    with pytest.raises(CodeError, match="symlinks"):
        workspace(service, p)
    assert not service.store.list("workspace")


def test_cancel_observes_children_and_revocation(service):
    p, grant = principal(service)
    ws = workspace(service, p)
    argv = [sys.executable, "-c", "import subprocess,time,sys; subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);print('ready',flush=True);time.sleep(60)"]
    r = run(service, p, ws, argv, timeout=20)
    end = time.monotonic() + 5
    while time.monotonic() < end:
        output = service.store.root / "runs" / r["id"] / "output.log"
        if output.exists() and b"ready" in output.read_bytes():
            break
        time.sleep(.05)
    assert b"ready" in output.read_bytes()
    requested = service.cancel(p, r["id"], {"operation_id": "cancel"})
    assert requested["status"] == "cancel_requested" and not requested["acknowledged"]
    stopped = finish(service, r["id"])
    assert stopped["status"] == "cancelled" and stopped["descendants_terminated"]
    assert not group_members(stopped["pgid"])
    r2 = run(service, p, ws, argv, timeout=20, op="revoke-run")
    service.authority.revoke(grant["grant"]["id"])
    assert finish(service, r2["id"])["status"] == "cancelled"
    with pytest.raises(CodeError):
        service.authority.authenticate(grant["token"])


def test_timeout_output_limit_mutation_and_clean_env(service, monkeypatch):
    p, _ = principal(service)
    ws = workspace(service, p)
    monkeypatch.setenv("OPENAI_API_KEY", "synthetic-secret-must-not-leak")
    r = finish(service, run(service, p, ws, [sys.executable, "-c", "import os;assert 'OPENAI_API_KEY' not in os.environ;open('calculator.py','w').write('tampered')"], op="env") ["id"])
    vr = service.verify(p, {"operation_id": "mutated", "run_id": r["id"]})
    assert r["exit_code"] == 0 and vr["status"] == "failed" and "calculator.py" in vr["input_mutations"]
    timed = finish(service, run(service, p, ws, [sys.executable, "-c", "import time;time.sleep(5)"], timeout=1, op="timeout")["id"])
    assert timed["status"] == "timed_out" and not group_members(timed["pgid"])
    large = finish(service, run(service, p, ws, [sys.executable, "-c", "print('x'*5000000)"], op="large")["id"])
    assert large["status"] == "output_limit" and large["output_bytes"] == 4194304


def test_capability_and_http_boundary(service):
    p, grant = principal(service)
    client = TestClient(create_app(service))
    assert client.get("/v1/capabilities").status_code == 401
    assert client.get("/v1/capabilities", headers={"Authorization": "Bearer garbage"}).status_code == 401
    operator = {"Authorization": "Bearer " + OPERATOR}
    assert client.post("/v1/workspaces", headers=operator, json={"operation_id": "op", "task_id": "goal-test", "repository_id": "synthetic", "base_commit": "HEAD"}).status_code == 403
    headers = {"Authorization": "Bearer " + grant["token"]}
    ws = workspace(service, p)
    other, _ = principal(service, task_id="other-task")
    with pytest.raises(CodeError):
        service.read(other, ws["id"], "calculator.py")
    read = client.get(f"/v1/workspaces/{ws['id']}/files", headers=headers, params={"path": "calculator.py"})
    assert read.status_code == 200
    assert client.post("/v1/runs", headers=headers, json={"operation_id": "invalid", "workspace_id": ws["id"], "expected_generation": 1, "expected_tree_digest": ws["tree_digest"], "argv": ["/bin/sh", "-c", "true"], "timeout_seconds": 1}).status_code == 403
    limited, _ = principal(service, paths=["test_calculator.py"])
    with pytest.raises(CodeError):
        service.read(limited, ws["id"], "calculator.py")
    with pytest.raises(CodeError):
        run(service, limited, ws)


def test_hive_policy_and_claim_are_server_checked(tmp_path, repo):
    state = {"decision": "deny", "status": "claimed", "binding": None, "redeemed": False}
    calls = []
    def transport(request):
        calls.append((request.url.path, request.content))
        if "/approvals/" in request.url.path:
            if request.method == "GET":
                return httpx.Response(200, json={"agent_id": "dot-test", "skill": "code-workspace", "status": "approved", "binding": state["binding"]})
            if state["redeemed"]:
                return httpx.Response(409, json={"error": "approval_redeemed"})
            state["redeemed"] = True
            return httpx.Response(200, json={"redeemed": True})
        if request.method == "GET":
            return httpx.Response(200, json={"swarm_id": "swarm-test", "claimed_by": "dot-test",
                                             "status": state["status"], "lease_until": "2099-01-01T00:00:00Z"})
        return httpx.Response(200, json={"decision": state["decision"]})
    service = Service(tmp_path / "hive-state", OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(transport), service_token="synthetic-service-token")
    try:
        p, grant = principal(service, actor="dot-test", kind="agent", member_token="synthetic-member-token")
        with pytest.raises(CodeError, match="denied"):
            workspace(service, p)
        assert not service.store.list("workspace")
        state["decision"] = "allow"
        # Even upstream default-allow cannot authorize a mutating request without its exact receipt.
        with pytest.raises(CodeError, match="approval"):
            workspace(service, p)
        payload = {"operation_id": "create", "task_id": "goal-test", "repository_id": "synthetic", "base_commit": "HEAD"}
        operation = {"action": "workspace", "workspace_id": None, **payload}
        state["binding"] = {"task_id": "goal-test", "swarm_id": "swarm-test", "workspace_id": None,
                            "operation_id": "create", "expected_generation": None,
                            "payload_digest": "sha256:" + digest(canonical(operation))}
        ws = service.create_workspace(p, dict(payload, approval_id="p_test"))
        assert state["redeemed"]
        assert service.create_workspace(p, dict(payload, approval_id="p_test")) == ws
        state["status"] = "cancelled"
        with pytest.raises(CodeError, match="not actively"):
            edit(service, p, ws, "forbidden", "stale-authority")
        assert service.read(p, ws["id"], "calculator.py")["content"]
        with pytest.raises(CodeError):
            service.authority.authenticate(grant["token"], "other-member-token")
        assert any(b"code-workspace" in body for _, body in calls)
    finally:
        service.close()


def test_enrolment_is_narrow_and_credentials_are_not_returned(tmp_path, repo):
    seen = []
    receipt = {"operation_id": None, "request_digest": "a" * 64, "service_id": "svc-test", "status": "pending"}
    def transport(request):
        seen.append(request)
        if request.url.path == "/api/services/register":
            body = json.loads(request.content)
            receipt["operation_id"] = body["operation_id"]
            return httpx.Response(201, json={"service_id": "svc-test", "service_token": "synthetic-registered-secret",
                "capability_secret": "synthetic-capability-secret", "address": "http://127.0.0.1:8724",
                "registered_at": "synthetic", "receipt": dict(receipt)})
        if request.url.path.endswith("/ack"):
            return httpx.Response(200, json={**receipt, "status": "active"})
        raise AssertionError(request.url)
    s = Service(tmp_path / "registration", OPERATOR, {"synthetic": {"path": str(repo)}},
                "http://hive.invalid", httpx.MockTransport(transport))
    try:
        client = TestClient(create_app(s))
        response = client.post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                               json={"enrol_token": "synthetic-one-time-enrol-token"})
        assert response.status_code == 201
        assert "secret" not in response.text and "token" not in response.text
        body = json.loads(seen[0].content)
        assert body["surfaces"] == ["diff", "log", "editor"] and "pty" not in body["surfaces"]
        assert 16 <= len(body["operation_id"]) <= 128
        assert body["operation_id"] == receipt["operation_id"]
        path = s.store.root / "registration.json"
        assert path.stat().st_mode & 0o077 == 0
        assert json.loads(path.read_text())["receipt"]["status"] == "active"
        assert s.authority.service_token == "synthetic-registered-secret"
        assert client.post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                           json={"enrol_token": "synthetic-one-time-enrol-token"}).status_code == 409
    finally:
        s.close()


def test_enrolment_retry_reuses_operation_after_lost_register_response(tmp_path, repo):
    root = tmp_path / "registration-retry"
    operation_ids = []
    def lost(request):
        operation_ids.append(json.loads(request.content)["operation_id"])
        raise httpx.ConnectError("synthetic lost response", request=request)
    s = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(lost))
    try:
        client = TestClient(create_app(s))
        response = client.post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                               json={"enrol_token": "synthetic-one-time-enrol-token"})
        assert response.status_code == 503 and response.json()["error"] == "registration_unknown"
        operation = json.loads((root / "registration.operation.json").read_text())
        operation_path = root / "registration.operation.json"
        assert operation_path.stat().st_mode & 0o077 == 0
        assert operation["enrol_token"] == "synthetic-one-time-enrol-token"
        operation_id = operation["operation_id"]
        assert operation_ids == [operation_id]
    finally:
        s.close()

    seen = []
    def recovered(request):
        seen.append(request)
        if request.url.path.endswith("/register"):
            body = json.loads(request.content)
            assert body["operation_id"] == operation_id
            return httpx.Response(201, json={"service_id": "svc-retry", "service_token": "synthetic-service-secret",
                "capability_secret": "synthetic-capability-secret", "address": "http://127.0.0.1:8724",
                "receipt": {"operation_id": operation_id, "request_digest": "b" * 64,
                            "service_id": "svc-retry", "status": "pending"}})
        return httpx.Response(200, json={"operation_id": operation_id, "request_digest": "b" * 64,
                                         "service_id": "svc-retry", "status": "active"})
    s2 = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(recovered))
    try:
        response = TestClient(create_app(s2)).post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                                                    json={"enrol_token": "synthetic-one-time-enrol-token"})
        assert response.status_code == 201
        assert len([r for r in seen if r.url.path.endswith("/register")]) == 1
        assert not (root / "registration.operation.json").exists()
    finally:
        s2.close()


def test_enrolment_recovers_ack_that_committed_before_response_loss(tmp_path, repo):
    operation_id = None
    state = {"active": False}
    def transport(request):
        nonlocal operation_id
        if request.url.path.endswith("/register"):
            operation_id = json.loads(request.content)["operation_id"]
            return httpx.Response(201, json={"service_id": "svc-ack", "service_token": "synthetic-ack-secret",
                "capability_secret": "synthetic-capability-secret", "address": "http://127.0.0.1:8724",
                "receipt": {"operation_id": operation_id, "request_digest": "c" * 64,
                            "service_id": "svc-ack", "status": "pending"}})
        if request.url.path.endswith("/ack"):
            state["active"] = True
            raise httpx.ReadTimeout("synthetic lost ack response", request=request)
        return httpx.Response(200, json={"operation_id": operation_id, "request_digest": "c" * 64,
                                         "service_id": "svc-ack", "status": "active" if state["active"] else "pending"})
    s = Service(tmp_path / "registration-ack", OPERATOR, {"synthetic": {"path": str(repo)}},
                "http://hive.invalid", httpx.MockTransport(transport))
    try:
        response = TestClient(create_app(s)).post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                                                   json={"enrol_token": "synthetic-one-time-enrol-token"})
        assert response.status_code == 201
        assert s.authority.registration["receipt"]["status"] == "active"
        assert state["active"] and not (s.store.root / "registration.operation.json").exists()
    finally:
        s.close()


def test_pending_registration_credentials_are_disabled_after_restart(tmp_path, repo):
    root = tmp_path / "pending-registration"
    root.mkdir()
    (root / "registration.json").write_text(json.dumps({"service_id": "svc-pending",
        "service_token": "synthetic-pending-secret", "capability_secret": "synthetic-pending-key",
        "receipt": {"status": "pending"}}))
    s = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid",
                service_token="synthetic-configured-token")
    try:
        assert s.authority.registration is None
        assert s.authority.service_token is None
    finally:
        s.close()


def test_expired_enrolment_clears_only_its_pending_local_state(tmp_path, repo):
    root = tmp_path / "expired-registration"
    def expired(request):
        return httpx.Response(409, json={"error": {"code": "operation_expired"}})
    s = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(expired))
    try:
        response = TestClient(create_app(s)).post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                                                   json={"enrol_token": "synthetic-expired-enrol-token"})
        assert response.status_code == 409 and response.json()["error"] == "operation_expired"
        assert not (root / "registration.operation.json").exists()
        assert not (root / "registration.json").exists()
    finally:
        s.close()

    operation_ids = []
    def fresh(request):
        if request.url.path.endswith("/register"):
            body = json.loads(request.content)
            operation_ids.append(body["operation_id"])
            return httpx.Response(201, json={"service_id": "svc-fresh", "service_token": "synthetic-fresh-secret",
                "capability_secret": "synthetic-fresh-key", "address": "http://127.0.0.1:8724",
                "receipt": {"operation_id": body["operation_id"], "request_digest": "d" * 64,
                            "service_id": "svc-fresh", "status": "pending"}})
        return httpx.Response(200, json={"operation_id": operation_ids[-1], "request_digest": "d" * 64,
                                         "service_id": "svc-fresh", "status": "active"})
    s2 = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(fresh))
    try:
        response = TestClient(create_app(s2)).post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                                                    json={"enrol_token": "synthetic-fresh-enrol-token"})
        assert response.status_code == 201
        assert len(operation_ids) == 1
    finally:
        s2.close()


def test_enrolment_restart_recovers_ack_before_re_registering(tmp_path, repo):
    root = tmp_path / "registration-crash"
    root.mkdir()
    operation_id = "operation-crash-recovery-123456"
    token = "synthetic-one-time-enrol-token"
    body = {"name": "omegacode", "version": "0.1.0", "address": "http://127.0.0.1:8724",
            "contract": "omegacode/1", "surfaces": ["diff", "log", "editor"],
            "capabilities": ["workspaces", "runs", "changesets", "verifications", "events"]}
    receipt = {"operation_id": operation_id, "request_digest": "e" * 64, "service_id": "svc-crash", "status": "pending"}
    (root / "registration.operation.json").write_bytes(canonical({"operation_id": operation_id, "enrol_token": token, "body": body}))
    (root / "registration.json").write_bytes(canonical({"service_id": "svc-crash", "service_token": "synthetic-crash-token",
        "capability_secret": "synthetic-crash-key", "address": body["address"], "receipt": receipt}))
    calls = []
    def transport(request):
        calls.append(request.url.path)
        if request.method == "GET" and request.url.path.endswith("/" + operation_id):
            return httpx.Response(200, json={**receipt, "status": "active"})
        raise AssertionError(f"unexpected recovery request: {request.method} {request.url.path}")
    s = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(transport))
    try:
        response = TestClient(create_app(s)).post("/v1/operator/register", headers={"Authorization": "Bearer " + OPERATOR},
                                                   json={"enrol_token": token})
        assert response.status_code == 201
        assert calls == [f"/api/services/operations/{operation_id}"]
        assert json.loads((root / "registration.json").read_text())["receipt"]["status"] == "active"
        assert not (root / "registration.operation.json").exists()
    finally:
        s.close()


def test_enrolment_process_crash_after_ack_recovers_from_status(tmp_path, repo):
    root = tmp_path / "registration-post-ack-crash"
    state = {"operation_id": None, "active": False}
    def first_transport(request):
        if request.url.path.endswith("/register"):
            state["operation_id"] = json.loads(request.content)["operation_id"]
            return httpx.Response(201, json={"service_id": "svc-post-ack", "service_token": "synthetic-post-ack-token",
                "capability_secret": "synthetic-post-ack-key", "address": "http://127.0.0.1:8724",
                "receipt": {"operation_id": state["operation_id"], "request_digest": "1" * 64,
                            "service_id": "svc-post-ack", "status": "pending"}})
        if request.url.path.endswith("/ack"):
            state["active"] = True
            raise KeyboardInterrupt("synthetic process crash after host ack commits")
        raise AssertionError(request.url)
    first = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(first_transport))
    try:
        with pytest.raises(KeyboardInterrupt):
            enrol(first.authority, root, "synthetic-one-time-enrol-token", 8724)
        assert state["active"]
        assert json.loads((root / "registration.json").read_text())["receipt"]["status"] == "pending"
    finally:
        first.close()

    recovery_calls = []
    def recovery_transport(request):
        recovery_calls.append((request.method, request.url.path))
        if request.method == "GET":
            return httpx.Response(200, json={"operation_id": state["operation_id"], "request_digest": "1" * 64,
                                             "service_id": "svc-post-ack", "status": "active"})
        raise AssertionError(f"must recover before replay: {request.method} {request.url.path}")
    restarted = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid",
                        httpx.MockTransport(recovery_transport))
    try:
        result = enrol(restarted.authority, root, "synthetic-one-time-enrol-token", 8724)
        assert result["service_id"] == "svc-post-ack"
        assert recovery_calls == [("GET", f"/api/services/operations/{state['operation_id']}")]
        assert not (root / "registration.operation.json").exists()
    finally:
        restarted.close()


def test_concurrent_enrolments_cannot_create_two_service_identities(tmp_path, repo):
    root = tmp_path / "registration-race"
    guard = threading.Lock()
    calls = {"register": 0, "ack": 0}
    def transport(request):
        if request.url.path.endswith("/register"):
            body = json.loads(request.content)
            with guard:
                calls["register"] += 1
            time.sleep(0.05)
            return httpx.Response(201, json={"service_id": "svc-race", "service_token": "synthetic-race-token",
                "capability_secret": "synthetic-race-key", "address": "http://127.0.0.1:8724",
                "receipt": {"operation_id": body["operation_id"], "request_digest": "f" * 64,
                            "service_id": "svc-race", "status": "pending"}})
        if request.url.path.endswith("/ack"):
            with guard:
                calls["ack"] += 1
            body = json.loads((root / "registration.json").read_text())
            return httpx.Response(200, json={**body["receipt"], "status": "active"})
        raise AssertionError(request.url)
    s = Service(root, OPERATOR, {"synthetic": {"path": str(repo)}}, "http://hive.invalid", httpx.MockTransport(transport))
    def attempt(token):
        try:
            return enrol(s.authority, root, token, 8724)
        except CodeError as error:
            return error.code
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(attempt, ["synthetic-enrol-token-first", "synthetic-enrol-token-second"]))
        assert sum(isinstance(item, dict) for item in results) == 1
        assert sum(item == "already_registered" for item in results) == 1
        assert calls == {"register": 1, "ack": 1}
    finally:
        s.close()


def test_registration_file_lock_serializes_across_processes(tmp_path):
    ready = tmp_path / "child-holds-lock"
    code = ("import sys,time; from pathlib import Path; "
            "from omegacode.registration import _registration_lock; "
            "root=Path(sys.argv[1]); ready=Path(sys.argv[2]); "
            "ctx=_registration_lock(root); ctx.__enter__(); ready.write_text('locked'); "
            "time.sleep(0.4); ctx.__exit__(None,None,None)")
    child = subprocess.Popen([sys.executable, "-c", code, str(tmp_path), str(ready)],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        deadline = time.monotonic() + 5
        while not ready.exists() and child.poll() is None and time.monotonic() < deadline:
            time.sleep(0.01)
        assert ready.exists(), child.stderr.read() if child.poll() is not None else "child did not acquire lock"
        started = time.monotonic()
        with _registration_lock(tmp_path):
            elapsed = time.monotonic() - started
        assert elapsed >= 0.2
        assert child.wait(timeout=5) == 0
    finally:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=5)


@pytest.mark.parametrize("raw", [b"[]", b'"state"', b"null"])
def test_registration_recovery_refuses_non_object_state(tmp_path, raw):
    from omegacode.registration import _clear_expired, _enrol_locked, _remove_operation
    from types import SimpleNamespace

    operation_path = tmp_path / "registration.operation.json"
    operation_path.write_bytes(raw)
    with pytest.raises(CodeError) as removed:
        _remove_operation(operation_path, "synthetic-operation-id")
    assert removed.value.status == 503 and removed.value.code == "registration_recovery_required"

    authority = SimpleNamespace(hive_url="http://hive.invalid", client=None)
    with pytest.raises(CodeError) as enrolled:
        _enrol_locked(authority, tmp_path, "synthetic-enrol-token", 8724)
    assert enrolled.value.status == 503 and enrolled.value.code == "registration_recovery_required"

    registration_path = tmp_path / "registration.json"
    registration_path.write_bytes(raw)
    with pytest.raises(CodeError) as expired:
        _clear_expired(registration_path, operation_path, "synthetic-operation-id")
    assert expired.value.status == 503 and expired.value.code == "registration_recovery_required"


@pytest.mark.parametrize("raw", [b"[]", b'"state"', b"null"])
def test_enrolment_refuses_non_object_saved_registration(tmp_path, raw):
    from omegacode.registration import _enrol_locked
    from types import SimpleNamespace

    (tmp_path / "registration.json").write_bytes(raw)
    authority = SimpleNamespace(hive_url="http://hive.invalid", client=None)
    with pytest.raises(CodeError) as refused:
        _enrol_locked(authority, tmp_path, "synthetic-enrol-token", 8724)
    assert refused.value.status == 503 and refused.value.code == "registration_recovery_required"


@pytest.mark.parametrize("receipt", [b"[]", b'"receipt"', b"null"])
def test_enrolment_refuses_non_object_saved_receipt(tmp_path, receipt):
    from omegacode.registration import _enrol_locked, _clear_expired
    from types import SimpleNamespace

    registration_path = tmp_path / "registration.json"
    registration_path.write_bytes(b'{"receipt":' + receipt + b'}')
    authority = SimpleNamespace(hive_url="http://hive.invalid", client=None)
    with pytest.raises(CodeError) as refused:
        _enrol_locked(authority, tmp_path, "synthetic-enrol-token", 8724)
    assert refused.value.status == 503 and refused.value.code == "registration_recovery_required"
    with pytest.raises(CodeError) as expired:
        _clear_expired(registration_path, tmp_path / "registration.operation.json", "synthetic-operation-id")
    assert expired.value.status == 503 and expired.value.code == "registration_recovery_required"


@pytest.mark.parametrize("raw", [b"[]", b'"operation"', b"null"])
def test_expired_cleanup_validates_operation_before_removing_registration(tmp_path, raw):
    from omegacode.registration import _clear_expired

    operation_id = "synthetic-operation-id"
    registration_path = tmp_path / "registration.json"
    registration_path.write_bytes(canonical({"receipt": {"operation_id": operation_id}}))
    operation_path = tmp_path / "registration.operation.json"
    operation_path.write_bytes(raw)
    with pytest.raises(CodeError) as refused:
        _clear_expired(registration_path, operation_path, operation_id)
    assert refused.value.status == 503 and refused.value.code == "registration_recovery_required"
    assert registration_path.exists() and registration_path.read_bytes() == canonical({"receipt": {"operation_id": operation_id}})
    assert operation_path.read_bytes() == raw


def test_registration_thread_lock_wait_is_bounded(tmp_path, monkeypatch):
    import omegacode.registration as registration
    from omegacode.common import CodeError

    monkeypatch.setattr(registration, "_REGISTRATION_LOCK_TIMEOUT_SECONDS", 0.05)
    def contender():
        with registration._registration_lock(tmp_path):
            return "acquired"

    with registration._registration_lock(tmp_path):
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(contender)
            with pytest.raises(CodeError) as refused:
                future.result(timeout=1)
    assert refused.value.status == 503 and refused.value.code == "registration_busy"


def test_operator_registration_busy_returns_retry_after(service, monkeypatch):
    import omegacode.registration as registration

    monkeypatch.setattr(registration, "_REGISTRATION_LOCK_TIMEOUT_SECONDS", 0.05)
    entered = threading.Event()
    release = threading.Event()

    def hold_lock():
        with registration._registration_lock(service.store.root):
            entered.set()
            release.wait(timeout=2)

    with ThreadPoolExecutor(max_workers=1) as pool:
        held = pool.submit(hold_lock)
        assert entered.wait(timeout=1)
        try:
            client = TestClient(create_app(service))
            response = client.post("/v1/operator/register",
                headers={"Authorization": "Bearer " + OPERATOR},
                json={"enrol_token": "synthetic-enrol-token-123456"})
        finally:
            release.set()
            held.result(timeout=2)

    assert response.status_code == 503
    assert response.headers["retry-after"] == "35"
    assert response.json()["error"] == "registration_busy"
    assert response.json()["details"] == {"retry_after_seconds": 35}
    assert "wait at least 35 seconds" in response.json()["message"]


def test_running_agent_stops_when_live_hive_authority_ends(tmp_path, repo):
    state = {"active": True, "binding": None}
    def transport(request):
        if "/approvals/" in request.url.path:
            return httpx.Response(200, json={"agent_id": "dot-test", "skill": "code-run", "status": "approved", "binding": state["binding"]})
        if request.method == "GET":
            return httpx.Response(200, json={"swarm_id": "swarm-test", "claimed_by": "dot-test",
                                             "status": "claimed" if state["active"] else "cancelled", "lease_until": "2099-01-01T00:00:00Z"})
        return httpx.Response(200, json={"decision": "allow"})
    s = Service(tmp_path / "agent-run", OPERATOR, {"synthetic": {"path": str(repo)}},
                "http://hive.invalid", httpx.MockTransport(transport), "synthetic-service-token")
    try:
        human, _ = principal(s)
        ws = workspace(s, human)
        agent, _ = principal(s, actor="dot-test", kind="agent", member_token="synthetic-member-token")
        payload = {"operation_id": "agent-run", "workspace_id": ws["id"], "expected_generation": ws["generation"],
                   "expected_tree_digest": ws["tree_digest"], "argv": [sys.executable, "-c", "import time;time.sleep(60)"], "timeout_seconds": 20}
        state["binding"] = {"task_id": "goal-test", "swarm_id": "swarm-test", "workspace_id": ws["id"],
                            "operation_id": payload["operation_id"], "expected_generation": ws["generation"],
                            "payload_digest": "sha256:" + digest(canonical({"action": "run", **payload}))}
        r = s.start_run(agent, dict(payload, approval_id="p_run"))
        state["active"] = False
        stopped = finish(s, r["id"])
        assert stopped["status"] == "cancelled" and stopped["descendants_terminated"]
        assert not group_members(stopped["pgid"])
    finally:
        s.close()


def test_workspace_creation_from_valid_empty_git_commit(service, repo):
    git = lambda *args: subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True).stdout
    git("rm", "-f", "calculator.py", "test_calculator.py")
    git("-c", "user.name=Test", "-c", "user.email=test@example.invalid",
        "commit", "-qm", "valid empty source tree")
    empty_head = git("rev-parse", "HEAD").strip()
    assert git("ls-tree", "-r", "--name-only", "HEAD").strip() == b""

    _, grant = principal(service)
    client = TestClient(create_app(service))
    headers = {"Authorization": "Bearer " + grant["token"]}
    payload = {"operation_id": "empty-tree-workspace", "task_id": "goal-test",
               "repository_id": "synthetic", "base_commit": "HEAD"}
    created = client.post("/v1/workspaces", headers=headers, json=payload)
    assert created.status_code == 201, created.text
    replay = client.post("/v1/workspaces", headers=headers, json=payload)
    assert replay.status_code == 201 and replay.json() == created.json()
    ws = created.json()
    assert ws["base_commit"] == empty_head.decode()
    assert ws["generation"] == 1 and service.manifest(ws)["files"] == {}
    tree = client.get(f"/v1/workspaces/{ws['id']}/tree", headers=headers)
    assert tree.status_code == 200 and tree.json()["files"] == []
