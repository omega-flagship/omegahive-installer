"""Sandbox entry: explicit synthetic/project source bundle; no filesystem discovery."""
import json
from pathlib import Path
from python_index import index_sources,resolve_symbol
try:
    path=Path('request.json')
    if path.stat().st_size>4*1024*1024:raise ValueError('Navigation request exceeds limit')
    request=json.loads(path.read_text())
    sources={name:text.encode('utf-8') for name,text in request['sources'].items()}
    index=index_sources(sources)
    result={'index':index,'diagnostics':index['diagnostics'],'authority':'none'}
    if request.get('symbol') is not None:result['location']=resolve_symbol(request['index'] if 'index' in request else index,sources,request['file'],request['symbol'])
    Path('navigation.json').write_text(json.dumps(result,sort_keys=True)+'\n')
    print(json.dumps({'ok':True}))
except Exception as error:
    print(json.dumps({'ok':False,'reason':str(error)}));raise SystemExit(1)
