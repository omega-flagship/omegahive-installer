"""Read-only service-internal purpose preparation from retained owner records.

No caller plan/body, generic grant conversion, fork, bind, source acceptance or
execution. Existing pure proposal preparation owns reconstruction/digest format.
"""
import json
from omegacode.auth import Principal
from omegacode.common import canonical, digest, CodeError
from omegacode.proposal_test_preparation import prepare

def refuse():
    raise CodeError(409, 'proposal_preparation_binding', 'retained proposal preparation refused')

def inspect(service, purpose_authority, principal):
    service._check_owner(required=True)
    original = canonical(principal.grant)
    p = principal.grant.get('proposal_test', {})
    if p.get('stage') == 'prepare':
        route = '/v1/proposal-tests'
    elif p.get('stage') == 'run':
        route = '/v1/proposal-tests/' + p['test_id'] + '/launches'
    else:
        refuse()
    purpose_authority.require_route(principal, 'POST', route)
    g = principal.grant
    p = g['proposal_test']
    pid = p['proposal']['proposal_id']
    wsid = p['parent']['workspace_id']
    with service.store.lock:
        service._check_owner(required=True)
        parent = service.workspace(wsid)
        if any((parent[k] != g[k] for k in ('task_id', 'swarm_id', 'repository_id'))) or parent['generation'] != p['parent']['generation'] or 'sha256:' + parent['tree_digest'] != p['parent']['tree_digest']:
            refuse()

        def read(kind, id_):
            record = service.store.get(kind, id_)
            if record.get('workspace_id') != wsid:
                refuse()
            raw = service.store.read_blob(record['digest'], wsid)
            if digest(raw) != record['digest']:
                refuse()
            body = json.loads(raw)
            if canonical(body) != raw:
                refuse()
            return (record, body)
        (record, body) = read('suggestion', pid)
        (scope, ceiling) = read('suggestion_scope', p['origin_scope']['scope_id'])
        (provenance, attached) = read('suggestion_provenance', pid)
        expected_scope = p['origin_scope']
        expected_delegated = {k: p[k] for k in ('request_id', 'controller_id', 'execution_goal', 'issuer', 'origin_scope')}
        if record['id'] != pid or 'sha256:' + record['digest'] != p['proposal']['proposal_digest'] or body['digest'] != p['proposal']['normalized_hunks_digest'].removeprefix('sha256:') or (record['scope_id'] != scope['id']) or (body['scope_id'] != scope['id']) or (record['author'] != body['author']) or (scope['author'] != p['issuer']) or (ceiling['author'] != p['issuer']) or ('sha256:' + scope['digest'] != expected_scope['scope_digest']) or (ceiling['generation'] != expected_scope['generation']) or any((ceiling[k] != parent[k] for k in ('task_id', 'generation', 'tree_digest'))) or (ceiling['workspace_id'] != wsid) or (body['scope'] != ceiling['ranges']):
            refuse()
        expected_provenance = {'schema': 'omegacode-request-proposal-v1', 'workspace_id': wsid, 'proposal_id': pid, 'proposal_digest': record['digest'], 'author': record['author'], 'origin_task_id': parent['task_id'], 'origin_swarm_id': parent['swarm_id'], 'repository_id': parent['repository_id'], 'delegated': expected_delegated}
        if attached != expected_provenance:
            refuse()
        issuer = Principal(scope['author'], scope['issuer_claims'])
        service._live(issuer)
        service._authorize(issuer, 'read', parent, {'paths': list(ceiling['ranges'])})
        service._context_current(parent, ceiling['context_selection'])
        manifest = service.manifest(parent)
        if any((manifest['files'].get(path, {}).get('digest') != h for (path, h) in ceiling['file_digests'].items())):
            refuse()
        files = {path: service.store.read_blob(meta['digest'], wsid) for (path, meta) in manifest['files'].items()}
        projection = {'record': record, 'content': body, 'currency': 'current'}
        try:
            plan = prepare(projection, parent, manifest, files, proposal_id=pid, proposal_digest=record['digest'])
        except (ValueError, TypeError, KeyError):
            refuse()
        purpose_authority.require_route(principal, 'POST', route)
        service._check_owner(required=True)
        if original != canonical(principal.grant) or service.workspace(wsid) != parent:
            refuse()
        for (kind, saved) in [('suggestion', record), ('suggestion_scope', scope), ('suggestion_provenance', provenance)]:
            if service.store.get(kind, saved['id']) != saved:
                refuse()
        service._context_current(parent, ceiling['context_selection'])
        service._live(issuer)
        service._authorize(issuer, 'read', parent, {'paths': list(ceiling['ranges'])})
        if original != canonical(principal.grant) or service.workspace(wsid) != parent:
            refuse()
        for (kind, saved) in [('suggestion', record), ('suggestion_scope', scope), ('suggestion_provenance', provenance)]:
            if service.store.get(kind, saved['id']) != saved:
                refuse()
        service._context_current(parent, ceiling['context_selection'])
        service._check_owner(required=True)
        return plan
