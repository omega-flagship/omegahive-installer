"""Frozen JSONL Hyperon session worker. Trusted native execution, never a sandbox."""
import hashlib
import base64
import json
import pathlib
import sys
import termios
import tty
from collections import Counter

MAX_ATOMS = 4096
MAX_SNAPSHOT_BYTES = 262144
MAX_SESSION_SNAPSHOT_BYTES = 1048576


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def atom_strings(metta):
    if metta.space().atom_count() > MAX_ATOMS:
        raise ValueError('atom inspection exceeds 4096 atoms')
    atoms = [str(atom) for atom in metta.space().get_atoms()]
    if len(json.dumps(atoms, ensure_ascii=False).encode()) > MAX_SNAPSHOT_BYTES:
        raise ValueError('atom inspection exceeds 262144 bytes')
    return atoms


def page(request):
    after, limit = request.get('after', 0), request.get('limit', 50)
    if type(after) is not int or after < 0 or type(limit) is not int or not 1 <= limit <= 100:
        raise ValueError('paging needs nonnegative after and limit 1 to 100')
    return after, limit


def slice_page(items, after, limit):
    return {'items': items[after:after+limit], 'after': after,
            'next': min(after+limit, len(items)), 'eof': after+limit >= len(items), 'total': len(items)}


def snapshot_command(metta, request, state):
    snapshots = state['snapshots']
    op = request['op']
    if op == 'snapshot':
        label = request.get('label', '')
        if type(label) is not str or len(label) > 160:
            raise ValueError('snapshot label needs at most 160 characters')
        atoms = sorted(atom_strings(metta))
        # Multiset identity preserves duplicate atoms but does not claim a lossless
        # serialisation of grounded payloads or interpreter reductions.
        identity = {'context': state['context'], 'representation': 'rendered-atom-multiset-v1', 'atoms': atoms}
        id_ = 'atoms_' + sha(identity)
        size = len(json.dumps(identity, ensure_ascii=False).encode())
        if id_ not in snapshots:
            if len(snapshots) >= 32 or state['snapshot_bytes'] + size > MAX_SESSION_SNAPSHOT_BYTES:
                raise ValueError('session snapshot budget exhausted (32 snapshots / 1048576 bytes)')
            snapshots[id_] = {'id': id_, 'label': label, 'atom_count': len(atoms), 'atoms': atoms,
                              'context': state['context'], 'representation': identity['representation'],
                              'created_by_input': request['id'], 'input_sequence': state['sequence'],
                              'rendered_atoms_digest': sha(atoms), 'content_bytes': len(encoded(atoms)), 'bytes': size}
            state['snapshot_bytes'] += size
        return {k: v for k, v in snapshots[id_].items() if k != 'atoms'}
    if op == 'snapshot-bytes':
        id_ = request.get('snapshot_id')
        if type(id_) is not str or id_ not in snapshots:
            raise ValueError('snapshot is not held by this resident session')
        after, limit = request.get('after', 0), request.get('limit', 1024)
        if type(after) is not int or after < 0 or type(limit) is not int or not 1 <= limit <= 8192:
            raise ValueError('byte paging needs nonnegative after and limit 1 to 8192')
        snapshot = snapshots[id_]
        data = encoded(snapshot['atoms'])
        return {'snapshot_id': id_, 'rendered_atoms_digest': snapshot['rendered_atoms_digest'],
                'encoding': 'base64', 'content_type': 'application/json; charset=utf-8',
                'data': base64.b64encode(data[after:after+limit]).decode(), 'after': after,
                'next': min(after+limit, len(data)), 'eof': after+limit >= len(data), 'total_bytes': len(data)}
    after, limit = page(request)
    if op == 'snapshots':
        return slice_page([{k: v for k, v in item.items() if k != 'atoms'} for item in snapshots.values()], after, limit)
    if op == 'snapshot-atoms':
        id_ = request.get('snapshot_id')
        if type(id_) is not str or id_ not in snapshots:
            raise ValueError('snapshot is not held by this resident session')
        snapshot = snapshots[id_]
        return {'snapshot_id': id_, 'rendered_atoms_digest': snapshot['rendered_atoms_digest'],
                **slice_page(snapshot['atoms'], after, limit)}
    base, incoming = request.get('base'), request.get('incoming')
    if type(base) is not str or type(incoming) is not str or base not in snapshots or incoming not in snapshots:
        raise ValueError('diff needs two snapshots held by this resident session')
    before, later = Counter(snapshots[base]['atoms']), Counter(snapshots[incoming]['atoms'])
    changes = [{'kind': kind, 'atom': atom, 'count': count} for kind, delta in
               (('removed', before-later), ('added', later-before)) for atom, count in sorted(delta.items())]
    return {'diff_id': 'adiff_' + sha({'base': base, 'incoming': incoming, 'changes': changes}),
            'base': base, 'incoming': incoming, 'context': state['context'],
            'representation': 'rendered-atom-multiset-v1', **slice_page(changes, after, limit)}


def runtime_identity(config):
    root = pathlib.Path(config['root']).resolve()
    executable = pathlib.Path(config['executable']).absolute()
    files = sorted(p for site in (root / 'lib').glob('python*/site-packages')
                   for package in site.glob('hyperon*') for p in ([package] if package.is_file() else package.rglob('*'))
                   if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py', '.so'))
    if not files or len(files) > 500 or sum(p.stat().st_size for p in files) > 100 * 1024 * 1024:
        raise ValueError('configured Hyperon package is missing or exceeds fingerprint limits')
    if any(p.is_symlink() or not p.resolve().is_relative_to(root) for p in files):
        raise ValueError('symbolic runtime package symlinks are unsupported')
    return {'executable': str(executable), 'executable_digest': hashlib.sha256(executable.read_bytes()).hexdigest(),
            'root': str(root), 'files': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}


def emit(value):
    data = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
    if len(data) > 65536:
        data = encoded({'event': 'error', 'id': value.get('id'), 'reason': 'response exceeds 65536 bytes',
                        'state_may_have_changed': True, 'input_sequence': value.get('input_sequence')})
    sys.stdout.buffer.write(data + b'\n')
    sys.stdout.buffer.flush()


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate JSON fields are forbidden')
        value[key] = item
    return value


def step_command(metta, request, state):
    """Observe actual Hyperon RunnerState calls, without invented reduction internals."""
    op = request['op']
    trace = state.get('step_trace')
    if op == 'step-start':
        if trace is not None:
            raise ValueError('clear the retained step trace before starting another')
        from hyperon.runner import RunnerState
        source = request['source']
        budget = request.get('max_steps', 10000)
        if type(budget) is not int or not 1 <= budget <= 10000:
            raise ValueError('step budget needs 1..10000')
        atom_strings(metta)
        source_digest = hashlib.sha256(source.encode()).hexdigest()
        trace = {'id': 'step_' + sha([state['context'],source_digest,state['sequence']]),
                 'source_digest': source_digest, 'steps': 0, 'budget': budget,
                 'runner': RunnerState(metta,source), 'status': 'paused', 'results': [],
                 'observations': []}
        state['step_trace'] = trace
    else:
        if trace is None or request.get('trace_id') != trace['id']:
            raise ValueError('step trace is not held by this resident session')
    if op == 'step-clear':
        state['step_trace'] = None
        return {'trace_id': trace['id'], 'cleared': True, 'effects_reversed': False}
    if op == 'step-next':
        count = request.get('count', 1)
        if type(count) is not int or not 1 <= count <= 1000:
            raise ValueError('step count needs 1..1000')
        if trace['status'] in ('faulted','budget-exhausted'):
            raise ValueError('step trace cannot advance after fault or budget exhaustion')
        if trace['steps'] + count > trace['budget']:
            raise ValueError('requested advance exceeds retained step budget')
        try:
            for _ in range(count):
                if trace['runner'].is_complete():
                    break
                trace['runner'].run_step()
                trace['steps'] += 1
            results = [[str(atom) for atom in group] for group in trace['runner'].current_results()]
            if len(encoded(results)) > MAX_SNAPSHOT_BYTES:
                raise ValueError('step result exceeds bounded inspection size')
            trace['results'] = results
            trace['status'] = ('complete' if trace['runner'].is_complete() else
                               'budget-exhausted' if trace['steps'] == trace['budget'] else 'paused')
            atoms = sorted(atom_strings(metta))
            observation = {'input_sequence':state['sequence'],'step_count':trace['steps'],
                           'status':trace['status'],'results_digest':sha(results),
                           'rendered_atoms_digest':sha(atoms)}
            # Retain a bounded recent event window, not an unbounded execution log.
            trace['observations'] = (trace['observations'] + [observation])[-100:]
        except Exception:
            trace['status'] = 'faulted'
            raise
    return {'trace_id':trace['id'],'source_digest':trace['source_digest'],
            'context':state['context'],'step_count':trace['steps'],'max_steps':trace['budget'],
            'status':trace['status'],'results':trace['results'],'observations':trace['observations'],
            'results_currency':'last successful step batch' if trace['observations'] else 'not yet observed',
            'last_observed_step':trace['observations'][-1]['step_count'] if trace['observations'] else 0,
            'engine_api':'hyperon.runner.RunnerState.run_step',
            'substitutions_available':False,'grounded_call_trace_available':False,
            'persistence':'resident process only; no automatic replay',
            'effects_reversed':False}


def command(metta, request, state):
    if type(request) is not dict or type(request.get('id')) is not str or not 1 <= len(request['id']) <= 160:
        raise ValueError('request needs a string id of 1 to 160 characters')
    op = request.get('op')
    allowed = {'eval': {'source'}, 'add': {'source'}, 'remove': {'source'}, 'query': {'source'},
               'atoms': {'after', 'limit'}, 'close': set(), 'snapshot': {'label'},
               'snapshots': {'after', 'limit'}, 'snapshot-atoms': {'snapshot_id', 'after', 'limit'},
               'snapshot-bytes': {'snapshot_id', 'after', 'limit'},
               'diff': {'base', 'incoming', 'after', 'limit'},
               'step-start': {'source','max_steps'}, 'step-next': {'trace_id','count'},
               'step-status': {'trace_id'}, 'step-clear': {'trace_id'}}
    if op not in allowed or set(request) - ({'id', 'op'} | allowed[op]):
        raise ValueError('unknown operation or fields')
    if op in ('eval', 'add', 'remove', 'query', 'step-start'):
        source = request.get('source')
        if type(source) is not str or not source or len(source.encode()) > 7000:
            raise ValueError('source needs 1 to 7000 UTF-8 bytes')
    trace = state.get('step_trace')
    if trace is not None and op in ('eval','add','remove','query'):
        raise ValueError('clear the step trace before issuing other execution or mutation')
    if op.startswith('step-'):
        result = step_command(metta,request,state)
    elif op == 'eval':
        result = [[str(atom) for atom in group] for group in metta.run(source)]
    elif op in ('add', 'remove', 'query'):
        atoms = metta.parse_all(source)
        if len(atoms) != 1:
            raise ValueError('operation needs exactly one atom')
        atom = atoms[0]
        if op == 'add':
            metta.space().add_atom(atom)
            result = True
        elif op == 'remove':
            result = metta.space().remove_atom(atom)
        else:
            result = str(metta.space().query(atom))
    elif op == 'atoms':
        after, limit = page(request)
        atoms = atom_strings(metta)
        result = {'atoms': atoms[after:after+limit], 'after': after,
                  'next': min(after+limit, len(atoms)), 'eof': after+limit >= len(atoms)}
    elif op in ('snapshot', 'snapshots', 'snapshot-atoms', 'snapshot-bytes', 'diff'):
        result = snapshot_command(metta, request, state)
    else:
        result = 'closed'
    return {'event': 'result', 'id': request['id'], 'op': op, 'result': result,
            'atom_count': metta.space().atom_count(), 'input_sequence': state['sequence']}, op == 'close'


def main():
    expected = json.loads(pathlib.Path(sys.argv[1]).read_text())
    if runtime_identity(expected) != expected:
        raise ValueError('symbolic runtime changed after approval')
    from hyperon import MeTTa
    metta = MeTTa()
    spec = json.loads(pathlib.Path(sys.argv[1]).with_name('spec.json').read_text())
    context = {'run_id': spec['run_id'], 'generation': spec['generation'], 'tree_digest': spec['tree_digest'],
               'runtime_identity_digest': sha(expected), 'runtime': 'hyperon'}
    state = {'snapshots': {}, 'snapshot_bytes': 0, 'context': context, 'sequence': 0}
    original = termios.tcgetattr(0)
    tty.setraw(0)
    try:
        emit({'event': 'ready', 'protocol': 'omegacode-symbolic-jsonl-v1', 'runtime': 'hyperon',
              'persistence': 'resident process only; no automatic replay', 'atom_count': 0,
              'context': context, 'snapshot_representation': 'rendered-atom-multiset-v1',
              'step_protocol':'omegacode-hyperon-runner-step-v1',
              'step_commands':['step-start','step-next','step-status','step-clear']})
        while True:
            line = sys.stdin.buffer.readline(8193)
            if not line:
                break
            if len(line) > 8192 or not line.endswith(b'\n'):
                emit({'event': 'error', 'reason': 'input frame exceeds 8192 bytes or lacks newline'})
                break
            request = None
            try:
                request = json.loads(line, object_pairs_hook=unique_object)
                state['sequence'] += 1
                response, closed = command(metta, request, state)
                emit(response)
                if closed:
                    break
            except Exception as error:
                id_ = request.get('id') if type(request) is dict else None
                emit({'event': 'error', 'id': id_ if type(id_) is str and len(id_) <= 160 else None,
                      'reason': str(error)[:2000], 'input_sequence': state['sequence'],
                      'state_may_have_changed': True})
    finally:
        termios.tcsetattr(0, termios.TCSANOW, original)


if __name__ == '__main__':
    main()
