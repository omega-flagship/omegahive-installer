import {clone} from './scene.mjs';
import {createProject} from './project.mjs';
export async function briefFromFields(prior,{purpose,audience,criteria}){
 if([purpose,audience,criteria].some(v=>typeof v!=='string'))throw Error('Purpose, audience and criteria are required');
 const lines=criteria.trim().split(/\r?\n/).map(s=>s.trim());
 if(lines.some(s=>!s))throw Error('Each criterion needs its own nonempty line');
 if(new Set(lines).size!==lines.length)throw Error('Each criterion must be distinct');
 const brief={...clone(prior),purpose:purpose.trim(),audience:audience.trim(),criteria:lines};
 await createProject(brief);return brief;
}
